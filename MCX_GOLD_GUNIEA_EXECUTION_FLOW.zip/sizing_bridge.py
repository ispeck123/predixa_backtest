"""
PREDIXA — sizing bridge.

Single entry point that turns a formatted setup + its regime/TF context into an order quantity,
applying the OOS-validated regime x TF sizing weights. Wraps PositionSizer so the scanner needs
ONE line at the order-insert site.

Live-path usage (cash_wetrun_scanner.py, replacing the hardcoded qty at the insert call):
    from scripts.sizing_bridge import size_for_order
    qty = size_for_order(formatted, t_data, str(job.time_frame), "NSE_CASH")
    if qty is None:
        # regime x TF weight = 0 (net-negative / unmapped cell) -> do NOT place this order
        continue
    insert_order_and_oms_bucket(t_data, order_type, job.time_frame, formatted['STOCK_NAME'],
                                job.last_d_time, "india", 1, "NA", 0.0, formatted['trade_id'], qty)

WET-RUN OVERRIDE: while WETRUN_FIXED_QTY is True, permitted setups return qty=1 (keeps the 1-share
wet run intact) but EXCLUDED cells still return None (so we stop trading known net-negative cells
immediately — free benefit). Flip WETRUN_FIXED_QTY=False at real-capital go-live for full sizing.
"""
import math
from typing import Optional, Dict, Any
from scripts.position_sizing import (
    SLIPPAGE, PositionSizer, Position, Setup, PortfolioPolicy, SegmentPolicy, SEGMENTS
)
from shared.utils.logger import logger
from scripts.tf_regime_gate_by_exchange import gate

# ── wet-run switch ────────────────────────────────────────────────────────────
WETRUN_FIXED_QTY = True     # True: permitted cells -> qty 1 (wet run); exclusions still apply.
                            # False (go-live): full regime x TF sizing.

# ── portfolio / segment policy (load from config at go-live; defaults are wet-run-safe) ──
_PORTFOLIO = PortfolioPolicy(total_equity=1_000_000, max_open_risk_pct=5.0,
                             max_concurrent=10, per_sector_cap=3, reserve_pct=20.0)
# _SEGMENTS = {
#     "NSE_CASH": SegmentPolicy(enabled=True, risk_pct=1.0, max_concurrent=5,
#                               exposure_cap=1_000_000, notional_cap=1_000_000, margin_pct=1.0),
#     "NSEFO":    SegmentPolicy(enabled=True, risk_pct=1.0, max_concurrent=5,
#                               exposure_cap=2_000_000, notional_cap=2_000_000, margin_pct=0.15),
#     "MCX":    SegmentPolicy(enabled=True, risk_pct=1.0, max_concurrent=2,
#                             exposure_cap=400_000, notional_cap=1_000_000, margin_pct=0.16, min_net_R=0.10),
# }
_SEGMENTS = SEGMENTS
_SIZER = PositionSizer(_PORTFOLIO, SEGMENTS)


def size_for_mcx_proving(symbol: str, e_regime: str, a_regime: str,
                         strategy_tf: int, lot_size: int) -> Optional[int]:
    """Return exactly one contract lot for an eligible MCX proving setup.

    The provisional weight is an allow/deny signal only.  Keeping this helper
    separate from ``size_for_order`` prevents an accidental fractional or
    scaled MCX quantity before the tracking-error gate authorises scaling.
    """
    if gate("MCX", strategy_tf, e_regime, a_regime, symbol)[1] <= 0:
        logger.info("MCX_SIZING_EXCLUDED e=%s,a=%s,tf=%s,sym=%s",
                    e_regime, a_regime, strategy_tf, symbol)
        return None
    try:
        quantity = int(lot_size)
    except (TypeError, ValueError):
        return None
    return quantity if quantity > 0 else None


def translate_mcx_levels(*, source_entry: float, source_stop: float,
                         source_target: float, source_ltp: float,
                         execution_ltp: float) -> dict[str, float]:
    """Scale GOLDM-derived levels onto the live execution contract quote.

    GOLDM remains the liquid detection and gate series.  A proportional scale
    preserves the setup's stop percentage and reward/risk while ensuring that
    no GOLDM price can be sent with a GOLDGUINEA broker symbol.
    """
    values = (source_entry, source_stop, source_target, source_ltp, execution_ltp)
    try:
        entry, stop, target, source_quote, execution_quote = map(float, values)
    except (TypeError, ValueError):
        raise ValueError("MCX_QUOTE_TRANSLATION_INVALID_INPUT") from None
    if (not all(math.isfinite(value) and value > 0
                for value in (entry, stop, target, source_quote, execution_quote))
            or not stop < entry < target):
        raise ValueError("MCX_QUOTE_TRANSLATION_INVALID_INPUT")
    scale = execution_quote / source_quote
    translated = {
        "entry": entry * scale,
        "stoploss": stop * scale,
        "target": target * scale,
        "scale": scale,
    }
    if not translated["stoploss"] < translated["entry"] < translated["target"]:
        raise ValueError("MCX_QUOTE_TRANSLATION_INVALID_OUTPUT")
    return translated


def evaluate_mcx_execution_lot(*, source_symbol: str, e_regime: str,
                               a_regime: str, strategy_tf: int,
                               translated_entry: float, translated_stoploss: float,
                               translated_target: float, execution_lot_size: int) -> Optional[Position]:
    """Size/check a translated MCX execution lot using the GOLDM gate.

    The gate is intentionally evaluated with ``source_symbol`` (GOLDM), while
    risk, notional and modelled margin use the translated GOLDGUINEA prices and
    its 8-unit lot.  This ordering prevents GOLDM risk from rejecting a valid
    smaller execution contract.
    """
    try:
        lot_size = int(execution_lot_size)
        setup = Setup(
            symbol=str(source_symbol).strip().upper(), segment="MCX",
            entry=float(translated_entry), stop=float(translated_stoploss),
            target=float(translated_target), zone_score=0.0, rr=0.0,
            sector="MCX", lot_size=lot_size,
            e_regime=str(e_regime).strip().upper(),
            a_regime=str(a_regime).strip().upper(), time_frame=str(int(strategy_tf)),
        )
    except (TypeError, ValueError):
        return None
    if lot_size <= 0:
        return None
    _, gate_weight, _ = gate("MCX", int(strategy_tf), setup.e_regime,
                              setup.a_regime, setup.symbol)
    if gate_weight <= 0.0:
        return None
    policy = SEGMENTS["MCX"]
    qty = lot_size  # tier-0 MCX proving always submits exactly one real lot.
    risk = qty * abs(setup.entry - setup.stop) * (1 + SLIPPAGE)
    notional = qty * setup.entry
    if notional > policy.notional_cap:
        return None
    return Position(setup=setup, qty=qty, risk_rupees=risk, notional=notional,
                    margin=notional * policy.margin_pct)


def _normalize_tf(tf) -> str:
    """Normalize time_frame to a clean integer-string ('25'), robust to int / float / padded str.
    Guards against a VALID cell being wrongly excluded because tf arrived as 25.0 or ' 25 '."""
    try:
        return str(int(float(str(tf).strip())))   # 25 / '25' / 25.0 / '25.0' / ' 25 ' -> '25'
    except (ValueError, TypeError):
        return str(tf).strip()                     # non-numeric: use as-is (will miss -> suppress)


def _regime_key(formatted: Dict[str, Any], time_frame):
    """Extract (e_regime, a_regime, time_frame) from the formatted setup. Empty -> ('','',tf)."""
    e = str(formatted.get("e_regime", "") or "").strip().upper()
    a = str(formatted.get("a_regime", "") or "").strip().upper()
    return (e, a, _normalize_tf(time_frame))


def size_for_order(formatted: Dict[str, Any], t_data: Dict[str, Any],
                   time_frame: str, segment: str, lot_size: int = 1) -> Optional[int]:
    """
    Return order quantity, or None if the setup must be SUPPRESSED.

    None is returned when:
      - the exchange-aware gate denies the cell or symbol, OR
      - required price fields are missing / degenerate, OR
      - computed qty rounds to 0.
    A non-None return is a valid quantity to place.
    """
    e, a, tf = _regime_key(formatted, time_frame)

    try:
        strategy_tf = int(tf)
    except (TypeError, ValueError):
        return None
    _, gate_weight, gate_reason = gate(
        segment, strategy_tf, e, a, formatted.get("STOCK_NAME"))
    if gate_weight <= 0.0:
        logger.info("return None because gate denied: %s", gate_reason)
        return None

    # Map the REAL t_data keys (verified: entry_price / stop_loss / target_price).
    try:
        entry  = float(t_data["entry_price"])
        stop   = float(t_data["stop_loss"])
        target = float(t_data["target_price"])
    except (KeyError, TypeError, ValueError):
        logger.error("return None because of keyerror")
        return None   # can't size without valid levels

    setup_obj = Setup(
        symbol=str(formatted.get("STOCK_NAME", "")),
        segment=segment,
        entry=entry, stop=stop, target=target,
        zone_score=float(formatted.get("BUY_SCORE", t_data.get("overlap_ratio", 0.0)) or 0.0),
        rr=float(formatted.get("BUY_RRR", t_data.get("rr_ratio", 0.0)) or 0.0),
        sector=str(formatted.get("SECTOR", "") or ""),
        lot_size=max(1, lot_size),
        e_regime=e, a_regime=a, time_frame=tf,
    )

    pos = _SIZER.size(setup_obj)
    if pos is None:
        logger.error("return None because pos is None")
        return None   # sizer suppressed (weight 0, or qty floored to 0)

    if WETRUN_FIXED_QTY:
        # A permitted wet-run setup always emits its minimum tradeable unit.
        # Fractional gate weights are recorded as tier metadata, not rounded
        # into a zero-share/zero-lot order.
        quantity = lot_size if lot_size > 1 else 1
    else:
        quantity = pos.qty
    return quantity if quantity > 0 else None
