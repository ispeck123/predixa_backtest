import asyncio

from fastapi import HTTPException, Request
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from apps.backend.api import bucket_orders_commodity as commodity_api
from apps.backend.api.bucket_orders_commodity import approve_existing_commodity_candidate
from shared.db.db_model import OMSOrderBucketCommodity, TradeSignal
from shared.db.req_model import ApproveReject_BucketOrderBase


class FakeFyers:
    def __init__(self):
        self.submitted_payloads = []
        self.cancelled_payloads = []

    def place_cash_gtt(self, payload, *, execution_mode=None):
        assert execution_mode == "REAL"
        self.submitted_payloads.append(payload)
        return {"s": "ok", "id": "gtt-123", "id_fyers": "fyers-456"}

    def cancel_gtt_order(self, payload):
        self.cancelled_payloads.append(payload)
        return {"s": "ok"}


def _session():
    engine = create_engine("sqlite:///:memory:")
    OMSOrderBucketCommodity.__table__.create(engine)
    TradeSignal.__table__.create(engine)
    return sessionmaker(bind=engine)()


def _candidate():
    return OMSOrderBucketCommodity(
        bucket_id=12,
        stock_tick="CRUDEOILM",
        expiry_date="30102026",
        order_type="BUY",
        entry_price=100.0,
        stoploss_price=95.0,
        target_price=115.0,
        stock_quantity=10,
        order_status="pending",
        approval_status="pending",
        is_trade_started=0,
        execution_mode="REAL",
        candidate_source="GRADUATED_LIVE",
    )


def test_commodity_approval_submits_mcx_gtt_and_persists_broker_ids():
    session = _session()
    session.add(_candidate())
    session.commit()
    broker = FakeFyers()

    result = approve_existing_commodity_candidate(
        bucket_id=12,
        status="approved",
        approved_by="7",
        session_factory=lambda: session,
        fyers_factory=lambda: broker,
    )

    row = session.get(OMSOrderBucketCommodity, 12)
    payload = broker.submitted_payloads[0]
    assert result["decision"] == "SUBMITTED"
    assert payload["symbol"] == "MCX:CRUDEOILM26OCTFUT"
    assert payload["productType"] == "MARGIN"
    assert payload["orderTag"] == "12"
    assert row.approval_status == "approved"
    assert row.gtt_id == "gtt-123"
    assert row.id_fyers == "fyers-456"


def test_commodity_rejection_cancels_persisted_gtt_and_clears_live_link():
    session = _session()
    candidate = _candidate()
    candidate.approval_status = "approved"
    candidate.gtt_id = "gtt-123"
    candidate.id_fyers = "fyers-456"
    session.add(candidate)
    session.commit()
    broker = FakeFyers()

    result = approve_existing_commodity_candidate(
        bucket_id=12,
        status="rejected",
        approved_by="7",
        session_factory=lambda: session,
        fyers_factory=lambda: broker,
    )

    row = session.get(OMSOrderBucketCommodity, 12)
    assert result["decision"] == "REJECTED_BY_USER"
    assert broker.cancelled_payloads == [{"id": "gtt-123"}]
    assert row.approval_status == "rejected"
    assert row.order_status == "cancelled"
    assert row.gtt_id is None
    assert row.id_fyers is None


def test_goldm_candidate_submits_only_translated_goldguinea_prices():
    session = _session()
    signal = TradeSignal(
        exchange_id=10, stock_name="GOLDM", time_fr=4, country_id=1,
        trade_type="BUY", trade_data={"e_regime": "SW", "a_regime": "SW"},
        is_active=True,
    )
    session.add(signal)
    session.flush()
    candidate = OMSOrderBucketCommodity(
        bucket_id=13, trade_signal_id=signal.id, stock_tick="GOLDGUINEA",
        expiry_date="30102026", order_type="BUY",
        entry_price=100000.0, stoploss_price=98500.0, target_price=103000.0,
        stock_quantity=8, order_status="pending_quote_translation",
        approval_status="pending", is_trade_started=0, execution_mode="REAL",
        candidate_source="GRADUATED_LIVE",
    )
    session.add(candidate)
    session.commit()
    broker = FakeFyers()

    quotes = {
        "MCX:GOLDM26OCTFUT": {"ltp": 100000.0, "volume": 1000.0},
        "MCX:GOLDGUINEA26OCTFUT": {"ltp": 14375.0, "volume": 200.0},
    }
    result = approve_existing_commodity_candidate(
        bucket_id=13, status="approved", approved_by="7",
        session_factory=lambda: session, fyers_factory=lambda: broker,
        quote_provider=lambda contract: quotes[contract],
        liquidity_provider=lambda *_: 100.0,
    )

    row = session.get(OMSOrderBucketCommodity, 13)
    payload = broker.submitted_payloads[0]
    assert payload["symbol"] == "MCX:GOLDGUINEA26OCTFUT"
    assert payload["orderInfo"]["leg1"]["qty"] == 8
    assert result["translation"]["risk_rupees"] < 18_000
    assert result["translation"]["live_volume"] == 200.0
    assert result["translation"]["required_volume"] == 200.0
    assert row.entry_price == pytest.approx(14375.0)
    assert row.stoploss_price < row.entry_price < row.target_price


def test_goldguinea_real_lot_fails_closed_below_two_times_seven_day_liquidity():
    session = _session()
    signal = TradeSignal(
        exchange_id=10, stock_name="GOLDM", time_fr=4, country_id=1,
        trade_type="BUY", trade_data={"e_regime": "SW", "a_regime": "SW"},
        is_active=True,
    )
    session.add(signal)
    session.flush()
    session.add(OMSOrderBucketCommodity(
        bucket_id=14, trade_signal_id=signal.id, stock_tick="GOLDGUINEA",
        expiry_date="30102026", order_type="BUY",
        entry_price=100000.0, stoploss_price=98500.0, target_price=103000.0,
        stock_quantity=8, order_status="pending_quote_translation",
        approval_status="pending", is_trade_started=0, execution_mode="REAL",
        candidate_source="GRADUATED_LIVE",
    ))
    session.commit()
    quotes = {
        "MCX:GOLDM26OCTFUT": {"ltp": 100000.0, "volume": 1000.0},
        "MCX:GOLDGUINEA26OCTFUT": {"ltp": 14375.0, "volume": 199.0},
    }

    with pytest.raises(HTTPException, match="MCX_EXECUTION_LIQUIDITY_FAILURE"):
        approve_existing_commodity_candidate(
            bucket_id=14, status="approved", approved_by="7",
            session_factory=lambda: session, fyers_factory=FakeFyers,
            quote_provider=lambda contract: quotes[contract],
            liquidity_provider=lambda *_: 100.0,
        )


def test_commodity_endpoint_reports_confirmed_cancellation_to_ui(monkeypatch):
    monkeypatch.setattr(
        commodity_api,
        "approve_existing_commodity_candidate",
        lambda **_: {"decision": "REJECTED_BY_USER", "bucket_id": 12,
                     "cancelled_gtt_id": "gtt-123"},
    )
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})

    response = asyncio.run(commodity_api.approve_reject_bucket_orders_commodity(
        ApproveReject_BucketOrderBase(bucket_id=12, approved_by="7", status="rejected"),
        request,
    ))

    assert response.msg == "Order successfully canceled"
