-- Register GOLDGUINEA as an active MCX source contract.
-- The statement is idempotent: it preserves any existing operator-maintained
-- record and adds the product only when it is absent.
INSERT INTO commodities_master (
    symbol,
    full_name,
    exchange,
    unit,
    category,
    contract_type,
    is_active
)
SELECT
    'GOLDGUINEA',
    'MCX Gold Guinea Futures',
    'MCX',
    '8 grams',
    'Precious Metals',
    'Micro',
    TRUE
WHERE NOT EXISTS (
    SELECT 1
    FROM commodities_master
    WHERE symbol = 'GOLDGUINEA'
);
