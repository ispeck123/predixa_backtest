# MCX GOLDM → GOLDGUINEA execution flow

## Purpose

Gold setups continue to be detected, zoned and permission-gated on the liquid
`GOLDM` series.  The broker-facing contract is now `GOLDGUINEA`, one lot of
which is **8 grams**.  `GOLDGUINEA` is never a signal/zones source.

## Implemented behaviour

1. The MCX gate universe is unchanged: `("GOLDM", "CRUDEOILM")`.
   `GOLDGUINEA` is denied by the gate when presented as a source symbol.
2. A permitted GOLDM real candidate persists `GOLDGUINEA` as its execution
   symbol, quantity `8`, and `pending_quote_translation` status.  Its stored
   levels remain GOLDM-derived until an approver acts.
3. At approval, the commodity endpoint obtains live quotes for the GOLDM
   source contract and the matching GOLDGUINEA execution contract.  It scales
   entry, stop-loss and target by `GOLDGUINEA_LTP / GOLDM_LTP`.
4. The translated GOLDGUINEA levels and eight-unit lot are then used for the
   single-trade risk-cap, notional-cap and MCX policy-margin evaluation.  The
   GOLDM source is used only to re-check the regime/TF gate.
5. A real submission is blocked unless GOLDGUINEA live traded volume is at
   least **2 × the average quantity of the prior seven completed daily bars**.
   Missing quote or volume history also blocks submission.
6. Only the translated `MCX:GOLDGUINEA<YYMON>FUT` price levels reach FYERS.
   On broker acceptance, those translated levels replace the pending source
   values in the bucket and linked commodity order.

`SEGMENTS["MCX"].margin_pct` remains `0.32` and
`SEGMENTS["MCX"].notional_cap` remains `1_600_000`.  No policy value was
changed in `scripts/position_sizing.py`.

## Files changed for this work

Production files:

- `scripts/graduated_live_config.py` — added `FUTURES_LOT_SIZES["GOLDGUINEA"] = 8`.
- `scripts/tf_regime_gate_by_exchange.py` — confirms the MCX universe stays
  `GOLDM` and `CRUDEOILM`; GOLDGUINEA is execution-only.
- `scripts/mcx_policy.py` — maps `GOLDM` to `GOLDGUINEA` and declares the
  execution-only symbol set.
- `scripts/scanner_fc.py` — excludes execution-only contracts from the legacy
  commodity setup/zones scan, while their active master records still support
  data download and quote validation.
- `scripts/mcx_graduated_live_scanner.py` — persists source/gate provenance,
  routes real GOLDM candidates to the GOLDGUINEA 8-unit execution contract,
  and marks them for quote translation.
- `scripts/sizing_bridge.py` — supplies proportional level translation and
  execution-lot risk/notional/margin evaluation while retaining the GOLDM
  gate source.
- `apps/backend/api/bucket_orders_commodity.py` — performs live quote
  translation, seven-day liquidity validation, translated preflight, and
  translated GTT submission from `/approve/reject/bucket/orders/commodity`.
- `scripts/db_migrations/20261029_add_mcx_goldguinea.sql` — idempotently adds
  the active MCX GOLDGUINEA master record required for data/quote discovery.

Tests added or updated:

- `tests/test_commodity_bucket_approval.py`
- `tests/test_mcx_goldguinea_contract.py`
- `tests/test_mcx_golive_policy.py`
- `tests/test_tf_regime_gate_by_exchange.py`
- `tests/test_phase1_graduated_execution.py`

Files inspected but intentionally not changed for this request:

- `scripts/position_sizing.py` — retains MCX `margin_pct=0.32` and
  `notional_cap=1_600_000`.
- `data_fetchers/fyers/indian_commodity_data_updater.py` — already downloads
  all active commodity-master symbols, so the migration makes GOLDGUINEA data
  available without changing the updater.

## What to execute now

1. Apply the idempotent master-data migration using this environment's normal
   database migration procedure:

   ```sql
   scripts/db_migrations/20261029_add_mcx_goldguinea.sql
   ```

2. Run the MCX commodity data updater once.  It must produce the daily
   GOLDGUINEA CSV files before a real approval can pass the seven-day liquidity
   check.  In Dagster, run `update_indian_commodity_job`.

3. Gather candidates manually in safe PAPER mode (the default):

   ```bash
   /home/ispeck/anaconda3/envs/finpro/bin/python scripts/mcx_graduated_live_scanner.py --timeframe 3 --timeframe 4
   ```

   Results are written to `outputs/mcx_graduated_live/mcx_scan.jsonl`.

4. When real, manually approved MCX candidates are intended, set
   `MCX_EXECUTION_MODE=REAL` in the service environment and run the same
   scanner.  This only creates an approval candidate; it does not place an
   order.  The final broker action still requires
   `POST /approve/reject/bucket/orders/commodity` with `status: "approved"`.

## Current automatic call path

```text
Dagster update_indian_commodity_job (currently scheduled every 30 minutes)
  -> MCXFutureDataHandler downloads active MCX contracts, including GOLDGUINEA
  -> MCX daily / intraday CSV data

Dagster mcx_graduated_scanner_job (schedule exists, default STOPPED)
  -> mcx_graduated_scanner_op()
  -> run_graduated_mcx_scan()
  -> default_mcx_jobs(): source universe = GOLDM, CRUDEOILM
  -> GOLDM setup/gate/zones -> GOLDGUINEA pending approval candidate

UI approval
  -> POST /approve/reject/bucket/orders/commodity
  -> live GOLDM + GOLDGUINEA quotes, liquidity and translated execution checks
  -> FYERS GOLDGUINEA GTT submission
```

The defined `mcx_graduated_scanner` Dagster schedule runs every 30 minutes
from 09:00 through 23:00 IST on weekdays, but its default state is **STOPPED**.
Enable that schedule in Dagster only when automatic candidate gathering is
desired.

## Validation performed

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_commodity_bucket_approval.py \
  tests/test_mcx_goldguinea_contract.py \
  tests/test_mcx_golive_policy.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_phase1_graduated_execution.py
```

Result: `33 passed`.
