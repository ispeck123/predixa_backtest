"""MCX execution-symbol mapping backed by the shared exchange gate."""
from __future__ import annotations

from scripts.tf_regime_gate_by_exchange import gate

# GOLDM is deliberately reduced to the guinea lot.  GOLDGUINEA is execution
# only: it must not become a detection/gate/zone source series.
MCX_EXECUTION_ONLY_SYMBOLS = frozenset({"GOLDGUINEA"})

MCX_EXECUTION_SYMBOL = {
    "GOLDM": "GOLDGUINEA",
    "CRUDEOILM": "CRUDEOILM",
}


def mcx_weight(symbol, e_regime, a_regime, strategy_tf) -> float:
    """Return the shared gate multiplier, or zero when MCX is denied."""
    return gate("MCX", strategy_tf, e_regime, a_regime, symbol)[1]


def mcx_disposition(symbol, e_regime, a_regime, strategy_tf) -> tuple[str, float, str | None]:
    """Classify a long setup as FIRE, OBSERVE, or EXCLUDED.

    The gate owns MCX eligibility.  This module only maps a permitted source
    contract to its existing execution symbol.
    """
    weight = mcx_weight(symbol, e_regime, a_regime, strategy_tf)
    source = str(symbol).split("@", 1)[0].upper()
    if weight <= 0:
        return "EXCLUDED", 0.0, None
    return "FIRE", weight, MCX_EXECUTION_SYMBOL.get(source, source)
