# PREDIXA MCX Phase-1 Task 4 — Edge Reproduction Report

**Verdict: BLOCKED_MISSING_DATA.** No versioned authoritative `clean_mcx_trade_export.csv` was present under `audit/mcx_futures_backtest/outputs`. Consequently no real-market cell metrics or edge claim were produced.

## Verifier audit and integration

The existing `scripts/edge_repro_check.py` accepts the 14-column Task-3 export when paired with `trade_provenance.csv` and the authoritative run manifest. It joins on `export_row_index`, checks row-count reconciliation and unique indices, requires unique setup IDs, validates timezone-aware signal timestamps and split/partition consistency, checks outcomes and entry/stop inputs, reconciles `gross_r` to executable exit when present, calculates cost-adjusted realized R from `gross_r`, and reports win rate and MFE separately. It does not substitute `mfe_R` for realized R.

The original checker follows active gate cells and correctly rejects the intentionally empty MCX live allowlist. Added `--candidate-cells` to calculate evidence for cells found in an export for analysis only, grouped by underlying/E/A/X/timeframe. Default live mode still matches the gate's E/A/timeframe key. Candidate mode labels cells `CANDIDATE_NOT_LIVE` and cannot modify or authorize the gate.

Added `scripts/mcx_phase1_edge_validation.py` as a final fail-closed entry point. It discovers the latest versioned run or accepts a specific run directory, checks exact 14-column schema and export/run hashes, checks the Task-3 export validation sidecar, verifies Task-2 readiness flags and every input hash, revalidates the source bundle, verifies split approval, checks one-to-one provenance and dated-contract identity, and invokes the existing checker in candidate-only mode. It calculates IS/OOS gross expectancy from `gross_r`, net expectancy using the supplied `rt` cost fraction, and win rates from `outcome`; this is a cost model rather than a verified fee/slippage ledger. MFE is not used as expectancy.

The work-order's required sample/statistical acceptance policy was not found in repository configuration. The checker reports sample counts and win-rate behavior but does not define a minimum sample-size or statistical significance criterion; its native edge criterion checks positive net realized OOS R. The final wrapper therefore requires an independently approved sample/statistical spec and a `statistical_validation.json` PASS tied by hash to the exact export. It also requires positive IS and OOS net realized R. This avoids inventing a minimum or statistical method, or treating a tiny sample as statistically qualified.

## Actual invocation

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python scripts/mcx_phase1_edge_validation.py \
  --runs-root audit/mcx_futures_backtest/outputs \
  --split 2026-01-01 \
  --universe GOLDM,GOLDGUINEA,SILVERM,CRUDEOILM,NATGASMINI \
  --rt 0.0010 \
  --json-out PREDIXA_MCX_PHASE1_TASK4_VALIDATION_RESULTS.json \
  --report-out PREDIXA_MCX_PHASE1_TASK4_EDGE_REPRO_REPORT.md
```

Exit code **2**, verdict `BLOCKED_MISSING_DATA`: no versioned clean export exists. The supplied split was only a command argument; it is not an approved split and was not used to calculate results. No cell rows were available to evaluate.

When a clean run exists, supply `--approved-config <absolute-path-outside-the-checkout.json>`. That reference must independently identify the approved split and per-partition sample policy and match the source bundle; an ID written only inside the repository is insufficient.

## Tests

The new synthetic-only tests exercise positive IS/OOS realized metrics, negative OOS despite positive MFE, approved sample floors, schema/provenance/hash failures, split errors, policy/calendar/E1/contract failures, TEST_ONLY rejection, CLI candidate analysis, and checker exit propagation. Synthetic fixtures test software behavior only.

Final MCX/release regression command passed **176 tests**; Python compilation passed. Exact commands and outputs are summarized in `PREDIXA_MCX_PHASE1_FINAL_CLOSURE.md` and encoded in `PREDIXA_MCX_PHASE1_TASK4_VALIDATION_RESULTS.json`.

## Decision

Task-4 validation engineering is implemented and tested. Historical edge reproduction is blocked. No MCX permissions changed; MCX remains DENY and PAPER/REAL remain disabled.
