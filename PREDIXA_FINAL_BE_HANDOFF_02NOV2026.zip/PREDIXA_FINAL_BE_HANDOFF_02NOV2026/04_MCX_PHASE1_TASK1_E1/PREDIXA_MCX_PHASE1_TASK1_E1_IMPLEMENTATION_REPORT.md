# PREDIXA MCX Phase-1 / Task 1 — E1 Session-Gap Boundary Correction

Assessment date: 02 November 2026. This is an offline code/test change only.
No scanner, broker, paper order, live order, service, or market-data fetch was
started.

## Status

**COMPLETED** for the repository-owned E1 session-boundary correction. This
does not perform Task 2 contract-roll correction, Task 3 realized-R export, or
Task 4 edge reproduction, and does not authorize MCX trading.

## Root cause and traced path

The MCX history path is:

`MCXFutureDataHandler._fetch_candle_data_once()` (FYERS UTC epoch -> naive IST
`tradeDate`) -> CSV -> `load_preprocess_data()` -> `CandleSeries` ->
`SDEnginePipeline.get_candle_series_data()` -> `ZoneDetector.detect()` /
`GapModule.detect()` -> `ZoneQualifier.update_violation()` and
`update_retest()` -> setup formatting.

The primary commodity route enables E1 only for `is_future is False` in
`scripts/setup_engine_new.py:362-368`; NSEFO and NSE_CASH retain their prior
path. `ZoneDetector.detect()` already splits a session-labelled MCX series
before base/legout processing (`scripts/trade_engine.py:1360-1394`), and
`GapModule.detect()` rejects consecutive candles with different session ids
(`scripts/trade_engine.py:2971-2977`). Regular-zone pure gap-through violation
handling is guarded at `scripts/trade_engine.py:2435-2488`; gap-zone retests
are session scoped at `scripts/trade_engine.py:2547-2563`.

The remaining defect was in `scripts/mcx_session.py:_session_ids`. It required
the previous timestamp to be `23:30` or later. Repository provenance shows
FYERS 60-minute MCX bars use a `23:00` start timestamp; session-anchored
240-minute bars can use a `21:00` final partial-bucket timestamp. Therefore
the existing zone safeguards were not labelled for those supported source bars
and could treat the next 09:00 candle as adjacent.

The raw FYERS API path does not synthesize a single overnight OHLC candle. A
separate risk existed in `MCXFutureDataHandler.create_75munite_from_15munite`:
it grouped five positional rows without resetting at a session seam, so an
incomplete pre-close chunk could be completed with the next 09:00 candle. That
was a genuine synthetic aggregation risk. The configured MCX strategy uses
`monthly/weekly/daily`, `two_forty`, `one_twenty`, and `sixty`; the 75-minute
fix is nevertheless applied because the repository owns that derived path.

## Changes made

| Path | Function/control | Before | After | Regression risk |
|---|---|---|---|---|
| `scripts/mcx_session.py` | `is_mcx_e1_boundary`, `_session_ids`, `mcx_e1_session_ids` | Close-side recognition began at `23:30`, missing FYERS/derived final buckets. | IST-aware E1 seam is previous date, close-side bucket `>=21:00`, next timestamp `<=09:00`; 60m/120m/240m bucket timestamps are covered. Duplicate/unordered input becomes a conservative non-bridging boundary. | Only MCX callers opt in; no generic elapsed-gap rule. |
| `data_fetchers/fyers/indian_commodity_data_updater.py` | `create_75munite_from_15munite` | Five-row chunks could span the overnight void. | Groups chunks by E1 session; an incomplete final session chunk is dropped per the existing partial-bar policy rather than carried into 09:00. | Derived 75m output may contain fewer invalid bars; raw OHLC is unchanged. |
| `tests/test_mcx_e1_session_boundary.py` | E1-01 through E1-14 coverage | No focused Task-1 regression suite. | Offline fixtures cover seams, resampling, zone segmentation, violation/retest, supported buckets, UTC/IST conversion, malformed sequence fail-closed behaviour, non-MCX path, and MCX execution holds. | Test-only. |

`scripts/trade_engine.py`, `scripts/setup_engine_new.py`, and
`scripts/models.py` already contained the session-id propagation, zone split,
gap skip, and session-aware qualifier paths at the reviewed repository state.
They were inspected and exercised, but not edited for this task.

## E1 policy

- Timezone: `Asia/Kolkata`; numeric Unix timestamps are normalized before
  session comparison.
- Standard seam: close-side final bucket on one calendar date to a next-session
  timestamp at or before 09:00 IST. `21:00` is the earliest verified final
  bucket timestamp for the configured session-anchored 240m construction;
  `23:00` covers FYERS 60m data. This is bucket semantics, not a claim that
  the exchange closes at 21:00.
- Holidays/weekends: no repository-owned verified historical MCX calendar was
  found. Friday-to-Monday is conservatively a seam when it has the documented
  close-side/open-side shape. Missing daytime bars are not reclassified merely
  due to elapsed duration.
- Base/legout: the detector operates independently per session id. Global
  positional indices are restored only after each bounded local detection, so
  an emitted zone cannot have base/legout indices from two E1 sessions.
- Gap opens: no bridging bar/interpolation is created. A 09:00 cross-session
  pair cannot form a gap zone. A pure gap-through cannot invalidate a regular
  zone; an actual opening-candle range may still be analysed as observed
  same-session price action, not as synthetic movement.
- Persisted zones: regular zones can be evaluated by later observed candles;
  gap zones exclude later E1 sessions for violation/retest. This preserves
  existing lifecycle semantics while blocking the overnight transition itself.
- Ambiguous source ordering: duplicates or descending timestamps become
  conservative boundaries. The data loader remains responsible for canonical
  sorting/deduplication.

## Test evidence

Executed:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_mcx_remediation_guardrails.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_commodity_bucket_approval.py
```

Result: **34 passed**, 7 third-party/deprecation warnings, exit code 0.

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile \
  scripts/mcx_session.py data_fetchers/fyers/indian_commodity_data_updater.py \
  scripts/trade_engine.py scripts/setup_engine_new.py
```

Result: **PASS**, exit code 0.

The Task-1 test module covers E1-01 through E1-14. The 75m fixture proves the
former four-candle pre-close remainder is not combined with the five-candle
09:00 session. A paired same-session/cross-session gap fixture proves an
otherwise qualifying observed OHLC gap is rejected only at the E1 seam. The
direct session-split detector fixture proves every emitted fixture zone has
`session_id[base_start] == session_id[base_end]` and that its departure remains
in the same session.

`git diff --check` against the entire dirty worktree reports trailing whitespace
in pre-existing unrelated API/socket files. The focused Task-1 paths produced
no whitespace diagnostics. No unrelated file was modified to mask that
pre-existing state.

## Historical diagnostics

No engine-compatible, verified MCX history run was performed. Available
research metadata confirms FYERS 60m data has `09:00` opening and `23:00`
final timestamps, which supports the bucket diagnosis, but it is not a clean
dated-contract series and no before/after setup count is claimed. No realized-R
or edge conclusion is produced by this task.

## Outstanding dependencies and next phase

The repository lacks a verified historical MCX holiday/special-session calendar;
the standard documented E1 rule is isolated in `scripts/mcx_session.py` for a
future validated calendar extension. Task 2 still needs verified dated-contract
history, roll dates/prices, and adjustment methodology. Task 1 is **READY FOR
TASK 2 IMPLEMENTATION** as a code dependency only; the MCX dataset is not
thereby clean, MCX PAPER/REAL remain blocked, and no trading reactivation is
authorized.
