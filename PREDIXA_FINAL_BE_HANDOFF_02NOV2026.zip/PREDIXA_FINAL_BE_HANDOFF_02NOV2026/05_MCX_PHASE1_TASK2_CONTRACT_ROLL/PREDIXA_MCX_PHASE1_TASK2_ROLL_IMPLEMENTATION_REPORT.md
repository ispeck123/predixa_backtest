# PREDIXA MCX Phase-1 / Task 2 — Roll Attribution and Back-Adjusted Series

Assessment date: 02 November 2026. Scope is an offline research-data pipeline;
no provider request, scanner, broker, paper order, live order, or deployment was
performed. Task 3 trade export and Task 4 edge reproduction were not run.

## Status

**PARTIALLY_COMPLETED — IMPLEMENTATION VERIFIED, HISTORICAL DATA VALIDATION
BLOCKED.** The repository now has tested, fail-closed components for explicit
dated-contract selection, roll schedules, additive/ratio adjustment, raw-price
mapping, expiry-window classification, and machine-readable data checks. A
verified multi-contract history and approved production roll policy are still
unavailable, so no clean continuous historical dataset is claimed.

The earlier reported expiry-removal figures (`+0.32R` to `+0.14R`) were not
recomputed here. They remain unverified observations; this task makes no
realized-R, profitability, or strategy-edge claim.

The referenced `PREDIXA_MCX_Phase1_WorkOrder_01NOV2026.xlsx` was not present in
the repository inventory. This implementation followed the supplied Task 2
requirements in the request.

## Root cause and existing path

The current research data path is not historically contract-aware:

1. `MCXFutureDataHandler.get_latest_fyers_commodity_symbol_expiry()` in
   `data_fetchers/fyers/indian_commodity_data_updater.py:50-73` downloads the
   current public FYERS master, extracts current symbols/expiries, and returns
   up to three contracts. It does not archive a point-in-time master, listing
   time, or selection interval.
2. `_fetch_candle_data_once()` at `:258-274` always sends `cont_flag="1"`.
   `download_all()` at `:307-345` stores that series under a filename made from
   the currently listed contract expiry. A filename expiry is therefore not
   proof that every row belongs to that contract.
3. `ExpiryRefreshCoordinator.observe()` in
   `data_fetchers/fyers/expiry_refresh.py:196-234` retains symbols and expiry
   dates seen in current master snapshots to detect a front change. It does
   not maintain historical listing/effective intervals or a raw OHLC archive.
4. The available-history inventory at
   `audit/derivatives_backtest_common/contract_inventory.py` classifies the
   supplied files, and `audit/mcx_futures_backtest/preflight.py` has a strict
   rejection for stitched sources. It found 216 files, 27 symbol/expiry keys,
   and nine symbols; all 216 were `STITCHED_OR_CONTINUOUS`.
5. `mcx_contract_live()` in
   `audit/derivatives_backtest_common/calendar_contracts.py:31-35` labels a
   historical trade by its calendar month. `export_labeled.py:86-99` records
   that label as `CALENDAR_INFERRED_FROM_STITCHED_SERIES`. This is a descriptive
   inferred label, not dated-contract attribution.

The evidence points to a stitched/continuous history stored under current
expiry filenames, followed by month-derived trade labels. It does not show
that the raw FYERS OHLC itself was fabricated, nor does the repository contain
enough evidence to reconstruct which dated contract generated every stitched
bar. Current front-contract refresh state cannot repair that historical loss
of identity.

## Changes made

Only two implementation files were added for Task 2; Task 1 code and trading
execution paths were not changed.

| File | Component | Behaviour and safety properties |
|---|---|---|
| `audit/mcx_futures_backtest/contract_roll.py` | `DatedContract`, `RollTransition`, `RollPolicy`, `TradingCalendar`; `select_historical_contract`; `build_back_adjusted_series`; `classify_expiry_window` | Requires explicit MCX contract identifiers, provenance, verified attribution and active intervals. Selects exactly one contract at a point in time; rejects missing/overlapping matches. Requires verified source-attributed roll prices and an explicit policy. Validates OHLCV, timestamps, duplicates, ordering, roll price matches, active-interval overlap/gaps, and missing roll events. Produces raw executable fields separately from adjusted research fields, adjustment metadata, per-underlying series, machine-readable status, and E1 session IDs. `as_of` snapshots exclude future bars and future-effective rolls. |
| `tests/test_mcx_contract_roll_adjustment.py` | T2-01..T2-20 plus policy/schema edge checks | Synthetic fixtures verify deterministic behavior only. They are not market-performance evidence. |

The additive factor for an outgoing contract is the incoming observed roll
price less the outgoing observed roll price, carried recursively through
later rolls. The optional ratio method uses the corresponding positive-price
ratio. The caller must explicitly choose the method and supply policy status;
there is no default production roll convention. Both methods alter only
`research_open/high/low/close`. `raw_open/high/low/close`, volume, dated
contract symbol, provider identifier, and source ID remain available for
execution-price accounting. Roll prices are checked against the outgoing
contract's final close before the effective time and incoming contract's first
open at/after it.

Retrospective back-adjusted output can use later roll observations. The
`as_of` argument instead builds a snapshot from only bars and roll events
available by that timestamp; a historical replay must build/use the matching
point-in-time snapshot rather than reuse a final retrospective chart. The
output records `adjustment_known_at` and `is_point_in_time_snapshot`.

Expiry classification counts verified trading sessions strictly after the
signal's session date through the expiry date. It flags only when fewer than
three such sessions remain. It never substitutes calendar days. Without a
complete, source-verified exchange calendar covering signal and expiry, it
returns `UNVERIFIED` with no guessed count.

Validation summary statuses are `VALID`, `WARNING`, `UNVERIFIED`, or
`REJECTED`. Invalid OHLC, duplicate/unordered timestamps, overlap, missing
roll prices, or inconsistent schedule raises `ContractDataError`, which carries
a machine-readable `REJECTED` summary; missing
provenance, listing dates, transition records, or unapproved policy is not
reported as clean. Timestamp-naive bars require a declared source timezone.
No missing candle is interpolated. The builder does not resample; it attaches
`e1_session_id` to the selected bars, and downstream resamplers/zone code must
continue to respect it.

## Contract master and source inventory findings

The files under `data/indian_commodity_data/latest_data_csv` are current
stitched files, not validated expired-contract files. The existing inventory
has three expiry-named keys for each of the five requested underlyings, each
with daily, 15m, 60m, 120m, 240m, derived 75m, weekly, and monthly frames; all
are classified `STITCHED_OR_CONTINUOUS`. For each underlying, observed source
coverage is 2025-11-03 through 2026-11-02. The 384 processed files are
derived timeframe outputs and do not add contract identity.

There are limited genuine dated-contract artifacts, but no verified complete
roll chain:

| Source | Verified facts | Limitation |
|---|---|---|
| `research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv` and `metadata/fyers_raw.json` | FYERS dated symbol `MCX:CRUDEOILM26OCTFUT`, `cont_flag=0`, 1,302 60m rows, 2026-05-22 21:00 IST through 2026-10-08 23:00 IST, expiry 2026-10-19. CSV SHA-256 `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6`; metadata SHA-256 `bdbe2a271a03f8f56cce1301ad7c9333fce90659bc88a3f15f96bc74b0cf113b`. | One contract only; listing time and adjacent historical contracts/roll prices are missing. It cannot form or validate a roll-adjusted series. |
| `research/zone_series_comparison/data/SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.csv` and corresponding metadata | Dated scrip code 569901; 397 rows, 2026-09-01 through 2026-10-08. | Provider timestamp boundary/timezone and volume units are undocumented; default history window only. No roll schedule. |
| `research/zone_series_comparison/data/CRUDEOILM_19OCT2026_SK_RAW_daily.csv` and metadata | FYERS/Sharekhan investigation recorded the provider identifier/expiry evidence. | 752 rows begin in 2015, years before the named 2026 contract existed; historical mapping is explicitly unresolved and must not be treated as raw 2026-contract history. |
| `research/zone_series_comparison/data/GOLD_04DEC_raw_60m.csv` | Dated `GOLD` provider sample. | It is `GOLD`, not the required `GOLDM`; no substitution is made. |

No dated raw historical OHLCV source was verified for `GOLDM`,
`GOLDGUINEA`, `SILVERM`, or `NATGASMINI`. `SILVER` is not substituted for
`SILVERM`.

### Limited real-data integrity check

The FYERS CRUDEOILM 60m source above was passed in memory through the new
builder with its documented dated symbol and expiry. OHLC, unique timestamp,
ordering, and E1 session IDs validated: 1,302 rows, 0 duplicates, 81 E1
session IDs. No roll event was present. The result was correctly
`UNVERIFIED` (`LISTING_DATE_MISSING`, `ROLL_POLICY_PENDING_APPROVAL`, and
`NO_VERIFIED_ROLL_TRANSITIONS`); no output dataset was written and no edge
calculation was performed. This is limited source-integrity evidence only.

## Roll policy and E1 status

No approved MCX roll convention was found in the repository. Existing
calendar/expiry artifacts contain some official expiry dates, including a
CRUDEOILM calendar for selected years, but report actual roll timestamps as
unknown. The FYERS expiry refresher observes current front changes; that is
not a historical roll policy. The new API accepts an explicitly supplied
schedule and adjustment method and refuses to call an omitted transition
verified. Production roll-policy approval and complete data remain pending.

The builder keeps underlyings separate and does not combine `GOLDM` with
`GOLDGUINEA`, or `SILVERM` with `SILVER`. It treats contract transitions as
separate metadata from E1 session IDs. `scripts/mcx_session.py` is imported
unchanged; its Asia/Kolkata E1 IDs are attached to the assembled chronological
bars. No overnight bridge candle is created. Task 1's 15m-to-75m resampler and
zone/session logic are unchanged. Task 2 outputs are research-only and are
not connected to a trading or order path.

## Test and validation evidence

Focused command:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_mcx_contract_roll_adjustment.py \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_mcx_remediation_guardrails.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_commodity_bucket_approval.py
```

Result: **65 passed, 7 third-party/deprecation warnings, exit 0**.
The Task-2 module contributes **31 collected cases**, including parameterized
invalid-input and timeframe scenarios.

Compilation command:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile \
  audit/mcx_futures_backtest/contract_roll.py \
  tests/test_mcx_contract_roll_adjustment.py \
  scripts/mcx_session.py \
  data_fetchers/fyers/indian_commodity_data_updater.py
```

Result: **PASS, exit 0**.

Strict source preflight (writes only to `/tmp/predixa_mcx_t2_preflight`):

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.preflight \
  --root data/indian_commodity_data/latest_data_csv \
  --output /tmp/predixa_mcx_t2_preflight --strict-contract-history
```

Result: **expected fail-closed exit 2** — `216` source files, `27` contract
keys, `9` symbols; source modes were `{'STITCHED_OR_CONTINUOUS': 216}`; strict
failure says historical contract-live attribution is not evidenced.

The in-memory real sample integrity check is detailed above. Tests use only
explicit deterministic fixtures for roll arithmetic, point-in-time snapshots,
calendar classification, invalid schema, and the roll-plus-E1 boundary. They
do not establish trading profitability.

## Remaining data and policy dependencies

See `PREDIXA_MCX_PHASE1_TASK2_DATA_REQUIREMENTS.md` for the exact input
contract and reproducible collection procedure. In summary, full validation
requires archived point-in-time dated masters for all five exact underlyings,
actual dated OHLCV over each historical contract period, verified roll
prices/timestamps and a pre-approved roll rule, an authoritative historical
MCX calendar including expiry changes/holidays/special sessions, and executable
price mapping. The current FYERS updater uses continuous history and only the
current master; Sharekhan's documented/history behavior does not provide an
adequate full archive in the available evidence.

## Task 3 readiness

**CODE READY / DATA BLOCKED.** Task 3 may consume the builder API once the
required historical contract, roll, calendar, and policy inputs are supplied
and validation returns an acceptable status. It must not consume current
stitched files or the calendar-inferred `contract_live` label as verified
contract data. MCX remains blocked in the gate, allocator, scanners, and broker
entry boundaries. No MCX PAPER/REAL execution or reactivation occurred.

## Task 2B follow-up — FYERS-only historical data audit (02-Nov-2026)

Task 2B follow-up confirms the prior partial status. Per owner direction, FYERS is the only applicable provider for this validation; no Kite or Sharekhan data is used as evidence. The existing saved FYERS `MCX:CRUDEOILM26OCTFUT` `cont_flag=0` 60m capture (1,302 bars, 2026-05-22 to 2026-10-08) remains a single-contract integrity sample. It lacks a verified point-in-time listing interval, adjacent incoming/outgoing dated-contract overlap, and a roll transition. The current 216 files remain continuous/stitched outputs. The legacy 224-file archive has expiry-like filenames but lacks per-file provider/instrument/request provenance, so it remains UNKNOWN.

FYERS official plan documentation lists expired F&O data entitlements (including expired intraday access subject to plan limits), but account entitlement and exact expired-MCX retrieval were not exercised. The Task2B regression rerun passed 65 tests (7 dependency deprecation warnings). No code changes were made to the Task2 builder or Task1 E1 pipeline. Real all-underlying historical validation remains blocked by missing archived FYERS dated masters/OHLCV and overlaps, an approved roll policy/adjustment method, and an authoritative MCX calendar. See `PREDIXA_MCX_PHASE1_TASK2B_DATA_AUDIT.md`, `PREDIXA_MCX_PHASE1_TASK2B_CONTRACT_INVENTORY.csv`, and `PREDIXA_MCX_PHASE1_TASK2B_VALIDATION_REPORT.md`.
