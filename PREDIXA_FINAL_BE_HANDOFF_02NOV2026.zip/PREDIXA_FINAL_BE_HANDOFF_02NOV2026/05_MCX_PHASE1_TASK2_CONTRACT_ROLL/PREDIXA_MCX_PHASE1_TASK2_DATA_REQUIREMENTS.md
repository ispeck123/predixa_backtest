# PREDIXA MCX Phase-1 / Task 2 — Historical Data Requirements

## Current finding

The live updater in `data_fetchers/fyers/indian_commodity_data_updater.py`
reads the current FYERS MCX master and requests history with `cont_flag="1"`.
Its three expiry-named CSVs per underlying therefore are not dated-contract
archives. `audit/mcx_futures_backtest/preflight.py --strict-contract-history`
found 216/216 source files to be `STITCHED_OR_CONTINUOUS`.

One bounded FYERS dated CRUDEOILM 60m file exists (`cont_flag=0`, 1,302 rows,
2026-05-22 through 2026-10-08); a dated Sharekhan CRUDEOILM sample also exists
for 2026-09-01 through 2026-10-08. They do not cover a roll transition. The
dated FYERS sample is integrity-checkable but its listing date and neighbor
contracts are absent. No verified exact-symbol dated archive was found for
GOLDM, GOLDGUINEA, SILVERM, or NATGASMINI. The available `GOLD` contract is not
GOLDM. The old Sharekhan CRUDEOILM daily response begins in 2015 under a
2026-expiry code and its own metadata says that historical contract mapping is
unresolved.

The original `PREDIXA_MCX_Phase1_WorkOrder_01NOV2026.xlsx` was not found in the
repository during this audit.

## Required input package

Keep one independent package per underlying and timeframe. Never pool
`GOLDM`/`GOLDGUINEA` or `SILVERM`/`SILVER`.

### 1. Point-in-time dated contract master

For every contract and each master snapshot, provide:

- `underlying`: exactly one of `GOLDM`, `GOLDGUINEA`, `SILVERM`, `CRUDEOILM`,
  `NATGASMINI`.
- `exchange`: `MCX`.
- Exact dated `contract_symbol` and provider `provider_instrument_id`.
- `expiry_date` as an authoritative exchange/provider date, including any
  official expiry shift.
- `listed_from` (or first time the contract was available to select), plus
  snapshot/effective timestamps and the interval in which that contract was
  historically selected.
- Lot size, multiplier, tick size, price scale, and currency if executable
  P&L is later computed. Keep each underlying's actual specification.
- Master source, retrieval timestamp/timezone, original file hash, and
  `attribution_status`. Missing IDs/dates remain explicitly unverified.

The active selection intervals must be non-overlapping and must cover the
specified historical period. A current master by itself does not establish
past availability. Do not infer a dated ID from today's front month or from a
stitched filename.

### 2. Dated-contract OHLCV files

For every contract that can be selected during the backtest lookback and
evaluation periods, retain:

- Timestamp for each bar, documented candle-start/end semantics, timezone,
  and declared timestamp resolution.
- `open`, `high`, `low`, `close`, `volume`; open interest if the approved roll
  policy uses it.
- Exact exchange, underlying, dated symbol, provider ID, expiry, and source ID
  on every file/manifest entry.
- Requested and actual date range, provider response metadata, missing/empty
  request ranges, duplicate handling, and SHA-256 hash.
- Raw, unmodified source values. No interpolation, synthetic contract mapping,
  or overwriting of downloaded evidence.

The archive must cover the strategy's complete history and lookback for each
dated contract, including overlap across outgoing/incoming contracts around
each approved transition. It must include all configured strategy timeframes
or sufficient native data plus the documented session-aware resampling rule.
An empty request response is not proof that no history exists; retain the
provider response and retrieval result.

### 3. Roll schedule and prices

Before building, provide a versioned, approved policy stating whether the
contract changes by an explicit schedule, fixed trading-session offset,
volume crossover, open-interest crossover, or another owner-approved rule.
Include the policy version, who approved it, and the timestamp when a roll
decision became knowable.

For every transition, provide:

- Underlying, outgoing and incoming exact dated symbols/IDs.
- `decision_at` and `effective_at` with timezone.
- Observed outgoing and incoming roll prices with source timestamps, provider,
  raw-price references, and source hashes. The current builder checks those
  values against the outgoing last pre-transition close and incoming first
  at/after-transition open.
- Roll-policy identifier and verification state.
- Evidence that the chosen decision did not use future volume, open interest,
  price, or expiry information.

The repository currently contains no approved historical MCX roll policy or
verified roll timestamps. The only explicit supported code policies are
additive and positive-price ratio adjustment; the method must be named for
each run. No method is silently selected as the research standard.

### 4. Adjustment and executable-price mapping

Retain raw executable dated prices and produce adjusted research OHLC in
separate fields. Store the method, per-contract factor/offset, each roll's raw
prices, adjustment-known timestamp, and source IDs. Do not compute trade P&L
from a synthetic difference between outgoing and incoming contract levels.

For historical signals, use a snapshot built `as_of` the signal timestamp, or
another proven causal series. A retrospective back-adjusted chart must not be
used to replay earlier signals as if later roll prices were then known. Preserve
the mapping from each research row to its original dated contract and raw
executable OHLC.

### 5. MCX calendar and expiry-window eligibility

Provide an authoritative historical session-date calendar covering every
signal and expiry date, plus holidays, special sessions, early closes, and
underlying-specific expiry changes. Include source, version, timezone,
publication date, and integrity hash. Existing regular-session defaults and
the partial CRUDEOILM expiry calendar are insufficient to establish complete
trading-day counts for every requested underlying and year.

The required roll-boundary flag is based on the count of verified MCX trading
sessions strictly after the signal session through expiry. Fewer than three
remaining sessions is flagged. Without complete calendar coverage, the result
is `UNVERIFIED`; do not substitute weekdays or calendar days.

### 6. Provider collection procedure

The repository's FYERS updater already calls `fyers.history`, but hardcodes
`cont_flag="1"` and obtains only current contract symbols from the public
master. Prior research evidence confirms that a direct dated FYERS symbol with
`cont_flag="0"` returned raw dated CRUDEOILM candles for a bounded period. That
is a viable provider path to evaluate under approved credentials and documented
retention, but no request was made in this task.

Collection procedure once an authorized provider operator is assigned:

1. Archive a timestamped, hashed MCX instrument-master snapshot before it is
   pruned; capture the exact dated IDs, expiry, and listing/availability
   metadata for all five exact underlyings.
2. Obtain provider documentation and confirm dated-symbol history mode,
   interval semantics, retention, rate limits, and request limits. Do not pass
   `cont_flag="1"` for a raw-contract capture.
3. Request each dated symbol independently for the complete required date
   range, with bounded batches and saved request/response metadata. No
   unbounded downloads or production data writes.
4. Hash and archive each original response; validate schema, timestamp order,
   duplicates, OHLC envelope, interval coverage, and exact instrument ID.
5. Capture adjacent outgoing/incoming contract data at each pre-approved roll
   and preserve the observed prices used by the policy.
6. Import the authoritative historical MCX session/holiday/expiry calendar.
7. Supply a manifest to `audit.mcx_futures_backtest.contract_roll` with
   verified contract intervals, raw bars keyed by `(underlying,
   contract_symbol)`, verified transitions, named adjustment policy, source
   IDs/hashes, declared naive timestamp timezone if applicable, and expected
   bar interval. The builder returns series, contract mapping, roll metadata,
   and a validation summary. Any unverified identity/policy/calendar remains
   explicitly unverified.

The Sharekhan investigation records dated contract scrip codes and a limited
dated CRUDEOILM sample, but its SDK's default historical window has no
date-range arguments and the candle timezone/boundary/volume semantics are
not fully documented. Obtain provider clarification before using it for a
historical roll reconstruction.

## Acceptance gate before Task 3

Do not label a continuous dataset clean or proceed to Task 3 until all five
underlyings have the required point-in-time masters and dated OHLCV, roll
prices/timestamps and approved non-lookahead policy, verified historical
calendar, successful data validation, preserved executable-price mappings,
and reproducible E1-aware output. The bounded raw CRUDEOILM sample is not a
substitute for this package.
