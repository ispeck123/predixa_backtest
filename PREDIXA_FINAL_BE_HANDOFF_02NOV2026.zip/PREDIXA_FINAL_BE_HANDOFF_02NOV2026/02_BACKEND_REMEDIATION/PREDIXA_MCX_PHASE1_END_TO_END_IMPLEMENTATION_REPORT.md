# PREDIXA MCX Phase-1 — End-to-End Implementation Report

Date: 2026-11-02

Repository HEAD reviewed: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba`

Scope: FYERS-only historical data discovery/collection, Task-2 contract series, existing strategy replay, Task-3 realized-R export. No Task-4 edge promotion, live/paper execution, deployment, or permission change was performed.

The repository worktree is dirty and these changes are uncommitted. The recorded HEAD is the base revision observed during this run; it does not contain the implementation or generated FYERS artifacts listed below. The broad dirty tree includes unrelated existing files and is excluded from the task-specific changed-file inventory.

## Status

- **Engineering integration: PARTIALLY COMPLETE.** FYERS collection, strict Task-2 bundle validation, the existing PREDIXA setup engine adapter, and the realized-R exporter are connected by `audit/mcx_futures_backtest/run_clean_phase1.py`. Deterministic offline integration tests exercise strategy → BUY setup → dated-contract execution bars → realized-R export. The actual full runner cannot complete authoritatively without the required five-underlying bundle, verified calendar, approved roll/split configuration, and complete dated-contract inputs.
- **Real historical validation: PARTIALLY COMPLETE / DATA BLOCKED.** FYERS read-only expired-data access succeeded for one CRUDEOILM exact dated contract. It overlaps a separately archived exact October dated contract, but a later bounded collection encountered invalid OHLC and the rejected response was not retained by the then-current collector. No valid complete roll series was constructed.
- **Authoritative clean export: BLOCKED_MISSING_DATA and POLICY_BLOCKED.** No clean export was generated.
- **MCX trading: BLOCKED.** Gate deny, allocation block, scanner suspensions, and broker entry protections were not modified or exercised through trading paths.

## Integrated path and implementation

`fyers_expired_contract_collector.py` calls the documented FYERS expired expiry, contract-discovery, and historical-data routes with exact symbols; it validates response identity and OHLC, chunks requests, keeps request budgets, and persists source responses and hashes. The installed `fyers-apiv3` version is 3.1.7 and lacks the three newer documented convenience methods, so the collector uses the documented read-only HTTP routes with the existing repository authentication token. The token is not logged.

`run_clean_phase1.py` exposes `check-access`, `collect`, `validate-data`, `replay`, and `full` modes. The replay path validates all Task-2 evidence before using `clean_strategy_replay.py`; that adapter calls the existing `SDEnginePipeline.run` setup path, only reads `best_setup_long`, carries E/A/X regime values, maps adjusted analytical levels back to the actual contract basis, and never calls order, scanner, or broker code. It then passes candidates and raw dated-contract execution bars to the existing `clean_realized_r_export.py`.

The versioned bundle schema requires five distinct underlyings, all configured research/strategy frames, contract mappings, raw executable bars, calendar, policy, coverage and approval metadata. Research-mode behavior is explicitly non-authoritative. Missing/invalid bundle evidence fails closed; no manual setup JSON is required.

The exporter preserves the required 14-column CSV and joins timestamps via its sidecar. For ambiguous same-bar stop and target touches, the clean resolver now takes the conservative stop-first result, flags the resolution, and does not claim favorable excursion from the ambiguous exit bar. `gross_r` remains gross of costs; no unsupported cost assumption is made.

## FYERS evidence

An authenticated read-only request using the exact dated symbol discovered `MCX:CRUDEOILM26OCTFUT`, expiry 2026-10-19. A bounded expired-data collection returned `MCX:CRUDEOILM26AUGFUT`, expiry 2026-08-19, 195 60-minute bars from 2026-08-03 09:00 IST through 2026-08-19 23:00 IST. Normalized OHLCV SHA-256: `942206eae43efc27535ed2791e8fa75ff0e62e44266c85fbd2dc773379656842`; raw provider response SHA-256: `4e190c2a321783826b32f2c5fd07904ec00cafb62bd72e5380527e8ed0a7ac2b`.

The existing October exact-symbol file `research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv` contains 1,302 bars and hashes to `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6`. An exact timestamp join of the August/October files found 195 overlapping rows, 2026-08-03 09:00 through 2026-08-19 23:00 IST; mean August-minus-October close difference was 197.78974358974358. Diagnostic CSV SHA-256: `9e0d61cf24615df002a36e5e8805ada0682a69ac41a33bc745171413035e95e`; diagnostic JSON SHA-256: `5a101616016b0c4878684181c166813a1c6aa5e23d1ef4e943a2ac871fc8030e`.

This proves exact dated-symbol response identity and overlapping bars for these two files only. It does not establish their actual active intervals, selected historical roll, executable roll mechanics, approved adjustment, clean continuous series, or profitability. A subsequent bounded provider response failed OHLC validation (`DATA_VALIDATION_FAILED`, invalid OHLC envelope or negative volume); it was not persisted by the pre-fix collector. No retry was made in this execution to avoid further quota use. The current collector now persists rejected responses for later audit.

## Policy/configuration boundaries

No owner-approved historical roll rule, adjustment method, complete MCX holiday calendar, or authoritative IS/OOS split was present in the inspected artifacts. The bundle supports explicit per-underlying policies and approval IDs. The proposed candidate described in the task (roll at end of session three verified trading sessions before expiry; additive adjustment from genuine overlaps) is not marked approved by this code. Fewer-than-three remaining verified trading sessions is a separate eligibility check. Calendar results remain unverified without a sourced full calendar.

The collector can discover expiry symbols and download exact dated histories. FYERS data alone does not establish all historical listing/effective intervals or which contract should be held at every point in time under an approved policy; those fields must not be inferred from today’s chain. The prepared bundle is the explicit interface between observed provider sources and research decisions.

## Validation

Commands and results are recorded in `PREDIXA_MCX_CLEAN_REPLAY_VALIDATION_REPORT.md` (same-turn evidence; see exact execution below): compilation passed; focused tests passed **152** with 7 dependency deprecation warnings; actual offline `SDEnginePipeline.run` executed with TEST_ONLY deterministic inputs and did not require or emit a signal; strict validation of a missing bundle returned exit 2. The real API collection was bounded as above. No strategy P&L, IS/OOS result, clean export, or Task-4 reproduction was run.

## Remaining blockers

1. FYERS-validated exact expired histories for all five required underlyings and every required timeframe/date range; preserve rejected provider responses and resolve OHLC anomalies.
2. Verified per-contract listing/effective periods and dated-contract identity for the full range.
3. Actual overlapping outgoing/incoming contract bars at each transition.
4. Owner-approved roll selection and additive/ratio adjustment convention; no retrospective optimization.
5. Complete sourced historical MCX session/holiday calendar.
6. Approved coverage and IS/OOS split records.
7. Full bundle validation, point-in-time replay, raw contract execution mapping, setup reconciliation, and validated versioned export.
8. Task 4 realized-R OOS reproduction and separate owner authorization remain future work; MCX cannot be re-enabled by this task.

## Safety

No gate, sizing, allocator, scanner, broker-entry, NSEFO, or NSE_CASH implementation was changed. No trading engine was initialized through an order path, no orders were submitted, no scanner was launched, and no deployment occurred.
# Addendum — 2026-11-02 final integration pass

Automatic cache inventory and session-aware 60-minute-to-strategy-timeframe derivation were exercised. The focused pipeline passed 116 tests and the broader MCX/release safety set passed 160. The runner no longer requires hand-built JSON merely to report cached readiness, but the automatic candidate-to-validated-Task-2-bundle assembly and a single complete bundle-to-export fixture are still incomplete. It fails closed and emits an inventory rather than inventing active intervals, roll decisions, calendar sessions, or approval evidence. Overall engineering integration remains PARTIALLY COMPLETE; real historical validation and authoritative export remain blocked. See `PREDIXA_MCX_AUTOMATIC_BUNDLE_VALIDATION.md` and `PREDIXA_MCX_CLEAN_REPLAY_FINAL_STATUS.md` for final evidence.

