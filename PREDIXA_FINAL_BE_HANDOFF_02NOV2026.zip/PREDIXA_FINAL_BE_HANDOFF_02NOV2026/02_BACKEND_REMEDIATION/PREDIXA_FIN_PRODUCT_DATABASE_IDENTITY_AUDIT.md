# PREDIXA `Fin_product` Database Identity Audit

Audit mode: read-only. No migration, DDL, DML, scanner, order, or deployment action was performed.

## Identity result

**Database identity verified; environment ownership/classification unknown.** A one-off connection using the repository's configured credentials established the following effective identity:

| Attribute | Observed value |
|---|---|
| Configured endpoint | `192.168.1.16:3306` |
| Selected schema | `Fin_product` |
| DBMS | MySQL Community Server |
| Version | `8.0.45` |
| Server hostname | `4aadd5e4f931` |
| Server UUID | `a1c8fbf0-0e1d-11f1-a597-861103cd2f63` |
| Connection user (`USER()`) | `root@192.168.1.16` |
| Authenticated account (`CURRENT_USER()`) | `root@%` |
| Global read-only | `OFF` (`@@read_only=0`) |
| `super_read_only` | `OFF` |
| Server TLS support | Available (`have_ssl=YES`, TLS 1.2/1.3 advertised) |
| TLS on this audit connection | **Not in use** (`Ssl_cipher` empty) |

The server identity is now concrete, but neither hostname, UUID, private address, nor schema name proves who owns it or whether it is test, development, staging, or production. Repository runtime definitions also disagree: shared settings default to `Fin_product`, while the checked-in compose services select `Fin_prod`. No operator environment classification or ownership confirmation was available.

## Connection configuration and compatibility

- `shared/config/settings.py` loads dotenv when available and reads `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, and `DB_SCHEMA`. The observed values came from that configuration. Password contents are intentionally not recorded.
- The application dialect is `mysql+pymysql` (`shared/db/dbconn.py`). Installed versions used for this audit: SQLAlchemy `2.0.43`, PyMySQL `1.1.1`, Python `3.13`; the MySQL 8 server accepted the driver connection and metadata queries.
- `DBConnection` builds a DSN without an explicit port, therefore MySQL's default 3306 is used. Pool settings: `QueuePool`, size 10, overflow 20, timeout 30 seconds, recycle 1800 seconds, pre-ping enabled, rollback on return.
- The main engine has no TLS/CA verification `connect_args`; observed connection status confirms the connection was plaintext even though the server offers TLS.
- The repository includes credential literals in deployment/helper configuration. They are not reproduced here. This makes source-controlled/runtime secret handling a separate security risk; move credentials to a managed secret source and rotate exposed credentials before any write-enabled use.

## Privileges and server write posture

`SHOW GRANTS` reported that `root@%` has broad global privileges including `SELECT`, `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `ALTER`, `DROP`, `CREATE USER`, `GRANT OPTION`, shutdown/admin and replication privileges. This account is not suitable for a PAPER writer. The successful audit used a session-level read-only transaction setting and issued only identity, `SHOW`, and metadata/aggregate `SELECT` statements. The account itself remains write-capable and the server is writable.

The database had 50 listed tables/views, including application order/OMS, futures and commodity masters, signals, alerts, and user/subscription tables. Relevant table counts were obtained as aggregates only. Existing counts: `future_order_master` 418, `oms_order_bucket_future` 428, `commodity_order_master` 22, and `oms_order_bucket_commodity` 26. Grouping those four tables by execution provenance showed only `PAPER / GRADUATED_LIVE` rows (418/428 futures and 22/26 commodity/order-bucket respectively). This demonstrates pre-existing application use and shared business schema; it does **not** establish environment ownership or prove that other tables/jobs are non-production.

## Isolation classification

**`UNKNOWN_ENVIRONMENT` + `ISOLATION_NOT_VERIFIED` + `UNSAFE_FOR_PAPER_WRITES`.** Treat the selected schema as potentially shared until the operator/DB owner confirms ownership and deployment usage. No paper-write authorization is granted by this audit.

Reasons:

1. The account has global root/admin privileges and `GRANT OPTION`.
2. `@@read_only=0` and `super_read_only=OFF`.
3. PAPER and other application functions share the same schema and order tables.
4. The current connection did not negotiate TLS.
5. No verified dedicated PAPER schema/user or operator isolation statement exists.
6. Repository deployment configuration disagrees on schema (`Fin_product` versus `Fin_prod`).

## Commands/evidence

Read-only identity/metadata query run with the `finpro` Python environment using SQLAlchemy/PyMySQL. The session set `SET SESSION TRANSACTION READ ONLY`; it then ran `SELECT DATABASE()/USER()/CURRENT_USER()/@@hostname/@@port/VERSION()/@@read_only`, `SHOW GRANTS`, selected server variables/status, `information_schema.TABLES`, `COLUMNS`, `STATISTICS`, `KEY_COLUMN_USAGE`, and aggregate counts grouped only by execution mode/source. No customer or individual order fields were read. No database write or schema operation was attempted.

The first sandboxed connection was denied by network policy; an elevated read-only invocation succeeded. Exit status for the successful metadata session: 0.
