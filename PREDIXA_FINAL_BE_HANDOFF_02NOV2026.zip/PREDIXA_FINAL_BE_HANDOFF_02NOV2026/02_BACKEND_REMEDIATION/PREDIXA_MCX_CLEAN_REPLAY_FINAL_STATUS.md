# PREDIXA MCX Clean Replay — Final Status

## Status

- FYERS acquisition implementation: **COMPLETE** (bounded, cached, resumable interface; supported here by direct FYERS expired endpoints).
- FYERS historical coverage: **PARTIAL**.
- OHLC parser correction: **COMPLETE**; observed SEP failure is malformed provider OHLC, not parser defect.
- Automatic bundle assembly: **PARTIAL**. The runner inventories cache and derives compatible frames without hand-assembled input JSON, but it does not yet construct a validated Task-2 bundle/roll schedule from provider discovery. It exits blocked when required evidence is absent.
- Roll builder integration: **IMPLEMENTED; HISTORICAL VALIDATION BLOCKED**.
- Historical calendar: **UNAVAILABLE for requested full coverage**.
- TEST_ONLY regression/integration suite: **PASS** (116 passed). This exercises the SDEngine adapter, exporter, E1, roll-builder, and bundle-inventory components, but does not claim a single full five-underlying bundle-to-export replay.
- Real historical replay: **BLOCKED**.
- Authoritative trade export: **BLOCKED**; none generated.
- MCX trading activation: **BLOCKED**.

## Validation commands

1. `/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile audit/mcx_futures_backtest/run_clean_phase1.py audit/mcx_futures_backtest/fyers_expired_contract_collector.py audit/mcx_futures_backtest/derive_strategy_timeframes.py` — exit 0.
2. `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_fyers_expired_collector.py tests/test_mcx_derived_strategy_timeframes.py tests/test_mcx_contract_roll_adjustment.py tests/test_mcx_e1_session_boundary.py tests/test_mcx_clean_strategy_replay.py tests/test_mcx_clean_realized_r_export.py tests/test_mcx_clean_phase1_runner.py` — **116 passed**, one SQLAlchemy deprecation warning.
3. `/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.run_clean_phase1 full --mode TEST_ONLY` — **116 passed**, exit 0.
4. `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py` — **160 passed**, 7 existing deprecation warnings.
5. Automatic `assemble-bundle` command is documented in `PREDIXA_MCX_AUTOMATIC_BUNDLE_VALIDATION.md`; exit **2**, correctly blocked, report emitted.

The system `python` initially failed to import the pre-existing `sqlitedict` dependency during E1 tests; the repository's `finpro` Python environment includes it and all tests passed there. No live/paper scanner, broker API, order, or deployment was invoked. The FYERS request budget was exhausted at 10/10; no new provider request was attempted after that point.

The automatic inventory emitted 12 diagnostic frames: six from the response-hash-verified August CRUDEOILM contract and six from the October sidecar-only contract. The latter retain `cache_hashes_valid=false`, `SIDECAR_VERIFIED_NO_RAW_PROVIDER_RESPONSE`, and `authoritative_series=false`; they are useful for pipeline compatibility diagnostics only. There were no assembly read errors. This is not a validated Task-2 replay bundle. No Task 3 authoritative clean trade export or Task 4 edge verification was run. The existing integration remains non-authoritative until the complete automatic bundle builder and all data, policy, calendar, and split prerequisites are satisfied.
