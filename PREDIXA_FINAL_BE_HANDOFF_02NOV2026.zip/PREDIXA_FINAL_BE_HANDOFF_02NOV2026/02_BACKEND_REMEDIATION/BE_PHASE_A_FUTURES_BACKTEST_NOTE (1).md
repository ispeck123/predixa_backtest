# BE Work Order — Phase A: Clean Futures Backtest (NSEFO + MCX)


**Supersedes:** `FUT_REGIME_TF_BACKTEST_EXPORT_SPEC.md`, the `future_setups.csv` request, and the
universe notes. This is the single consolidated instruction. Harness run + export + evaluator change;
no production trading logic changes.

---

## Why a re-run (what the last two attempts got wrong)
1. `future_setups.csv` was a `SELECT` from the **live signals table** — 15 rows, no outcomes, no use.
2. `FRESH_FUTURES_CORE8_2Y` was a real backtest but **not usable for a verdict**:
   - **Wrong contract attribution:** every trade tagged to a **2026** expiry (29Sep/27Oct/23Nov)
     yet spanning Oct-2024→Sep-2026. A Sep-2026 contract can't trade in 2024 → the 3 "expiries" per
     symbol are near-duplicates of one stitched series → **~3× redundant trades**.
   - **Only 8 symbols; TF5 and TF25 emitted ZERO setups** (only TF1/TF2 populated).
   - `favorable_before_adverse`, `first_positive_bar`, `first_negative_bar` all **null** → the
     give-back / trailing-stop lever can't be measured (see §4, the key new ask).

## 1. Universe — BROAD for backtest (do NOT narrow)
Full definition (backtest set, live set, exact names) is in **`FUTURES_UNIVERSE_SPEC.md`** — the single
source; don't restate it. Two directives that must hold for this run:
- Sweep the **full liquid F&O list** (target ≥ ~80–100 underlyings) + **NIFTY, BANKNIFTY**. Narrowing
  is what made core-8 useless.
- Tag every row `instrument_class` ∈ {stock, index}.

## 2. Contract continuity — the core fix (shared with MCX)
- **Correct contract-live-at-trade attribution:** each historical bar belongs to the contract
  actually trading then. Emit `contract_live` per row. Do NOT tag old history with a current expiry.
- **Drop the 3× duplication** (don't replay the same stitched series under 3 expiry labels).
- **Back-adjusted continuous series** per underlying (ratio-adjust at each roll) with **roll-boundary
  exclusion** — zone detection / violation / base / legout / retest must NOT span a roll seam.
- Audit the existing NSEFO stitching first; reuse if sound.

## 3. Timeframes
- Emit **all production futures TFs**; **ensure none is silently empty** (core-8 lost TF5/TF25).
  Confirm why the futures scanner produced zero TF5/TF25 setups and fix so they populate.

## 4. Path metrics + exit-lever measurability — the KEY new ask
The give-back lever (breakeven/trailing stop) is the most promising fix but is currently unmeasurable.
Fix the evaluator to emit real intra-trade path:
- Populate `favorable_before_adverse`, `first_positive_bar`, `first_negative_bar` (were null).
- Emit a per-trade **bar path** (or enough ordered excursion data to price a trailing stop).
- **Run an in-evaluator trailing/breakeven-stop variant** alongside the baseline: for each trade,
  also record the outcome/R under "move stop to breakeven once +0.5R favorable" (and one trailing
  variant). This lets us measure the exit lever directly instead of approximating.

## 5. Export schema (one row per resolved trade)
`stock_name, instrument_class, contract_live, strategy_tf, side, setup_timestamp, entry_price,
stop_price, target_price, exit_price, outcome, gross_r, R_realized, e_regime, a_regime, zone_signature,
rrr` — PLUS the fixed path fields (§4) and the trailing-stop-variant outcome/R.
- BUY side is the priority (SELL is OFF), but export both.
- `e_regime`/`a_regime` = engine emission-time TrendContext (as core-8 already did — keep it).

## 6. MCX (parallel track — bullion + energy only)
- Same contract-continuity fix as §2, PLUS the **E1 session-gap** fix (23:30→09:00 IST must be a
  boundary; no zone/violation/base/legout/retest across it) — spec already delivered.
- Instruments: GOLD/GOLDM, SILVER/SILVERM, CRUDEOIL/CRUDEOILM, NATURALGAS/NATGASMINI.

## 7. Live-liquidity feed
Handled separately — see `BE_ACCOMPANYING_NOTE.md` §B (rank by value-traded; add OI later). Not part
of this backtest run.

---

## Deliverable
`nsefo_fut_regime_tf_backtest_labeled.csv` (broad universe, clean attribution, all TFs, path fields
fixed, trailing-stop variant) + the MCX equivalent. Package like the core-8 evidence bundle.

## End Objective (I'll do once you deliver the dataset)
Re-run the regime×TF OOS **split by instrument_class** (index / stock / commodity), measure the
trailing-stop lever directly, stress-test any positive cell (symbol-diverse, period-consistent), and
classify FULL/MIN/EXCLUDE per class. Go-live only per class/cell that passes, via the Option-3
single-lot + tracking-error gate.
