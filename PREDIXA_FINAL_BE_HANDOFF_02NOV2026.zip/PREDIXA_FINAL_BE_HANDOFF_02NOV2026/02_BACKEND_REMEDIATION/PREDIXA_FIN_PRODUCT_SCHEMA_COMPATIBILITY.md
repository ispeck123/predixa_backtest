# `Fin_product` Schema Compatibility

Scope: compare live read-only MySQL metadata with repository models and the unapplied MCX paper-observation migration. No DDL or DML was executed.

## Observed schema

All four primary order tables exist as InnoDB tables:

| Table | Row count (aggregate) | Primary key | Execution fields | MCX idempotency/status fields |
|---|---:|---|---|---|
| `future_order_master` | 418 | `order_id` | `execution_mode`, `candidate_source` present | Not applicable to current MCX observation migration |
| `oms_order_bucket_future` | 428 | `bucket_id` | `execution_mode`, `candidate_source` present | Not applicable to current MCX observation migration |
| `commodity_order_master` | 22 | `order_id` | `execution_mode`, `candidate_source` present | `idempotency_key`, `edge_validation`, `paper_updated_at`, `trading_status` absent |
| `oms_order_bucket_commodity` | 26 | `bucket_id` | `execution_mode`, `candidate_source` present | `idempotency_key`, `edge_validation`, `paper_updated_at`, `trading_status` absent |

Other relevant existing tables include `commodities_master` (12 rows), `futures_master` (564 rows), and `trade_signals` (present; count not queried). All four order tables have their primary-key index only. No foreign keys were reported for these tables. There is no unique index for a setup/idempotency key. Nullable execution provenance fields exist in the live tables; the audit did not inspect individual order data.

## Model and migration comparison

The repository models are in `shared/db/db_model.py`:

- `Future_Order` → `future_order_master`
- `Commodity_Order` → `commodity_order_master`
- `OMSOrderBucketFuture` → `oms_order_bucket_future`
- `OMSOrderBucketCommodity` → `oms_order_bucket_commodity`
- `TradeSignal` → `trade_signals`
- `CommoditiesMaster` → `commodities_master`

The four execution provenance columns required by `scripts/db_migrations/20261025_phase1_execution_provenance.sql` already exist in all four live tables. The migration must not be blindly rerun.

The fields in `scripts/db_migrations/20261102_mcx_paper_observation_idempotency.sql` are absent from both commodity tables. **That migration is required for the current MySQL-backed model shape**, but it has not been applied. It adds four nullable columns to each commodity table and a unique index over nullable `idempotency_key`. It must only be reviewed and applied to a subsequently verified isolated PAPER target, never this currently unclassified schema.

## Compatibility matrix

| Capability | NSEFO PAPER on current schema | MCX PAPER observer on current schema |
|---|---|---|
| Existing order/bucket tables | Present | Present |
| `execution_mode`, `candidate_source` | Present | Present |
| Required master/signal tables | Present (`futures_master`, `trade_signals`) | Present (`commodities_master`, `trade_signals`) |
| Idempotency uniqueness at DB boundary | Absent in observed future tables | Absent until migration |
| Edge/status observation fields | Not required by current future model | Absent until migration |
| Repository runtime accepts this DB | Yes, shared `DBConnection` | **No**; it explicitly requires marked SQLite under local PAPER root |
| Safe write authorization | No | No |

## Backward-compatibility and migration risks

- Existing nullable provenance fields mean legacy rows can remain unclassified; current code must continue failing closed for REAL approval unless `execution_mode=REAL` is explicit.
- Adding unique nullable idempotency columns is compatible with multiple historical NULL values in MySQL, but migration preflight must check existing duplicate non-NULL keys before index creation.
- The migration targets live commodity/order tables used by other processes. Even additive DDL can affect schema locks, deployment compatibility, and monitoring/API consumers.
- The ORM's `unique=True` declaration is not proof the live unique indexes exist; metadata showed they do not.
- Existing tables do not have foreign keys tying bucket, order, and signal rows together. Transactional application insertion currently provides grouping, but database-level referential guarantees are absent.
- The migration does not provide DB isolation. A PAPER marker field or unique key in the shared schema is not a substitute for schema/user isolation.

## Status

`SCHEMA_MIGRATION_REQUIRED` for MCX MySQL support. NSEFO field compatibility exists, but order queries and shared-schema operation do not constitute safe database isolation. No schema changes were made.

The focused offline PAPER/REAL boundary suite passed 46 tests; the broader related suite passed 359 tests. No test connected to or modified this live MySQL target.
