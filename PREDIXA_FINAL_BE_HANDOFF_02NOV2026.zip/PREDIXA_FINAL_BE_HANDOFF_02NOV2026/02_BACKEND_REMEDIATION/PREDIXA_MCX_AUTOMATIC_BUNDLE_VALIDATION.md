# Automatic MCX Bundle Validation

## Implemented path

`audit/mcx_futures_backtest/run_clean_phase1.py` now supports `assemble-bundle` and `full` without requiring hand-built JSON just to inventory cached evidence. It inventories cached FYERS expiry/symbol responses, exact contract OHLCV, rejected responses, and the historical dated-raw OCT sidecar. It checks hashes and exact symbol identity, writes `bundle_readiness.json` plus `contract_acquisition_manifest.csv`, and derives session-aware research timeframes from compatible 60-minute inputs. Derived outputs retain `RAW_DATED_CONTRACT` basis and `authoritative_series=false`. **This is readiness/inventory assembly, not full construction of a validated Task-2 bundle or roll schedule.** That remains a software integration gap as well as a data/policy blocker.

The strategy configuration actually uses monthly, weekly, daily, 240m, 120m, and 60m input stacks. The derivation module builds those from 60m by E1 session. It does not interpolate. The cached August source generated 195 60m, 104 120m, 52 240m, 13 daily, 3 weekly, and 1 monthly bars. The sidecar-only October input generated 1,302 60m, 642 120m, 321 240m, 81 daily, 20 weekly, and 6 monthly bars; it remains explicitly unhashed at provider-response level. These counts are derivation diagnostics, not historical completeness evidence.

The assembly review fixed timestamp comparison in the older FYERS sidecar (parse timestamps before comparison), normalizes `timestamp_ist` through the shared bar reader, allows sidecar-only data to be resampled diagnostically while leaving `cache_hashes_valid=false`, and associates expiry results to exact symbols only where a matching expiry exists. Regression coverage proves sidecar bars remain non-authoritative while being available for offline derivation.

## Actual command result

`/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.run_clean_phase1 assemble-bundle --data-root research/mcx_fyers_expired --output-dir research/mcx_clean_phase1/assembled --coverage-start 2025-11-03 --coverage-end 2026-11-02 --daily-request-limit 10`

Exit **2** as designed. It wrote a machine-readable blocked readiness report. No authoritative bundle was emitted. Blockers include no exact OHLCV for four underlyings, unresolved active intervals, rejected provider responses, incomplete historical session/holiday calendar, unapproved roll policy, incomplete roll price pairs, missing approved split date, and incomplete all-underlying coverage.

The TEST_ONLY route executes the regression/integration suite (116 passing); current tests exercise the real strategy adapter and exporter as connected components, but not one full five-underlying automatic bundle-to-export run. The full historical replay still requires a complete validated bundle; the runner does not silently substitute the 216 stitched files or infer missing active intervals. The automatic candidate-to-validated-bundle and complete full replay wiring remain incomplete and are not reported as engineering-complete.
