# PREDIXA MCX Historical Contract Coverage

Coverage requested by the local runner: **2025-11-03 through 2026-11-02**. Current request budget recorded in `research/mcx_fyers_expired/.daily_request_budget.json`: 10/10 on 2026-11-02, 0 remaining. No further FYERS requests were issued.

| Underlying | Verified exact dated contracts | Usable bars | Coverage / status |
|---|---|---:|---|
| GOLDM | None | 0 | FYERS expiry endpoint returned 12 expiry dates (2025-11-05 through 2026-10-05); exact expired symbols and candles were not collected. |
| GOLDGUINEA | None | 0 | No expiry/symbol/candle cache. |
| SILVERM | None | 0 | No expiry/symbol/candle cache. |
| CRUDEOILM | AUG 2026 | 195 | FYERS exact dated response, 2026-08-03 09:00 to 2026-08-19 23:00 IST. SEP response rejected on two invalid provider OHLC rows. |
| NATGASMINI | None | 0 | No expiry/symbol/candle cache. |

CRUDEOILM OCT 2026 has a local FYERS `cont_flag=0` sidecar and 1,302 60-minute rows (2026-05-22 to 2026-10-08), but its raw provider response is absent. It is therefore `SIDECAR_VERIFIED_NO_RAW_PROVIDER_RESPONSE`, not source-hash verified. August/OCT overlapping prices were compared as a diagnostic only; overlap does not prove the right roll pair, effective date, or executable roll.

Only CRUDEOILM August bars are verified exact-response raw dated bars. None of the five underlyings has enough verified neighboring contracts, historical effective/listing intervals, complete MCX calendar coverage, approved roll policy, or approved IS/OOS split for an authoritative series or replay. The inventory CSV `PREDIXA_MCX_FYERS_COLLECTION_PROGRESS.csv` records each discovered/cached item and its provenance class.

## Collection workload still required

At the next authorized quota window, query expiry dates for each product using a past `range_to`; query exact expired symbols for every relevant expiry; retrieve contract OHLCV in compliant chunks at the validated 60-minute native source resolution; collect overlapping outgoing/incoming contracts; validate raw response and normalized hashes; and resume from successful cache entries. Do not promote sidecar or continuous data into verified raw history.
