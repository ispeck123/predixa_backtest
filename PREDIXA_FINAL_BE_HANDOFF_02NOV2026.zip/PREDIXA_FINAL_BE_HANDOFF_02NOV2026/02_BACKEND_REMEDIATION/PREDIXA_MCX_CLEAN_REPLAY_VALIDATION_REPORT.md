# PREDIXA MCX Clean Replay — Validation Report

Date: 2026-11-02. TEST_ONLY fixtures are software tests, never market evidence.

Repository HEAD observed: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba`. Worktree is dirty/uncommitted; HEAD is not a release revision containing these changes.

## Commands actually run

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile audit/mcx_futures_backtest/compare_raw_contract_overlap.py audit/mcx_futures_backtest/fyers_expired_contract_collector.py audit/mcx_futures_backtest/clean_strategy_replay.py audit/mcx_futures_backtest/run_clean_phase1.py audit/mcx_futures_backtest/contract_roll.py audit/mcx_futures_backtest/clean_realized_r_export.py scripts/edge_repro_check.py
```

Result: exit 0.

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py
```

Result: **152 passed, 7 warnings, exit 0**. Warnings were dependency deprecations from SQLAlchemy, Pydantic, and pkg_resources.

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.run_clean_phase1 validate-data --bundle /tmp/predixa_nonexistent_bundle.json
```

Result: expected `BLOCKED_MISSING_DATA`, exit **2**; no output export created.

The broad `git diff --check` returned exit 2 because of trailing whitespace in other existing dirty working-tree files, including commodity/futures order APIs, socket, and order endpoint. It does not identify whitespace in the Task-2/Task-3 files checked separately. Those unrelated changes were not edited as part of this pipeline work.

## Integration evidence

- Offline tests invoke the existing `SDEnginePipeline.run` via `clean_strategy_replay.py` with TEST_ONLY synthetic research candles; strategy engine initializes only for offline signal analysis. It does not initialize scanners, format orders, or call broker methods.
- An adapter integration test returns only the existing engine’s `best_setup_long`, preserves E/A/X regimes and stable setup ID, maps adjusted levels to raw contract basis, and sends the setup to `build_clean_export` with exact dated execution bars.
- Export test verifies 14-column schema, `gross_r`, distinct `mfe_R`, partition/provenance, and bars-held behavior. Same-bar stop/target is stop-first and flagged; favorable ambiguous exit-bar excursion is not asserted.
- FYERS adapter parser and collection tests cover symbol/expiry identity, errors, chunking/cache/resume and request caps with mocked responses. Mock tests do not count as a real endpoint success.
- Actual FYERS bounded requests and two exact CRUDEOILM source overlap are documented in `PREDIXA_MCX_FYERS_EXPIRED_DATA_ACCESS_REPORT.md`.

## Clean replay status

The authoritative bundle has not passed Task-2 prerequisites. A full `full`/`replay` command was therefore not run against a fabricated or stitched bundle, and no `mcx_trade_export.csv` was written. Current valid data covers only two CRUDEOILM exact dated symbols and has no approved historical selection/roll, complete calendar, five-underlying coverage, full timeframe coverage, or approved IS/OOS split. One separate API response failed OHLC validation and needs a controlled retry.

**Status: CLEAN_EXPORT_BLOCKED — DATA, POLICY, CALENDAR, COVERAGE, AND SPLIT APPROVAL.** No Task-4 edge reproduction or MCX promotion was attempted.
# Addendum — final automatic assembly and test results, 2026-11-02

The TEST_ONLY command passed 116 focused tests. The broader MCX, gate, release-preflight, and drop-verifier test command passed 160. The assembly command returned expected exit 2 and emitted `bundle_readiness.json`; it correctly withheld an authoritative replay bundle and trade export. Twelve derived frames were generated (six from response-hash-verified August source, six from the October sidecar-only source), all non-authoritative and separate from executable prices. No real historical replay, clean export, or Task 4 edge reproduction was performed. The assembly currently inventories and derives inputs but does not build a complete validated Task-2 bundle or run a single full fixture through bundle validation, strategy replay, and exporter.

