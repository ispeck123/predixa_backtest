# PREDIXA Pending Tasks — Final Assessment

| ID | Task | Code complete? | Actual runtime/data verified? | Status | Exact blocker | Resolution | Owner |
|---|---|---:|---:|---|---|---|---|
| A1 | MCX Task 1 — E1 | Yes | Regression verified; full historical diagnostic unavailable | COMPLETE | None for code correctness | Optional verified-data diagnostic only | Data provider / operator |
| A2 | MCX Task 2 — roll correction | Yes | No | CODE_COMPLETE_DATA_BLOCKED | Missing five-underlying raw dated contract chains, valid overlap/effective intervals, calendar, approved policy | Obtain FYERS exact raw data and approvals | Data provider / owner / operator |
| A3 | MCX Task 3 — realized-R export | Yes | No | CODE_COMPLETE_DATA_BLOCKED | Task-2 strict validation bundle cannot pass | Complete A2 and approve split | Data provider / owner |
| A4 | MCX Task 4 — edge reproduction | Yes | No | CODE_COMPLETE_DATA_BLOCKED | No authoritative export; no independent split/statistical criteria | Complete A3, publish independent config, run checker | Owner / operator |
| B1 | NSEFO PAPER startup | Yes | No | BLOCKED_ENVIRONMENT | No verified isolated DB or FYERS read-only runtime configuration | Operator supplies approved local DB, credentials, and current runtime mapping | Operator |
| B2 | NSEFO local DB persistence | Yes, isolated tests | No intended DB | BLOCKED_UNVERIFIED_DATABASE | Default DB is configured remote MySQL; no approved local target | Verify target identity, run bounded write/read/cleanup | Operator |
| B3 | MCX PAPER startup | Yes, one-shot local runner | No | BLOCKED_ENVIRONMENT | Local-paper env variables/marked DB/master rows are absent; FYERS runtime unavailable | Provision isolated DB, master rows, and a verified job | Operator |
| B4 | MCX local DB persistence | Yes, isolated tests | No intended DB | BLOCKED_UNVERIFIED_DATABASE | No marked `LOCAL_PAPER` SQLite database under configured root | Initialize/authorize one and run bounded observation | Operator |
| B5 | Monitoring APIs | Yes, handler tests | No live server | CODE_COMPLETE_RUNTIME_PENDING | Backend has not been started with local-paper environment | Start local backend after DB verification and query endpoints | Operator |
| B6 | Paper-order lifecycle | Candidate/monitoring scope yes | NSEFO evaluator tests only; MCX observation fill lifecycle no | CODE_COMPLETE_RUNTIME_PENDING | MCX observation intentionally lacks fill/exit/P&L service | Not required for current observation acceptance; separately authorize lifecycle scope if desired | Owner |
| B7 | Full relevant regression suite | Yes | Yes | COMPLETE | None | 351 tests passed | Developer |
| B8 | MCX REAL safety | Yes | Regression verified | COMPLETE | None for repository controls | Retain blocks through any deployment | Developer / operator |

## Direct decisions

- Full relevant regression suite: **PASS — 351 tests**.
- NSEFO PAPER can run locally: **NOT VERIFIED**.
- MCX PAPER observation can run locally: **NOT VERIFIED**.
- Simulated orders can be stored in the intended local database: **NOT VERIFIED**; isolated SQLite persistence is proven.
- MCX REAL remains blocked: **YES**, verified by gate, allocator, scanner, approval, and broker-boundary tests.
- Final ZIP preparation: **not yet ready for an operationally validated handoff**. It is ready to preserve current source/test/report evidence, but the requested local runtime/database validation is still pending operator-controlled prerequisites.
