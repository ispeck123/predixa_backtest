# PREDIXA Release Readiness — Phase 2 Verification

Assessment date: 02 November 2026. No deployment, service restart, broker call,
order submission, or production endpoint access was performed.

## Decision

**Repository MCX safety controls: READY FOR CODE REVIEW.**

**Production release / MCX re-enablement: NOT READY.** Clean contract-aware
evidence, explicit authorization, release-pipeline enforcement, and external
runtime verification are still absent. NSEFO and NSE_CASH behavior is outside
this change and preserved.

## Phase 3 safety-release preparation

`scripts/release_preflight.py` and
`config/predixa_release_permission_baseline.json` now provide the minimal
repository-owned release entry point. The checked-in baseline is deliberately
not treated as approval: both safety and promotion use an externally supplied
approved baseline located outside the checkout. Safety mode requires that the
active gate, checked-in baseline, and external approved reference all match;
any difference is a nonzero HOLD. Promotion additionally requires a previous
external approved reference and realized-R evidence for every changed segment.
This prevents an unreviewed gate-plus-baseline edit from masquerading as a
safety-only release.

Executed Phase 3 preflight:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python scripts/release_preflight.py \
  --mode safety --python /home/ispeck/anaconda3/envs/finpro/bin/python \
  --approved-baseline /secure/predixa/approved/predixa_release_permission_baseline.json \
  --report-dir /tmp/predixa-safety-preflight
```

Result: **PASS** — C1–C12 passed and 33 preflight regression tests passed.
The expanded focused suite, including external-baseline and generic-broker
boundary tests, is **33 passed**.

No CI platform is present in the repository. The preflight is therefore
`PARTIALLY_COMPLETED` as an enforcement mechanism until the external deployment
workflow invokes it and rejects nonzero status. The safety release checklist is
in `PREDIXA_SAFETY_HOTFIX_RELEASE_CHECKLIST.md`.

## Verified code protections

| Protection | State | Evidence |
|---|---|---|
| Regime permission | COMPLETED | `gate()` normalizes `MCX` exchange spelling/case/whitespace and denies before TF, symbol, or regime parsing. GOLD, GOLDM, GOLDGUINEA, CRUDE, CRUDEOILM, missing symbols, and malformed TFs deny. |
| Capital allocation | COMPLETED | `SEGMENT_NET_R["MCX"] == -0.18`; `CapitalAllocator.segment_status("MCX")` is `BLOCKED`. |
| Graduated scanner | COMPLETED | `MCXGraduatedLiveScanner.run()` blocks before engine, signal insertion, or candidate persistence. `persist_mcx_candidate()` independently blocks. |
| Legacy scheduled scanner | COMPLETED | `SetupScannerOrchestrator_FC.run()` returns `MCX_EXECUTION_BLOCKED` before expiry work or `process_setup_fc`; this covers Dagster commodity jobs. |
| Existing REAL buckets | COMPLETED | Commodity approval rejects `approved` MCX requests before DB/broker work. Rejection/cancellation remains available. |
| Legacy PAPER creation | COMPLETED | `create_commodity_order` returns `MCX_EXECUTION_BLOCKED` before it creates a paper commodity order. |
| Generic broker endpoints | COMPLETED | Explicit `MCX:` entry symbols are rejected before risk checks or broker calls; cancellation and exit routes remain available for operator remediation. |
| NSE_CASH boundary | PENDING_OWNER_APPROVAL | `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and `UP/UP/25` remain in the active gate. The separate proposed patch is unapplied. |

Focused test execution:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_tf_regime_gate_by_exchange.py tests/test_mcx_remediation_guardrails.py \
  tests/test_commodity_bucket_approval.py tests/test_mcx_golive_policy.py
```

Result: **28 passed**, with 7 third-party deprecation warnings. Tests include
direct approval, direct persistence, both scanner paths, aliases, malformed
inputs, capital allocation, and historical MCX policy expectations.

## Verifier and release integration

| Check | Evidence basis | Failure behavior | Integration status |
|---|---|---|---|
| `scripts/predixa_drop_verifier.py` | AST/source regression checks, including C12 for MCX holds | Any FAIL exits 1 and prints `HOLD — DO NOT DEPLOY`; unsupported/missing source produces NA/WARN where applicable | PARTIALLY_COMPLETED: runs correctly (`C1–C12 PASS`), but no CI, Makefile, release job, or container deployment hook calls it. |
| `scripts/edge_repro_check.py` | `gross_r`, entry, stop, timestamp, regime, TF, outcome, and symbol; calculates net realized R after costs | Missing schema fields exit 2; a missing/empty OOS result is non-positive and exits nonzero; MCX empty live schedule exits 1 fail-closed | PARTIALLY_COMPLETED: code is fail-closed, but no release path supplies an approved evidence artifact or invokes it. |
| `scripts/confirm_peak_vs_realized.py` | Requires original Phase-A schema including OOS partition and `mfe_R` | Missing fields exit 2 | BLOCKED_MISSING_ARTIFACT: original compatible export is absent. |

Executed commands:

```bash
python3 scripts/predixa_drop_verifier.py . --report-dir /tmp/predixa-phase2-drop-verifier
# PASS, exit 0, C1–C12

python3 scripts/edge_repro_check.py \
  audit/mcx_futures_backtest/results/mcx_phase_a_available_history/mcx_fut_regime_tf_backtest_labeled.csv \
  --segment MCX --rt 0.001 --split 2026-01-01 --universe GOLDM,CRUDEOILM
# FAIL CLOSED, exit 1: no live-eligible MCX cells

python3 scripts/confirm_peak_vs_realized.py \
  audit/mcx_futures_backtest/results/mcx_phase_a_available_history/mcx_fut_regime_tf_backtest_labeled.csv
# BLOCKED, exit 2: missing A_regime, E_regime, mfe_R, partition, symbol
```

Automatic integration cannot be completed safely because the repository has no
CI configuration, release workflow, package/publish script, or deployment
preflight hook. Docker Compose starts web services only; adding research-evidence
checks to application boot would not provide a release gate and could make a
running service fail unpredictably. The required release procedure must invoke
both verifier commands in CI or the external deployment workflow and fail the
release on any nonzero exit.

## Phase-A root-cause finding

`audit/derivatives_backtest_common/analyze_phase_a.py:9` aggregates realized
performance using `avg_r=('gross_r','mean')`. Repository search found no
available Phase-A script or notebook aggregating `mfe_R` as expectancy. The
available code therefore does **not** prove the alleged MFE aggregation defect.

The historical claim remains unsupported: the untracked confirmation helper
references positive claims, but the required original `mcx_trade_export.csv`,
publication/run ID, and producer notebook/script are missing. The closest file,
`mcx_fut_regime_tf_backtest_labeled.csv`, has `source_symbol`, lowercase
`e_regime`/`a_regime`, `max_favorable_excursion`, and no `partition` or `mfe_R`;
it cannot demonstrate the claimed OOS MFE-versus-realized comparison. Schema
validation was not weakened to accept it.

## Historical-data readiness

`python3 -m audit.mcx_futures_backtest.preflight` reports 216 source files, 27
contract keys, and 9 symbols. `mcx_contract_inventory.csv` shows three nominal
expiries per underlying, eight frame files each, all marked
`STITCHED_OR_CONTINUOUS`:

| Underlying | Nominal contract keys | Coverage represented in inventory |
|---|---:|---|
| CRUDEOILM, GOLDM, GOLDGUINEA, NATGASMINI, SILVERM | 3 each | Mostly 2025-11-03 to 2026-11-02 |
| GOLDPETAL, ZINCMINI | 3 each | Some frames begin 2020-01-01; others later |
| GOLDTEN | 3 | Mostly 2025-03-31 to 2026-11-02 |
| SILVER | 3 | Some frames begin 2020-01-01; later contracts have shorter coverage |

The filenames contain expiry-like identifiers, but the importer requests FYERS
history with `cont_flag="1"`; the source itself warns that these are
stitched/continuous. Consequently, the assets do not verify dated-contract
OHLC attribution, actual roll time, roll price, back-adjustment amount/method,
or executable historical contract price. E1 is defined in `scripts/mcx_session.py`
as the 23:30→09:00 IST seam and is enforceable in the engine, but this does not
repair continuous-series roll provenance.

An existing legitimate collection adapter exists in
`data_fetchers/fyers/indian_commodity_data_updater.py`: it retrieves the FYERS
MCX master and historical candles. It currently sets `cont_flag="1"`, so it
cannot satisfy clean-series requirements as implemented. Required externally
verified input contract:

1. Provider-supported dated MCX futures identifier and `cont_flag`/request
   convention for each historical contract.
2. Immutable raw OHLCV per `(underlying, exchange contract ID, expiry, interval)`
   with timezone, retrieval timestamp, provider, and file hash.
3. Exchange/provider roll calendar: roll timestamp, outgoing/incoming IDs,
   roll price, and deterministic selection rule known at or before the roll.
4. Back-adjustment method and adjustment series, separate adjusted research
   prices from executable dated-contract prices.
5. E1 session/calendar specification, fees/slippage assumptions, OOS boundary,
   and trade export containing `partition`, `mfe_R`, realized `gross_r`, and
   all required cell identifiers.

Only then may a clean offline replay and `edge_repro_check.py` run occur. This
is `BLOCKED_MISSING_DATA`, not a negative or positive edge conclusion.

## Runtime and deployment verification

Repository-owned launcher paths are guarded: direct MCX scanner CLI/programmatic
entry, Dagster `mcx_graduated_scanner_op`, legacy Dagster commodity scan jobs,
direct PAPER order creation, and REAL commodity-bucket approval. Repository
deployment definitions include `docker-compose.yml`, `fpv2_latest.yml`,
`manage_backend.sh`, and alert-engine scripts. No service unit, CI pipeline, or
production scheduler state is versioned; the checked-in commodity Dagster
schedules are `STOPPED`, but deployed state is unknown.

An operator with production access should run these read-only checks before any
release; do not restart services or invoke scanner jobs:

```bash
git rev-parse HEAD
git status --short
grep -RIn --exclude='*.pyc' 'MCX_EXECUTION_SUSPENDED\|MCX_EXECUTION_BLOCKED' scripts apps
python3 scripts/predixa_drop_verifier.py . --report-dir /var/tmp/predixa-preflight
systemctl list-units --type=service --all | grep -Ei 'predixa|dagster|mcx|alert'
systemctl list-timers --all | grep -Ei 'predixa|dagster|mcx'
ps auxww | grep -Ei '[d]agster|[m]cx_graduated|[s]canner_fc|[s]canner.py'
docker compose ps
docker ps --format '{{.Names}} {{.Image}} {{.Command}}'
dagster schedule list  # if Dagster CLI is installed for the deployed instance
```

Also query the production order store read-only for pending/approved commodity
buckets and reconcile any pre-existing broker GTTs before release. The repository
cannot establish whether external cron, systemd, an older image, another clone,
or a manual broker action remains capable of submitting MCX orders.

## Required approvals and blockers

- `PENDING_OWNER_APPROVAL`: remove the four NSE_CASH cells only through the
  unapplied proposed patch.
- `BLOCKED_MISSING_ARTIFACT`: original Phase-A export, publication run ID, and
  producer analysis artifact.
- `BLOCKED_MISSING_DATA`: verified dated MCX raw history plus roll/back-adjustment
  and execution specifications.
- `PARTIALLY_COMPLETED`: CI/deployment workflow integration of both verifiers.
- Separate owner authorization is mandatory for any future MCX PAPER or REAL
  enablement, even after a verified OOS realized-R PASS.

## Final approved NSE_CASH reduction — 02 November 2026

The evidence-based removal of `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and `UP/UP/25`
was not pre-authorized and was owner-ratified after the fact on 02 November
2026. The active gate no longer permits them; focused regression
coverage verifies DENY for all four and retention of every allowed cash cell.
The candidate baseline contains the same reduced schedule. It must be copied
unchanged to the separately protected approval store before a release.

`release_preflight.py --mode reduction` is the release path for this change.
It requires external `--previous-approved-baseline` and `--approved-baseline`,
requires both the active gate and checked-in candidate to match the latter, and
rejects anything other than strict permission removal. A permission increase
continues to require `--mode promotion` and valid realized-R evidence. Local
candidate validation passed C1-C12 and 36 focused tests; it is not an external
approval or a production validation.
