# PREDIXA Regression Final Results

Repository revision reviewed: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba` on branch `prod`. The worktree contained prior unrelated/remediation changes and was preserved.

## Date-dependent regression correction

`tests/test_futures_approval.py::test_scanner_row_refreshes_a_stale_rollover_contract_map` previously embedded 27-Oct-2026 as its candidate expiry. On 02-Nov-2026, production expiry validation correctly rejected it. The test now derives a contract date 30 days in the future, derives its expected FYERS contract/cache values, and continues to assert stale cached-contract replacement. `test_expired_futures_candidate_is_rejected_before_risk_or_broker_access` explicitly verifies the original expiry-safety boundary.

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_futures_approval.py
16 passed, exit 0
```

## Final relevant suite

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_paper_order_monitoring.py
351 passed, 25 warnings, exit 0
```

This suite covers E1, roll builder, realized-R exporter, clean replay runner, Task-4 edge validation, release preflight, drop verifier, MCX gate/allocator/scanner/approval/broker safety, NSEFO paper persistence, MCX observation persistence, monitoring, and broker isolation.

## Compilation

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile scripts/mcx_session.py data_fetchers/fyers/indian_commodity_data_updater.py audit/mcx_futures_backtest/contract_roll.py audit/mcx_futures_backtest/clean_realized_r_export.py audit/mcx_futures_backtest/clean_strategy_replay.py audit/mcx_futures_backtest/fyers_expired_contract_collector.py audit/mcx_futures_backtest/run_clean_phase1.py scripts/edge_repro_check.py scripts/mcx_phase1_edge_validation.py scripts/paper_observation.py scripts/paper_observation_runtime.py scripts/mcx_graduated_live_scanner.py scripts/futures_graduated_live_scanner.py
exit 0
```

## Warnings

Warnings are existing SQLAlchemy declarative/default, Pydantic v1 validator, `pkg_resources`, and futures-reconciliation `utcnow` deprecations. No warnings were suppressed and none changed the exit status.

## Diff checks

`git diff --check` passed for the scoped scanner/model/test changes. The already-dirty `apps/backend/api/bucket_orders_commodity.py` contains prior trailing-whitespace lines outside the added monitoring endpoint; those unrelated lines were left untouched.
