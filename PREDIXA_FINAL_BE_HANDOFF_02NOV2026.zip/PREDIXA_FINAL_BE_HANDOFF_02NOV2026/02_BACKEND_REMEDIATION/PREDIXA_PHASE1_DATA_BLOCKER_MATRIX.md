# PREDIXA MCX Phase-1 Data Blocker Matrix

| Task | Engineering state | Exact blocker | Type | Can current repository access resolve it? | Required next action | Owner |
|---|---|---|---|---|---|---|
| Task 1 — E1 session gap | Complete and regression-tested | Historical before/after signal-count diagnostic lacks full verified inputs; code correctness itself is not blocked | Data limitation | No | Supply validated historical dated-contract coverage if historical diagnostic counts are required | Data provider / operator |
| Task 2 — rolls | Builder implemented and synthetic integration-tested | No valid five-underlying dated-contract chain, no verified adjacent roll pair or effective/listing intervals; SEP CRUDEOILM response quarantined for two `open > high` rows; October sidecar lacks original response hash | Provider data | No | FYERS bounded collection of exact expired symbols and raw responses for GOLDM, GOLDGUINEA, SILVERM, CRUDEOILM, NATGASMINI; retain hashes and overlap observations | Data provider / operator |
| Task 2 — calendar and policy | Interfaces implemented | Complete official historical MCX session/holiday/special-session calendar absent; no independent roll-selection/adjustment approval | Approval and data | No | Owner approves policy; operator supplies authoritative calendar and source/version | Owner / operator |
| Task 3 — clean realized-R export | Exporter/replay implemented and tested | Task-2 validation gate has no `RAW_DATED` all-underlying, roll, calendar, executable-price, and source-hash PASS bundle | Data and approval | No | Validate a complete Task-2 bundle, then run exporter using approved split configuration | Data provider / owner |
| Task 4 — edge reproduction | Wrapper/checker integration implemented and tested | No authoritative clean export; no externally approved IS/OOS split, sample/statistical criteria, or hash-linked statistical PASS evidence | Data and approval | No | Produce validated Task-3 run, publish independent approval config, run wrapper unchanged | Owner / operator |

## Evidence inventory

- Valid response-hash-backed dated sample: `MCX:CRUDEOILM26AUGFUT`, 195 60-minute bars, 03-Aug-2026 through 19-Aug-2026 IST.
- Quarantined provider response: `MCX:CRUDEOILM26SEPFUT`, 532 rows, two rows with `open > high`.
- Sidecar-only dated file: `MCX:CRUDEOILM26OCTFUT`, 1,302 rows, no original provider response hash.
- GOLDM: 12 expiry dates discovered but no exact historical contract collection.
- GOLDGUINEA, SILVERM, NATGASMINI: no verified dated raw history.
- 216 stitched/continuous files: explicitly excluded from clean contract attribution.
- FYERS local request budget: recorded at 10/10 on 02-Nov-2026. No new provider calls were made in this execution.

No current blocker is an unaddressed repository implementation defect. All require either external data, an approved policy, an approved split/statistical specification, or operator-controlled access.
