# PREDIXA MCX FYERS Expired-Data Access Report

Date: 2026-11-02. Provider scope: FYERS only. Requests were read-only and bounded. No credential or token is included here.

## Compatibility and endpoint behavior

The installed `fyers-apiv3` is version 3.1.7. Inspection found `.history` but not the newer Python methods `expiry_dates`, `history_underlying_symbols`, or `fno_historical_data`. The repository adapter therefore uses the documented FYERS V3 HTTP data routes while reusing the existing FYERS auth helper without printing or refreshing credentials.

Documented endpoints:

- [FYERS expiry dates](https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expiry-dates/)
- [FYERS expired contract discovery](https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expired-contracts/)
- [FYERS expired futures OHLCV](https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expired-fo-data/)
- [FYERS historical candles](https://fyers.in/api-docs/v3/api/market-data/historical-data)

The collector uses exact returned dated symbols, separates authentication, entitlement, rate-limit, symbol, no-data, and data-validation failures, and enforces the documented 100-day maximum chunk for the supported minute history route. Active dated contracts use ordinary history with `cont_flag=0`; no active-contract request was made here.

## Bounded real API requests

1. An initial expiry lookup using the product-root form `MCX:CRUDEOILM` returned FYERS HTTP 422/code -50 (invalid symbol). This established that the request symbol must match the endpoint’s accepted format; it was not treated as missing entitlement.
2. Expiry discovery using the exact dated symbol `MCX:CRUDEOILM26OCTFUT` succeeded and returned product `CRUDEOILM`, expiry `2026-10-19`.
3. Exact expired-contract discovery for that expiry returned `MCX:CRUDEOILM26OCTFUT`.
4. Bounded collection for `CRUDEOILM`, interval 2026-08-01 through 2026-10-08, 60-minute bars, max one contract, request budget 10, returned `MCX:CRUDEOILM26AUGFUT` expiry `2026-08-19`: SUCCESS, 195 bars, 2026-08-03 09:00 through 2026-08-19 23:00 IST. Normalized data SHA-256 `942206eae43efc27535ed2791e8fa75ff0e62e44266c85fbd2dc773379656842`; raw response SHA-256 `4e190c2a321783826b32f2c5fd07904ec00cafb62bd72e5380527e8ed0a7ac2b`.
5. A subsequent bounded request reached a response rejected as `DATA_VALIDATION_FAILED` because of an invalid OHLC envelope or negative volume. That response was not persisted by the collector version active at the time. The improved code now preserves rejected responses; no retry was made in this execution.

No calls were made to another broker. No bulk download was performed.

## Existing dated October sample and overlap

`research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv` is an existing dated-symbol file for `MCX:CRUDEOILM26OCTFUT` (1,302 bars); source hash `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6`. Exact timestamp matching against the August file yielded 195 overlap rows. This is raw-price overlap diagnostics only; no roll date or adjustment is asserted. See `research/mcx_fyers_expired/diagnostics/crudeoilm_aug_oct_60m_raw_overlap.json`.

## Access classification

- **Authentication:** authenticated requests succeeded for the bounded calls.
- **Entitlement:** expired-contract API entitlement is demonstrated for this CRUDEOILM sample only.
- **Coverage:** incomplete; no verified all-underlying or all-timeframe coverage.
- **Contract symbols:** exact dated symbols were returned by FYERS for the queried CRUDEOILM expiries.
- **Roll overlap:** observed for the two listed files, but roll schedule/policy is not verified.
- **Active-contract API:** adapter implemented, exact dated noncontinuous mode; not exercised against an active contract.
- **Rejected data:** one bounded provider response failed quality validation; response needs a quota-approved retry under the updated response-preserving collector.

## Current files

Collection artifacts live in `research/mcx_fyers_expired/`. Existing stitched sources were not overwritten. Request budget and cache state are local provenance artifacts; they contain no auth token. Hashes are in the per-request metadata.

## External requirements

Continue with bounded FYERS calls after the account quota window permits: resolve the rejected candle response; collect exact dated history for GOLDM, GOLDGUINEA, SILVERM, CRUDEOILM, and NATGASMINI for all required coverage/timeframes; and verify entitlement/coverage per contract. The expired endpoint does not by itself provide approved roll dates, a complete historical active interval master, complete exchange holiday calendar, or policy authorization.
# Addendum — bounded FYERS collection results, 2026-11-02

The request budget reached 10/10. Exact CRUDEOILM SEP history was captured but rejected for two provider OHLC violations (`open > high`); there was no optional-OI parser defect. GOLDM expiry discovery succeeded for 12 dates after correcting a `range_to=current_date` request error, but exact symbols/history remain uncollected. No further FYERS calls were made after quota exhaustion. See `PREDIXA_MCX_FYERS_OHLC_FAILURE_RCA.md` and `PREDIXA_MCX_FYERS_COLLECTION_PROGRESS.csv`.

