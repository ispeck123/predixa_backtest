# PREDIXA MCX FYERS OHLC Failure RCA

Reviewed 2026-11-02. Provider: FYERS only. No other broker was queried.

## CRUDEOILM September response

The failed request was to `/history/fno/expired/historical-data` for exact symbol `MCX:CRUDEOILM26SEPFUT`, resolution `60`, include OI, range 2026-08-01 through 2026-10-08. FYERS returned `s=ok`, the matching symbol, columns `timestamp, open, high, low, close, volume, open_interest`, and 532 rows. Named-column parsing handled OI correctly; timestamps were ordered, unique, and within the request range. Two source rows violate OHLC validity because open exceeds high:

| IST timestamp | O | H | L | C | Volume | OI |
|---|---:|---:|---:|---:|---:|---:|
| 2026-08-24 09:00 | 8357 | 8224 | 8195 | 8206 | 9952 | 38409 |
| 2026-09-03 09:00 | 8597 | 8591 | 8557 | 8568 | 6961 | 46296 |

Classification: **provider source data contains malformed OHLC**. It is not an optional-column indexing defect, numeric conversion defect, duplicate, symbol mismatch, or range-boundary issue. The response is preserved intact and rejected; no candle was repaired or silently removed. Response SHA-256: `90878481677b3656dddea9bcea70c2573723ca72d40a98a7ad0fe2f88abe8907`.

## GOLDM request error

An expiry query for `MCX:GOLDM26NOVFUT` used `range_to=2026-11-02`, the current date. FYERS returned HTTP 422, code -50, `s=error`, with `range_to cannot be current date or a future date`. This is a caller range error, not bad market data or missing entitlement. Repeating it was unnecessary; a corrected bounded query ending 2026-11-01 succeeded and returned 12 expiry dates. The raw error response is preserved, SHA-256 `7f22e3e8bbd936719c0f0e16f3cf61c2e3a388711ce3c673bdc537cc38f8ab5c`. No auth headers or credentials are included.

## Code and validation

`audit/mcx_futures_backtest/fyers_expired_contract_collector.py` parses the provider `columns` array by name, preserves optional OI/extra columns, and retains strict OHLC checks. It persists rejected provider bodies and metadata without request authorization headers. Regression tests cover the two observed malformed rows and named optional columns. No parser change weakens market-data validity checks.

The expired candle endpoint's current daily request budget is exhausted (10/10 for 2026-11-02); no further authenticated requests were made. The exact response plus request metadata can be replayed through local parser tests without network access.
