# MCX operational hold verification — 02-Nov-2026

The 02-Nov NSEFO hand-off supersedes the earlier MCX PAPER-observation
proposal.  `MCX_EXECUTION_SUSPENDED=True` remains non-configurable.
`MCX_PAPER_OBSERVATION_AUTHORIZED=False` causes the local observation adapter
to reject operational use even when an environment flag is supplied.

The primary MCX scanner now stops both PAPER and REAL jobs before engine,
signal insertion, candidate persistence, or broker paths.  Direct candidate
persistence rejects the same hold.  The MCX regime gate remains unconditionally
DENY and the allocator remains independently blocked.  Existing broker,
approval, Dagster/legacy-scanner and generic order-entry protections remain
unchanged.

Offline fixture tests may temporarily exercise research components only; they
do not provide an activation path.  Phase-1 Task 1 remains code-tested. Tasks
2–4 remain blocked on complete verified FYERS dated-contract coverage, roll
evidence, calendar coverage, an approved roll/split policy, and an
authoritative clean realized-R export.
