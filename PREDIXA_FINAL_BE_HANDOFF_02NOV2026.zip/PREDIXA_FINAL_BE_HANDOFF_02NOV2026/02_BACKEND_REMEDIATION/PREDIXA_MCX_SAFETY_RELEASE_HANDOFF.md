# PREDIXA MCX Safety Release — Production Handoff

Assessment date: 02 November 2026. This is a repository review, not a
deployment record. No production service, scheduler, broker API, order, or
container was accessed or changed.

## Final decision

**SAFETY HOTFIX: READY FOR APPROVAL.**

**PRODUCTION DEPLOYMENT: NOT PERFORMED.**

**MCX REACTIVATION: NOT READY.**

Approval applies to suspension controls only; it does not authorize MCX PAPER
or REAL trading.

## Repository revision and scope

- Reviewed base revision: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba`.
- Safety changes are an uncommitted review worktree change: no release tag,
  image digest, package, or deployment revision exists.
- The worktree contains pre-existing unrelated changes. Package and review only
  the listed safety files; do not use a broad rollback.
- No repository CI/build/package/deployment hook exists. The external release
  system must execute the preflight and block every nonzero exit.

## Changed safety inventory

| Area | Files | Verified outcome |
|---|---|---|
| Gate/allocation | `scripts/tf_regime_gate_by_exchange.py`, `scripts/position_sizing.py` | All MCX requests deny; allocation is blocked at `-0.18`. |
| Common hold | `scripts/graduated_live_config.py` | Code-controlled hold; no environment override. |
| Scanners | `scripts/mcx_graduated_live_scanner.py`, `scripts/scanner_fc.py`, `apps/pipelines/stock_process.py` | Primary and legacy/Dagster paths block before engine/persistence; the repository MCX Dagster schedule defaults to stopped. |
| Order boundaries | `apps/backend/api/bucket_orders_commodity.py`, `apps/backend/api/commodity_orders.py`, `apps/backend/api/fyers_order_management.py` | REAL approval, legacy PAPER creation, and generic explicit-`MCX:` entry routes block before DB/broker calls. Cancels/exits remain available. |
| Release controls | `scripts/predixa_drop_verifier.py`, `scripts/edge_repro_check.py`, `scripts/release_preflight.py`, `config/predixa_release_permission_baseline.json` | Verifiers fail closed; preflight requires an external approved baseline. |
| Tests/docs | `tests/test_release_preflight.py`, `tests/test_mcx_remediation_guardrails.py`, release reports | 33 focused tests passed. |

Review only the hotfix scope:

```bash
git diff -- scripts/tf_regime_gate_by_exchange.py scripts/position_sizing.py \
  scripts/graduated_live_config.py scripts/mcx_graduated_live_scanner.py scripts/scanner_fc.py \
  apps/backend/api/bucket_orders_commodity.py apps/backend/api/commodity_orders.py \
  apps/backend/api/fyers_order_management.py scripts/predixa_drop_verifier.py \
  scripts/edge_repro_check.py scripts/release_preflight.py \
  config/predixa_release_permission_baseline.json tests/test_release_preflight.py \
  tests/test_mcx_remediation_guardrails.py
```

## Actual verification

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_release_preflight.py tests/test_tf_regime_gate_by_exchange.py \
  tests/test_mcx_remediation_guardrails.py tests/test_commodity_bucket_approval.py \
  tests/test_mcx_golive_policy.py
# 33 passed, 7 third-party deprecation warnings

/home/ispeck/anaconda3/envs/finpro/bin/python scripts/release_preflight.py --mode safety \
  --approved-baseline /tmp/predixa-approved-baseline.XXXXXX/approved-baseline.json \
  --python /home/ispeck/anaconda3/envs/finpro/bin/python \
  --report-dir /tmp/predixa-final-safety-preflight
# PASS: C1-C12 passed; 33 preflight regression tests passed
```

The external baseline above was a temporary test artifact, proving the
interface only. Production must use an independently protected artifact. A
missing approval is an expected HOLD (exit 2):

```text
HOLD: invalid release-preflight input: --approved-baseline is required; missing approval fails closed
```

## Permission baseline integrity and preflight contract

The prior checked-in-only baseline could be changed alongside the gate. The
preflight now requires `--approved-baseline` outside the checkout. Safety mode
requires active gate, checked-in baseline, and external approval to match.
Promotion also requires `--previous-approved-baseline`, calculates changed
segments against it, and requires valid realized-`gross_r` evidence for each
segment. This supports safety-only changes without a new edge finding while
preventing gate-plus-baseline edits from being treated as approval.

The external artifact must be protected by the release system, with write
access separate from the code author. Supplying a self-created external file is
not independent approval. All invalid/missing approval or evidence inputs exit
nonzero and block release.

```bash
# Safety-only release
<python> scripts/release_preflight.py --mode safety \
  --approved-baseline <protected-approved-baseline-path> \
  --python <python> --report-dir /var/tmp/predixa-safety-preflight

# Future permission promotion only; not for this hotfix
<python> scripts/release_preflight.py --mode promotion \
  --previous-approved-baseline <previous-approved-baseline-path> \
  --approved-baseline <new-approved-baseline-path> \
  --evidence 'SEGMENT:<verified-export.csv>:<round-trip-cost>:<oos-split>[:<universe>]'

<python> -m pytest -q tests/test_release_preflight.py tests/test_tf_regime_gate_by_exchange.py \
  tests/test_mcx_remediation_guardrails.py tests/test_commodity_bucket_approval.py \
  tests/test_mcx_golive_policy.py
<python> scripts/predixa_drop_verifier.py . --report-dir /var/tmp/predixa-drop-verifier
```

The empty MCX allowlist is valid in safety mode. `edge_repro_check.py` is not
needed for an unchanged safety release, but is mandatory for a promotion.

## Production operator: read-only verification

Replace angle-bracket values with target-specific values. These commands
discover names rather than assuming a service, path, or broker tenancy.

```bash
git -C <deployed-checkout> rev-parse HEAD
git -C <deployed-checkout> status --short
docker inspect <predixa-container-or-image> --format '{{.Id}} {{.Config.Image}}'  # if Docker is used
grep -RIn --exclude='*.pyc' 'MCX_EXECUTION_SUSPENDED\|MCX_EXECUTION_BLOCKED' \
  <deployed-checkout>/scripts <deployed-checkout>/apps
<python> <deployed-checkout>/scripts/release_preflight.py --mode safety \
  --approved-baseline <protected-approved-baseline-path> --python <python> \
  --report-dir /var/tmp/predixa-production-preflight
systemctl list-units --type=service --all | grep -Ei 'predixa|dagster|mcx|alert'
systemctl list-timers --all | grep -Ei 'predixa|dagster|mcx'
ps auxww | grep -Ei '[d]agster|[m]cx_graduated|[s]canner_fc|[s]canner.py'
crontab -l
sudo crontab -l
docker compose ps
docker ps --format '{{.Names}} {{.Image}} {{.Command}}'
dagster schedule list
```

The repository's `mcx_graduated_scanner` Dagster schedule defaults to stopped.
That does not prove the runtime state; the operator must record the deployed
revision/image and scheduler/process output after an authorized deployment.

## Broker-side pending orders

Repository controls do not cancel orders already accepted by a broker or made
outside this application. An authorized broker operator must use the approved
read-only broker order/GTT/position view to list every commodity/`MCX:` pending
order, GTT, and position, reconcile them to application records, and escalate
every stale entry-capable order for owner-approved cancellation. This handoff
does not authorize cancellation, modification, or submission of broker orders.

## Deployment and safe rollback

1. Obtain code review, release authorization, and a protected approved baseline.
2. Run and retain the actual-release preflight reports.
3. Deploy only through the authorized mechanism; then run the read-only runtime
   and broker reconciliation checks above.
4. Keep external MCX schedules disabled until the runtime evidence is signed off.

Do **not** roll back to an older MCX-enabled image/revision: it may restore
permissions, scanner execution, or bucket approval. Recovery must be a
forward-fix build retaining every MCX hold, followed by the same preflight and
runtime checks. An older build is safe only with an independent operational
hold covering all old scheduler and broker-entry paths.

## Required approvals and remaining blockers

- Release owner: approve this safety-only code patch and protected baseline.
- Production operator: verify deployment revision/image, schedulers, processes,
  and broker pending orders.
- NSE_CASH owner: approval for removing `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and
  `UP/UP/25` is recorded. External release governance must publish the reviewed
  candidate baseline before deployment; this is `PENDING_EXTERNAL_ACTION`.
- MCX risk/owner: reactivation requires dated-contract history, documented
  rolls/E1 enforcement, executable-price provenance, realized-R OOS PASS, and
  explicit authorization.

Repository verification supports approval; it does not establish production
readiness or MCX trading authorization.

## Approved NSE_CASH reduction addendum

The four non-positive cells were removed from the active gate and from the
checked-in candidate baseline; the evidence-based change was owner-ratified
after the fact on 02 November 2026. A dedicated `--mode reduction`
preflight now validates an externally supplied previous baseline and candidate
baseline, enforces active/checked-in equality to the candidate, and allows only
a strict permission reduction. Local candidate validation passed C1-C12 and
36 focused tests. The external protected baseline publication and actual
deployment validation remain unperformed.
