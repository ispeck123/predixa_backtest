# PREDIXA MCX Contract Coverage Report

As of 2026-11-02. Classification is evidence-based; absence of a row is not inferred coverage.

| Underlying | Verified dated contracts available | Resolution / bars | Coverage | Roll overlap | Status |
|---|---|---:|---|---|---|
| GOLDM | None in this execution | — | No validated dated-history range | No | BLOCKED_MISSING_DATA |
| GOLDGUINEA | None in this execution | — | No validated dated-history range | No | BLOCKED_MISSING_DATA |
| SILVERM | None in this execution | — | No validated dated-history range | No | BLOCKED_MISSING_DATA |
| CRUDEOILM | `MCX:CRUDEOILM26AUGFUT` from FYERS; existing exact dated `MCX:CRUDEOILM26OCTFUT` file | 60m; 195 and 1,302 bars | Aug source 2026-08-03 09:00–2026-08-19 23:00 IST; October source has 1,302 rows (its exact first/last dates are in source) | 195 exact timestamp matches | PARTIAL; no selected roll |
| NATGASMINI | None in this execution | — | No validated dated-history range | No | BLOCKED_MISSING_DATA |

## CRUDEOILM source details

| Source | Contract | Type | Hash / status |
|---|---|---|---|
| `research/mcx_fyers_expired/CRUDEOILM/MCX_CRUDEOILM26AUGFUT/60/2026-08-01_2026-10-08_4e190c2a3217/bars.csv` | `MCX:CRUDEOILM26AUGFUT`, expiry 2026-08-19 | FYERS expired exact dated candles | 195 bars; SHA256 `942206eae43efc27535ed2791e8fa75ff0e62e44266c85fbd2dc773379656842`; provider raw response SHA256 `4e190c2a321783826b32f2c5fd07904ec00cafb62bd72e5380527e8ed0a7ac2b` |
| `research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv` | `MCX:CRUDEOILM26OCTFUT`, expiry 2026-10-19 | Existing exact dated-symbol file; provider provenance comes from prior report | 1,302 bars; SHA256 `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6` |

The overlap diagnostic reports a mean simultaneous close difference of 197.78974358974358 (August minus October). A difference between two futures contracts is not itself a roll adjustment or executable P&L. Neither file establishes when the strategy should transition, contract listing dates, or whether all needed resolution histories can be acquired.

The pre-existing 216 FYERS stitched/continuous source files remain classified as `CONTINUOUS`/stitched and are not counted as dated contract coverage. No monthly symbol label or current contract master has been used to infer historical contract identity.

## Coverage needed to unblock Task 2 validation

For each of all five underlyings, collect actual FYERS expiry dates and exact expired symbols, then fetch and retain OHLCV for each required contract across the complete evaluation range and configured strategy input resolutions (monthly, weekly, daily, 240m, 120m, 60m, with source-resolution/resampling provenance). Preserve exact provider symbol, expiry, request dates, retrieval time, response hash, normalized hash, timezone, volume and OI when available. Supply verified listing/effective interval metadata, overlapping outgoing/incoming bars, complete MCX session calendar, approved roll schedule/policy, adjustment method and price provenance. Coverage and validity must be checked per contract rather than inferred from file names.
# Addendum — current coverage inventory, 2026-11-02

Final current cached coverage: one verified exact dated CRUDEOILM August contract (195 60m bars); one rejected exact SEP response (532 bars, two invalid OHLC rows); one October exact-dated sidecar (1,302 bars, no provider response hash); 12 GOLDM expiries without exact contract symbols or history; no verified history for GOLDGUINEA, SILVERM, or NATGASMINI. Thus no verified two-contract roll pair and no full five-underlying historical coverage. See `PREDIXA_MCX_HISTORICAL_CONTRACT_COVERAGE.md` and its CSV inventory.

