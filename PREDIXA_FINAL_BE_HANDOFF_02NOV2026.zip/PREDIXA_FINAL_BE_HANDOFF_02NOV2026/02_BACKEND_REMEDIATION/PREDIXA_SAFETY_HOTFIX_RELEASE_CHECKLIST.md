# PREDIXA MCX Safety Hotfix — Release Checklist

## Decision

**MCX SAFETY HOTFIX: READY FOR REVIEW.**

**MCX TRADING REACTIVATION: NOT READY.** This checklist releases only blocking
controls. It does not establish an MCX edge or authorize PAPER/REAL trading.

## Release scope

- MCX gate remains empty and denies all requests.
- MCX capital allocation remains blocked at `-0.18`.
- Primary scanner, legacy Dagster scanner, direct candidate persistence, legacy
  PAPER creation, and REAL commodity-bucket approval remain blocked.
- Generic broker entry endpoints reject explicit `MCX:` symbols before broker
  calls, so they cannot become an alternate live-entry path.
- NSEFO and NSE_CASH permissions are checked against the reviewed baseline and
  are not changed by this hotfix.
- The NSE_CASH reduction removes `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and
  `UP/UP/25`; it was BE-initiated from evidence and owner-ratified after the
  fact on 02 November 2026. It does not add any permission.

## Revision and package identity

- Base repository revision: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba`
  (`Add derivative tuning sweep audit engine`).
- Safety changes are in the current review worktree; no commit, image build, or
  deployment was created.
- Preflight command executed successfully on 02 November 2026:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python scripts/release_preflight.py \
  --mode reduction \
  --previous-approved-baseline /secure/predixa/approved/pre_nse_cash_2026-11-02.json \
  --python /home/ispeck/anaconda3/envs/finpro/bin/python \
  --report-dir /tmp/predixa-safety-preflight
```

## Changed safety files

- `scripts/tf_regime_gate_by_exchange.py`
- `scripts/position_sizing.py`
- `scripts/graduated_live_config.py`
- `scripts/mcx_graduated_live_scanner.py`
- `scripts/scanner_fc.py`
- `apps/backend/api/bucket_orders_commodity.py`
- `apps/backend/api/commodity_orders.py`
- `scripts/predixa_drop_verifier.py`
- `scripts/edge_repro_check.py`
- `scripts/release_preflight.py`
- `config/predixa_release_permission_baseline.json`
- Focused tests and remediation/release-readiness reports.

Review the actual patch with:

```bash
git diff -- scripts/tf_regime_gate_by_exchange.py scripts/position_sizing.py \
  scripts/graduated_live_config.py scripts/mcx_graduated_live_scanner.py \
  scripts/scanner_fc.py apps/backend/api/bucket_orders_commodity.py \
  apps/backend/api/commodity_orders.py scripts/predixa_drop_verifier.py \
  scripts/edge_repro_check.py scripts/release_preflight.py \
  config/predixa_release_permission_baseline.json
```

## Mandatory local/CI checks

Run in the reviewed dependency environment. Any nonzero exit is a release hold.

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python scripts/release_preflight.py \
  --mode safety \
  --python /home/ispeck/anaconda3/envs/finpro/bin/python \
  --approved-baseline /secure/predixa/approved/predixa_release_permission_baseline.json \
  --report-dir /var/tmp/predixa-safety-preflight

/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_release_preflight.py tests/test_tf_regime_gate_by_exchange.py \
  tests/test_mcx_remediation_guardrails.py tests/test_commodity_bucket_approval.py \
  tests/test_mcx_golive_policy.py
```

Recorded results: reduction preflight **PASS**; 36 focused tests **PASS**; Python
compilation **PASS**. The preflight internally runs 33 MCX execution and gate
regression tests plus C1–C12 of the drop verifier.

## Promotion and evidence rule

`--mode safety` requires the active gate and checked-in baseline to match an
external approved-baseline artifact held outside the checkout. A change to
NSEFO, NSE_CASH, or MCX gate permissions exits nonzero. `--mode promotion`
also requires a previous external approved baseline, a new external approved
baseline, and an evidence argument for every changed segment:

```bash
python scripts/release_preflight.py --mode promotion \
  --previous-approved-baseline /secure/predixa/approved/previous_permissions.json \
  --approved-baseline /secure/predixa/approved/new_permissions.json \
  --evidence 'SEGMENT:/verified/export.csv:0.001:2026-01-01:OPTIONAL,UNIVERSE'
```

The edge checker reads the active gate, validates export schema, and calculates
net realized R from `gross_r`; missing/invalid evidence fails closed. Current
MCX drop policy also requires `permit_cells = {}`, so an MCX promotion remains
blocked until a separately reviewed policy change, evidence pass, and owner
authorization are all present.

`--mode reduction` is for an independently approved strict removal only. It
requires both external predecessor and candidate references, but deliberately
does not require a new profitability finding because it cannot promote trade
permission. It rejects additions, replacements, checked-in drift, or active
gate drift.

## Production configuration and read-only verification

Before an authorized deployment, an operator must verify the deployed checkout
or image contains this hold and that no external scheduler runs an older image:

```bash
grep -RIn --exclude='*.pyc' 'MCX_EXECUTION_SUSPENDED\|MCX_EXECUTION_BLOCKED' scripts apps
python scripts/release_preflight.py --mode safety \
  --approved-baseline /secure/predixa/approved/predixa_release_permission_baseline.json \
  --report-dir /var/tmp/predixa-preflight
systemctl list-units --type=service --all | grep -Ei 'predixa|dagster|mcx|alert'
systemctl list-timers --all | grep -Ei 'predixa|dagster|mcx'
ps auxww | grep -Ei '[d]agster|[m]cx_graduated|[s]canner_fc|[s]canner.py'
docker compose ps
docker ps --format '{{.Names}} {{.Image}} {{.Command}}'
dagster schedule list
```

Also perform a read-only reconciliation of existing commodity buckets and broker
GTTs. Do not submit an order merely to test the hold.

## Rollback and recovery

Do **not** roll back to an older MCX-enabled release. A normal binary/image
rollback may silently restore MCX permissions, scanner execution, or bucket
approval. If this safety release must be recovered, create a forward-fix image
that retains all MCX suspension controls, deploy it through the normal approved
process, and re-run the safety preflight and runtime checks. Keep external MCX
schedules disabled until that replacement is verified.

## Independent prerequisites

### Safety release

- Code review of this hotfix.
- Passing safety preflight and focused tests.
- Authorized deployment.
- External scheduler/process verification on the target runtime.

### MCX trading reactivation

- Verified dated-contract MCX history.
- Documented roll selection and back-adjustment method.
- E1-enforced clean series and executable-price provenance.
- Realized-R trade export with required schema and OOS partition.
- Successful edge reproduction.
- Explicit owner authorization and controlled activation plan.

## Outstanding approvals

- External release approval/publishing of the candidate NSE_CASH baseline.
- Separate owner authorization before any MCX PAPER or REAL reactivation.
