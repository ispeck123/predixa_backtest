# PREDIXA MCX Phase-1 — Final Closure Assessment

**Phase-1 status: ENGINEERING IMPLEMENTED; HISTORICAL VALIDATION BLOCKED.** Tasks 1–4 have repository-owned code and regression coverage, but the Phase-1 work order is not quantitatively closed because a validated five-underlying dated-contract dataset, approved roll/calendar/split configuration, and authoritative clean trade export are unavailable. No realized-R edge finding is asserted.

| Task | Engineering | Historical validation | Remaining blocker |
|---|---|---|---|
| Task 1 — E1 session gap | **VERIFIED**: Asia/Kolkata MCX session segmentation, resampling resets, and sequence protections implemented; regression suite passes. | **Code behavior verified; full historical signal-count diagnostic unavailable.** | Full verified historical inputs needed for historical before/after counts. |
| Task 2 — contract rolls | **IMPLEMENTED / TESTED**: point-in-time dated-contract model, roll builder, adjustments, raw-price separation, timeframe/session integration, and validation interface. | **BLOCKED_MISSING_DATA**: only one exact-response CRUDEOILM contract is valid; another response has malformed provider OHLC; other underlyings incomplete. | More genuine FYERS exact-contract history, adjacent verified contract overlap, historical contract effective intervals, full MCX calendar, approved roll/adjustment policy. |
| Task 3 — realized-R export | **IMPLEMENTED / TESTED**: BUY setup replay adapter, conservative exit handling, 14-column realized-R export, provenance and exclusion sidecars. | **BLOCKED_MISSING_DATA**: no authoritative clean export produced. | Task-2 bundle, approved IS/OOS split, executable prices and complete historical coverage. |
| Task 4 — edge reproduction | **IMPLEMENTED / TESTED**: final validation wrapper and candidate-only checker mode; evidence failures exit nonzero. | **BLOCKED_MISSING_DATA**: real reproduction not run; no export. | Valid Task-2/3 evidence plus independent split and sample-criteria approval. |

## Task-4 validator behavior

`scripts/mcx_phase1_edge_validation.py` locates the latest versioned run under `audit/mcx_futures_backtest/outputs` or takes `--run-dir`. It validates the 14-column export, `export_validation.json`, hashes, Task-2 status and source bundle, approved split and edge sample policy, complete provenance mapping, underlying/contract attribution, partition consistency, and `gross_r = (exit-entry)/(entry-stop)`. It then invokes `scripts/edge_repro_check.py` with `--segment MCX`, the approved `--split`, selected `--universe`, costs, provenance and manifest. A real invocation must also supply `--approved-config <absolute-path-outside-the-checkout.json>` and a hash-linked `statistical_validation.json` PASS generated under that approved specification. Neither artifact exists in this workspace.

`edge_repro_check.py --candidate-cells` evaluates export cells as `CANDIDATE_NOT_LIVE`, grouped by underlying and E/A/X/timeframe even though the MCX live permit list is empty. This is analysis-only and leaves the existing default gate-based checker behavior unchanged. A candidate PASS never changes gate permissions. The final gate requires positive net realized expectancy in both IS and OOS, an approved minimum sample count for each partition, and a passing statistical-validation sidecar tied to the exact export hash. The repository defines no minimum sample or statistical method; absent independently approved criteria and a matching PASS artifact, the result is `BLOCKED_UNAPPROVED_CONFIGURATION`.

## Data and export evidence

The current local FYERS collection budget recorded 10/10 requests on 2026-11-02. Verified data consists of 195 60-minute CRUDEOILM August 2026 bars with source hashes. CRUDEOILM September history was rejected because two provider bars had `open > high`. The October file is sidecar-only and lacks the original response hash. GOLDM has 12 expiry dates but no exact contract history; GOLDGUINEA, SILVERM, and NATGASMINI have no verified contract histories in the cache. There is no complete historical MCX holiday/special-session calendar, no independently approved roll policy/adjustment method, and no approved IS/OOS split/sample policy.

The 216 stitched/continuous files were not used as clean dated-contract evidence. No `mcx_trade_export.csv` was generated, no per-cell market metrics exist, and no Task-4 real reproduction was performed.

## Commands and test evidence

Using `/home/ispeck/anaconda3/envs/finpro/bin/python`:

```text
python -m py_compile scripts/edge_repro_check.py scripts/mcx_phase1_edge_validation.py
PASS, exit 0

python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py
176 passed, 7 dependency deprecation warnings, exit 0

python scripts/mcx_phase1_edge_validation.py --runs-root audit/mcx_futures_backtest/outputs --split 2026-01-01 --universe GOLDM,GOLDGUINEA,SILVERM,CRUDEOILM,NATGASMINI --rt 0.0010 --json-out PREDIXA_MCX_PHASE1_TASK4_VALIDATION_RESULTS.json --report-out PREDIXA_MCX_PHASE1_TASK4_EDGE_REPRO_REPORT.md
BLOCKED_MISSING_DATA, exit 2; no versioned clean export exists
```

The requested split in the blocked invocation is not approved; the command exited before using it. The real validator was not given fabricated data.

## Changed files for Task 4

- `scripts/edge_repro_check.py` — analysis-only candidate-cell mode; default live-cell mode unchanged.
- `scripts/mcx_phase1_edge_validation.py` — final run discovery, evidence checks, metric calculation, checker invocation and exit verdicts.
- `tests/test_mcx_phase1_edge_validation.py` — synthetic-only regression tests for pass/failure/blocking paths.
- `PREDIXA_MCX_PHASE1_TASK4_EDGE_REPRO_REPORT.md`
- `PREDIXA_MCX_PHASE1_TASK4_VALIDATION_RESULTS.json`
- `PREDIXA_MCX_PHASE1_TASK4_CHANGED_FILES.txt`
- `PREDIXA_MCX_PHASE1_FINAL_CLOSURE.md`

The repository has pre-existing unrelated dirty files. This Task-4 list excludes them.

## Required before future MCX activation

1. Complete FYERS dated-contract acquisition for all five underlyings and the approved coverage period; resolve or exclude rejected candles using verifiable provider data, never synthetic repairs.
2. Reconstruct verified historical active/listing intervals and roll transitions with overlapping executable contract prices.
3. Obtain an authoritative MCX historical trading calendar covering holidays, special sessions, session-hour changes, and expiry adjustments.
4. Obtain independent approval for roll-selection and adjustment methodology, IS/OOS split, and statistical/sample acceptance criteria.
5. Generate and validate a versioned clean Task-3 export with full provenance and source hashes.
6. Run Task 4; review each cell's IS/OOS realized gross/net R, win rate, and sample counts. Do not substitute MFE.
7. Obtain separate owner authorization and controlled release approval before any MCX gate, allocator, PAPER, or REAL reactivation.

MCX gate remains `DENY`; allocator and scanner/order protections remain blocked. No deployment or trading action was performed.
