from __future__ import annotations
"""MCX single-lot proving scanner.

This is intentionally separate from ``scanner_fc``: that legacy scanner
inserts every qualifying commodity signal immediately and has no proving
policy, observation tier, or source-to-execution routing.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from scripts.mcx_policy import mcx_disposition
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE, gate
from scripts.setup_engine_new import format_calculate_setup_response, process_setup_fc
from scripts.scanner_fc import build_commodity_expiry_map
from scripts.graduated_live_config import (PAPER, REAL, FUTURES_LOT_SIZES,
                                           execution_mode_for, mcx_execution_permitted)
from shared.config.settings import stock_logic_config
from shared.db import db_utils
from shared.db.db_model import Commodity_Order, CommoditiesMaster, OMSOrderBucketCommodity, TradeSignal
import time


MCX_EXCHANGE_ID = 10
CANDIDATE_SOURCE = "GRADUATED_LIVE"
# Contract units used by the existing REAL proving workflow.  PAPER candidates
# always use one simulated unit, independently of this mapping.
MCX_LOT_SIZE = {"CRUDEOILM": 10, "GOLDGUINEA": FUTURES_LOT_SIZES["GOLDGUINEA"],
                "SILVER": 30, "SILVERM": 3}
MIN_RR = 2.1
DEFAULT_OUTPUT = Path("outputs/mcx_graduated_live/mcx_scan.jsonl")
# DEFAULT_TIMEFRAMES = (1, 2, 3, 4)
DEFAULT_TIMEFRAMES = (3, 4)


@dataclass(frozen=True)
class MCXScanJob:
    symbol: str
    expiry: str
    strategy_tf: int
    time_list: list[str]
    last_d_time: Any
    execution_mode: str | None = None


def default_mcx_jobs(timeframes=DEFAULT_TIMEFRAMES, last_d_time=None, min_expiry_days=5):
    """Yield the gate-scoped MCX source universe with a NEAR/NEXT contract."""
    mode = execution_mode_for("MCX")
    allowed_symbols = set(TF_REGIME_GATE["MCX"].universe)
    for timeframe in timeframes:
        stack = list(getattr(stock_logic_config, f"COMMODITY_TIME_FRAME_{timeframe}"))
        # Unlike the legacy commodity scanner, a live OMS scanner must revisit
        # an active contract on every cycle to withdraw a setup invalidated by
        # the latest candle.
        for item in build_commodity_expiry_map(
                min_days=min_expiry_days, time_fr=timeframe, include_existing=True):
            symbol = str(item.get("symbol", "")).upper()
            # Filtering here avoids unnecessary engine/market-data work for
            # contracts outside the gate-scoped MCX proving universe.
            if allowed_symbols and symbol not in allowed_symbols:
                continue
            for expiry in item.get("expiry", []):
                yield MCXScanJob(symbol, str(expiry), timeframe, stack,
                                 last_d_time or datetime.now(), mode)


def classify_mcx_setup(formatted: dict, job: MCXScanJob) -> dict:
    """Produce a durable audit record; never permit a SELL candidate."""
    record = {
        "timestamp": datetime.now().isoformat(), "symbol": job.symbol,
        "expiry": job.expiry, "strategy_tf": job.strategy_tf,
        "execution_mode": job.execution_mode,
        "e_regime": formatted.get("e_regime", ""),
        "a_regime": formatted.get("a_regime", ""),
        "e1_session_boundary_count": formatted.get("e1_session_boundary_count", 0),
        "setup": formatted,
    }
    if str(job.execution_mode or "").strip().upper() not in {PAPER, REAL}:
        return record | {"status": "INVALID_EXECUTION_MODE"}
    buy = formatted.get("BUY")
    if not isinstance(buy, dict):
        return record | {"status": "NO_BUY_SETUP"}
    mode = str(job.execution_mode or "").strip().upper()
    tier, size_mult, gate_reason = gate(
        "MCX", job.strategy_tf, formatted.get("e_regime"), formatted.get("a_regime"), job.symbol)
    record.update(gate_tier=tier, gate_size_multiplier=size_mult, gate_reason=gate_reason)
    # MCX is fully operationally held.  A PAPER mode label is never a bypass
    # for the empty MCX gate while clean-series evidence remains incomplete.
    if size_mult == 0:
        return record | {"status": "TF_REGIME_GATE_DENIED"}
    try:
        entry = float(buy["entry_price"])
        stop = float(buy["stop_loss"])
        target = float(buy["target_price"])
        if not (stop < entry < target):
            raise ValueError("invalid long price ordering")
        calculated_rr = (target - entry) / (entry - stop)
        reported_rr = float(formatted.get("BUY_RRR", 0) or 0)
        if not (math.isfinite(calculated_rr) and math.isfinite(reported_rr)):
            raise ValueError("non-finite RR")
    except (KeyError, TypeError, ValueError):
        return record | {"status": "INVALID_BUY_LEVELS"}
    record["calculated_buy_rrr"] = round(calculated_rr, 4)
    record["reported_buy_rrr"] = reported_rr
    # This is a fail-closed guard around the common engine used by futures,
    # cash, and MCX.  A disagreement is evidence that E/S/T and the displayed
    # RR do not describe the same trade; never persist it as approvable.
    if not math.isclose(calculated_rr, reported_rr, rel_tol=0.0, abs_tol=0.0001):
        return record | {"status": "RRR_MISMATCH"}
    if mode == REAL and calculated_rr < MIN_RR:
        return record | {"status": "RRR_TOO_LOW"}
    disposition, weight, execution_symbol = mcx_disposition(
        job.symbol, formatted.get("e_regime"), formatted.get("a_regime"), job.strategy_tf)
    if disposition == "EXCLUDED":
        return record | {"status": "MCX_SIZING_EXCLUDED",
                         "reason": "MCX_SIZING_EXCLUDED e=%s,a=%s,tf=%s,sym=%s" % (
                             formatted.get("e_regime"), formatted.get("a_regime"), job.strategy_tf, job.symbol),
                         "weight": 0.0}
    if disposition == "OBSERVE":
        return record | {"status": "OBSERVE_WOULD_FIRE", "weight": weight,
                         "side": "BUY", "execution_symbol": execution_symbol,
                         "lot_size": MCX_LOT_SIZE[execution_symbol],
                         "source_symbol": job.symbol,
                         "requires_quote_translation": execution_symbol != job.symbol,
                         "entry": entry,
                         "stop_loss": stop, "target": target,
                         "BUY_RRR": round(calculated_rr, 4)}
    return record | {
        "status": "FIRE_PENDING_OPTION3", "weight": weight, "side": "BUY",
        "execution_symbol": execution_symbol, "lot_size": MCX_LOT_SIZE[execution_symbol],
        "source_symbol": job.symbol, "requires_quote_translation": execution_symbol != job.symbol,
        "entry": entry, "stop_loss": stop, "target": target,
        "BUY_RRR": round(calculated_rr, 4),
    }


def persist_mcx_candidate(candidate: dict, job: MCXScanJob, signal_result: Any) -> dict:
    """Create/reuse TradeSignal, Commodity_Order, and OMS commodity candidate.

    This function is deliberately DB-only: no broker call is reachable here.
    GOLDM candidates are marked pending quote translation, so source-series
    prices can never be submitted as GOLDGUINEA prices.
    """
    mode = str(job.execution_mode or "").strip().upper()
    if mode not in {PAPER, REAL}:
        raise ValueError("MCX_REJECT_INVALID_EXECUTION_MODE")
    if not mcx_execution_permitted():
        raise RuntimeError("MCX_EXECUTION_BLOCKED")
    signal_id = signal_result[1] if isinstance(signal_result, tuple) and len(signal_result) > 1 else signal_result
    from scripts.scanner_fc import parse_expiry_date
    order_expiry = parse_expiry_date(job.expiry).strftime("%d-%m-%Y")
    session = db_utils.dbc.get_session()
    try:
        signal = session.query(TradeSignal).filter(TradeSignal.id == signal_id).first() if signal_id else None
        if signal is None:
            signal = session.query(TradeSignal).filter(
                TradeSignal.stock_name == job.symbol, TradeSignal.time_fr == job.strategy_tf,
                TradeSignal.trade_type == "BUY", TradeSignal.exp_date == str(job.expiry),
            ).order_by(TradeSignal.id.desc()).first()
        if signal is None:
            raise ValueError("MCX_REJECT_TRADE_SIGNAL_NOT_PERSISTED")
        execution_symbol = candidate["execution_symbol"]
        quantity = 1 if mode == PAPER else int(candidate["lot_size"])
        master = session.query(CommoditiesMaster).filter(
            CommoditiesMaster.symbol == execution_symbol, CommoditiesMaster.is_active == True,
        ).first()
        if master is None:
            raise ValueError(f"MCX_REJECT_EXECUTION_SYMBOL_NOT_ACTIVE:{execution_symbol}")
        if mode == PAPER and candidate["requires_quote_translation"]:
            status = "pending_quote_translation"
            approval_status = "not_required"
        elif mode == PAPER:
            status = "paper_monitoring"
            approval_status = "not_required"
        elif candidate["status"] == "OBSERVE_WOULD_FIRE":
            status = "pending_observation"
            approval_status = "pending"
        else:
            status = "pending_quote_translation" if candidate["requires_quote_translation"] else "pending"
            approval_status = "pending"
        now = datetime.now()
        order = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == signal.id).first()
        if order is not None and (
                order.execution_mode != mode or order.candidate_source != CANDIDATE_SOURCE):
            raise ValueError("MCX_REJECT_EXISTING_ORDER_PROVENANCE_MISMATCH")
        if order is None:
            order = Commodity_Order(
                trade_signal_id=signal.id, stock_tick=execution_symbol, stock_id=master.id,
                country_id=1, time_frame=job.strategy_tf, order_type="BUY",
                entry_price=candidate["entry"], stoploss_price=candidate["stop_loss"],
                target_price=candidate["target"], stock_quantity=quantity,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"), purchased_on=now,
                order_status=status, is_trade_started=False, is_evaluated=False,
                expiry_date=order_expiry, arima_ab_model_prediction="NA", arima_ab_model_prob=0.0,
                execution_mode=mode, candidate_source=CANDIDATE_SOURCE,
            )
            session.add(order); session.flush()
        bucket = session.query(OMSOrderBucketCommodity).filter(
            OMSOrderBucketCommodity.trade_signal_id == signal.id).first()
        if bucket is not None and (
                bucket.execution_mode != mode or bucket.candidate_source != CANDIDATE_SOURCE):
            raise ValueError("MCX_REJECT_EXISTING_BUCKET_PROVENANCE_MISMATCH")
        if bucket is None:
            bucket = OMSOrderBucketCommodity(
                order_id=order.order_id, trade_signal_id=signal.id, stock_tick=execution_symbol,
                stock_id=master.id, country_id=1, time_frame=job.strategy_tf, order_type="BUY",
                entry_price=candidate["entry"], stoploss_price=candidate["stop_loss"],
                target_price=candidate["target"], stock_quantity=quantity,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"), purchased_on=now,
                order_status=status, is_trade_started=0, is_evaluated=0,
                expiry_date=order_expiry, approval_status=approval_status, approved_by=None,
                approved_at=None, id_fyers=None, gtt_id=None,
                arima_ab_model_prediction="NA", arima_ab_model_prob=0.0,
                execution_mode=mode, candidate_source=CANDIDATE_SOURCE,
            )
            session.add(bucket); session.flush()
        session.commit()
        return {"trade_signal_id": signal.id, "commodity_order_id": order.order_id,
                "bucket_id": bucket.bucket_id, "status": status,
                "execution_symbol": execution_symbol, "execution_mode": mode}
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def reconcile_live_mcx_candidates(job: MCXScanJob, live_status: str) -> int:
    """Withdraw unapproved candidates that a newer live scan no longer supports.

    OMS is a review queue, not a historical ledger of still-actionable setups.
    Never alter broker-linked or started orders here; those require the normal
    execution/reconciliation path.
    """
    if live_status in {"FIRE_PENDING_OPTION3", "OBSERVE_WOULD_FIRE", "PROCESSING_ERROR"}:
        return 0
    session = db_utils.dbc.get_session()
    try:
        signals = session.query(TradeSignal).filter(
            TradeSignal.exchange_id == MCX_EXCHANGE_ID,
            TradeSignal.stock_name == job.symbol,
            TradeSignal.time_fr == job.strategy_tf,
            TradeSignal.exp_date == str(job.expiry),
            TradeSignal.is_active == True,
        ).all()
        changed = 0
        for signal in signals:
            bucket = session.query(OMSOrderBucketCommodity).filter(
                OMSOrderBucketCommodity.trade_signal_id == signal.id).first()
            order = session.query(Commodity_Order).filter(
                Commodity_Order.trade_signal_id == signal.id).first()
            if bucket is None or bucket.gtt_id or bucket.id_fyers or int(bucket.is_trade_started or 0):
                continue
            if not str(bucket.order_status or "").lower().startswith("pending"):
                continue
            bucket.order_status = "stale_live_rescan"
            bucket.approval_status = "expired"
            if order is not None:
                order.order_status = "stale_live_rescan"
            signal.is_active = False
            changed += 1
        session.commit()
        return changed
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


class MCXGraduatedLiveScanner:
    """Run supplied MCX jobs and emit only long-only proving records.

    FIRE records deliberately remain pending manual approval.  For GOLDM the
    record carries source levels and explicitly requires live GOLDGUINEA quote
    translation at approval; it must never be sent to Fyers using GOLDM prices.
    """
    def __init__(self, engine: Callable = process_setup_fc, formatter: Callable = format_calculate_setup_response,
                 signal_inserter: Callable = db_utils.insert_trade_signals,
                 candidate_persister: Callable = persist_mcx_candidate,
                 candidate_reconciler: Callable = reconcile_live_mcx_candidates):
        self.engine, self.formatter = engine, formatter
        self.signal_inserter, self.candidate_persister = signal_inserter, candidate_persister
        self.candidate_reconciler = candidate_reconciler

    def run(self, jobs: Iterable[MCXScanJob], output_path: Path) -> list[dict]:
        records = []
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8") as fh:
            for job in jobs:
                try:
                    mode = str(job.execution_mode or "").strip().upper()
                    # The repository-wide operational hold covers both PAPER
                    # and REAL scanner jobs.  MCX research remains offline.
                    if not mcx_execution_permitted():
                        record = {
                            "timestamp": datetime.now().isoformat(),
                            "symbol": job.symbol,
                            "expiry": job.expiry,
                            "strategy_tf": job.strategy_tf,
                            "execution_mode": job.execution_mode,
                            "status": "MCX_EXECUTION_BLOCKED",
                            "reason": "MCX PAPER and REAL remain suspended pending clean-series revalidation and owner authorization",
                        }
                        records.append(record)
                        fh.write(json.dumps(record, default=str) + "\n")
                        continue
                    # This is a live scanner: bind the engine cut-off at the
                    # moment this contract is evaluated.  A job can remain in
                    # memory while other contracts are scanned, so its
                    # construction-time timestamp must never become the data
                    # cut-off for a later live evaluation.
                    scan_time = datetime.now()
                    raw = self.engine(job.symbol, job.time_list, job.expiry, scan_time, False)
                    if isinstance(raw, str):
                        raise RuntimeError(raw)
                    formatted = self.formatter(raw, stock_name=job.symbol,
                        time_fr=job.strategy_tf, exp_num=job.expiry,
                        last_d_time=scan_time, is_future=False, is_cash=False)
                    record = classify_mcx_setup(formatted, job)

                    print("BUY_RRR", record.get("BUY_RRR"))
                    # print(time.sleep(2))

                    active_statuses = {"FIRE_PENDING_OPTION3", "OBSERVE_WOULD_FIRE", "PAPER_CANDIDATE"}
                    if record["status"] in active_statuses and (
                            mode == PAPER or float(record.get("BUY_RRR") or 0) >= MIN_RR):
                        record["scan_timestamp"] = scan_time.isoformat()
                        signal_payload = dict(formatted)
                        # Persist the independently verified RR alongside the
                        # exact E/S/T values, never the engine's stale value.
                        signal_payload["BUY_RRR"] = record["BUY_RRR"]
                        signal_payload.update(TRADE_TYPE="BUY", PREDICTION="NA", PROBABILITY=0.0,
                                            EXP_NUM=job.expiry)
                        signal_payload["BUY"] = dict(signal_payload["BUY"], **{
                            "source_symbol": record["source_symbol"],
                            "execution_symbol": record["execution_symbol"],
                            "requires_quote_translation": record["requires_quote_translation"],
                            # Required to re-check the GOLDM gate while the
                            # approval path sizes translated GOLDGUINEA prices.
                            "e_regime": record["e_regime"],
                            "a_regime": record["a_regime"],
                            "strategy_tf": record["strategy_tf"],
                            "mcx_weight": record["weight"],
                        })
                        inserted = self.signal_inserter(signal_payload, 1, MCX_EXCHANGE_ID, job.strategy_tf)
                        record["persistence"] = self.candidate_persister(record, job, inserted)
                    elif record["status"] == "NO_BUY_SETUP":
                        record["reconciled_candidates"] = self.candidate_reconciler(job, record["status"])
                        # print("inserted")
                        # time.sleep(2)
                    # else:
                    #     print("skipped")
                    #     time.sleep(2)
                except Exception as exc:
                    record = {"timestamp": datetime.now().isoformat(), "symbol": job.symbol,
                              "expiry": job.expiry, "strategy_tf": job.strategy_tf,
                              "status": "PROCESSING_ERROR", "error": str(exc)}
                records.append(record)
                fh.write(json.dumps(record, default=str) + "\n")
        return records


def run_mcx_paper_observation(jobs: Iterable[MCXScanJob], *, config=None,
                              engine: Callable = process_setup_fc,
                              formatter: Callable = format_calculate_setup_response) -> list[dict]:
    """Run the separate, brokerless local MCX observation workflow.

    The normal ``MCXGraduatedLiveScanner.run`` remains suspended.  This entry
    point requires a local-paper kill-switch and a separately marked SQLite
    database; it never invokes real allocation, approvals, or broker APIs.
    """
    from scripts.paper_observation import (
        MCXPaperObservationRunner, PaperObservationConfig,
        PaperObservationStore, local_paper_session_factory,
    )
    config = config or PaperObservationConfig.from_environment()
    session_factory, local_engine = local_paper_session_factory(config)
    try:
        return MCXPaperObservationRunner(
            engine=engine, formatter=formatter,
            store=PaperObservationStore(session_factory), config=config,
        ).run(jobs)
    finally:
        local_engine.dispose()


def run_graduated_mcx_scan(*, timeframes=None, last_d_time=None, min_expiry_days=5,
                            output_path=DEFAULT_OUTPUT):
    """Programmatic MCX entry point used by orchestration; no CLI parsing."""
    scanner = MCXGraduatedLiveScanner()
    return scanner.run(
        default_mcx_jobs(timeframes or DEFAULT_TIMEFRAMES, last_d_time, min_expiry_days),
        output_path,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="MCX Option-3 single-lot proving scanner")
    parser.add_argument("--timeframe", type=int, action="append", dest="timeframes")
    parser.add_argument("--min-expiry-days", type=int, default=5)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    records = run_graduated_mcx_scan(
        timeframes=args.timeframes, min_expiry_days=args.min_expiry_days, output_path=args.output)
    print(json.dumps({"records": len(records),
                      "fire_candidates": sum(x.get("status") == "FIRE_PENDING_OPTION3" for x in records),
                      "observe": sum(x.get("status") == "OBSERVE_WOULD_FIRE" for x in records),
                      "output": str(args.output)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
