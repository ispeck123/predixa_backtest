#!/usr/bin/env python3
"""Fail-closed release preflight for the PREDIXA safety hotfix.

Safety mode accepts only the reviewed permission baseline.  Permission-reduction
mode accepts a separately approved strict reduction.  Promotion mode is for a
separately reviewed permission increase and requires realized-R evidence for
every changed segment; every mode still runs the drop verifier, so MCX remains
blocked until the operational-hold policy itself is explicitly reviewed and changed.
"""
from __future__ import annotations

import argparse
import ast
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TESTS = (
    "tests/test_release_preflight.py",
    "tests/test_tf_regime_gate_by_exchange.py",
    "tests/test_mcx_remediation_guardrails.py",
    "tests/test_commodity_bucket_approval.py",
    "tests/test_mcx_golive_policy.py",
)


def _literal(node):
    try:
        return ast.literal_eval(node)
    except Exception:
        return None


def active_permissions(gate_path: Path) -> dict[str, set[tuple[str, str, int, str]]]:
    tree = ast.parse(gate_path.read_text(encoding="utf-8"), filename=str(gate_path))
    gate = next((node.value for node in tree.body if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == "TF_REGIME_GATE"
                         for target in node.targets)), None)
    if not isinstance(gate, ast.Dict):
        raise ValueError("TF_REGIME_GATE literal not found")
    result: dict[str, set[tuple[str, str, int, str]]] = {}
    for key, value in zip(gate.keys, gate.values):
        segment = _literal(key)
        if not isinstance(segment, str) or not isinstance(value, ast.Call):
            continue
        permits = next((kw.value for kw in value.keywords if kw.arg == "permit_cells"), None)
        schedule = _literal(permits)
        if not isinstance(schedule, dict):
            raise ValueError(f"{segment}.permit_cells is not a literal dictionary")
        result[segment] = {(str(e), str(a), int(tf), str(tier))
                           for (e, a, tf), tier in schedule.items()}
    return result


def baseline_permissions(path: Path) -> dict[str, set[tuple[str, str, int, str]]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    raw = payload.get("permissions")
    if not isinstance(raw, dict):
        raise ValueError("baseline permissions are missing")
    return {segment: {tuple(cell) for cell in cells} for segment, cells in raw.items()}


def external_baseline_permissions(path: Path, *, label: str) -> dict[str, set[tuple[str, str, int, str]]]:
    """Read an approval reference which must not be supplied by this checkout.

    A checked-in baseline is useful for review, but is not an independent
    approval: an unreviewed change could otherwise alter the gate and baseline
    together. Release automation must inject this file from protected release
    configuration or an approved artifact store.
    """
    try:
        resolved = path.resolve(strict=True)
    except OSError as exc:
        raise ValueError(f"{label} is unavailable: {exc}") from exc
    try:
        resolved.relative_to(ROOT.resolve())
    except ValueError:
        pass
    else:
        raise ValueError(f"{label} must be outside the repository checkout")
    return baseline_permissions(resolved)


def run(command: list[str]) -> int:
    print("+", " ".join(command), flush=True)
    return subprocess.run(command, cwd=ROOT, check=False).returncode


def parse_evidence(values: list[str]) -> dict[str, list[str]]:
    evidence: dict[str, list[str]] = {}
    for value in values:
        parts = value.split(":", 4)
        if len(parts) < 4:
            raise ValueError("evidence must be SEGMENT:EXPORT:RT:SPLIT[:UNIVERSE]")
        segment, export, rt, split = parts[:4]
        cmd = [str(ROOT / "scripts" / "edge_repro_check.py"), export,
               "--segment", segment, "--rt", rt, "--split", split]
        if len(parts) == 5 and parts[4]:
            cmd += ["--universe", parts[4]]
        evidence[segment.upper()] = cmd
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("safety", "reduction", "promotion"), default="safety")
    parser.add_argument("--python", default=sys.executable, help="reviewed environment Python interpreter")
    parser.add_argument("--baseline", type=Path,
                        default=ROOT / "config" / "predixa_release_permission_baseline.json")
    parser.add_argument("--approved-baseline", type=Path,
                        help="required external approved permission reference; must be outside this checkout")
    parser.add_argument("--previous-approved-baseline", type=Path,
                        help="promotion only: external previously approved permission reference")
    parser.add_argument("--report-dir", type=Path, default=ROOT / "reports" / "release_preflight")
    parser.add_argument("--evidence", action="append", default=[],
                        help="promotion only: SEGMENT:EXPORT:RT:SPLIT[:UNIVERSE]")
    args = parser.parse_args()

    try:
        active = active_permissions(ROOT / "scripts" / "tf_regime_gate_by_exchange.py")
        baseline = baseline_permissions(args.baseline)
        if args.approved_baseline is None:
            raise ValueError("--approved-baseline is required; missing approval fails closed")
        approved = external_baseline_permissions(args.approved_baseline,
                                                  label="approved baseline")
        previous = None
        if args.mode in {"reduction", "promotion"}:
            if args.previous_approved_baseline is None:
                raise ValueError(f"{args.mode} requires --previous-approved-baseline")
            previous = external_baseline_permissions(
                args.previous_approved_baseline, label="previous approved baseline")
        evidence = parse_evidence(args.evidence)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"HOLD: invalid release-preflight input: {exc}")
        return 2

    checked_in_drift = {segment for segment in set(baseline) | set(approved)
                        if baseline.get(segment, set()) != approved.get(segment, set())}
    if checked_in_drift:
        print("HOLD: checked-in baseline differs from independently approved reference: "
              + ", ".join(sorted(checked_in_drift)))
        return 1

    active_drift = {segment for segment in set(active) | set(approved)
                    if active.get(segment, set()) != approved.get(segment, set())}
    if active_drift:
        print("HOLD: active gate differs from independently approved reference: "
              + ", ".join(sorted(active_drift)))
        return 1
    if args.mode == "safety":
        changed = set()
    else:
        assert previous is not None
        changed = {segment for segment in set(active) | set(previous)
                   if active.get(segment, set()) != previous.get(segment, set())}
    if args.mode == "safety" and changed:
        print("HOLD: safety release changes regime permissions: " + ", ".join(sorted(changed)))
        return 1
    if args.mode == "reduction":
        if not changed:
            print("HOLD: reduction mode requires an actual independently approved permission removal")
            return 1
        expanded = {segment for segment in changed
                    if not active.get(segment, set()) < previous.get(segment, set())}
        if expanded:
            print("HOLD: reduction mode may only remove existing permissions: "
                  + ", ".join(sorted(expanded)))
            return 1
    if args.mode == "promotion":
        if not changed:
            print("HOLD: promotion mode requires an actual reviewed permission change")
            return 1
        missing = changed - set(evidence)
        if missing:
            print("HOLD: missing realized-R evidence for changed segment(s): " + ", ".join(sorted(missing)))
            return 1

    args.report_dir.mkdir(parents=True, exist_ok=True)
    checks = [
        [args.python, str(ROOT / "scripts" / "predixa_drop_verifier.py"), str(ROOT),
         "--report-dir", str(args.report_dir / "drop_verifier")],
        [args.python, "-m", "pytest", "-q", *DEFAULT_TESTS],
    ]
    if args.mode == "promotion":
        checks.extend([[args.python, *evidence[segment]] for segment in sorted(changed)])
    else:
        print("EDGE-REPRO: not applicable; no new or expanded trading permission is being released")

    failures = [command for command in checks if run(command) != 0]
    if failures:
        print(f"HOLD: {len(failures)} mandatory release check(s) failed")
        return 1
    print("PASS: mandatory safety release preflight completed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
