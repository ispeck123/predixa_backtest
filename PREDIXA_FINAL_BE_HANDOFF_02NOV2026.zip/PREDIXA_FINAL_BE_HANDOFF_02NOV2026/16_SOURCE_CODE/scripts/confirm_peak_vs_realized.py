#!/usr/bin/env python3
"""
PREDIXA — MCX Phase-A: confirm PEAK-vs-REALIZED (root-cause for the non-reproduction).

PURPOSE (row 5 of the BE fix sheet): show, from Phase-A's OWN baseline export, that the
"+1.61 / +0.70 / +1.14R" MCX edge is PEAK favorable excursion (mfe_R), NOT realized
expectancy (gross_r). Run this; you will see realized is negative while peak ~= the
finding's numbers. Then locate, in your Phase-A analysis script, where mfe_R (peak) was
summarised instead of gross_r (realized) — that is the bug to fix.

Realized R (what capital banks): gross_r in the export = (exit-entry)/(entry-stop).
A win books its target R; a loss books -1. (Verified: gross_r == realized-from-exit.)
Peak R: mfe_R = max favorable excursion in R — the best the trade was EVER up, before it
reversed. Peak is NOT bankable; the trades gave it back to the stop.

Run:
  python3 confirm_peak_vs_realized.py mcx_trade_export.csv
"""
import csv, sys

RT = 0.0010                       # MCX round-trip cost fraction (~0.10%)
UNI = {"GOLDM", "CRUDEOILM"}      # GOLD+CRUDE live universe
CELLS = {("SW", "SW", "4"): "+1.61", ("UP", "SW", "3"): "+0.70"}   # cell -> Phase-A OOS claim
def ff(x):
    try: return float(x)
    except: return None

def main(path):
    agg = {c: {"gr": [], "mfe": [], "win": 0, "n": 0} for c in CELLS}
    with open(path, encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        required = {"side", "outcome", "partition", "symbol", "E_regime", "A_regime",
                    "strategy_tf", "entry_price", "stop_price", "gross_r", "mfe_R"}
        missing = required - set(reader.fieldnames or ())
        if missing:
            print("BLOCKED: export is not the required Phase-A trade export; missing columns: "
                  + ", ".join(sorted(missing)))
            return 2
        for r in reader:
            if r.get("side") != "BUY" or r.get("outcome") not in ("WIN", "LOSS"):
                continue
            if r.get("partition") != "OOS":                       # the export's own IS/OOS label
                continue
            if r.get("symbol", "").split("@")[0] not in UNI:
                continue
            cell = (r.get("E_regime"), r.get("A_regime"), str(r.get("strategy_tf")))
            if cell not in CELLS:
                continue
            e, s, g, mfe = ff(r["entry_price"]), ff(r["stop_price"]), ff(r["gross_r"]), ff(r.get("mfe_R"))
            if None in (e, s, g) or (e - s) == 0:
                continue
            a = agg[cell]
            a["gr"].append(g - RT * e / abs(e - s))               # REALIZED, net-of-cost
            if mfe is not None: a["mfe"].append(mfe)              # PEAK
            a["win"] += (r["outcome"] == "WIN"); a["n"] += 1
    mean = lambda L: sum(L) / len(L) if L else float("nan")
    print(f"{'cell':12}{'n':>6}{'win%':>7}{'REALIZED netR':>15}{'PEAK mfe_R':>12}{'PhaseA claim':>14}")
    for cell, claim in CELLS.items():
        a = agg[cell]
        ck = f"{cell[0]}/{cell[1]}/{cell[2]}"
        print(f"{ck:12}{a['n']:>6}{100*a['win']/a['n'] if a['n'] else float('nan'):>6.1f}%"
              f"{mean(a['gr']):>15.3f}{mean(a['mfe']):>12.3f}{claim:>14}")
    if any(not a["n"] for a in agg.values()):
        print("\nBLOCKED: one or more claimed OOS cells have no qualifying rows; no conclusion is valid.")
        return 2
    print("\nCONCLUSION: realized (gross_r) is NEGATIVE; peak (mfe_R) ~= the Phase-A claim.")
    print("The finding reported PEAK excursion as if it were realized expectancy. Fix the Phase-A")
    print("summary to aggregate gross_r (realized), re-run, and re-validate via edge_repro_check.py.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: python3 confirm_peak_vs_realized.py mcx_trade_export.csv"); sys.exit(2)
    sys.exit(main(sys.argv[1]))
