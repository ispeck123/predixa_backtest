-- Additive fields for the separately labeled, brokerless MCX paper-observation
-- records. Apply only to an explicitly approved local-paper database. This
-- migration is not authorized for a production database by this work order.
ALTER TABLE commodity_order_master
    ADD COLUMN idempotency_key CHAR(64) NULL,
    ADD COLUMN edge_validation VARCHAR(30) NULL,
    ADD COLUMN paper_updated_at DATETIME NULL,
    ADD COLUMN trading_status VARCHAR(20) NULL,
    ADD UNIQUE INDEX uq_commodity_paper_idempotency (idempotency_key);

ALTER TABLE oms_order_bucket_commodity
    ADD COLUMN idempotency_key CHAR(64) NULL,
    ADD COLUMN edge_validation VARCHAR(30) NULL,
    ADD COLUMN paper_updated_at DATETIME NULL,
    ADD COLUMN trading_status VARCHAR(20) NULL,
    ADD UNIQUE INDEX uq_oms_commodity_paper_idempotency (idempotency_key);
