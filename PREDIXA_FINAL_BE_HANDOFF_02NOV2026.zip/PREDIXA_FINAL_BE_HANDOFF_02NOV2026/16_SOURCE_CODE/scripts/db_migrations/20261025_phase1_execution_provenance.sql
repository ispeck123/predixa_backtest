-- Phase 1 schema only. Apply through the normal reviewed deployment process.
-- Existing NULL rows intentionally remain unknown and are not reclassified.
ALTER TABLE future_order_master
    ADD COLUMN execution_mode VARCHAR(10) NULL,
    ADD COLUMN candidate_source VARCHAR(50) NULL;

ALTER TABLE commodity_order_master
    ADD COLUMN execution_mode VARCHAR(10) NULL,
    ADD COLUMN candidate_source VARCHAR(50) NULL;

ALTER TABLE oms_order_bucket_future
    ADD COLUMN execution_mode VARCHAR(10) NULL,
    ADD COLUMN candidate_source VARCHAR(50) NULL;

ALTER TABLE oms_order_bucket_commodity
    ADD COLUMN execution_mode VARCHAR(10) NULL,
    ADD COLUMN candidate_source VARCHAR(50) NULL;
