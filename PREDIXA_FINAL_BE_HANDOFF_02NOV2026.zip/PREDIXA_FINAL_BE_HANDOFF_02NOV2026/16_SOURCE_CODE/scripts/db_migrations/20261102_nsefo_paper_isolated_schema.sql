-- REVIEW ONLY. Do not apply without DBA authorization to an empty isolated
-- PAPER schema, restricted account, tested backup/rollback, and TLS identity.
CREATE TABLE trade_signals (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, exchange_id INT NOT NULL,
  stock_name VARCHAR(100) NOT NULL, time_fr INT NOT NULL, country_id INT NOT NULL,
  price_cmp DOUBLE, trade_type VARCHAR(10), rrr DOUBLE, timestamps JSON, trade_data JSON,
  prediction VARCHAR(20), probability DOUBLE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL, is_active BOOLEAN NOT NULL, is_send BOOLEAN, exp_date VARCHAR(100),
  UNIQUE KEY uq_paper_signal (exchange_id,stock_name,time_fr,trade_type,exp_date,price_cmp)
);
CREATE TABLE future_order_master (
  order_id BIGINT AUTO_INCREMENT PRIMARY KEY, trade_signal_id BIGINT NOT NULL,
  stock_tick VARCHAR(200), stock_id BIGINT, country_id INT, time_frame INT, order_type VARCHAR(200),
  entry_price DOUBLE, stoploss_price DOUBLE, target_price DOUBLE, stock_quantity BIGINT,
  purchased_cmp_date VARCHAR(200), purchased_on DATETIME, order_status VARCHAR(200),
  is_trade_started BOOLEAN DEFAULT 0, is_evaluated BOOLEAN DEFAULT 0, entry_timestamp DATETIME,
  completed_on DATETIME, expiry_date VARCHAR(50), execution_mode VARCHAR(10) NOT NULL,
  candidate_source VARCHAR(50) NOT NULL,
  UNIQUE KEY uq_paper_order_signal (trade_signal_id),
  KEY ix_paper_order_mode_source (execution_mode,candidate_source,order_status)
);
CREATE TABLE oms_order_bucket_future (
  bucket_id BIGINT AUTO_INCREMENT PRIMARY KEY, order_id BIGINT NOT NULL, trade_signal_id BIGINT NOT NULL,
  stock_tick VARCHAR(200), stock_id BIGINT, country_id INT, time_frame INT, order_type VARCHAR(200),
  entry_price DOUBLE, stoploss_price DOUBLE, target_price DOUBLE, stock_quantity BIGINT,
  purchased_cmp_date VARCHAR(200), purchased_on DATETIME, order_status VARCHAR(200),
  is_trade_started BOOLEAN DEFAULT 0, is_evaluated BOOLEAN DEFAULT 0, entry_timestamp DATETIME,
  completed_on DATETIME, expiry_date VARCHAR(45), approval_status VARCHAR(20) NOT NULL,
  approved_by INT, approved_at DATETIME, id_fyers VARCHAR(255), gtt_id VARCHAR(255),
  execution_mode VARCHAR(10) NOT NULL, candidate_source VARCHAR(50) NOT NULL,
  UNIQUE KEY uq_paper_bucket_signal (trade_signal_id),
  KEY ix_paper_bucket_mode_source (execution_mode,candidate_source,approval_status,order_status)
);
-- Restricted runtime account: SELECT/INSERT on these three tables, UPDATE only
-- future_order_master and oms_order_bucket_future; no DDL, DELETE, GRANT, or
-- access to Fin_product. DBA supplies hostname and password policy.
