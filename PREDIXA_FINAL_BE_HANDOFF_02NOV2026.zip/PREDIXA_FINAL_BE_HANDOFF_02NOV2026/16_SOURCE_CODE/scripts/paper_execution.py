from sqlalchemy import text


def derivative_paper_orders_sql(order_table, bucket_table, lifecycle_filter):
    """Select only rows carrying explicit, recognized paper provenance."""
    allowed = {
        ("future_order_master", "oms_order_bucket_future"),
        ("commodity_order_master", "oms_order_bucket_commodity"),
    }
    if (order_table, bucket_table) not in allowed:
        raise ValueError("UNSUPPORTED_DERIVATIVE_ORDER_TABLE")
    if lifecycle_filter not in {
        "candidate.is_trade_started=0",
        "candidate.is_evaluated=0 and candidate.is_trade_started=1",
    }:
        raise ValueError("UNSUPPORTED_DERIVATIVE_LIFECYCLE_FILTER")
    return text(f"""
        select candidate.* from {order_table} candidate
        where {lifecycle_filter}
          and lower(coalesce(candidate.order_status, '')) not in
              ('cancelled', 'rejected', 'stale_live_rescan', 'pending_quote_translation')
          and (
                (candidate.execution_mode='PAPER'
                 and candidate.candidate_source in ('GRADUATED_LIVE', 'LEGACY_PAPER'))
          )
    """)
