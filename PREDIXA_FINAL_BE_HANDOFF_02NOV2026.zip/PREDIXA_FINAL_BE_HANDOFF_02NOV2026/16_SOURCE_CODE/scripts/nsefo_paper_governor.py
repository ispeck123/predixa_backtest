"""Brokerless Option-3 serial governor for approved NSEFO PAPER candidates."""
from __future__ import annotations

from datetime import datetime
from shared.db.db_model import Future_Order, OMSOrderBucketFuture

PAPER_SOURCE = "NSEFO_TIER0_PAPER"
PAPER_PENDING = "paper_pending_approval"
PAPER_ACTIVE = "paper_monitoring"
TERMINAL = frozenset({"cancelled", "expired", "closed", "rejected", "success", "failed"})


def has_active_paper_position(session) -> bool:
    rows = session.query(OMSOrderBucketFuture).filter(
        OMSOrderBucketFuture.execution_mode == "PAPER",
        OMSOrderBucketFuture.candidate_source == PAPER_SOURCE,
    ).all()
    # Unapproved rows are a review queue, not simulated exposure.  Only an
    # approved/resting/open PAPER record owns the Option-3 serial slot.
    return any(str(row.order_status or "").lower() not in TERMINAL | {PAPER_PENDING}
               for row in rows)


def approve_paper_candidate(*, bucket_id: int, approved_by: int, session_factory,
                            now_factory=datetime.now) -> dict:
    """Approve exactly one pending candidate without contacting FYERS.

    Pending candidates are intentionally not simulated resting orders.  This
    transition is the explicit per-order owner approval boundary.
    """
    session = session_factory()
    try:
        bucket = session.query(OMSOrderBucketFuture).filter(
            OMSOrderBucketFuture.bucket_id == bucket_id).first()
        if bucket is None:
            raise ValueError("NSEFO_PAPER_BUCKET_NOT_FOUND")
        if bucket.execution_mode != "PAPER" or bucket.candidate_source != PAPER_SOURCE:
            raise ValueError("NSEFO_PAPER_PROVENANCE_REJECTED")
        if bucket.approval_status != "pending" or bucket.order_status != PAPER_PENDING:
            raise ValueError("NSEFO_PAPER_NOT_PENDING_APPROVAL")
        if has_active_paper_position(session):
            raise ValueError("NSEFO_PAPER_OPTION3_SERIAL_LOCKED")
        bucket.approval_status = "approved"
        bucket.approved_by = int(approved_by)
        bucket.approved_at = now_factory()
        bucket.order_status = PAPER_ACTIVE
        order = session.query(Future_Order).filter(
            Future_Order.trade_signal_id == bucket.trade_signal_id).first()
        if order is None:
            raise ValueError("NSEFO_PAPER_ORDER_NOT_FOUND")
        order.order_status = PAPER_ACTIVE
        session.commit()
        return {"status": "PAPER_APPROVED", "bucket_id": bucket_id,
                "trade_signal_id": bucket.trade_signal_id}
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
