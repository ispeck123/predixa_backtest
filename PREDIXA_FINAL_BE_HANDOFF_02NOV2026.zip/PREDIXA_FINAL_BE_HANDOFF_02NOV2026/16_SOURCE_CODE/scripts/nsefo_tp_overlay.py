"""NSEFO SW/SW/25 PAPER-only TP@50% shadow-exit policy.

This module is deliberately pure.  It does not import a broker client, alter
the strategy engine, or decide whether an order may be sent to a broker.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_HALF_UP
from math import sqrt
from statistics import mean, stdev
from typing import Iterable, Mapping

ELIGIBLE_CELL = ("NSEFO", "SW", "SW", 25, "BUY")


def _number(value: object) -> Decimal:
    try:
        return Decimal(str(value))
    except Exception as exc:
        raise ValueError("TP50_INVALID_PRICE") from exc


def is_eligible(*, segment: object, e_regime: object, a_regime: object,
                strategy_tf: object, side: object) -> bool:
    try:
        tf = int(strategy_tf)
    except (TypeError, ValueError):
        return False
    return (str(segment).upper(), str(e_regime).upper(), str(a_regime).upper(),
            tf, str(side).upper()) == ELIGIBLE_CELL


def round_to_tick(price: object, tick_size: object) -> float:
    price_d, tick_d = _number(price), _number(tick_size)
    if tick_d <= 0:
        raise ValueError("TP50_INVALID_TICK_SIZE")
    return float((price_d / tick_d).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * tick_d)


def build_overlay(*, entry: object, stop: object, original_target: object,
                  tick_size: object) -> dict:
    """Return immutable target data; original target is never overwritten."""
    entry_d, stop_d, target_d = _number(entry), _number(stop), _number(original_target)
    if not stop_d < entry_d < target_d:
        raise ValueError("TP50_INVALID_LONG_LEVELS")
    requested = entry_d + Decimal("0.50") * (target_d - entry_d)
    rounded = Decimal(str(round_to_tick(requested, tick_size)))
    if rounded <= entry_d or rounded >= target_d:
        raise ValueError("TP50_ROUNDED_TARGET_INVALID")
    return {
        "original_target": float(target_d),
        "candidate_tp50_requested": float(requested),
        "candidate_tp50_executable": float(rounded),
        "tick_size": float(_number(tick_size)),
        "candidate_exit": "TP50_FULL_POSITION",
        "control_exit": "ORIGINAL_TARGET_FULL_POSITION",
        "oco_stop": float(stop_d),
    }


def overlay_for_setup(setup: Mapping[str, object], *, tick_size: object) -> dict | None:
    if not is_eligible(segment=setup.get("segment"), e_regime=setup.get("e_regime"),
                       a_regime=setup.get("a_regime"), strategy_tf=setup.get("strategy_tf"),
                       side=setup.get("side")):
        return None
    return build_overlay(entry=setup["entry"], stop=setup["stop_loss"],
                         original_target=setup["target"], tick_size=tick_size)


def resolve_long_exit(*, entry: object, stop: object, target: object,
                      candle_low: object, candle_high: object) -> dict:
    """Conservative OHLC exit resolution for one full-position variant.

    When both stop and target touch the same candle, ordering is unknowable;
    no favorable fill is assumed and the result is explicitly unresolved.
    """
    entry_d, stop_d, target_d = _number(entry), _number(stop), _number(target)
    low, high = _number(candle_low), _number(candle_high)
    stop_hit, target_hit = low <= stop_d, high >= target_d
    if stop_hit and target_hit:
        return {"status": "UNRESOLVED_AMBIGUOUS_OHLC", "exit_price": None}
    if stop_hit:
        return {"status": "STOP", "exit_price": float(stop_d)}
    if target_hit:
        return {"status": "TARGET", "exit_price": float(target_d)}
    return {"status": "OPEN", "exit_price": None}


def realized_r(*, entry: object, stop: object, exit_price: object, costs_r: object = 0) -> float:
    entry_d, stop_d, exit_d, costs_d = (_number(v) for v in (entry, stop, exit_price, costs_r))
    risk = entry_d - stop_d
    if risk <= 0:
        raise ValueError("TP50_INVALID_RISK")
    return float((exit_d - entry_d) / risk - costs_d)


def tracking_summary(rows: Iterable[Mapping[str, object]], *, ci_critical: float = 1.96) -> dict:
    """Summarise one exit variant only; callers must not pool variants."""
    values = [float(r["tracking_error"]) for r in rows]
    n = len(values)
    avg = mean(values) if values else None
    ci = None
    if n >= 2:
        width = float(ci_critical) * stdev(values) / sqrt(n)
        ci = [avg - width, avg + width]
    return {"n": n, "mean_tracking_error": avg, "ci95": ci,
            "gross_divergence_review": n >= 20 and avg is not None and avg > -0.15,
            "full_review": n >= 40 and avg is not None and avg > -0.15,
            "promotion": "BLOCKED_PENDING_CRITERION_RECONCILIATION"}
