#!/usr/bin/env python3
"""
PREDIXA — BE-drop verifier (regression gate).

Verifies a BE code drop (a directory of .py files) against the known, fixed
checklist established through review: the four live sizing bugs, the segment-scoped
gate schedule, scan-side enforcement, the GOLDGUINEA execution safety gates, single
source of truth, and the risk rails.

SCOPE / LIMITS (read this):
  * This is a REGRESSION gate. A PASS means the KNOWN failure modes are clear.
    It does NOT mean the drop is fully correct — it cannot catch a novel error
    class (the margin_pct 100x and the 0.5-truncation bugs were both caught by
    reasoning, not a fixed check). A human still reviews anything it flags and
    anything new.
  * READ-ONLY. It parses the drop with the `ast` module; it never imports or
    executes it, never touches a broker, a DB, live config, or doctrine.
  * It can CLEAR a drop for PAPER only. It NEVER authorizes a REAL lot — that
    stays a human decision behind the operational gates (migration, data updater,
    approve-one).

Usage:
  python3 predixa_drop_verifier.py <drop_dir>
  python3 predixa_drop_verifier.py <drop_dir> --reconcile <emitted_cells.csv>
      (post-deploy: emitted_cells.csv columns: segment,e_regime,a_regime,time_frame)
"""
from __future__ import annotations
import ast, os, re, sys, glob, csv, json, argparse, hashlib
from datetime import datetime, timezone
from typing import Optional

# ---- the canonical permitted schedule (fallback for --reconcile when no gate file) ----
CANON_PERMIT = {
    "NSE_CASH": {("SW","SW",2),("SW","SW",6),("SW","SW",25),("SW","UP",2),("SW","UP",6),
                 ("UP","UP",2),("UP","UP",5),("UP","SW",2),("UP","SW",5),("UP","UP",25)},
    "NSEFO":    {("SW","SW",25)},
    "MCX":      set(),
}
CANON_MARGINAL = {"NSE_CASH": {("UP","SW",2),("UP","SW",5),("UP","UP",25)}}
MCX_UNIVERSE = {"GOLDM","CRUDEOILM"}

# ----------------------------------------------------------------- source loading
def load_sources(drop_dir):
    files = {}
    for p in glob.glob(os.path.join(drop_dir, "**", "*.py"), recursive=True):
        try:
            with open(p, encoding="utf-8") as f:
                files[os.path.basename(p)] = (p, f.read())
        except Exception as e:
            files[os.path.basename(p)] = (p, "")
    return files


def source_manifest(drop_dir):
    """Return deterministic source fingerprints for automation/audit monitoring.

    Checks intentionally continue to use their legacy basename lookup.  The
    manifest records relative paths and SHA-256 so an automated release system
    can see exactly which Python source files were added, removed, or changed
    between verifier runs without executing any application code.
    """
    root = os.path.abspath(drop_dir)
    entries = []
    for path in sorted(glob.glob(os.path.join(root, "**", "*.py"), recursive=True)):
        try:
            with open(path, "rb") as handle:
                payload = handle.read()
        except OSError:
            continue
        entries.append({
            "path": os.path.relpath(path, root).replace(os.sep, "/"),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size_bytes": len(payload),
        })
    return entries


def compare_source_manifests(previous, current):
    """Summarize path-aware source drift; malformed prior data fails closed."""
    if not isinstance(previous, list):
        raise ValueError("previous report has no source_manifest list")
    def index(entries):
        result = {}
        for entry in entries:
            if not isinstance(entry, dict) or not isinstance(entry.get("path"), str) \
                    or not isinstance(entry.get("sha256"), str):
                raise ValueError("previous report source_manifest is malformed")
            result[entry["path"]] = entry["sha256"]
        return result
    old, new = index(previous), index(current)
    return {
        "added": sorted(set(new) - set(old)),
        "removed": sorted(set(old) - set(new)),
        "modified": sorted(path for path in set(old) & set(new) if old[path] != new[path]),
    }

def top_assign(src, name):
    """Return the ast value node of a top-level `name = ...`, or None."""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return None
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id == name:
                    return node.value
    return None

def dict_of_calls(node):
    """{key_str: {kwarg: value_node}} for a Dict literal whose values are Call()s."""
    out = {}
    if not isinstance(node, ast.Dict):
        return out
    for k, v in zip(node.keys, node.values):
        try:
            key = ast.literal_eval(k)
        except Exception:
            continue
        if isinstance(v, ast.Call):
            kw = {a.arg: a.value for a in v.keywords if a.arg}
            # positional SegmentPolicy(enabled, risk_pct, max_concurrent, exposure_cap, notional_cap, margin_pct)
            pos = v.args
            out[key] = {"_kw": kw, "_pos": pos}
    return out

def lit(node):
    try: return ast.literal_eval(node)
    except Exception: return None

# ----------------------------------------------------------------- check result
class R:
    def __init__(self, cid, title, status, evidence):
        self.cid, self.title, self.status, self.evidence = cid, title, status, evidence

def P(cid,t,e=""): return R(cid,t,"PASS",e)
def F(cid,t,e=""): return R(cid,t,"FAIL",e)
def W(cid,t,e=""): return R(cid,t,"WARN",e)
def NA(cid,t,e=""): return R(cid,t,"NA",e)

# ----------------------------------------------------------------- checks
def c_margin(files):
    src = files.get("position_sizing.py",(None,""))[1] or files.get("sizing_bridge.py",(None,""))[1]
    if not src: return NA("C1","NSEFO margin_pct is a fraction (≤1.0)","no position_sizing/sizing_bridge")
    bad=[]
    for name in ("SEGMENTS","_SEGMENTS"):
        node = top_assign(src,name)
        for seg,info in dict_of_calls(node).items():
            mp = info["_kw"].get("margin_pct")
            val = lit(mp) if mp is not None else None
            if val is None and len(info["_pos"])>=6: val = lit(info["_pos"][5])
            if isinstance(val,(int,float)) and val>1.0:
                bad.append(f"{seg} margin_pct={val}")
    # regex fallback across both files
    for fn in ("position_sizing.py","sizing_bridge.py"):
        s=files.get(fn,(None,""))[1]
        for m in re.finditer(r"margin_pct\s*=\s*([0-9]+(?:\.[0-9]+)?)", s):
            if float(m.group(1))>1.0: bad.append(f"{fn}: margin_pct={m.group(1)}")
    if bad: return F("C1","NSEFO margin_pct is a fraction (≤1.0)","; ".join(sorted(set(bad)))+"  (bug-1: fraction, not percent)")
    return P("C1","NSEFO margin_pct is a fraction (≤1.0)","all segment margin_pct ≤ 1.0")

def c_net_r(files):
    src = files.get("position_sizing.py",(None,""))[1]
    if not src: return NA("C2","SEGMENT_NET_R[MCX] blocks allocation","no position_sizing.py")
    d = lit(top_assign(src,"SEGMENT_NET_R")) or {}
    if "MCX" not in d: return F("C2","SEGMENT_NET_R[MCX] blocks allocation","MCX key absent")
    if d["MCX"] >= 0: return F("C2","SEGMENT_NET_R[MCX] blocks allocation",f"MCX={d['MCX']} (must be negative during hold)")
    return P("C2","SEGMENT_NET_R[MCX] blocks allocation",f"MCX={d['MCX']} → segment BLOCKED")

def c_legacy_veto(files):
    s = files.get("sizing_bridge.py",(None,""))[1]
    if not s: return NA("C3","Legacy REGIME_TF_SIZE_WEIGHT veto removed","no sizing_bridge.py")
    # a live lookup = `REGIME_TF_SIZE_WEIGHT.get(` on a non-comment line
    for ln,line in enumerate(s.splitlines(),1):
        code = line.split("#",1)[0]
        if re.search(r"REGIME_TF_SIZE_WEIGHT\s*\.\s*get\s*\(", code):
            return F("C3","Legacy REGIME_TF_SIZE_WEIGHT veto removed",
                     f"sizing_bridge.py:{ln} active lookup (bug-3: parasitic 2nd veto)")
    if re.search(r"\bREGIME_TF_SIZE_WEIGHT\b", s):
        return W("C3","Legacy REGIME_TF_SIZE_WEIGHT veto removed","name still imported/referenced but no active .get() veto")
    return P("C3","Legacy REGIME_TF_SIZE_WEIGHT veto removed","no reference")

def c_trunc(files):
    s = files.get("sizing_bridge.py",(None,""))[1]
    if not s: return NA("C4","Fixed-qty emits min unit (no 0.5→0 truncation)","no sizing_bridge.py")
    if "WETRUN_FIXED_QTY" not in s: return W("C4","Fixed-qty emits min unit","WETRUN_FIXED_QTY not found")
    # the correct fix: under the fixed-qty branch quantity = lot_size if lot_size>1 else 1
    good = re.search(r"WETRUN_FIXED_QTY\s*:(.|\n){0,400}?quantity\s*=\s*lot_size\s+if\s+lot_size\s*>\s*1\s+else\s+1", s)
    # the bug: int(quantity * ... multiplier) inside/after the fixed path
    bug = re.search(r"int\(\s*(?:quantity|1)\s*\*\s*(?:float\()?\s*size_multiplier", s)
    if bug and not good:
        return F("C4","Fixed-qty emits min unit",f"int(qty*size_multiplier) truncation present (bug-4), no min-unit guard")
    if good:
        return P("C4","Fixed-qty emits min unit","permitted cell → min tradeable unit (1 share / 1 lot)")
    return W("C4","Fixed-qty emits min unit","min-unit pattern not matched; manual check")

def _gate_dict(files):
    s = files.get("tf_regime_gate_by_exchange.py",(None,""))[1]
    if not s: return None, None
    node = top_assign(s,"TF_REGIME_GATE")
    segs = {}
    if isinstance(node, ast.Dict):
        for k,v in zip(node.keys,node.values):
            key = lit(k)
            if isinstance(v,ast.Call):
                kw={a.arg:a.value for a in v.keywords if a.arg}
                segs[key] = {
                    "permit": lit(kw.get("permit_cells")) or {},
                    "universe": lit(kw.get("universe")) or (),
                    "default": lit(kw.get("default")),
                }
    return s, segs

def c_gate_nsefo(files):
    s,segs = _gate_dict(files)
    if s is None: return NA("C5","Gate NSEFO = SW/SW/25 only","no tf_regime_gate file")
    if "NSEFO" not in segs: return W("C5","Gate NSEFO = SW/SW/25 only","NSEFO segment absent")
    permit = set(segs["NSEFO"]["permit"].keys())
    withtrend = {c for c in permit if c[:2] in {("UP","UP"),("UP","SW"),("SW","UP")}}
    if withtrend:
        return F("C5","Gate NSEFO = SW/SW/25 only",f"with-trend cell(s) permitted: {sorted(withtrend)} (overfit OOS → must be DENY)")
    if ("SW","SW",25) not in permit:
        return F("C5","Gate NSEFO = SW/SW/25 only","SW/SW/25 not permitted")
    extra = permit - {("SW","SW",25)}
    if extra: return W("C5","Gate NSEFO = SW/SW/25 only",f"extra cells beyond SW/SW/25: {sorted(extra)}")
    return P("C5","Gate NSEFO = SW/SW/25 only","permit = {('SW','SW',25)}")

def c_gate_mcx(files):
    s,segs = _gate_dict(files)
    if s is None: return NA("C6","Gate MCX operational hold","no tf_regime_gate file")
    if "MCX" not in segs: return F("C6","Gate MCX operational hold","MCX segment absent")
    permit=set(segs["MCX"]["permit"].keys()); uni=set(segs["MCX"]["universe"])
    probs=[]
    if permit:
        probs.append(f"cells={sorted(permit)} (MCX permit_cells must be empty during hold)")
    if "GOLDGUINEA" in uni:
        probs.append("universe contains GOLDGUINEA — gate must stay on GOLDM (execution-only swap)")
    if uni and uni != MCX_UNIVERSE:
        probs.append(f"universe={sorted(uni)} (expect GOLDM,CRUDEOILM)")
    if probs: return F("C6","Gate MCX operational hold","; ".join(probs))
    return P("C6","Gate MCX operational hold",f"permit_cells={{}}; universe={sorted(uni)}")

def c_gate_default(files):
    s,segs = _gate_dict(files)
    if s is None: return NA("C7","Futures gate default = DENY (not fail-open)","no tf_regime_gate file")
    bad=[seg for seg in ("NSEFO","MCX") if segs.get(seg,{}).get("default") not in ("DENY",)]
    if bad: return F("C7","Futures gate default = DENY",f"{bad} default != DENY (fail-open risk)")
    return P("C7","Futures gate default = DENY","NSEFO & MCX default=DENY")

def c_scan_enforce(files):
    s = files.get("scanner_fc.py",(None,""))[1]
    if not s: return NA("C8","Scan-side gate enforcement (deny + RR≥2.1 before persist)","no scanner_fc.py")
    has_gate = "gate(" in s
    has_block = re.search(r"size_mult\s*==\s*0", s) and "continue" in s
    has_rr = re.search(r"RRR?['\"]?\]?\s*>=\s*2\.1", s) or ">= 2.1" in s
    has_insert = "insert_trade_signals" in s
    probs=[]
    if not has_gate: probs.append("no gate() call")
    if not has_block: probs.append("no `size_mult==0 → continue` guard")
    if has_insert and not has_rr: probs.append("no RR≥2.1 guard before insert")
    if probs: return F("C8","Scan-side gate enforcement","; ".join(probs))
    return P("C8","Scan-side gate enforcement","gate()+deny-guard+RR≥2.1 present")

def c_goldguinea(files):
    s = files.get("bucket_orders_commodity.py",(None,""))[1]
    if not s:
        return W("C9","GOLDGUINEA: ₹18k cap + 2×/7d liquidity on translated order",
                 "bucket_orders_commodity.py absent — GOLDGUINEA REAL path NOT verifiable (OK for pre-GG / CRUDEOILM+NSEFO start)")
    cap = re.search(r"risk_rupees\s*>\s*float\(\s*OPTION3_SINGLE_TRADE_RISK_CAP_INR", s) or \
          re.search(r"risk_rupees\s*>\s*.*RISK_CAP", s)
    liq = re.search(r"volume\"?\]?\s*<\s*required", s) or ("LIQUIDITY_THRESHOLD" in s and "volume" in s)
    translate = "translate_mcx_levels" in s and "GOLDGUINEA" in s
    probs=[]
    if not cap: probs.append("₹18k risk-cap comparison on translated risk_rupees NOT found")
    if not liq: probs.append("2×/7d liquidity gate NOT found")
    if not translate: probs.append("GOLDM→GOLDGUINEA translation NOT found")
    if probs: return F("C9","GOLDGUINEA safety gates","; ".join(probs))
    return P("C9","GOLDGUINEA safety gates","risk-cap + liquidity + translation on the executed GOLDGUINEA order")

def c_single_source(files):
    s = files.get("sizing_bridge.py",(None,""))[1]
    ps = files.get("position_sizing.py",(None,""))[1]
    if not s or not ps: return NA("C10","Single source of truth (SEGMENTS)","missing file")
    ps_has = top_assign(ps,"SEGMENTS") is not None
    imports = re.search(r"from\s+scripts\.position_sizing\s+import\s*\([^)]*\bSEGMENTS\b", s) or "import SEGMENTS" in s
    # active local literal (uncommented) `_SEGMENTS = {`
    local_literal=False
    for line in s.splitlines():
        code=line.split("#",1)[0]
        if re.search(r"^\s*_SEGMENTS\s*=\s*\{", code): local_literal=True
    if not ps_has: return W("C10","Single source of truth","SEGMENTS not defined in position_sizing")
    if local_literal: return F("C10","Single source of truth","sizing_bridge defines its own _SEGMENTS literal (duplicate schedule)")
    if not imports: return W("C10","Single source of truth","sizing_bridge does not import SEGMENTS")
    return P("C10","Single source of truth","SEGMENTS in position_sizing; sizing_bridge imports it")

def c_rails(files):
    s = files.get("graduated_live_config.py",(None,""))[1]
    if not s: return NA("C11","Risk rails present (₹18k cap, 2× liquidity, 7d, GOLDGUINEA lot)","no graduated_live_config.py")
    probs=[]
    m = re.search(r"OPTION3_SINGLE_TRADE_RISK_CAP_INR[^\n]*?=\s*([0-9_]+)", s)
    if not m or int(m.group(1).replace("_",""))<=0: probs.append("single-trade risk cap missing/≤0")
    if "OPTION3_LIQUIDITY_THRESHOLD" not in s: probs.append("liquidity threshold missing")
    if "GOLDGUINEA" in s and not re.search(r"GOLDGUINEA\"?\]?\s*[:=]\s*8", s):
        probs.append("GOLDGUINEA lot present but != 8")
    if probs: return F("C11","Risk rails present","; ".join(probs))
    cap = m.group(1) if m else "?"
    return P("C11","Risk rails present",f"risk cap={cap}, liquidity threshold + 7d present")

def c_mcx_hold(files):
    cfg = files.get("graduated_live_config.py", (None, ""))[1]
    scanner = files.get("mcx_graduated_live_scanner.py", (None, ""))[1]
    legacy_scanner = files.get("scanner_fc.py", (None, ""))[1]
    approval = files.get("bucket_orders_commodity.py", (None, ""))[1]
    if not cfg or not scanner or not legacy_scanner or not approval:
        return NA("C12", "MCX execution hold covers scanner and approval", "required source file missing")
    probs=[]
    if not re.search(r"MCX_EXECUTION_SUSPENDED\s*=\s*True", cfg):
        probs.append("MCX_EXECUTION_SUSPENDED=True missing")
    if "if not mcx_execution_permitted():" not in scanner:
        probs.append("scanner hold check missing")
    if "MCX_EXECUTION_BLOCKED" not in legacy_scanner or "mcx_execution_permitted" not in legacy_scanner:
        probs.append("legacy commodity scanner hold missing")
    if "MCX_EXECUTION_BLOCKED" not in approval or "mcx_execution_permitted" not in approval:
        probs.append("commodity approval hold missing")
    if probs:
        return F("C12", "MCX execution hold covers scanner and approval", "; ".join(probs))
    return P("C12", "MCX execution hold covers scanner and approval", "both scanners, direct persistence, and REAL approval fail closed")

CHECKS = [c_margin,c_net_r,c_legacy_veto,c_trunc,c_gate_nsefo,c_gate_mcx,
          c_gate_default,c_scan_enforce,c_goldguinea,c_single_source,c_rails,c_mcx_hold]

# ----------------------------------------------------------------- reconcile
def reconcile(files, csv_path):
    _,segs = _gate_dict(files)
    permit = {seg:set(segs[seg]["permit"].keys()) for seg in segs} if segs else CANON_PERMIT
    rows=list(csv.DictReader(open(csv_path)))
    out=[]; cells=set(); marg_seen=False
    for r in rows:
        seg=(r.get("segment") or "").strip().upper()
        try: tf=int(float(r.get("time_frame") or r.get("tf")))
        except: tf=r.get("time_frame")
        cell=((r.get("e_regime") or "").strip().upper(),(r.get("a_regime") or "").strip().upper(),tf)
        cells.add((seg,cell))
        if cell not in permit.get(seg,set()):
            out.append(f"NOT-PERMITTED: {seg} {cell[0]}/{cell[1]}/tf{cell[2]}  symbol={r.get('symbol','')}")
        if seg in CANON_MARGINAL and cell in CANON_MARGINAL[seg]: marg_seen=True
    print("=== POST-DEPLOY RECONCILIATION (emitted cells vs permitted gate) ===")
    print(f"rows={len(rows)}  distinct (segment,cell)={len(cells)}")
    if out:
        print(f"\n[FAIL] {len(out)} emission(s) outside the permitted schedule:")
        for o in out[:50]: print("  "+o)
    else:
        print("[PASS] every emitted cell is permitted by the gate.")
    # truncation fingerprint: cash CORE present but zero marginal over a meaningful sample
    cash_core = any(seg=="NSE_CASH" for seg,_ in cells)
    if cash_core and not marg_seen and len(rows)>=20:
        print("\n[WARN] zero NSE_CASH MARGINAL-cell emissions over "
              f"{len(rows)} rows — possible 0.5-truncation fingerprint (bug-4 regression). Investigate.")
    return 0 if not out else 1

# ----------------------------------------------------------------- main
def _write_reports(report_dir, drop_dir, files, manifest, changes, results, verdict, counts, exit_code, report_text):
    """Write verify_report.md (human) + verify_report.json (structured) into report_dir.
    Returns (md_path, json_path, error|None). Never raises — delivery is best-effort."""
    ts = datetime.now(timezone.utc).isoformat()
    md = os.path.join(report_dir, "verify_report.md")
    js = os.path.join(report_dir, "verify_report.json")
    try:
        os.makedirs(report_dir, exist_ok=True)
        with open(md, "w", encoding="utf-8") as f:
            f.write(f"# PREDIXA BE-drop verifier report\n\n"
                    f"- generated (UTC): {ts}\n- drop: {os.path.abspath(drop_dir)}\n"
                    f"- verdict: **{verdict}**  (exit {exit_code})\n\n```\n{report_text}\n```\n")
        with open(js, "w", encoding="utf-8") as f:
            json.dump({
                "generated_utc": ts,
                "drop_dir": os.path.abspath(drop_dir),
                "files": sorted(files),
                "source_manifest": manifest,
                "source_changes": changes,
                "verdict": verdict,
                "exit_code": exit_code,
                "counts": counts,
                "checks": [{"id": r.cid, "title": r.title, "status": r.status,
                            "evidence": r.evidence} for r in results],
            }, f, indent=2)
        return md, js, None
    except Exception as e:
        return None, None, str(e)


def _load_previous_manifest(path):
    try:
        with open(path, encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"previous report is unreadable: {exc}") from exc
    return payload.get("source_manifest")


def _append_event_log(path, event):
    """Append one machine-readable, no-secret verifier event for log collectors."""
    try:
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, sort_keys=True) + "\n")
    except OSError as exc:
        return str(exc)
    return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("drop_dir")
    ap.add_argument("--reconcile", metavar="CSV", default=None)
    ap.add_argument("--report-dir", metavar="DIR", default=None,
                    help="where to write verify_report.md/.json (default: the drop_dir)")
    ap.add_argument("--event-log", metavar="JSONL", default=None,
                    help="append one structured verifier event for automated log collection")
    ap.add_argument("--previous-report", metavar="JSON", default=None,
                    help="compare source fingerprints with a previous verify_report.json")
    ap.add_argument("--no-report", action="store_true", help="print only; write no report files")
    a=ap.parse_args()
    files=load_sources(a.drop_dir)
    if not files:
        print(f"no .py files under {a.drop_dir}"); return 2
    manifest = source_manifest(a.drop_dir)
    try:
        changes = (compare_source_manifests(_load_previous_manifest(a.previous_report), manifest)
                   if a.previous_report else None)
    except ValueError as exc:
        print(f"HOLD: invalid source-change baseline: {exc}")
        return 2
    if a.reconcile:
        return reconcile(files, a.reconcile)

    results=[chk(files) for chk in CHECKS]
    width=max(len(r.title) for r in results)
    icon={"PASS":"PASS","FAIL":"FAIL","WARN":"WARN","NA":" NA "}
    L=["="*78,
       f"PREDIXA BE-DROP VERIFIER — {os.path.abspath(a.drop_dir)}",
       f"files: {', '.join(sorted(files))}",
       "="*78]
    if changes is not None:
        L.append("SOURCE-CHANGES: " + ", ".join(
            f"{name}={len(changes[name])}" for name in ("added", "modified", "removed")))
    for r in results:
        L.append(f"[{icon[r.status]}] {r.cid:3} {r.title:<{width}}  {r.evidence}")
    fails=[r for r in results if r.status=="FAIL"]
    warns=[r for r in results if r.status=="WARN"]
    nas=[r for r in results if r.status=="NA"]
    L.append("="*78)
    if fails:
        verdict="HOLD — DO NOT DEPLOY"
        L.append(f"VERDICT: {verdict}  ({len(fails)} FAIL, {len(warns)} WARN, {len(nas)} NA)")
        L.append("  Regressions found: " + "; ".join(f"{r.cid}" for r in fails))
    else:
        verdict="CLEAR FOR PAPER"
        L.append(f"VERDICT: {verdict}  ({len(warns)} WARN, {len(nas)} NA)")
    L += ["-"*78,
          "LIMITS: regression gate only — a PASS clears the KNOWN failure modes, not a full",
          "review; it cannot catch a novel error class. NEVER authorizes a REAL lot — REAL",
          "stays a human decision behind the operational gates (migration, data updater,",
          "approve-one). A human adjudicates every WARN/FAIL and anything new."]
    report_text="\n".join(L)
    print(report_text)
    exit_code = 1 if fails else 0
    report_paths = {"markdown": None, "json": None}
    if not a.no_report:
        rdir = a.report_dir or a.drop_dir
        counts={"PASS":sum(1 for r in results if r.status=="PASS"),
                "FAIL":len(fails),"WARN":len(warns),"NA":len(nas)}
        md,js,err=_write_reports(rdir,a.drop_dir,files,manifest,changes,results,verdict,counts,exit_code,report_text)
        report_paths = {"markdown": md, "json": js}
        print(f"\n[report not written: {err}]" if err else f"\nreports written: {md}  |  {js}")
    else:
        counts={"PASS":sum(1 for r in results if r.status=="PASS"),
                "FAIL":len(fails),"WARN":len(warns),"NA":len(nas)}
    if a.event_log:
        event = {
            "event_type": "predixa_drop_verifier",
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "drop_dir": os.path.abspath(a.drop_dir),
            "verdict": verdict,
            "exit_code": exit_code,
            "counts": counts,
            "source_manifest_sha256": hashlib.sha256(
                json.dumps(manifest, sort_keys=True).encode("utf-8")).hexdigest(),
            "source_changes": changes,
            "failed_checks": [r.cid for r in fails],
            "report_paths": report_paths,
        }
        event_error = _append_event_log(a.event_log, event)
        if event_error:
            print(f"HOLD: automated event log was not written: {event_error}")
            return 2
        print(f"event written: {os.path.abspath(a.event_log)}")
    return exit_code

if __name__=="__main__":
    sys.exit(main())
