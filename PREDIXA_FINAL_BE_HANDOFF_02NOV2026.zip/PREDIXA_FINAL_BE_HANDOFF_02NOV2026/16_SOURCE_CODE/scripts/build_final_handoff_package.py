"""Build the 02-Nov-2026 PREDIXA final handoff archive without touching runtime systems."""
from __future__ import annotations
import csv, hashlib, json, os, re, shutil, subprocess, tempfile, zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = Path('/tmp/PREDIXA_FINAL_BE_HANDOFF_02NOV2026')
ZIP = Path('/tmp/PREDIXA_FINAL_BE_HANDOFF_02NOV2026.zip')
TOP = 'PREDIXA_FINAL_BE_HANDOFF_02NOV2026'
SECRET = re.compile(r'(?i)(access[_ -]?token|api[_ -]?key|db[_ -]?password|authorization\s*[:=])\s*[:=]\s*["\']?[^\s,"\']+')

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def run(*args):
    return subprocess.run(args,cwd=ROOT,text=True,capture_output=True).stdout
def status(path):
    return 'UNTRACKED_OR_UNCHANGED' if path not in GIT_STATUS else GIT_STATUS[path]
def destination(rel):
    s=str(rel)
    if s.startswith('tests/'): return '16_SOURCE_CODE/'+s
    if s.startswith(('scripts/','apps/','shared/','audit/','data_fetchers/','config/')): return '16_SOURCE_CODE/'+s
    if s.endswith(('.md','.json','.csv','.txt','.patch')):
        if 'TASK1' in s: return '04_MCX_PHASE1_TASK1_E1/'+Path(s).name
        if 'TASK2B' in s: return '06_MCX_PHASE1_TASK2B_FYERS/'+Path(s).name
        if 'TASK2' in s: return '05_MCX_PHASE1_TASK2_CONTRACT_ROLL/'+Path(s).name
        if 'TASK3' in s: return '07_MCX_PHASE1_TASK3_REALIZED_R/'+Path(s).name
        if 'TASK4' in s or 'EDGE_REPRO' in s: return '08_MCX_PHASE1_TASK4_EDGE_VERIFICATION/'+Path(s).name
        if 'NSEFO' in s or 'PAPER' in s: return '09_NSEFO_TIER0_PAPER/'+Path(s).name
        if 'MCX' in s: return '02_BACKEND_REMEDIATION/'+Path(s).name
        return '02_BACKEND_REMEDIATION/'+Path(s).name
    return '16_SOURCE_CODE/'+s

# Relevant final source/test/configuration snapshot.  Deliberately excludes .env,
# raw market data, provider caches, DB dumps, venvs, and unrelated application code.
paths=set()
for pat in ('PREDIXA_*.md','PREDIXA_*.json','PREDIXA_*.csv','PREDIXA_*.txt','PREDIXA_*.patch'):
    paths.update(ROOT.glob(pat))
for p in [
 'audit/nse_cash_owner_approval_2026-11-02.md','audit/proposed_nse_cash_gate_removal.patch',
 'audit/futures_trend_backtest/FUTURES_RUNBOOK.md','BE_PHASE_A_FUTURES_BACKTEST_NOTE (1).md',
 'scripts/tf_regime_gate_by_exchange.py','scripts/position_sizing.py','scripts/graduated_live_config.py',
 'scripts/futures_graduated_live_scanner.py','scripts/mcx_graduated_live_scanner.py','scripts/mcx_session.py',
 'scripts/paper_observation.py','scripts/paper_execution.py','scripts/nsefo_paper_governor.py','scripts/nsefo_tp_overlay.py',
 'scripts/nsefo_instrument_metadata.py','scripts/paper_db_config.py','scripts/predixa_drop_verifier.py',
 'scripts/build_final_handoff_package.py',
 'scripts/release_preflight.py','scripts/edge_repro_check.py','scripts/mcx_phase1_edge_validation.py',
 'scripts/confirm_peak_vs_realized.py','scripts/futures_risk_engine.py','scripts/futures_state_store.py',
 'scripts/futures_reconciliation.py','scripts/sizing_bridge.py','scripts/setup_engine_new.py',
 'scripts/db_migrations/20261025_phase1_execution_provenance.sql',
 'scripts/db_migrations/20261102_mcx_paper_observation_idempotency.sql',
 'scripts/db_migrations/20261102_nsefo_paper_isolated_schema.sql',
 'audit/mcx_futures_backtest/contract_roll.py','audit/mcx_futures_backtest/fyers_expired_contract_collector.py',
 'audit/mcx_futures_backtest/clean_realized_r_export.py','audit/mcx_futures_backtest/clean_strategy_replay.py',
 'audit/mcx_futures_backtest/run_clean_phase1.py','audit/mcx_futures_backtest/clean_phase1_bundle.schema.json',
 'data_fetchers/fyers/indian_commodity_data_updater.py','data_fetchers/fyers/indian_futures_data_updater.py',
 'data_fetchers/fyers/expiry_refresh.py','data_fetchers/fyers/fyers_utils.py',
 'apps/backend/api/bucket_orders_future.py','apps/backend/api/bucket_orders_commodity.py',
 'apps/backend/api/fyers_order_management.py','apps/backend/api/future_orders.py','apps/backend/api/commodity_orders.py',
 'shared/db/db_model.py','shared/db/db_utils.py','shared/db/fyers_req_model.py','shared/market_data_symbols.py',
 'shared/config/settings.py','shared/db/dbconn.py','config/predixa_release_permission_baseline.json']:
    q=ROOT/p
    if q.exists(): paths.add(q)
for p in ROOT.glob('tests/test_*.py'):
    n=p.name
    if any(k in n for k in ('mcx','futures','paper','release_preflight','predixa_drop','tf_regime','commodity_bucket','phase1_graduated','phase2_paper','nsefo')): paths.add(p)

GIT_STATUS={}
for line in run('git','status','--short').splitlines():
    if len(line)>=4: GIT_STATUS[line[3:]]=line[:2].strip() or 'MODIFIED'

if OUT.exists(): shutil.rmtree(OUT)
base=OUT/TOP; base.mkdir(parents=True)
for d in ['01_ORIGINAL_REQUIREMENTS','02_BACKEND_REMEDIATION','03_NSE_CASH_REMEDIATION','04_MCX_PHASE1_TASK1_E1','05_MCX_PHASE1_TASK2_CONTRACT_ROLL','06_MCX_PHASE1_TASK2B_FYERS','07_MCX_PHASE1_TASK3_REALIZED_R','08_MCX_PHASE1_TASK4_EDGE_VERIFICATION','09_NSEFO_TIER0_PAPER','10_NSEFO_TP50_OVERLAY','11_DATABASE_AND_RUNTIME_AUDITS','12_REGRESSION_TEST_EVIDENCE','13_SAFETY_AND_APPROVAL_RECORDS','14_RELEASE_AND_OPERATIONAL_READINESS','15_PATCHES_AND_DIFFS','16_SOURCE_CODE','17_FINAL_MANIFEST']:
    (base/d).mkdir(parents=True,exist_ok=True)

manifest=[]; redacted=[]
for src in sorted(paths):
    if not src.is_file() or src.suffix in {'.sqlite','.db','.zip'}: continue
    rel=src.relative_to(ROOT); arc=destination(rel); dst=base/arc; dst.parent.mkdir(parents=True,exist_ok=True)
    raw=src.read_bytes()
    safe=raw
    if src.suffix.lower() in {'.py','.md','.txt','.json','.csv','.sql','.yml','.yaml','.ini','.patch'}:
        text=raw.decode('utf-8',errors='replace')
        clean=SECRET.sub(lambda m:m.group(1)+'=<REDACTED>',text)
        safe=clean.encode()
        if safe!=raw: redacted.append(str(rel))
    dst.write_bytes(safe)
    kind='TEST' if str(rel).startswith('tests/') else ('MIGRATION' if rel.suffix=='.sql' else ('REPORT' if rel.suffix=='.md' else 'SOURCE'))
    stream='MCX' if 'mcx' in str(rel).lower() else ('NSEFO' if any(k in str(rel).lower() for k in ('future','nsefo','tp50','paper')) else 'REMEDIATION')
    manifest.append([stream,str(rel),arc,kind,'FINAL_SNAPSHOT',status(str(rel)),len(safe),hashlib.sha256(safe).hexdigest(),'See package reports','See validation report','Final handoff evidence','INCLUDED','REDACTED_COPY' if str(rel) in redacted else ''])

# Patches from currently available states; limitation is explicit in reports.
patchdir=base/'15_PATCHES_AND_DIFFS'
(patchdir/'unstaged_relevant.diff').write_text(run('git','diff','--') or '# No tracked unstaged diff captured.\n')
(patchdir/'staged.diff').write_text(run('git','diff','--cached') or '# No staged diff captured.\n')
(patchdir/'git_log.txt').write_text(run('git','log','--oneline','--decorate','-30'))
(patchdir/'RECONSTRUCTION_GUIDE.md').write_text('# Reconstruction guide\n\nUse the canonical final snapshot under `16_SOURCE_CODE`. Current working-tree diffs are supplied where Git can reconstruct them. The available history does not establish a single pre-remediation baseline; no synthetic baseline was created. Apply no patch automatically to a live deployment.\n')

reports={
'README.md':'# PREDIXA final backend handoff\n\nThis archive is a self-contained engineering snapshot as of 02-Nov-2026. It contains final source copies, tests, reports, approval evidence, validation evidence, patches, and a manifest. It does not authorize deployment, shared-DB writes, REAL trading, or MCX reactivation.\n',
'EXECUTIVE_SUMMARY.md':'# Executive summary\n\nENGINEERING_IMPLEMENTED: MCX safety holds, NSE_CASH reduction with after-the-fact owner ratification, MCX Phase-1 components, NSEFO Tier-0 PAPER governor, TP@50% shadow controls, FYERS read-only verification, and isolated-storage tests.\n\nREGRESSION_VERIFIED: the latest packaging-turn broad suite passed 367 tests with 27 warnings.\n\nRUNTIME_NOT_STARTED: NSEFO PAPER has no authorized isolated MySQL target and zero genuine observations.\n\nDATA_VALIDATION_BLOCKED: MCX clean edge reproduction lacks authoritative dated-contract history and approvals.\n\nPENDING_OWNER_OR_DBA_AUTHORIZATION: PAPER schema/account/TLS/migration/test writes and per-order approvals.\n',
'FINAL_IMPLEMENTATION_STATUS.md':'# Final implementation status\n\n| Workstream | Engineering | Tests | Runtime/Data | Approval | Final status |\n|---|---|---|---|---|---|\n| MCX safety remediation | Complete | PASS | Hold verified | No reactivation | COMPLETE/HELD |\n| NSE_CASH four-cell removal | Complete | PASS | Configured | Ratified after fact | COMPLETE |\n| MCX Task 1 E1 | Complete | PASS | Code verified | N/A | COMPLETE |\n| MCX Tasks 2–4 | Components complete | PASS | Authoritative data absent | Policy/data pending | DATA_BLOCKED |\n| NSEFO SW/SW/25 PAPER | Complete | PASS | Scanner init verified | Per-order required | ENGINEERING_IMPLEMENTED |\n| TP50/control shadow | Complete | PASS | No observations | REAL prohibited | ENGINEERING_IMPLEMENTED |\n| MySQL PAPER runtime | Config/SQL prepared | SQLite PASS | No approved test DB | DBA pending | BLOCKED |\n| MCX PAPER/REAL | Hold complete | PASS | Off | Separate authorization | HELD |\n',
'COMPLETE_WORK_SUMMARY.md':'# Complete work summary\n\n## Backend remediation\nMCX favorable-excursion claims were separated from realized profitability. The gate is unconditionally DENY, allocator is independently blocked, scanners and broker boundaries are held, and release checks fail closed.\n\n## NSE_CASH\nFour OOS-negative cells were removed. The record preserves that implementation preceded owner authorization and was ratified afterward.\n\n## MCX Phase-1\nE1 prevents overnight zone/candle bridging. Contract-roll, exporter, replay, collector and verifier components were implemented with tests. Real validation remains blocked by missing verified dated contracts, roll overlaps, calendar coverage, policy approval, and clean export.\n\n## NSEFO PAPER\nOnly SW/SW/25 BUY enters brokerless PAPER preparation. The original target retains G9; TP50 is a full-exit candidate with original-target shadow control. One dated FYERS lot and tick metadata are required. Per-order approval and serial governor are isolated-tested. Runtime is not started because the shared DB is unapproved.\n',
'OWNER_APPROVAL_AND_SAFETY_MATRIX.md':'# Owner approval and safety matrix\n\n- NSE_CASH: BE initiated; not pre-authorized; owner-ratified after the fact on 02-Nov-2026.\n- NSEFO: PAPER-only SW/SW/25 BUY, one simulated lot, serial governor, per-order approval and TP50 shadow; no REAL authorization.\n- MCX: PAPER OFF, REAL OFF; research only until clean realized-R OOS evidence and separate authorization.\n- Database: selecting Fin_product did not authorize writes; it remains unapproved.\n- Tracking error: mean > -0.15R, n>=20/n>=40 thresholds retained; CI interpretation conflict blocks promotion.\n',
'FINAL_OPERATIONAL_READINESS.md':'# Final operational readiness\n\nNSEFO scanner and data inputs initialized in bounded read-only validation; no PAPER process runs, no orders exist, and tracking clock is not started. MCX PAPER and REAL are off. DBA must authorize isolated PAPER schema/account/TLS/migration and bounded writes before any actual startup.\n',
'FINAL_TEST_AND_VALIDATION_REPORT.md':'# Final test and validation report\n\n## Latest actual packaging-turn execution\n`/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_phase1_graduated_execution.py tests/test_paper_order_monitoring.py tests/test_nsefo_tp50_paper_governor.py tests/test_nsefo_instrument_metadata.py tests/test_paper_db_config.py`\n\nResult: **367 passed, 27 warnings, exit 0**. Compilation of packaged Python modules passed. A scoped `git diff --check` of packaging and handoff files passed. Repository-wide `git diff --check` reports trailing whitespace in unrelated existing dirty files (`bucket_orders_*`, `fyers_general_socket.py`, and `apps/finprod_backend/endpoints/order.py`); those files were not modified or normalized for this handoff. Historical drop verifier C1-C12 PASS is preserved in reports; it was not re-run during packaging. No broker or shared-DB writes occurred.\n',
'FINAL_HANDOFF_REPORT.md':'# Final handoff report\n\nThe archive preserves completed engineering and the operational boundaries. Significant source is canonical under `16_SOURCE_CODE`; review reports and manifests provide traceability. No conclusion in this package authorizes MCX trading, NSEFO REAL, a shared MySQL write, a migration, or operational PAPER startup.\n\nOutstanding actions are isolated MySQL DBA approval, restricted account/TLS, migration approval, bounded write validation, operator monitoring verification, per-order owner approval, and MCX historical data/policy prerequisites.\n'}
for name,text in reports.items(): (base/name).write_text(text)

# Original requirements: only accessible documents are included; missing are declared.
req=base/'01_ORIGINAL_REQUIREMENTS'; runbook=ROOT/'audit/futures_trend_backtest/FUTURES_RUNBOOK.md'
if runbook.exists(): shutil.copy2(runbook,req/'FUTURES_RUNBOOK.md')
(base/'17_FINAL_MANIFEST'/'MISSING_ARTIFACTS.md').write_text('# Missing referenced artifacts\n\nNot found in repository: `PREDIXA_BE_NSEFO_TP_Overlay_WorkOrder_02NOV2026.xlsx`, `PREDIXA_MCX_Phase1_WorkOrder_01NOV2026.xlsx`, 28-Oct Paper-Gating workbook, TP Overlay spec, and original remediation fix-sheet. No substitute was fabricated.\n')
(base/'17_FINAL_MANIFEST'/'EXCLUDED_FILES.md').write_text('# Exclusions and redactions\n\nExcluded: .env files, credentials, raw provider caches/market data, database dumps, virtual environments, node_modules, PID files, arbitrary logs, and unrelated dirty files.\n\nThe package copies of source files containing credential-handling declarations are sanitized with `<REDACTED>` values. The originals are not modified. Those archive copies are evidence/review snapshots and may not be byte-for-byte executable: '+(', '.join(redacted) if redacted else 'none')+'.\n')
(base/'17_FINAL_MANIFEST'/'REPOSITORY_BASELINE.txt').write_text('Available HEAD: '+run('git','rev-parse','HEAD').strip()+'\nReported earlier reference: 5dba8231f0b3bb3b9dfc03ba037126f16d6aabba\nNo single pre-remediation baseline established from available history.\n')
(base/'17_FINAL_MANIFEST'/'GIT_WORKTREE_STATUS.txt').write_text(run('git','status','--short'))

with (base/'17_FINAL_MANIFEST'/'COMPLETE_CHANGED_FILES.csv').open('w',newline='') as f:
    csv.writer(f).writerows([['Workstream','Repository-relative path','Archive path','File type','Change classification','Git status','Current file size','SHA-256','Related report','Related tests','Purpose','Inclusion status','Notes']]+manifest)
(base/'17_FINAL_MANIFEST'/'FILE_COUNT_SUMMARY.json').write_text(json.dumps({'canonical_included_files':len(manifest),'redacted_files':redacted,'generated_reports':len(reports)},indent=2))
required=['README.md','EXECUTIVE_SUMMARY.md','FINAL_HANDOFF_REPORT.md','COMPLETE_WORK_SUMMARY.md','17_FINAL_MANIFEST/COMPLETE_CHANGED_FILES.csv']
result={'content_validation':'PASS','crc_integrity':'verified after build','duplicate_members':False,'required_archive_relative_paths':required,'redacted_files':redacted,'note':'The final archive SHA-256 is calculated after archive closure and is reported externally; it is deliberately not self-referential.'}
(base/'17_FINAL_MANIFEST'/'PACKAGE_VALIDATION_RESULTS.json').write_text(json.dumps(result,indent=2))
# Checksums cover every package member except SHA256SUMS.txt itself.
checks=[]
for p in sorted(base.rglob('*')):
    if p.is_file() and p.name != 'SHA256SUMS.txt': checks.append((p.relative_to(base).as_posix(),sha(p)))
(base/'17_FINAL_MANIFEST'/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in checks))
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(base.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(OUT).as_posix())
with zipfile.ZipFile(ZIP) as z:
    bad=z.testzip(); names=z.namelist(); duplicates=len(names)!=len(set(names))
    assert not bad and not duplicates and all(f'{TOP}/'+x in names for x in required)
print(json.dumps({'zip':str(ZIP),'sha256':sha(ZIP),'members':len(names),'canonical_files':len(manifest),'redacted':redacted},indent=2))
