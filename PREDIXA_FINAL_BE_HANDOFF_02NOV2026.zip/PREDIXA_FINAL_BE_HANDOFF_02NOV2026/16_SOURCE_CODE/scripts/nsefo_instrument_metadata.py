"""Verified NSEFO lot/tick metadata from the FYERS public instrument master."""
from __future__ import annotations

import csv
import io
import re
import time
from datetime import date, datetime
from decimal import Decimal
from functools import lru_cache

import requests

FYERS_NSE_FO_MASTER_URL = "https://public.fyers.in/sym_details/NSE_FO.csv"


def _expiry_token(value: object) -> date:
    return datetime.strptime(str(value), "%d%m%Y").date()


@lru_cache(maxsize=1)
def _master(hour_bucket: int) -> dict[tuple[str, date], dict]:
    """Read schema-validated futures rows only; no lot/tick is inferred."""
    try:
        response = requests.get(FYERS_NSE_FO_MASTER_URL, timeout=30)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise RuntimeError("NSEFO_FYERS_MASTER_UNAVAILABLE") from exc
    result: dict[tuple[str, date], dict] = {}
    for row in csv.reader(io.StringIO(response.text)):
        # FYERS public NSE_FO schema observed 02-Nov-2026: description[1],
        # lot[3], tick[4], exact FYERS symbol[9].
        if len(row) < 10 or not row[9].startswith("NSE:") or not row[9].endswith("FUT"):
            continue
        match = re.fullmatch(r"(.+?)\s+(\d{2}\s+[A-Za-z]{3}\s+\d{2})\s+FUT", row[1].strip())
        if not match:
            continue
        try:
            expiry = datetime.strptime(match.group(2), "%d %b %y").date()
            lot, tick = int(Decimal(row[3])), Decimal(row[4])
            if lot <= 0 or tick <= 0:
                continue
        except (ArithmeticError, ValueError):
            continue
        result[(match.group(1).upper(), expiry)] = {
            "fyers_symbol": row[9], "lot_size": lot, "tick_size": float(tick),
            "source": "FYERS_NSE_FO_PUBLIC_MASTER",
        }
    return result


def resolve_nsefo_contract_metadata(symbol: object, expiry: object, *, now=None) -> dict:
    normalized, expiry_date = str(symbol or "").strip().upper(), _expiry_token(expiry)
    metadata = _master(int((now or time.time()) // 3600)).get((normalized, expiry_date))
    if metadata is None:
        raise ValueError(f"NSEFO_FYERS_CONTRACT_METADATA_MISSING:{normalized}:{expiry_date.isoformat()}")
    return dict(metadata) | {"symbol": normalized, "expiry": expiry_date.isoformat()}
