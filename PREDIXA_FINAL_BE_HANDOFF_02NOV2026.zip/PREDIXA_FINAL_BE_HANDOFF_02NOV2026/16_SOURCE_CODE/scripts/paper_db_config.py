"""Fail-closed isolated MySQL PAPER database configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import quote


@dataclass(frozen=True)
class PaperDatabaseConfig:
    host: str
    port: int
    schema: str
    user: str
    password: str
    ca_path: str
    expected_server_uuid: str

    @classmethod
    def from_environment(cls) -> "PaperDatabaseConfig":
        values = {name: os.getenv(name, "").strip() for name in (
            "PREDIXA_PAPER_DB_HOST", "PREDIXA_PAPER_DB_SCHEMA", "PREDIXA_PAPER_DB_USER",
            "PREDIXA_PAPER_DB_PASSWORD", "PREDIXA_PAPER_DB_CA", "PREDIXA_PAPER_DB_SERVER_UUID")}
        if not all(values.values()):
            raise RuntimeError("PAPER_DB_CONFIGURATION_INCOMPLETE")
        if values["PREDIXA_PAPER_DB_SCHEMA"] == "Fin_product":
            raise RuntimeError("PAPER_DB_SHARED_SCHEMA_REJECTED")
        try:
            port = int(os.getenv("PREDIXA_PAPER_DB_PORT", "3306"))
        except ValueError as exc:
            raise RuntimeError("PAPER_DB_PORT_INVALID") from exc
        return cls(values["PREDIXA_PAPER_DB_HOST"], port, values["PREDIXA_PAPER_DB_SCHEMA"],
                   values["PREDIXA_PAPER_DB_USER"], values["PREDIXA_PAPER_DB_PASSWORD"],
                   values["PREDIXA_PAPER_DB_CA"], values["PREDIXA_PAPER_DB_SERVER_UUID"])

    def sqlalchemy_url(self) -> str:
        return f"mysql+pymysql://{quote(self.user)}:{quote(self.password)}@{self.host}:{self.port}/{self.schema}"

    def connect_args(self) -> dict:
        return {"ssl": {"ca": self.ca_path, "check_hostname": True}}
