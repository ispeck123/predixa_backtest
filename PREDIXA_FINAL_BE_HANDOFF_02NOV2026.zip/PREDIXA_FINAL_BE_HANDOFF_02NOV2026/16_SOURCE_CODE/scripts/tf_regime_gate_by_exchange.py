"""
PREDIXA — Exchange-specific TF / regime gate
============================================
Drop-in, config-driven permission gate applied in the setup/permission layer
BEFORE a setup is emitted. Decides, per (exchange, strategy_tf, e_regime,
a_regime), whether to trade and at what size.

WHY exchange-specific:
  - The TF *set itself differs by exchange*. NSE cash / stock-futures use one
    strategy_tf enum; MCX commodities use a DIFFERENT stack (e.g. D-240-60).
    So a TF index means different things across exchanges — never share a list.
  - Regime edge is asset-class-specific (cross-asset study, 12-Oct-2026):
    equities favour with-trend / dip-buy, NOT sideways; commodities favour SW.
    So permit/deny cells must be derived per segment from that segment's own
    per-cell backtest — not copied across.

STATUS:
  - NSE_CASH : POPULATED from CASH_2Y_BACKTEST net-of-cost per-cell R (delivery).
  - MCX      : POPULATED from MCX_PHASE_A OOS finding (05-Oct-2026); GOLD+CRUDE only.
  - NSEFO    : POPULATED from NSEFO_REMAINING_2023_2026 labeled regime×TF export (152-univ).

Fail-open by design: an unconfigured/pending segment is NOT blocked (the gate is
additive; it only filters where we have data). Flip `default` to "DENY" per
segment once its backtest lands.
"""

from dataclasses import dataclass, field
from typing import Optional

# tier -> position-size multiplier
SIZE = {"CORE": 1.0, "MARGINAL": 0.5, "PERMIT": 1.0, "DENY": 0.0}


@dataclass
class ExchangeGate:
    tf_set: tuple                 # strategy_tf values valid for THIS exchange
    excluded_tfs: frozenset       # TFs net-negative in every regime -> always deny
    permit_cells: dict            # (e_regime, a_regime, strategy_tf) -> "CORE"|"MARGINAL"
    default: str = "DENY"         # for cells not excluded and not in permit_cells
    source: str = ""
    notes: str = ""
    universe: tuple = ()          # if set, gate applies ONLY to these underlyings/symbols
                                  # (empty = applies to the whole segment universe)


TF_REGIME_GATE = {
    # ---------------------------------------------------------------- NSE CASH
    # Source: CASH_2Y_BACKTEST_TRACKING_CELL_EVIDENCE, net of delivery cost
    # (STT 0.2% RT on ~1.5% stops => ~0.14R). tf1 net -0.36R in EVERY regime.
    # BUY-only engine. Cells not listed are DENY.
    "NSE_CASH": ExchangeGate(
        tf_set=(1, 2, 5, 6, 25),
        excluded_tfs=frozenset({1}),
        permit_cells={
            # edge_repro_check.py (31-Oct, realized R, OOS split 2025-11-01) in brackets:
            ("SW", "SW", 2): "CORE",  ("SW", "SW", 6): "CORE",  ("SW", "SW", 25): "CORE",  # reproduce: +1.02 / +0.47 / +1.69R
            ("SW", "UP", 6): "CORE",          # reproduces: OOS +0.39R
            # positive net mean but fat-tail-dependent -> half size, monitor
            ("UP", "SW", 2): "MARGINAL", ("UP", "SW", 5): "MARGINAL",   # reproduce: OOS +0.36 / +0.07R
        },
        default="DENY",
        source="CASH_2Y_BACKTEST net-of-cost per-cell R (delivery, STT 0.2%)",
        notes="Equity segment: SW/SW is the reproduced edge (SW/SW/25 OOS +1.69R). "
              "EDGE-REPRO REMEDIATION (02-Nov, owner approved): OOS-nonpositive cells SW/UP/2, "
              "UP/UP/2, UP/UP/5 (CORE), and UP/UP/25 (MARGINAL) were removed and now deny. "
              "tf1 excluded globally. The with-trend cells "
              "failing here match the live wet-run losses clustering in UP/UP/SW-UP.",
    ),

    # ------------------------------------------------------------------- MCX
    # *** UNVALIDATED — OFF (real AND paper) as of 31-Oct-2026. permit_cells intentionally empty. ***
    # The MCX GOLD+CRUDE edge does NOT reproduce on realized R. Reading the Phase-A baseline
    # export directly (realized gross_r = exit R; verified), the two "deployable" cells are
    # OOS-NEGATIVE: SW/SW/4 OOS -0.49R (12.6% win), UP/SW/3 OOS -0.56R (15% win). The Phase-A
    # "+1.61 / +0.70 / +1.14R" tracked PEAK favorable excursion (mfe_R +1.1 / +1.4R), NOT
    # realized expectancy — the trades spiked toward target then gave it ALL back to the stop.
    # The finding was over-claimed. (That series is also roll/stitch/overnight-gap contaminated
    # with E1 NOT enforced, so neither sign is trustworthy either way.)
    # RE-ENABLE ONLY after a clean realized-R reproduction on an E1-enforced, roll-corrected
    # series shows the cells OOS-positive — i.e. edge_repro_check.py must PASS. Until then DENY.
    "MCX": ExchangeGate(
        tf_set=(1, 2, 3, 4),
        excluded_tfs=frozenset(),
        permit_cells={},                   # UNVALIDATED — all MCX cells DENY (see banner above)
        default="DENY",
        source="UNVALIDATED — Phase-A non-reproducible on realized R (31-Oct-2026)",
        universe=("GOLDM", "CRUDEOILM"),   # retained for re-enable; inert while permit_cells is empty
        notes="MCX OFF pending clean realized-R re-validation (E1-enforced, roll-corrected series). "
              "Candidate cells were SW/SW/4 + UP/SW/3; both FAILED realized-R reproduction "
              "(positive only on peak excursion). Also revert position_sizing.SEGMENT_NET_R['MCX'] "
              "to a blocking value so the allocator BLOCKs the segment independent of this gate.",
    ),

    # ------------------------------------------------------------------ NSEFO
    # Source: NSEFO_REMAINING_2023_2026 labeled regime×TF export (run bb0029a3),
    # 152 underlyings, 147,434 BUY trades, 2023-01 -> 2026-10, TFs {1,25}.
    # Net-of-cost (per-trade RT 0.13%/stop%), BUY-only, multi-split OOS
    # (2025-07-01 / 2025-11-01 / 2026-02-01):
    #   - SW/SW/25: OOS +0.138 / +0.129 / +0.240 across ALL 3 splits; bootstrap 95%
    #     CI excludes 0 at each; drop-any-single-symbol still positive (worst +0.070,
    #     95 symbols) -> CORE. (Supersedes the core-8 negative; that was 8 symbols.)
    #   - SW/SW/1 : positive all 3 splits but THIN (n~318 OOS) and drop-best -> +0.018
    #     (fragile) -> DENY. (Would be MARGINAL, but the 0.5 tier is a NO-OP at tier-0:
    #     int(1 * 0.5) == 0 in sizing_bridge -> silently drops. Restore once that is fixed.)
    #   - All WITH-TREND cells (UP/UP, UP/SW, SW/UP) are positive in TRAIN but flip
    #     NEGATIVE OOS at every split -> overfit -> DENY.
    # NOTE: counter to the equity 'with-trend' prior, the surviving NSEFO edge is
    # SW/SW (range), mirroring cash. Applies to the whole NSEFO universe (regime x TF
    # is symbol-agnostic); NOT universe-scoped. SELL off (long-only).
    "NSEFO": ExchangeGate(
        tf_set=(1, 2, 5, 6, 25),           # M-W-D / W-D-60 / W-D-75 / D-125-25 / D-60-15
        excluded_tfs=frozenset(),
        permit_cells={
            ("SW", "SW", 25): "CORE",      # W-D-75; OOS +0.13..+0.24 (3 splits), CI excl 0, drop-best +0.07
            # ("SW","SW",1): fragile (thin, drop-best ~0) AND 0.5-tier is a no-op at tier-0 -> DENY for now
        },
        default="DENY",
        source="NSEFO_REMAINING_2023_2026 labeled regime×TF export (152-univ, 147k BUY)",
        notes="STILL PENDING the B-W-EMBED parameter sweep (C7/C8 lock) — that is a "
              "SEPARATE deliverable from this sizing schedule, not a blocker for it. "
              "Governor remains tier-0 single lot + graduated-live tracking-error gate "
              "before any scaling. Evidence base is the remaining-152 universe; "
              "consistent with the earlier 30-most-liquid pooled read.",
    ),
}


def gate(exchange: str, strategy_tf, e_regime: Optional[str] = None,
         a_regime: Optional[str] = None, symbol: Optional[str] = None):
    """
    Returns (tier, size_mult, reason).
      tier     : "CORE" | "MARGINAL" | "PERMIT" | "DENY"
      size_mult: position-size multiplier (0.0 means do not trade)
    Call in the permission layer before emitting a setup; drop the setup if
    size_mult == 0, else scale size by size_mult.

    `symbol` is optional; when a gate declares a `universe`, a symbol outside it
    is denied (used for MCX GOLD+CRUDE scoping). Pass the underlying/symbol when
    the segment is universe-scoped.
    """
    # MCX is under an explicit operational hold.  Keep this ahead of all
    # parsing/scoping so malformed TFs, omitted symbols, aliases (GOLD,
    # GOLDGUINEA, CRUDE), and legacy callers cannot reach a fail-open branch.
    # Do not normalize arbitrary exchange names here: unknown exchanges retain
    # the legacy behaviour below, while the configured MCX segment fails closed.
    if str(exchange or "").strip().upper() == "MCX":
        return ("DENY", 0.0, "MCX operational hold: clean-series OOS revalidation and owner authorization required")

    cfg = TF_REGIME_GATE.get(exchange)
    if cfg is None:
        return ("PERMIT", 1.0, f"unconfigured exchange '{exchange}' -> fail-open")

    # universe scoping (e.g. MCX GOLD+CRUDE only)
    if cfg.universe and symbol is not None and symbol not in cfg.universe:
        return ("DENY", 0.0, f"{exchange} symbol {symbol} not in scoped universe {cfg.universe}")

    if cfg.tf_set and strategy_tf not in cfg.tf_set:
        # TF index not valid for this exchange — almost always a wiring bug.
        return ("PERMIT", 1.0, f"tf {strategy_tf} not in {exchange} tf_set -> fail-open (check wiring)")

    if strategy_tf in cfg.excluded_tfs:
        return ("DENY", 0.0, f"tf {strategy_tf} excluded on {exchange} (net-negative all regimes)")

    tier = cfg.permit_cells.get((e_regime, a_regime, strategy_tf))
    if tier:
        return (tier, SIZE[tier], f"{exchange} {e_regime}/{a_regime}/tf{strategy_tf} = {tier}")

    if cfg.default == "PERMIT_ALL":
        return ("PERMIT", 1.0, f"{exchange} gate pending backtest -> fail-open")
    return ("DENY", 0.0, f"{exchange} {e_regime}/{a_regime}/tf{strategy_tf} not in permit set")


# ---------------------------------------------------------------------------
# INTEGRATION
# ---------------------------------------------------------------------------
# In the permission/scoring layer, where a setup's permission_state is finalised:
#
#     tier, size_mult, reason = gate(exchange, strategy_tf, e_regime, a_regime, symbol)
#     if size_mult == 0.0:
#         skip_setup(reason)            # do not emit
#     else:
#         setup.size *= size_mult       # CORE=full, MARGINAL=half
#         setup.gate_tier = tier
#         setup.gate_reason = reason    # for the tracking-cell audit trail
#
# NOTES
# - `exchange` must be the segment key ("NSE_CASH" | "MCX" | "NSEFO"), derived
#   from the instrument/segment, NOT guessed from the symbol.
# - NSEFO + MCX are now POPULATED with default="DENY"; re-derive a segment's cells
#   ONLY from that segment's own labeled export, never copied across segments.
# - Keep this the SINGLE source of truth for TF/regime gating across segments.
# - WIRING position_sizing: the sizer currently reads its own global dict
#   REGIME_TF_SIZE_WEIGHT keyed by (E,A,TF) with no segment — unsafe (TF codes
#   collide across segments). Point sizing_bridge / PositionSizer.size() here:
#       w = gate(s.segment, int(s.time_frame), s.e_regime, s.a_regime, s.symbol)[1]
#       if w <= 0.0: return None
#   BUT first reconcile the CASH divergence noted on NSE_CASH above — this gate's
#   cash schedule is not identical to the sizer's dict, and cash is live.

if __name__ == "__main__":
    for ex, tf, e, a, sym in [
        ("NSE_CASH", 1, "SW", "SW", None),   ("NSE_CASH", 2, "SW", "SW", None),
        ("NSE_CASH", 2, "UP", "SW", None),   ("NSE_CASH", 25, "UP", "SW", None),
        ("MCX", 4, "SW", "SW", "GOLDM"),     ("MCX", 3, "UP", "SW", "CRUDEOILM"),
        ("MCX", 4, "SW", "SW", "SILVERM"),   ("MCX", 2, "SW", "SW", "GOLDM"),
        ("NSEFO", 1, "UP", "UP", None),
    ]:
        print(f"{ex:9} tf{tf:<3} {e}/{a} {str(sym):10} -> {gate(ex, tf, e, a, sym)}")
