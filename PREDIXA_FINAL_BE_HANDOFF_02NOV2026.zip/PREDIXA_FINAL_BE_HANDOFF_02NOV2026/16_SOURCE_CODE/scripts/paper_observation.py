"""Brokerless local PAPER_OBSERVATION path for MCX setup monitoring.

This module is intentionally independent of the MCX REAL gate and the shared
production database connection.  It accepts only an explicitly enabled local
paper configuration and a marked SQLite database.  It imports no broker
client and contains no broker mutation calls.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Callable, Iterable

from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from scripts.graduated_live_config import PAPER, MCX_PAPER_OBSERVATION_AUTHORIZED
from shared.db.db_model import (
    Base,
    Commodity_Order,
    CommoditiesMaster,
    OMSOrderBucketCommodity,
    TradeSignal,
)

MCX_OBSERVATION_SOURCE = "MCX_PAPER_OBSERVATION"
MCX_OBSERVATION_UNIVERSE = frozenset(
    {"GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"}
)
MCX_EXCHANGE_ID = 10
PAPER_DB_IDENTITY_TABLE = "predixa_local_paper_identity"


@dataclass(frozen=True)
class PaperObservationConfig:
    enabled: bool
    runtime_environment: str
    database_path: Path | None
    local_root: Path | None = None

    @classmethod
    def from_environment(cls) -> "PaperObservationConfig":
        enabled = os.getenv("MCX_PAPER_OBSERVATION_ENABLED", "").strip().lower() in {
            "1", "true", "yes", "on"
        }
        configured_path = os.getenv("PREDIXA_PAPER_DB_PATH", "").strip()
        return cls(
            enabled=enabled,
            runtime_environment=os.getenv("PREDIXA_RUNTIME_ENV", "").strip().upper(),
            database_path=Path(configured_path).expanduser() if configured_path else None,
            local_root=Path.cwd() / "var" / "local_paper",
        )


def validate_local_paper_config(config: PaperObservationConfig, *, require_enabled: bool = True) -> Path:
    """Fail closed unless explicitly configured for a marked local SQLite DB."""
    if not MCX_PAPER_OBSERVATION_AUTHORIZED:
        raise RuntimeError("MCX_PAPER_OBSERVATION_OPERATIONALLY_HELD")
    if require_enabled and not config.enabled:
        raise RuntimeError("MCX_PAPER_OBSERVATION_DISABLED")
    if config.runtime_environment != "LOCAL_PAPER":
        raise RuntimeError("PAPER_OBSERVATION_REQUIRES_LOCAL_PAPER_ENV")
    if config.database_path is None:
        raise RuntimeError("PAPER_OBSERVATION_DATABASE_PATH_REQUIRED")
    path = config.database_path.expanduser().resolve()
    root = (config.local_root or (Path.cwd() / "var" / "local_paper")).expanduser().resolve()
    if not path.is_relative_to(root):
        raise RuntimeError("PAPER_OBSERVATION_DATABASE_OUTSIDE_LOCAL_ROOT")
    if path.suffix.lower() not in {".sqlite", ".sqlite3", ".db"}:
        raise RuntimeError("PAPER_OBSERVATION_REQUIRES_SQLITE_DATABASE")
    if not path.is_file():
        raise RuntimeError("PAPER_OBSERVATION_DATABASE_NOT_INITIALIZED")
    return path


def _paper_tables():
    return [
        Base.metadata.tables[name]
        for name in (
            "commodities_master",
            "trade_signals",
            "commodity_order_master",
            "oms_order_bucket_commodity",
        )
    ]


def initialize_local_paper_database(path: Path, *, local_root: Path | None = None) -> None:
    """Explicit local setup helper; refuses to adopt an existing unmarked DB."""
    path = Path(path).expanduser().resolve()
    root = (local_root or (Path.cwd() / "var" / "local_paper")).expanduser().resolve()
    if not path.is_relative_to(root):
        raise RuntimeError("PAPER_OBSERVATION_DATABASE_OUTSIDE_LOCAL_ROOT")
    if path.exists():
        raise RuntimeError("REFUSE_TO_INITIALIZE_OR_ADOPT_EXISTING_DATABASE")
    path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(f"sqlite:///{path}", future=True)
    try:
        Base.metadata.create_all(engine, tables=_paper_tables())
        with engine.begin() as connection:
            connection.execute(text(
                f"CREATE TABLE {PAPER_DB_IDENTITY_TABLE} "
                "(identity_id INTEGER PRIMARY KEY, environment TEXT NOT NULL, "
                "created_at TEXT NOT NULL)"
            ))
            connection.execute(
                text(f"INSERT INTO {PAPER_DB_IDENTITY_TABLE} "
                     "(identity_id, environment, created_at) VALUES (1, :env, :created)"),
                {"env": "LOCAL_PAPER", "created": datetime.now(timezone.utc).isoformat()},
            )
    finally:
        engine.dispose()


def _assert_marked_local_db(engine) -> None:
    try:
        with engine.connect() as connection:
            row = connection.execute(text(
                f"SELECT environment FROM {PAPER_DB_IDENTITY_TABLE} WHERE identity_id=1"
            )).first()
    except Exception as exc:
        raise RuntimeError("PAPER_DATABASE_IDENTITY_UNVERIFIED") from exc
    if row is None or row[0] != "LOCAL_PAPER":
        raise RuntimeError("PAPER_DATABASE_IDENTITY_UNVERIFIED")


def local_paper_session_factory(config: PaperObservationConfig | None = None, *, require_enabled: bool = True):
    config = config or PaperObservationConfig.from_environment()
    path = validate_local_paper_config(config, require_enabled=require_enabled)
    engine = create_engine(f"sqlite:///{path}", future=True)
    try:
        _assert_marked_local_db(engine)
    except Exception:
        engine.dispose()
        raise
    return sessionmaker(bind=engine, expire_on_commit=False, future=True), engine


def _canonical_timestamp(value: Any) -> str:
    if value is None:
        raise ValueError("PAPER_OBSERVATION_SIGNAL_TIMESTAMP_REQUIRED")
    if isinstance(value, (int, float)):
        parsed = datetime.fromtimestamp(float(value), tz=timezone.utc)
        return parsed.isoformat()
    if isinstance(value, datetime):
        parsed = value
    else:
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("PAPER_OBSERVATION_INVALID_SIGNAL_TIMESTAMP") from exc
    if parsed.tzinfo is None:
        # Strategy timestamps are repository-local IST unless explicitly zoned.
        from zoneinfo import ZoneInfo
        parsed = parsed.replace(tzinfo=ZoneInfo("Asia/Kolkata"))
    return parsed.astimezone(timezone.utc).isoformat()


def _signal_timestamp(formatted: dict, side: str, job: Any) -> str:
    values = formatted.get(f"{side}_TIMESTAMPS") or {}
    if isinstance(values, dict):
        for key in ("signal_timestamp", "entry_price_timestamp", "setup_timestamp", "timestamp"):
            if values.get(key) is not None:
                return _canonical_timestamp(values[key])
        nested = values.get("timestamp_list")
        if isinstance(nested, list) and nested:
            return _canonical_timestamp(nested[-1])
    return _canonical_timestamp(getattr(job, "signal_timestamp", None))


def _stable_key(symbol: str, expiry: str, timeframe: int, side: str,
                signal_timestamp: str) -> str:
    material = "|".join(("MCX", symbol, expiry, str(timeframe), side,
                         signal_timestamp))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _levels_for_side(formatted: dict, side: str):
    values = formatted.get(side)
    if not isinstance(values, dict):
        return None
    entry = float(values["entry_price"])
    stop = float(values["stop_loss"])
    target = float(values["target_price"])
    if side == "BUY" and not stop < entry < target:
        raise ValueError("PAPER_OBSERVATION_INVALID_BUY_LEVELS")
    if side == "SELL" and not target < entry < stop:
        raise ValueError("PAPER_OBSERVATION_INVALID_SELL_LEVELS")
    return entry, stop, target


def classify_observation_setups(formatted: dict, job: Any) -> list[dict]:
    """Validate mechanical BUY/SELL setups while recording live-gate DENY.

    This is observation eligibility only.  It never changes or overrides the
    gate result used by real execution.
    """
    symbol = str(getattr(job, "symbol", "") or "").strip().upper().removeprefix("MCX:")
    if symbol not in MCX_OBSERVATION_UNIVERSE:
        raise ValueError("MCX_PAPER_OBSERVATION_SYMBOL_NOT_SUPPORTED")
    if str(getattr(job, "execution_mode", "") or "").strip().upper() != PAPER:
        raise ValueError("MCX_PAPER_OBSERVATION_REQUIRES_PAPER_MODE")
    from scripts.tf_regime_gate_by_exchange import gate
    gate_tier, gate_size, gate_reason = gate(
        "MCX", getattr(job, "strategy_tf"), formatted.get("e_regime"),
        formatted.get("a_regime"), symbol,
    )
    setups = []
    for side in ("BUY", "SELL"):
        if not isinstance(formatted.get(side), dict):
            continue
        levels = _levels_for_side(formatted, side)
        entry, stop, target = levels
        timestamp = _signal_timestamp(formatted, side, job)
        risk = abs(entry - stop)
        if risk <= 0:
            continue
        rr = abs(target - entry) / risk
        setups.append({
            "segment": "MCX", "symbol": symbol, "expiry": str(getattr(job, "expiry", "")),
            "fyers_symbol": _exact_fyers_symbol(symbol, str(getattr(job, "expiry", ""))),
            "strategy_tf": int(getattr(job, "strategy_tf")), "side": side,
            "signal_timestamp": timestamp, "entry": entry, "stop_loss": stop,
            "target": target, "rr": rr, "quantity": 1,
            "execution_mode": PAPER, "trading_status": "SIMULATED",
            "edge_validation": "UNVALIDATED", "gate_tier": gate_tier,
            "gate_size_multiplier": gate_size, "gate_reason": gate_reason,
            "e_regime": formatted.get("e_regime"),
            "a_regime": formatted.get("a_regime"),
            "x_regime": formatted.get("x_regime", formatted.get("X_regime")),
            "source": "MCX_GRADUATED_PAPER_OBSERVATION",
        })
    return setups


class PaperObservationStore:
    """Transactional persistence against an explicitly injected local DB."""
    def __init__(self, session_factory: Callable[[], Any]):
        self.session_factory = session_factory

    def require_active_symbol(self, symbol: str) -> None:
        normalized = str(symbol or "").strip().upper().removeprefix("MCX:")
        if normalized not in MCX_OBSERVATION_UNIVERSE:
            raise ValueError("MCX_PAPER_OBSERVATION_SYMBOL_NOT_SUPPORTED")
        session = self.session_factory()
        try:
            master = session.query(CommoditiesMaster).filter(
                CommoditiesMaster.symbol == normalized,
                CommoditiesMaster.is_active.is_(True),
            ).first()
            if master is None:
                raise ValueError("PAPER_OBSERVATION_ACTIVE_COMMODITY_MASTER_REQUIRED")
        finally:
            session.close()

    def persist(self, setup: dict) -> dict:
        if setup.get("segment") != "MCX" or setup.get("execution_mode") != PAPER:
            raise ValueError("PAPER_OBSERVATION_INVALID_EXECUTION_PROVENANCE")
        if setup.get("trading_status") != "SIMULATED" or setup.get("edge_validation") != "UNVALIDATED":
            raise ValueError("PAPER_OBSERVATION_INVALID_STATUS")
        key = _stable_key(setup["symbol"], setup["expiry"], setup["strategy_tf"],
                          setup["side"], setup["signal_timestamp"])
        session = self.session_factory()
        try:
            existing = session.query(Commodity_Order).filter(
                Commodity_Order.idempotency_key == key
            ).first()
            if existing:
                if (existing.execution_mode != PAPER
                        or existing.candidate_source != MCX_OBSERVATION_SOURCE):
                    raise ValueError("PAPER_OBSERVATION_IDEMPOTENCY_PROVENANCE_MISMATCH")
                if (existing.entry_price != setup["entry"]
                        or existing.stoploss_price != setup["stop_loss"]
                        or existing.target_price != setup["target"]):
                    raise ValueError("PAPER_OBSERVATION_SIGNAL_IDENTITY_LEVEL_MISMATCH")
                bucket = session.query(OMSOrderBucketCommodity).filter(
                    OMSOrderBucketCommodity.idempotency_key == key
                ).first()
                if bucket is None:
                    raise RuntimeError("PAPER_OBSERVATION_ORDER_BUCKET_INCOMPLETE")
                return {"status": "EXISTING", "order_id": existing.order_id,
                        "bucket_id": bucket.bucket_id, "idempotency_key": key}

            master = session.query(CommoditiesMaster).filter(
                CommoditiesMaster.symbol == setup["symbol"],
                CommoditiesMaster.is_active.is_(True),
            ).first()
            if master is None:
                raise ValueError("PAPER_OBSERVATION_ACTIVE_COMMODITY_MASTER_REQUIRED")

            now = datetime.now()
            signal = TradeSignal(
                exchange_id=MCX_EXCHANGE_ID,
                stock_name=setup["symbol"], time_fr=setup["strategy_tf"], country_id=1,
                price_cmp=setup["entry"], trade_type=setup["side"], rrr=setup["rr"],
                timestamps={"signal_timestamp": setup["signal_timestamp"]},
                trade_data={
                    "entry_price": setup["entry"], "stop_loss": setup["stop_loss"],
                    "target_price": setup["target"], "e_regime": setup.get("e_regime"),
                    "a_regime": setup.get("a_regime"), "x_regime": setup.get("x_regime"),
                    "edge_validation": "UNVALIDATED", "execution_mode": PAPER,
                    "candidate_source": MCX_OBSERVATION_SOURCE,
                    "idempotency_key": key,
                    "fyers_symbol": setup["fyers_symbol"],
                },
                prediction="UNVALIDATED", probability=0.0, created_at=now,
                is_active=True, is_send=False, exp_date=setup["expiry"],
            )
            session.add(signal)
            session.flush()
            expiry = _format_expiry(setup["expiry"])
            order = Commodity_Order(
                trade_signal_id=signal.id, stock_tick=setup["symbol"], stock_id=master.id,
                country_id=1, time_frame=setup["strategy_tf"], order_type=setup["side"],
                entry_price=setup["entry"], stoploss_price=setup["stop_loss"],
                target_price=setup["target"], stock_quantity=1,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"), purchased_on=now,
                order_status="paper_monitoring", is_trade_started=False,
                is_evaluated=False, expiry_date=expiry,
                arima_ab_model_prediction="UNVALIDATED", arima_ab_model_prob=0.0,
                execution_mode=PAPER, candidate_source=MCX_OBSERVATION_SOURCE,
                idempotency_key=key, edge_validation="UNVALIDATED", paper_updated_at=now,
                trading_status="SIMULATED",
            )
            session.add(order)
            session.flush()
            bucket = OMSOrderBucketCommodity(
                order_id=order.order_id, trade_signal_id=signal.id,
                stock_tick=setup["symbol"], stock_id=master.id, country_id=1,
                time_frame=setup["strategy_tf"], order_type=setup["side"],
                entry_price=setup["entry"], stoploss_price=setup["stop_loss"],
                target_price=setup["target"], stock_quantity=1,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"), purchased_on=now,
                order_status="paper_monitoring", is_trade_started=0, is_evaluated=0,
                expiry_date=expiry, approval_status="not_required", approved_by=None,
                approved_at=None, id_fyers=None, gtt_id=None,
                execution_mode=PAPER, candidate_source=MCX_OBSERVATION_SOURCE,
                idempotency_key=key, edge_validation="UNVALIDATED", paper_updated_at=now,
                trading_status="SIMULATED",
            )
            session.add(bucket)
            session.commit()
            return {"status": "CREATED", "signal_id": signal.id,
                    "order_id": order.order_id, "bucket_id": bucket.bucket_id,
                    "idempotency_key": key}
        except IntegrityError as exc:
            session.rollback()
            existing = session.query(Commodity_Order).filter(
                Commodity_Order.idempotency_key == key
            ).first()
            if existing:
                bucket = session.query(OMSOrderBucketCommodity).filter(
                    OMSOrderBucketCommodity.idempotency_key == key
                ).first()
                if bucket:
                    return {"status": "EXISTING", "order_id": existing.order_id,
                            "bucket_id": bucket.bucket_id, "idempotency_key": key}
            raise RuntimeError("PAPER_OBSERVATION_TRANSACTION_REJECTED") from exc
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def orders(self, segment: str = "MCX") -> list[dict]:
        if str(segment).strip().upper() != "MCX":
            raise ValueError("PAPER_OBSERVATION_MONITOR_ONLY_SUPPORTS_MCX")
        session = self.session_factory()
        try:
            rows = (session.query(OMSOrderBucketCommodity, TradeSignal)
                    .join(TradeSignal, TradeSignal.id == OMSOrderBucketCommodity.trade_signal_id)
                    .filter(OMSOrderBucketCommodity.execution_mode == PAPER,
                            OMSOrderBucketCommodity.candidate_source == MCX_OBSERVATION_SOURCE)
                    .order_by(OMSOrderBucketCommodity.purchased_on.desc()).all())
            return [{
                "order_id": bucket.order_id, "bucket_id": bucket.bucket_id,
                "trade_signal_id": bucket.trade_signal_id, "segment": "MCX",
                "symbol": bucket.stock_tick, "side": bucket.order_type,
                "strategy_tf": bucket.time_frame, "entry_price": bucket.entry_price,
                "stop_loss": bucket.stoploss_price, "target_price": bucket.target_price,
                "quantity": bucket.stock_quantity, "execution_mode": bucket.execution_mode,
                "trading_status": bucket.trading_status, "order_status": bucket.order_status,
                "signal_timestamp": (signal.timestamps or {}).get("signal_timestamp"),
                "fyers_symbol": (signal.trade_data or {}).get("fyers_symbol"),
                "created_at": bucket.purchased_on.isoformat() if bucket.purchased_on else None,
                "updated_at": bucket.paper_updated_at.isoformat() if bucket.paper_updated_at else None,
                "strategy_tf": bucket.time_frame, "edge_validation": bucket.edge_validation,
                "e_regime": (signal.trade_data or {}).get("e_regime"),
                "a_regime": (signal.trade_data or {}).get("a_regime"),
                "x_regime": (signal.trade_data or {}).get("x_regime"),
                "candidate_source": bucket.candidate_source,
            } for bucket, signal in rows]
        finally:
            session.close()


def _format_expiry(value: str) -> str:
    from scripts.scanner_fc import parse_expiry_date
    return parse_expiry_date(value).strftime("%d-%m-%Y")


def _exact_fyers_symbol(symbol: str, expiry: str) -> str:
    # Reuse the repository's established exact dated commodity-symbol format.
    from apps.backend.api.bucket_orders_commodity import format_commodity_contract
    contract = format_commodity_contract(symbol, expiry)
    if not contract:
        raise ValueError("PAPER_OBSERVATION_FYERS_CONTRACT_UNRESOLVED")
    return contract


class MCXPaperObservationRunner:
    """Evaluate through the existing strategy engine and persist only locally."""
    def __init__(self, engine: Callable, formatter: Callable, store: PaperObservationStore,
                 config: PaperObservationConfig):
        self.engine, self.formatter, self.store, self.config = engine, formatter, store, config

    def run(self, jobs: Iterable[Any]) -> list[dict]:
        validate_local_paper_config(self.config)
        results = []
        for job in jobs:
            try:
                if str(getattr(job, "execution_mode", "") or "").strip().upper() != PAPER:
                    raise ValueError("MCX_PAPER_OBSERVATION_REQUIRES_PAPER_MODE")
                self.store.require_active_symbol(str(getattr(job, "symbol", "")))
                scan_time = datetime.now()
                raw = self.engine(job.symbol, job.time_list, job.expiry, scan_time, False)
                if isinstance(raw, str):
                    raise RuntimeError("MCX_PAPER_SETUP_ENGINE_FAILED")
                formatted = self.formatter(raw, stock_name=job.symbol,
                    time_fr=job.strategy_tf, exp_num=job.expiry,
                    last_d_time=scan_time, is_future=False, is_cash=False)
                setups = classify_observation_setups(formatted, job)
                if not setups:
                    results.append({"symbol": job.symbol, "status": "NO_VALID_SETUP"})
                    continue
                for setup in setups:
                    results.append(setup | {"persistence": self.store.persist(setup)})
            except Exception as exc:
                results.append({"symbol": getattr(job, "symbol", None),
                                "status": "REJECTED", "reason": str(exc)})
        return results

