"""Canonical live-market subscription symbols.

`ticker_tape` stores the exact FYERS contract identifier. Keeping live market
consumers on it prevents contract names being reconstructed from display data.
"""
from __future__ import annotations

import os
import csv
import io
import logging
import re
import time
from datetime import date, datetime
from functools import lru_cache
from typing import Dict, Iterable

import requests

DYNAMIC_REQUEST_PREFIX = "market:derivatives:request:"
DYNAMIC_CONTROL_CHANNEL = "market:derivatives:control"
FYERS_MCX_MASTER_URL = "https://public.fyers.in/sym_details/MCX_COM.csv"
FYERS_NSE_FO_MASTER_URL = "https://public.fyers.in/sym_details/NSE_FO.csv"
log = logging.getLogger(__name__)
_last_unresolved_futures: tuple[str, ...] | None = None


def _env_symbols(name: str, segment: str) -> Iterable[dict]:
    """Explicit operational additions; values must be exact FYERS symbols."""
    for symbol in os.getenv(name, "").split(","):
        symbol = symbol.strip()
        if symbol:
            yield {"symbol": symbol, "segment": segment, "display_name": symbol,
                   "expiry_date": None, "source": "environment"}


def _active_mcx_master_contracts(products: set[str], as_of: date) -> Iterable[dict]:
    """Yield all current FYERS contracts for active application MCX products.

    ``commodities_master`` intentionally stores products rather than a stale
    contract/expiry mapping.  The FYERS master is therefore used only to
    resolve contracts belonging to those configured products--never as an
    unbounded subscription to the whole MCX universe.
    """
    if not products:
        return []
    try:
        contracts = _mcx_futures_master(int(time.time() // 3600))
    except ValueError as exc:
        log.error("Unable to load active MCX contracts: %s", exc)
        return []
    return [
        {"symbol": fyers_symbol, "segment": "commodity", "display_name": product,
         "base_symbol": product, "expiry_date": expiry.isoformat(), "source": "commodities_master"}
        for (product, expiry), fyers_symbol in contracts.items()
        if product in products and expiry >= as_of
    ]


def _active_futures_master_contracts(session, futures_model, as_of: date) -> Iterable[dict]:
    """Return the nearest three unexpired NSEFO expiries per distinct symbol.

    FuturesMaster can contain repeated rows from master-data refreshes. Start
    with ``distinct(symbol)`` and then retain only three unique expiry dates
    per symbol, ordered nearest-first. This gives a fixed, rollover-safe
    subscription universe without duplicate FYERS contracts.
    """
    from sqlalchemy import distinct

    exchanges = ("NSEFO", "NFO", "NSE")
    symbols = [symbol for (symbol,) in session.query(distinct(futures_model.symbol)).filter(
        futures_model.expiry_date >= as_of,
        futures_model.exchange.in_(exchanges),
    ).all() if (symbol or "").strip()]
    if not symbols:
        return []
    rows = session.query(futures_model.symbol, futures_model.exchange, futures_model.expiry_date).filter(
        futures_model.symbol.in_(symbols),
        futures_model.expiry_date >= as_of,
        futures_model.exchange.in_(exchanges),
    ).order_by(futures_model.symbol, futures_model.expiry_date).all()

    try:
        fyers_contracts = _nse_futures_master(int(time.time() // 3600))
    except ValueError as exc:
        log.error("Unable to load active NSEFO contracts: %s", exc)
        return []

    selected, selected_expiries, unresolved = [], {}, []
    for display_name, exchange, expiry in rows:
        symbol_name = (display_name or "").strip().upper()
        if not symbol_name or expiry in selected_expiries.setdefault(symbol_name, set()):
            continue
        if len(selected_expiries[symbol_name]) >= 3:
            continue
        fyers_symbol = fyers_contracts.get((symbol_name, expiry))
        if not fyers_symbol:
            unresolved.append(f"{symbol_name}:{expiry.isoformat()}")
            continue
        selected_expiries[symbol_name].add(expiry)
        selected.append({"symbol": fyers_symbol, "segment": "futures", "display_name": symbol_name,
                         "base_symbol": symbol_name, "expiry_date": expiry.isoformat(),
                         "source": "futures_master"})
    global _last_unresolved_futures
    unresolved_signature = tuple(unresolved)
    if unresolved_signature and unresolved_signature != _last_unresolved_futures:
        log.warning("Skipped %d FuturesMaster contracts absent from FYERS NSEFO master; sample=%s",
                    len(unresolved), unresolved[:10])
    _last_unresolved_futures = unresolved_signature
    return selected


def load_segmented_symbols(db_connection, *, as_of: date | None = None) -> Dict[str, dict]:
    """Return all active application instruments keyed by FYERS identifier.

    Cash comes from ``ind_stock_master``. Three unexpired NSEFO expiries per
    distinct ``futures_master`` symbol and every current FYERS contract for an active
    ``commodities_master`` product are included. ``ticker_tape`` remains an
    exact-symbol override for rollover administration.
    """
    from shared.db.db_model import CommoditiesMaster, FuturesMaster, Ind_StockMaster, TickerTape

    as_of = as_of or date.today()
    result: Dict[str, dict] = {}
    session = db_connection.get_session()
    try:
        rows = session.query(Ind_StockMaster.stock_tick, Ind_StockMaster.fyers_symbol).filter(
            Ind_StockMaster.is_active == 1, Ind_StockMaster.fyers_symbol.isnot(None)).all()
        for display_name, symbol in rows:
            symbol = (symbol or "").strip()
            if symbol:
                result[symbol] = {"symbol": symbol, "segment": "cash", "display_name": display_name or symbol,
                                  "expiry_date": None, "source": "ind_stock_master"}
        for item in _active_futures_master_contracts(session, FuturesMaster, as_of):
            result[item["symbol"]] = item

        commodity_products = {
            (symbol or "").strip().upper()
            for (symbol,) in session.query(CommoditiesMaster.symbol).filter(
                CommoditiesMaster.is_active.is_(True), CommoditiesMaster.exchange == "MCX").all()
            if (symbol or "").strip()
        }

        rows = session.query(TickerTape.stock_tick, TickerTape.expiry_date, TickerTape.fyers_symbol,
                             TickerTape.exchange).filter(
            TickerTape.status.is_(True), TickerTape.fyers_symbol.isnot(None),
            TickerTape.exchange.in_(("NSEFO", "MCX"))).all()
        for display_name, expiry, symbol, exchange in rows:
            # Derivative expiry is mandatory for safe rollover.  Do not retain
            # an undated mapping merely because its status flag was forgotten.
            if expiry is None or expiry < as_of:
                continue
            symbol = (symbol or "").strip()
            if symbol:
                result[symbol] = {"symbol": symbol,
                                  "segment": "futures" if exchange == "NSEFO" else "commodity",
                                  "display_name": display_name or symbol,
                                  "expiry_date": expiry.isoformat() if expiry else None,
                                  "source": "ticker_tape"}
    finally:
        session.close()
    for item in _active_mcx_master_contracts(commodity_products, as_of):
        result[item["symbol"]] = item
    for item in _env_symbols("FYERS_FUTURES_SYMBOLS", "futures"):
        result.setdefault(item["symbol"], item)
    for item in _env_symbols("FYERS_COMMODITY_SYMBOLS", "commodity"):
        result.setdefault(item["symbol"], item)
    return result


def load_dynamic_derivative_symbols(redis_client) -> Dict[str, dict]:
    """Read unexpired Dashboard contract requests from Redis."""
    result: Dict[str, dict] = {}
    for key in redis_client.scan_iter(f"{DYNAMIC_REQUEST_PREFIX}*"):
        request = redis_client.hgetall(key)
        symbol, segment = request.get("symbol"), request.get("segment")
        if symbol and segment in {"futures", "commodity"}:
            result[symbol] = {"symbol": symbol, "segment": segment,
                              "display_name": request.get("display_name") or symbol,
                              "expiry_date": request.get("expiry_date"),
                              "source": "dashboard_lease"}
    return result


@lru_cache(maxsize=1)
def _mcx_futures_master(_hour_bucket: int) -> Dict[tuple[str, date], str]:
    """Return exact FYERS MCX futures identifiers, refreshed at most hourly."""
    try:
        response = requests.get(FYERS_MCX_MASTER_URL, timeout=15)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise ValueError("FYERS MCX instrument master is unavailable; provide an exact FYERS symbol") from exc

    contracts: Dict[tuple[str, date], str] = {}
    for row in csv.reader(io.StringIO(response.text)):
        if len(row) < 10 or not row[9].startswith("MCX:") or not row[9].endswith("FUT"):
            continue
        match = re.fullmatch(r"(.+?)\s+(\d{2}\s+[A-Za-z]{3}\s+\d{2})\s+FUT", row[1].strip())
        if not match:
            continue
        try:
            contracts[(match.group(1).upper(), datetime.strptime(match.group(2), "%d %b %y").date())] = row[9]
        except ValueError:
            continue
    return contracts


@lru_cache(maxsize=1)
def _nse_futures_master(_hour_bucket: int) -> Dict[tuple[str, date], str]:
    """Return exact active FYERS NSEFO futures identifiers, refreshed hourly."""
    try:
        response = requests.get(FYERS_NSE_FO_MASTER_URL, timeout=30)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise ValueError("FYERS NSEFO instrument master is unavailable") from exc

    contracts: Dict[tuple[str, date], str] = {}
    for row in csv.reader(io.StringIO(response.text)):
        if len(row) < 10 or not row[9].startswith("NSE:") or not row[9].endswith("FUT"):
            continue
        match = re.fullmatch(r"(.+?)\s+(\d{2}\s+[A-Za-z]{3}\s+\d{2})\s+FUT", row[1].strip())
        if not match:
            continue
        try:
            contracts[(match.group(1).upper(), datetime.strptime(match.group(2), "%d %b %y").date())] = row[9]
        except ValueError:
            continue
    return contracts


def _exact_mcx_futures_symbol(symbol: str, expiry_date: date) -> str:
    contracts = _mcx_futures_master(int(time.time() // 3600))
    exact = contracts.get((symbol, expiry_date))
    if not exact:
        raise ValueError(f"no active FYERS MCX futures contract for {symbol} expiring {expiry_date.isoformat()}")
    return exact


def resolve_derivative_contract(db_connection, symbol: str, expiry: str) -> dict:
    """Resolve Dashboard ``symbol``/``expiry`` to one FYERS contract.

    Exact FYERS symbols are accepted verbatim. Base symbols are resolved from
    the existing FuturesMaster/CommoditiesMaster records before the project's
    established FYERS contract notation is applied.
    """
    from shared.db.db_model import CommoditiesMaster, FuturesMaster

    base = (symbol or "").strip().upper()
    if not base:
        raise ValueError("symbol is required")
    try:
        expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
    except (TypeError, ValueError) as exc:
        raise ValueError("expiry must use YYYY-MM-DD") from exc
    if expiry_date < date.today():
        raise ValueError("expired contracts cannot be requested")
    if ":" in base:
        exchange, _, contract = base.partition(":")
        if exchange not in {"NSE", "MCX"} or not contract.endswith("FUT"):
            raise ValueError("symbol must be an NSE/MCX FYERS futures contract")
        return {"symbol": base, "segment": "commodity" if exchange == "MCX" else "futures",
                "display_name": contract, "base_symbol": contract,
                "expiry_date": expiry_date.isoformat()}

    session = db_connection.get_session()
    try:
        future = session.query(FuturesMaster).filter(
            FuturesMaster.symbol == base, FuturesMaster.expiry_date == expiry_date).first()
        commodity = session.query(CommoditiesMaster).filter(
            CommoditiesMaster.symbol == base, CommoditiesMaster.is_active.is_(True)).first()
    finally:
        session.close()
    if future:
        exchange = (future.exchange or "NSE").upper()
        exchange = "NSE" if exchange in {"NSEFO", "NFO"} else exchange
        return {"symbol": f"{exchange}:{base}{expiry_date.strftime('%y%b').upper()}FUT",
                "segment": "futures", "display_name": base, "base_symbol": base,
                "expiry_date": expiry_date.isoformat()}
    if commodity:
        return {"symbol": _exact_mcx_futures_symbol(base, expiry_date),
                "segment": "commodity", "display_name": commodity.full_name or base, "base_symbol": base,
                "expiry_date": expiry_date.isoformat()}
    raise ValueError("symbol/expiry is not an active futures or commodity contract")
