"""Single offline orchestration entry point for the MCX Phase-1 pipeline.

No command in this module places orders or starts scanners. FYERS acquisition is
an explicit read-only command; replay uses exact dated contract files and the
existing PREDIXA strategy engine. Authoritative export writes only after the
Task-2 evidence gate passes.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import date
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import pandas as pd

from .clean_realized_r_export import ExportBlocked, build_clean_export, readiness_issues, write_versioned_export
from .clean_strategy_replay import replay_existing_strategy
from .contract_roll import (DatedContract, RollPolicy, RollTransition, TradingCalendar,
    build_back_adjusted_series, classify_expiry_window, select_historical_contract)
from .fyers_expired_contract_collector import UNDERLYING_PRODUCTS, FyersDataError

TIMEFRAME_NAMES = ("monthly", "weekly", "daily", "two_forty", "one_twenty", "sixty")
DEFAULT_COVERAGE_START = "2025-11-03"
DEFAULT_COVERAGE_END = "2026-11-02"


def _load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read JSON configuration {path}: {type(exc).__name__}") from None
    if not isinstance(value, dict):
        raise ValueError("pipeline bundle must be a JSON object")
    return value


def _contract(record: dict) -> DatedContract:
    return DatedContract(**record)


def _roll(record: dict) -> RollTransition:
    return RollTransition(**record)


def _read_bars(path: str | Path, contract_symbol: str, underlying: str) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if "timestamp" not in frame and "timestamp_ist" in frame:
        frame = frame.rename(columns={"timestamp_ist": "timestamp"})
    if "timestamp" not in frame and "tradeDate" in frame:
        frame = frame.rename(columns={"tradeDate": "timestamp"})
    if "volume" not in frame and "qty" in frame:
        frame = frame.rename(columns={"qty": "volume"})
    if "contract_symbol" in frame and set(frame.contract_symbol.dropna().astype(str)) != {contract_symbol}:
        raise ValueError(f"dated-contract file symbol does not match declared identifier: {path}")
    if "underlying" in frame and set(frame.underlying.dropna().astype(str).str.upper()) != {underlying.upper()}:
        raise ValueError(f"dated-contract file underlying does not match declaration: {path}")
    frame["underlying"] = underlying
    if "contract_symbol" not in frame:
        frame["contract_symbol"] = contract_symbol
    return frame


def _hash_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assemble_cached_inputs(data_root: Path, output_dir: Path, *,
                           coverage_start: str = DEFAULT_COVERAGE_START,
                           coverage_end: str = DEFAULT_COVERAGE_END,
                           daily_request_limit: int = 10) -> dict:
    """Build an auditable replay-bundle readiness report from cached evidence.

    This never promotes expiry discovery into a historical active interval.
    It writes a machine-readable candidate manifest even when blocked, so the
    user does not have to hand-assemble a bundle merely to see what is missing.
    A runnable Task-2 bundle is emitted only when all data and policy inputs
    needed by the replay contract are present and independently verified.
    """
    data_root, output_dir = Path(data_root), Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    contracts: dict[str, dict[str, dict]] = {name: {} for name in UNDERLYING_PRODUCTS}
    expiry_catalog: dict[str, list[dict]] = {name: [] for name in UNDERLYING_PRODUCTS}
    source_files = []
    rejected_files = []
    discovery_errors = []

    for path in sorted((data_root / "discovery").glob("*.json")) if (data_root / "discovery").is_dir() else []:
        try:
            doc = _load_json(path)
            if doc.get("provider") != "FYERS" or doc.get("status") != "SUCCESS":
                continue
            if path.name.startswith("contracts_"):
                symbol = doc.get("requested_symbol", "")
                product = next((p for p in UNDERLYING_PRODUCTS if symbol.upper().split(":")[-1].startswith(p)), None)
                contract_list = doc.get("contracts", [])
                expected = hashlib.sha256(json.dumps(contract_list, sort_keys=True).encode()).hexdigest()
                if doc.get("sha256") != expected or not product:
                    discovery_errors.append({"path": str(path), "error": "contract discovery hash or product identity invalid"})
                    continue
                for contract_symbol in contract_list:
                    if product:
                        contracts[product].setdefault(contract_symbol, {
                            "contract_symbol": contract_symbol,
                            "underlying": product,
                            "expiry_date": doc.get("expiry_date"),
                            "provider_instrument_id": None,
                            "attribution_status": "EXACT_SYMBOL_AND_EXPIRY_DISCOVERED",
                            "active_from": None,
                            "active_to": None,
                            "source_id": str(path),
                        })
            else:
                for expiry_row in doc.get("expiries", []):
                    product = expiry_row.get("product")
                    if product in expiry_catalog:
                        expiry_catalog[product].append({"expiry_date": expiry_row.get("expiry_date"),
                            "requested_symbol": expiry_row.get("underlying_symbol"),
                            # Filled from the separately persisted exact-symbol
                            # discovery below; expiry discovery alone is not a contract.
                            "contracts_discovered": False,
                            "source_id": str(path)})
        except (OSError, ValueError, TypeError) as exc:
            discovery_errors.append({"path": str(path), "error": type(exc).__name__})

    for path in sorted(data_root.glob("**/metadata.json")):
        try:
            metadata = _load_json(path)
            if metadata.get("provider") != "FYERS":
                continue
            response_path = path.with_name("provider_response.json")
            bars_path = path.with_name("bars.csv")
            if metadata.get("status") == "REJECTED":
                response_sha = _hash_file(response_path) if response_path.is_file() else None
                rejected_files.append({"metadata_path": str(path), "response_path": str(response_path),
                    "response_sha256": response_sha, "expected_sha256": metadata.get("raw_response_sha256"),
                    "reason": metadata.get("reason"), "contract_symbol": metadata.get("contract_symbol"),
                    "underlying": metadata.get("underlying"), "resolution": metadata.get("resolution")})
                continue
            if metadata.get("status") != "SUCCESS" or not bars_path.is_file():
                continue
            bars_sha = _hash_file(bars_path)
            response_sha = _hash_file(response_path) if response_path.is_file() else None
            valid_hashes = bars_sha == metadata.get("normalized_bars_sha256")
            if metadata.get("raw_response_sha256"):
                valid_hashes = valid_hashes and response_sha == metadata.get("raw_response_sha256")
            frame = pd.read_csv(bars_path)
            exact_symbol = metadata.get("contract_symbol")
            identity_valid = ("contract_symbol" in frame and set(frame.contract_symbol.dropna().astype(str)) == {exact_symbol})
            product = metadata.get("underlying")
            item = {"metadata_path": str(path), "bars_path": str(bars_path),
                "contract_symbol": exact_symbol, "underlying": product,
                "expiry_date": metadata.get("expiry_date"), "resolution": str(metadata.get("resolution")),
                "bar_count": len(frame), "first_timestamp": str(frame.timestamp.iloc[0]) if len(frame) else None,
                "last_timestamp": str(frame.timestamp.iloc[-1]) if len(frame) else None,
                "bars_sha256": bars_sha, "provider_response_sha256": response_sha,
                "cache_hashes_valid": bool(valid_hashes), "exact_symbol_rows_valid": bool(identity_valid),
                "source_endpoint": metadata.get("source_endpoint"),
                "price_identity": metadata.get("price_identity"), "status": metadata.get("status")}
            source_files.append(item)
            if product in contracts and exact_symbol:
                record = contracts[product].setdefault(exact_symbol, {
                    "contract_symbol": exact_symbol, "underlying": product,
                    "expiry_date": metadata.get("expiry_date"), "provider_instrument_id": None,
                    "attribution_status": "EXACT_DATED_RESPONSE_IDENTITY_ONLY",
                    "active_from": None, "active_to": None, "source_id": str(path)})
                record.setdefault("sources", []).append(item)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            discovery_errors.append({"path": str(path), "error": type(exc).__name__})

    discovery_rejected_dir = data_root / "discovery" / "rejected"
    if discovery_rejected_dir.is_dir():
        for metadata_path in sorted(discovery_rejected_dir.glob("*.metadata.json")):
            try:
                meta = _load_json(metadata_path)
                response_path = metadata_path.with_name(metadata_path.name.replace(".metadata.json", ".json"))
                digest = _hash_file(response_path) if response_path.is_file() else None
                rejected_files.append({"metadata_path": str(metadata_path), "response_path": str(response_path),
                    "response_sha256": digest, "expected_sha256": meta.get("raw_response_sha256"),
                    "reason": meta.get("status"), "provider_code": meta.get("provider_code"),
                    "http_status": meta.get("http_status"), "contract_symbol": None,
                    "underlying": meta.get("requested_symbol"), "endpoint_kind": meta.get("endpoint_kind")})
            except (OSError, ValueError, TypeError) as exc:
                discovery_errors.append({"path": str(metadata_path), "error": type(exc).__name__})

    # Include the prior FYERS exact-symbol file only when its sidecar explicitly
    # records dated_raw and cont_flag=0; retain its weaker, unhashed provenance.
    known_sidecar = Path("research/zone_series_comparison/metadata/fyers_raw.json")
    if known_sidecar.is_file():
        try:
            known = _load_json(known_sidecar)
            if (known.get("source_broker") == "FYERS" and known.get("pull_type") == "dated_raw"
                    and str(known.get("continuous_flag")) == "0"):
                source_path = Path("research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv")
                if source_path.is_file():
                    frame = pd.read_csv(source_path)
                    digest = _hash_file(source_path)
                    if "timestamp" not in frame and "timestamp_ist" in frame:
                        frame = frame.rename(columns={"timestamp_ist": "timestamp"})
                    if "volume" not in frame and "qty" in frame:
                        frame = frame.rename(columns={"qty": "volume"})
                    frame["underlying"] = "CRUDEOILM"
                    frame["contract_symbol"] = known["api_symbol"]
                    frame["contract_expiry"] = known["contract_expiry"]
                    frame["resolution"] = known.get("resolution", "60")
                    timestamp_values = pd.to_datetime(frame.timestamp, errors="coerce")
                    ohlc_numeric = frame[["open", "high", "low", "close", "volume"]].apply(pd.to_numeric, errors="coerce")
                    first_sidecar_ts = pd.to_datetime(known.get("actual_first_timestamp_ist"), errors="coerce")
                    last_sidecar_ts = pd.to_datetime(known.get("actual_last_timestamp_ist"), errors="coerce")
                    sidecar_valid = (known.get("total_rows") == len(frame)
                        and not pd.isna(first_sidecar_ts) and not pd.isna(last_sidecar_ts)
                        and first_sidecar_ts == timestamp_values.iloc[0]
                        and last_sidecar_ts == timestamp_values.iloc[-1]
                        and not timestamp_values.isna().any() and not timestamp_values.duplicated().any()
                        and timestamp_values.is_monotonic_increasing and not ohlc_numeric.isna().any().any()
                        and not ((ohlc_numeric.high < ohlc_numeric[["open", "low", "close"]].max(axis=1))
                            | (ohlc_numeric.low > ohlc_numeric[["open", "high", "close"]].min(axis=1))
                            | (ohlc_numeric.volume < 0)).any())
                    entry = {"metadata_path": str(known_sidecar), "bars_path": str(source_path),
                        "contract_symbol": known.get("api_symbol"), "underlying": "CRUDEOILM",
                        "expiry_date": known.get("contract_expiry"), "resolution": str(known.get("resolution")),
                        "bar_count": len(frame), "first_timestamp": known.get("actual_first_timestamp_ist"),
                        "last_timestamp": known.get("actual_last_timestamp_ist"), "bars_sha256": digest,
                        # Row/schema checks pass, but no original response body is
                        # available to hash. Never promote this to hash-verified.
                        "provider_response_sha256": None, "cache_hashes_valid": False,
                        "exact_symbol_rows_valid": bool(sidecar_valid), "source_endpoint": "FYERS /history cont_flag=0 (sidecar claim)",
                        "price_identity": "DATED_RAW_SIDECAR_NO_RESPONSE_HASH",
                        "provenance_class": "SIDECAR_VERIFIED_NO_RAW_PROVIDER_RESPONSE",
                        "status": "SOURCE_SIDECAR_ONLY" if sidecar_valid else "SOURCE_SIDECAR_VALIDATION_FAILED"}
                    source_files.append(entry)
                    record = contracts["CRUDEOILM"].setdefault(entry["contract_symbol"], {
                        "contract_symbol": entry["contract_symbol"], "underlying": "CRUDEOILM",
                        "expiry_date": entry["expiry_date"], "provider_instrument_id": None,
                        "attribution_status": "DATED_SYMBOL_SIDECAR_ONLY",
                        "active_from": None, "active_to": None, "source_id": str(known_sidecar)})
                    record.setdefault("sources", []).append(entry)
        except (OSError, ValueError, TypeError) as exc:
            discovery_errors.append({"path": str(known_sidecar), "error": type(exc).__name__})

    # Derive only after all cached sources, including the legacy sidecar, have
    # been inventoried. A sidecar may support reproducible diagnostics, but its
    # missing raw response hash remains an explicit non-authoritative status.
    derived_frames = []
    from .derive_strategy_timeframes import derive_strategy_timeframes
    for source in list(source_files):
        source_provenance_ok = (source.get("cache_hashes_valid")
            or source.get("provenance_class") == "SIDECAR_VERIFIED_NO_RAW_PROVIDER_RESPONSE")
        if (source.get("resolution") != "60" or not source_provenance_ok
                or not source.get("exact_symbol_rows_valid")):
            continue
        try:
            hourly = _read_bars(source["bars_path"], source["contract_symbol"], source["underlying"])
            result = derive_strategy_timeframes(hourly)
            safe_contract = source["contract_symbol"].replace(":", "_")
            destination = output_dir / "derived" / str(source["underlying"]) / safe_contract / source["bars_sha256"][:12]
            destination.mkdir(parents=True, exist_ok=True)
            for frame_name, derived in result.items():
                path = destination / f"{frame_name}.csv"
                content = derived.to_csv(index=False).encode()
                expected_hash = hashlib.sha256(content).hexdigest()
                if path.exists() and _hash_file(path) != expected_hash:
                    raise ValueError(f"derived frame collision at {path}")
                if not path.exists():
                    path.write_bytes(content)
                derived_frames.append({"underlying": source["underlying"],
                    "contract_symbol": source["contract_symbol"], "timeframe": frame_name,
                    "path": str(path), "bar_count": len(derived),
                    "sha256": _hash_file(path), "source_bars_sha256": source["bars_sha256"],
                    "e1_attached": "e1_session_id" in derived,
                    "price_basis": "RAW_DATED_CONTRACT",
                    "provenance_class": source.get("provenance_class", "HASH_VERIFIED_PROVIDER_RESPONSE"),
                    "authoritative_series": False})
        except (OSError, ValueError, TypeError, KeyError) as exc:
            discovery_errors.append({"path": source.get("bars_path"),
                "error": f"timeframe derivation {type(exc).__name__}: {exc}"})

    budget_path = data_root / ".daily_request_budget.json"
    try:
        budget = _load_json(budget_path)
    except (OSError, ValueError):
        budget = {"date": None, "count": 0}
    used = int(budget.get("count", 0))
    for underlying, expiries in expiry_catalog.items():
        discovered_expiry_set = {row.get("expiry_date") for row in contracts[underlying].values()}
        for expiry_row in expiries:
            expiry_row["contracts_discovered"] = expiry_row.get("expiry_date") in discovered_expiry_set
    blockers = []
    for underlying in UNDERLYING_PRODUCTS:
        found = sorted(contracts[underlying].values(), key=lambda row: (row.get("expiry_date") or "", row["contract_symbol"]))
        if not found:
            blockers.append(f"{underlying}: no exact FYERS dated-contract discovery/cache found")
        verified_files = [x for x in source_files if x.get("underlying") == underlying
                          and x.get("cache_hashes_valid") and x.get("exact_symbol_rows_valid")]
        if not verified_files:
            blockers.append(f"{underlying}: no hash-verified cached exact-symbol OHLCV source")
        if any(x.get("attribution_status") != "VERIFIED" for x in found):
            blockers.append(f"{underlying}: point-in-time listing/effective intervals are not verified")
    if len(rejected_files):
        blockers.append(f"{len(rejected_files)} provider response(s) rejected and require source review")
    blockers.extend([
        "complete historical MCX session/holiday calendar with partial-session records is unavailable locally",
        "approved roll policy and adjustment methodology with independent approval record are absent",
        "verified roll schedule and outgoing/incoming price pairs are incomplete",
        "approved coverage and IS/OOS split records are absent",
        "all configured source resolutions and date coverage are not complete for every underlying",
    ])
    candidate = {
        "manifest_version": 1, "provider": "FYERS", "coverage_start": coverage_start,
        "coverage_end": coverage_end, "source_root": str(data_root),
        "discovered_contracts": {name: list(sorted(rows.values(), key=lambda x: (x.get("expiry_date") or "", x["contract_symbol"])))
                                  for name, rows in contracts.items()},
        "discovered_expiries": {name: sorted(values, key=lambda x: x.get("expiry_date") or "")
                                 for name, values in expiry_catalog.items()},
        "source_files": source_files, "rejected_responses": rejected_files,
        "derived_strategy_frames": derived_frames,
        "request_budget": {"date": budget.get("date"), "requests_counted": used,
                           "configured_daily_limit": daily_request_limit,
                           "remaining_configured_budget": max(0, daily_request_limit - used)},
        "calendar": {"status": "UNAVAILABLE_FOR_FULL_COVERAGE", "verified": False},
        "roll_policy": {"policy_id": "MCX_3_VERIFIED_SESSIONS_PRE_EXPIRY_ADDITIVE_CANDIDATE_V1",
                        "adjustment_method": "additive", "approval_status": "PENDING_APPROVAL"},
        "authoritative_bundle_emitted": False,
        "status": "BLOCKED_MISSING_DATA", "blockers": blockers,
        "discovery_read_errors": discovery_errors,
    }
    report_path = output_dir / "bundle_readiness.json"
    report_path.write_text(json.dumps(candidate, sort_keys=True, indent=2, default=str) + "\n")
    rows = []
    for underlying in UNDERLYING_PRODUCTS:
        discovered = candidate["discovered_contracts"][underlying]
        expiries = candidate["discovered_expiries"][underlying]
        if not discovered:
            if expiries:
                rows.extend({"underlying": underlying, "contract_symbol": "", "expiry_date": item["expiry_date"],
                         "source_status": "EXPIRY_DISCOVERED_CONTRACT_SYMBOL_MISSING", "source_files": 0,
                         "coverage_start": coverage_start, "coverage_end": coverage_end,
                         "reason": "FYERS expiry returned; exact contract symbol discovery not yet cached"}
                         for item in expiries)
            else:
                rows.append({"underlying": underlying, "contract_symbol": "", "expiry_date": "",
                             "source_status": "NOT_DISCOVERED", "source_files": 0,
                             "coverage_start": coverage_start, "coverage_end": coverage_end,
                             "reason": "No exact FYERS contract discovery cached"})
        for contract in discovered:
            files = [x for x in source_files if x.get("contract_symbol") == contract["contract_symbol"]]
            rows.append({"underlying": underlying, "contract_symbol": contract["contract_symbol"],
                "expiry_date": contract.get("expiry_date"),
                "source_status": "VALIDATED_SOURCE_PRESENT" if any(x.get("cache_hashes_valid") and x.get("exact_symbol_rows_valid") for x in files) else "DISCOVERED_ONLY_OR_UNVERIFIED_SOURCE",
                "source_files": len(files), "coverage_start": coverage_start, "coverage_end": coverage_end,
                "reason": "historical active interval unresolved; discovery does not establish contract selection"})
    csv_path = output_dir / "contract_acquisition_manifest.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["underlying", "contract_symbol", "expiry_date", "source_status", "source_files", "coverage_start", "coverage_end", "reason"])
        writer.writeheader()
        writer.writerows(rows)
    candidate["readiness_path"] = str(report_path)
    candidate["contract_manifest_path"] = str(csv_path)
    return candidate


def _calendar(value: dict) -> TradingCalendar:
    return TradingCalendar(frozenset(date.fromisoformat(x) for x in value["session_dates"]),
        date.fromisoformat(value["coverage_start"]), date.fromisoformat(value["coverage_end"]),
        value["source_id"], bool(value.get("verified")))


def _research_snapshot(bundle: dict, underlying: str, as_of: pd.Timestamp,
                       contracts: list[DatedContract], policy: RollPolicy) -> tuple[dict[str, pd.DataFrame], dict[str, object]]:
    frames, results = {}, {}
    for timeframe in TIMEFRAME_NAMES:
        frame_spec = bundle["frame_sources"].get(timeframe)
        if not isinstance(frame_spec, dict) or not frame_spec.get("contracts"):
            raise ValueError(f"bundle missing dated contract inputs for {underlying}/{timeframe}")
        raw = {(underlying, symbol): _read_bars(path, symbol, underlying)
               for symbol, path in frame_spec["contracts"].items()}
        transitions = [_roll(x) for x in frame_spec.get("rolls", [])]
        result = build_back_adjusted_series(contracts, raw, transitions, policy,
            as_of=as_of, expected_interval=frame_spec.get("expected_interval"),
            naive_timezone=frame_spec.get("naive_timezone"))
        selected = result.series[result.series.underlying == underlying].copy()
        if selected.empty:
            raise ValueError(f"Task-2 produced no {underlying}/{timeframe} point-in-time bars")
        frames[timeframe] = selected
        results[timeframe] = result
    return frames, results


def _build_for_underlying(bundle: dict, item: dict, split_date: str,
                          strategy_snapshots: int | None = None) -> dict:
    underlying = item["underlying"]
    contracts = [_contract(x) for x in item["contracts"]]
    if any(c.underlying != underlying for c in contracts):
        raise ValueError("bundle merges contracts from another underlying")
    policy = RollPolicy(**item["roll_policy"])
    calendar = _calendar(item["calendar"])
    executable = {symbol: _read_bars(path, symbol, underlying)
                  for symbol, path in item["executable_bars"].items()}
    from shared.config.settings import stock_logic_config
    stack = getattr(stock_logic_config, f"COMMODITY_TIME_FRAME_{int(item['strategy_tf'])}")
    exec_spec = stack[-1]
    if exec_spec not in item["frame_sources"]:
        raise ValueError("execution timeframe has no dated source configuration")
    exec_times = []
    for symbol, path in item["frame_sources"][exec_spec]["contracts"].items():
        part = _read_bars(path, symbol, underlying)
        exec_times.extend(pd.to_datetime(part.timestamp, errors="coerce").dropna().tolist())
    exec_times = sorted(set(pd.Timestamp(x) for x in exec_times))
    if strategy_snapshots is not None:
        exec_times = exec_times[-strategy_snapshots:]

    snapshot_cache = {}
    def load_snapshot(as_of):
        key = pd.Timestamp(as_of).isoformat()
        if key not in snapshot_cache:
            snapshot_cache[key] = _research_snapshot(item, underlying, pd.Timestamp(as_of), contracts, policy)
        return snapshot_cache[key]

    # Strategy uses the existing configured stack and runs at each completed
    # execute-timeframe bar. The adapter obtains its E1-clean, causal inputs
    # from Task-2 as_of snapshots; no setup JSON is required.
    def point_in_time_frames(clock):
        frames, _ = load_snapshot(clock)
        return frames

    # The execute bar timestamp is a candle start; point-in-time adjustment
    # knowledge is frozen at its close/next-period clock. Match the adapter's
    # deterministic frame clock semantics.
    from .clean_strategy_replay import _clock_after_bar
    decision_clocks = [_clock_after_bar(t, stack[-1]) for t in exec_times]
    setups = replay_existing_strategy(underlying, point_in_time_frames,
        strategy_tf=int(item["strategy_tf"]),
        contract_selector=lambda ts: _select_with_adjustment(contracts, ts, load_snapshot,
            underlying, stack[-1], executable),
        calendar_classifier=lambda ts, contract: classify_expiry_window(ts,
            next(c for c in contracts if c.contract_symbol == contract["contract_symbol"]), calendar),
        source_id=str(item["source_id"]), roll_policy_version=policy.policy_id,
        snapshot_timestamps=exec_times)

    bars_by_setup = {}
    for setup in setups:
        source = executable.get(setup["historical_contract"])
        if source is None:
            continue
        bars = source.copy()
        bars["timestamp"] = pd.to_datetime(bars.timestamp, errors="coerce")
        bars["e1_session_id"] = __import__("scripts.mcx_session", fromlist=["mcx_e1_session_ids"]).mcx_e1_session_ids(bars.timestamp.tolist())
        bars_by_setup[setup["setup_id"]] = bars

    frame_results = [{**result.validation_summary, "snapshot_as_of": result.snapshot_as_of}
                     for _, result in load_snapshot(decision_clocks[-1])[1].items()] if decision_clocks else []
    return {"underlying": underlying, "setups": setups, "bars_by_setup": bars_by_setup,
            "contracts": contracts, "policy": policy, "calendar": calendar,
            "frame_validation": frame_results, "snapshot_count": len(exec_times),
            "input_hashes": {str(path): _hash_file(path)
                for spec in item["frame_sources"].values() for path in spec["contracts"].values()} |
                {str(path): _hash_file(path) for path in item["executable_bars"].values()}}


def validate_bundle(path: Path | dict) -> dict:
    """Run Task-2 validation across the declared coverage before any replay."""
    bundle = _load_json(path) if isinstance(path, Path) else path
    errors = []
    items = bundle.get("underlyings")
    if bundle.get("schema_version") != 1 or bundle.get("provider") != "FYERS":
        errors.append("schema_version 1 and provider FYERS are required")
    if not isinstance(items, list) or {x.get("underlying") for x in items} != set(UNDERLYING_PRODUCTS):
        errors.append("all five MCX underlyings must be present separately")
        items = items if isinstance(items, list) else []
    validation_as_of = bundle.get("validation_as_of")
    if not validation_as_of:
        errors.append("explicit validation_as_of snapshot timestamp is required")
    summaries = {}
    hashes = {}
    for item in items:
        underlying = item.get("underlying", "UNKNOWN")
        try:
            contracts = [_contract(x) for x in item["contracts"]]
            policy = RollPolicy(**item["roll_policy"])
            calendar = _calendar(item["calendar"])
            if policy.approval_status == "APPROVED" and not item.get("policy_approval_id"):
                errors.append(f"{underlying}: APPROVED roll policy lacks independent policy_approval_id")
            if set(item.get("strategy_tfs", [])) != {1, 2, 3, 4}:
                errors.append(f"{underlying}: strategy_tfs must be [1,2,3,4]")
            if not calendar.verified:
                errors.append(f"{underlying}: exchange calendar is unverified")
            per_tf = {}
            for tf in TIMEFRAME_NAMES:
                spec = item["frame_sources"][tf]
                raw = {}
                for symbol, raw_path in spec["contracts"].items():
                    source = Path(raw_path)
                    if not source.is_file():
                        raise ValueError(f"missing dated-contract source {source}")
                    hashes[str(source)] = _hash_file(source)
                    raw[(underlying, symbol)] = _read_bars(source, symbol, underlying)
                rolls = [_roll(x) for x in spec.get("rolls", [])]
                result = build_back_adjusted_series(contracts, raw, rolls, policy,
                    as_of=validation_as_of, expected_interval=spec.get("expected_interval"),
                    naive_timezone=spec.get("naive_timezone"))
                per_tf[tf] = result.validation_summary
                if result.validation_summary.get("status") != "VALID":
                    errors.append(f"{underlying}/{tf}: Task-2 status {result.validation_summary.get('status')} issues={result.validation_summary.get('issues')}")
            executable_symbols = set()
            for symbol, raw_path in item["executable_bars"].items():
                source = Path(raw_path)
                if not source.is_file():
                    raise ValueError(f"missing executable dated bars {source}")
                frame = _read_bars(source, symbol, underlying)
                if {"timestamp", "open", "high", "low", "close", "volume"} - set(frame):
                    raise ValueError(f"executable bars lack OHLCV: {source}")
                hashes[str(source)] = _hash_file(source)
                executable_symbols.add(symbol)
            expected_symbols = {c.contract_symbol for c in contracts}
            if not expected_symbols.issubset(executable_symbols):
                errors.append(f"{underlying}: executable mapping missing contracts {sorted(expected_symbols-executable_symbols)}")
            summaries[underlying] = per_tf
        except (KeyError, TypeError, ValueError, OSError) as exc:
            errors.append(f"{underlying}: {type(exc).__name__}: {exc}")
    return {"status": "VALID" if not errors else "UNVERIFIED",
        "provider": "FYERS", "source_mode": "RAW_DATED",
        "dated_contract_ohlcv_verified": bool(summaries) and all(
            all(x.get("status") == "VALID" for x in per_tf.values()) for per_tf in summaries.values()),
        "historical_contract_attribution_verified": all(
            all(c.get("attribution_status") == "VERIFIED" for c in x.get("contracts", [])) for x in items),
        "roll_transitions_verified": bool(summaries) and all(
            all(y.get("verified_roll_transitions", 0) > 0 for y in x.values()) for x in summaries.values()),
        "roll_prices_verified": bool(summaries) and all(
            all(y.get("verified_roll_transitions", 0) > 0 for y in x.values()) for x in summaries.values()),
        "roll_policy_approved": bool(items) and all(
            x.get("roll_policy", {}).get("approval_status") == "APPROVED" and bool(x.get("policy_approval_id")) for x in items),
        "trading_calendar_verified": bool(items) and all(bool(x.get("calendar", {}).get("verified")) for x in items),
        "e1_enforced": bool(summaries) and all(
            all(y.get("e1_session_ids_attached") is True for y in x.values()) for x in summaries.values()),
        "executable_price_mapping_verified": bool(items) and all(
            {c.get("contract_symbol") for c in x.get("contracts", [])}.issubset(set(x.get("executable_bars", {}))) for x in items),
        "point_in_time_integrity_verified": bool(validation_as_of) and all(
            all(y.get("status") == "VALID" for y in x.values()) for x in summaries.values()),
        "coverage_verified": bundle.get("approvals", {}).get("coverage_approved") is True,
        "underlyings": sorted(summaries),
        "strategy_timeframes": sorted({int(tf) for x in items for tf in x.get("strategy_tfs", [])}),
        "coverage_start": bundle.get("coverage_start"), "coverage_end": bundle.get("coverage_end"),
        "roll_policy_version": ",".join(sorted({x.get("roll_policy", {}).get("policy_id", "") for x in items if x.get("roll_policy", {}).get("policy_id")})),
        "calendar_version": ",".join(sorted({x.get("calendar", {}).get("source_id", "") for x in items if x.get("calendar", {}).get("source_id")})),
        "input_hashes": hashes, "errors": errors, "task2_summaries": summaries}


def _select_with_adjustment(contracts, timestamp, load_snapshot, underlying, timeframe, executable):
    contract = select_historical_contract(contracts, underlying, timestamp)
    from shared.config.settings import stock_logic_config
    # Snapshot frames are keyed by the frame names in the strategy stack; use
    # the requested execution frame when present and otherwise the final X.
    available, results = load_snapshot(timestamp)
    candidates = available.get(timeframe)
    if candidates is None:
        candidates = next(iter(available.values()))
    rows = candidates[candidates.contract_symbol == contract.contract_symbol]
    if rows.empty:
        raise ValueError(f"no adjusted-price mapping for {contract.contract_symbol} at {timestamp}")
    row = rows.iloc[-1]
    return {**asdict(contract), "contract_symbol": contract.contract_symbol,
        "attribution_status": contract.attribution_status,
        "adjustment_factor": float(row.adjustment_factor),
        "adjustment_offset": float(row.adjustment_offset),
        "executable_price_status": "VERIFIED" if contract.contract_symbol in executable else "MISSING"}


def run_bundle(path: Path, *, output_root: Path | None = None, run_id: str | None = None,
               git_revision: str | None = None, split_date: str | None = None,
               diagnostic_only: bool = False, strategy_snapshots: int | None = None) -> dict:
    bundle = _load_json(path)
    if bundle.get("schema_version") != 1 or bundle.get("provider") != "FYERS":
        raise ValueError("bundle schema_version=1 and provider=FYERS are required")
    task2 = validate_bundle(bundle)
    task2_issues = readiness_issues(task2)
    if task2.get("status") != "VALID" or task2_issues:
        message = task2.get("errors", []) + task2_issues
        if diagnostic_only:
            return {"status": "NON_AUTHORITATIVE_DIAGNOSTIC_BLOCKED", "reason": message,
                    "data_validation": task2}
        raise ExportBlocked(message)
    if not diagnostic_only and not split_date:
        raise ExportBlocked(["explicit approved IS/OOS split date is required"])
    if not diagnostic_only:
        approvals = bundle.get("approvals", {})
        if approvals.get("split_date") != split_date or not approvals.get("split_date_approval_id"):
            raise ExportBlocked(["split date lacks a matching independent approval record; diagnostic replay only"])
    items = bundle.get("underlyings")
    if not isinstance(items, list) or {x.get("underlying") for x in items} != set(UNDERLYING_PRODUCTS):
        raise ExportBlocked(["authoritative/research full bundle requires all five separate MCX underlyings"])
    all_setups, all_bars = [], {}
    for item in items:
        strategy_tfs = item.get("strategy_tfs", [item.get("strategy_tf")])
        if set(strategy_tfs) != {1, 2, 3, 4} and not diagnostic_only:
            raise ExportBlocked([f"{item['underlying']} must cover configured strategy timeframes 1-4"])
        for strategy_tf in strategy_tfs:
            tf_item = {**item, "strategy_tf": strategy_tf}
            result = _build_for_underlying(bundle, tf_item, split_date or "", strategy_snapshots)
            all_setups.extend(result["setups"])
            all_bars.update(result["bars_by_setup"])
    issues = readiness_issues(task2)
    if diagnostic_only:
        return {"status": "NON_AUTHORITATIVE_DIAGNOSTIC", "setup_count": len(all_setups),
                "reason": "diagnostic mode never writes the clean trade export", "data_validation": task2}
    if issues:
        raise ExportBlocked(issues)
    result = build_clean_export(all_setups, all_bars, task2, split_date)
    if output_root is not None:
        if not all((run_id, git_revision)):
            raise ValueError("run_id and git_revision are required to write versioned results")
        target = write_versioned_export({"provider": "FYERS", "source_bundle": str(path),
            "source_bundle_sha256": _hash_file(path), "data_validation": task2},
            all_setups, all_bars, split_date=split_date, output_root=output_root,
            run_id=run_id, git_revision=git_revision, data_validation=task2)
        return {"status": "CLEAN_EXPORT_GENERATED_AND_VALIDATED", "output": str(target),
                "trades": len(result["trades"]), "excluded": len(result["excluded"]),
                "setup_count": len(all_setups)}
    return {"status": "REPLAY_VALIDATED_IN_MEMORY", "trades": len(result["trades"]),
            "excluded": len(result["excluded"]), "setup_count": len(all_setups)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("check-access", "collect"):
        p = sub.add_parser(command)
        p.add_argument("--underlying", required=True)
        p.add_argument("--from-date", required=True)
        p.add_argument("--to-date", required=True)
        p.add_argument("--data-root", type=Path, default=Path("research/mcx_fyers_expired"))
        p.add_argument("--daily-request-limit", type=int, default=10)
        if command == "collect":
            p.add_argument("--product", choices=UNDERLYING_PRODUCTS, required=True)
            p.add_argument("--resolution", required=True)
            p.add_argument("--max-contracts", type=int, default=1)
    assemble = sub.add_parser("assemble-bundle", help="inventory FYERS cache and create machine-readable bundle readiness")
    assemble.add_argument("--data-root", type=Path, default=Path("research/mcx_fyers_expired"))
    assemble.add_argument("--output-dir", type=Path, default=Path("research/mcx_clean_phase1/assembled"))
    assemble.add_argument("--coverage-start", default=DEFAULT_COVERAGE_START)
    assemble.add_argument("--coverage-end", default=DEFAULT_COVERAGE_END)
    assemble.add_argument("--daily-request-limit", type=int, default=10)
    for command in ("validate-data", "replay", "full"):
        p = sub.add_parser(command)
        p.add_argument("--bundle", required=(command != "full"), type=Path)
        if command == "full":
            p.add_argument("--data-root", type=Path, default=Path("research/mcx_fyers_expired"))
            p.add_argument("--assembly-output", type=Path, default=Path("research/mcx_clean_phase1/assembled"))
            p.add_argument("--coverage-start", default=DEFAULT_COVERAGE_START)
            p.add_argument("--coverage-end", default=DEFAULT_COVERAGE_END)
            p.add_argument("--daily-request-limit", type=int, default=10)
        if command in ("replay", "full"):
            p.add_argument("--split-date")
            p.add_argument("--output-root", type=Path)
            p.add_argument("--run-id")
            p.add_argument("--git-revision")
            p.add_argument("--diagnostic-only", action="store_true")
            p.add_argument("--mode", choices=("TEST_ONLY", "RESEARCH_DIAGNOSTIC", "AUTHORITATIVE"),
                           default="AUTHORITATIVE")
            p.add_argument("--strategy-snapshots", type=int)
    args = parser.parse_args(argv)
    try:
        if args.command in {"check-access", "collect"}:
            command = [sys.executable, "-m", "audit.mcx_futures_backtest.fyers_expired_contract_collector",
                       args.command, "--underlying", args.underlying, "--from-date", args.from_date,
                       "--to-date", args.to_date, "--data-root", str(args.data_root),
                       "--daily-request-limit", str(args.daily_request_limit)]
            if args.command == "collect":
                command += ["--product", args.product, "--resolution", args.resolution,
                            "--max-contracts", str(args.max_contracts)]
            return subprocess.run(command, check=False).returncode
        if args.command == "assemble-bundle":
            report = assemble_cached_inputs(args.data_root, args.output_dir,
                coverage_start=args.coverage_start, coverage_end=args.coverage_end,
                daily_request_limit=args.daily_request_limit)
            print(json.dumps(report, sort_keys=True, default=str))
            return 0 if report.get("status") == "READY_FOR_TASK2_VALIDATION" else 2
        if args.command == "validate-data":
            bundle = _load_json(args.bundle)
            report = validate_bundle(bundle)
            print(json.dumps(report, sort_keys=True, default=str))
            return 0 if report.get("status") == "VALID" else 2
        if getattr(args, "mode", "AUTHORITATIVE") == "TEST_ONLY":
            tests = ["tests/test_mcx_fyers_expired_collector.py",
                     "tests/test_mcx_derived_strategy_timeframes.py",
                     "tests/test_mcx_contract_roll_adjustment.py",
                     "tests/test_mcx_e1_session_boundary.py",
                     "tests/test_mcx_clean_strategy_replay.py",
                     "tests/test_mcx_clean_realized_r_export.py",
                     "tests/test_mcx_clean_phase1_runner.py"]
            return subprocess.run([sys.executable, "-m", "pytest", "-q", *tests], check=False).returncode
        if args.command == "full" and args.bundle is None:
            report = assemble_cached_inputs(args.data_root, args.assembly_output,
                coverage_start=args.coverage_start, coverage_end=args.coverage_end,
                daily_request_limit=args.daily_request_limit)
            print(json.dumps({"status": report.get("status"),
                "message": "automatic cache assembly completed; replay cannot proceed until every listed prerequisite is verified",
                "readiness_path": report.get("readiness_path"),
                "contract_manifest_path": report.get("contract_manifest_path"),
                "blockers": report.get("blockers", [])}, sort_keys=True))
            return 2
        diagnostic_only = (args.mode == "RESEARCH_DIAGNOSTIC" or args.diagnostic_only)
        result = run_bundle(args.bundle, output_root=args.output_root, run_id=args.run_id,
            git_revision=args.git_revision, split_date=args.split_date,
            diagnostic_only=diagnostic_only, strategy_snapshots=args.strategy_snapshots)
        print(json.dumps(result, sort_keys=True, default=str))
        return 0
    except (FyersDataError, ExportBlocked, KeyError, TypeError, ValueError, OSError) as exc:
        print(json.dumps({"status": "BLOCKED_MISSING_DATA", "message": str(exc)}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
