"""FYERS-only, resumable collector for genuine dated MCX futures history.

Uses the documented FYERS expired-F&O HTTP routes because the repository's
installed fyers-apiv3 3.1.7 does not expose the newer Python convenience
methods. It never sends trading requests. Downloads are explicit and bounded;
raw response JSON and normalized contract bars are content-hashed.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import time
from typing import Mapping, Sequence

import pandas as pd
import requests

UNDERLYING_PRODUCTS = ("GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI")
DATA_HOST = "https://api-t1.fyers.in/data"
EXPIRY_PATH = "/history/fno/expired/expiry-dates"
CONTRACTS_PATH = "/history/fno/expired/underlying-symbols"
EXPIRED_DATA_PATH = "/history/fno/expired/historical-data"
ACTIVE_DATA_PATH = "/history"
OHLCV_REQUIRED = ("timestamp", "open", "high", "low", "close", "volume")


class FyersDataError(RuntimeError):
    def __init__(self, status: str, message: str, code=None, http_status=None):
        self.status, self.code, self.http_status = status, code, http_status
        self.provider_payload = None
        super().__init__(message)


def classify_response(response: Mapping, http_status: int = 200) -> str:
    code = response.get("code")
    state = str(response.get("s", "")).lower()
    message = str(response.get("message", "")).lower()
    details = json.dumps(response.get("data", {}), sort_keys=True, default=str).lower()
    if http_status == 401 or code in (401, -8, -16):
        return "AUTHENTICATION_FAILED"
    if http_status == 403 or code in (403, -5, -6) or "entitlement" in message or "subscription" in message:
        return "ENTITLEMENT_DENIED"
    if http_status == 429 or code == 429:
        return "RATE_LIMITED"
    if code == -300 or "invalid symbol" in message or "symbol not found" in message or "invalid symbol" in details or "symbol not found" in details:
        return "SYMBOL_NOT_FOUND"
    if http_status == 422 or code == -50:
        return "INVALID_REQUEST"
    if state == "no_data":
        return "NO_DATA"
    if http_status >= 400 or state == "error" or (code not in (None, 200)):
        return "DATA_VALIDATION_FAILED"
    return "SUCCESS"


def _redact_provider_payload(value):
    """Return response-only evidence with credential-shaped fields removed."""
    sensitive = {"authorization", "access_token", "refresh_token", "token", "api_key",
                 "secret", "password", "client_secret"}
    if isinstance(value, Mapping):
        return {str(key): ("[REDACTED]" if str(key).lower() in sensitive else _redact_provider_payload(item))
                for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_provider_payload(item) for item in value]
    if isinstance(value, tuple):
        return [_redact_provider_payload(item) for item in value]
    return value


def _requested_product(symbol: str) -> str:
    """Extract a supported product root from an FYERS underlying or dated symbol."""
    candidate = str(symbol).upper().split(":", 1)[-1]
    matches = [p for p in UNDERLYING_PRODUCTS if candidate.startswith(p)]
    if len(matches) != 1:
        raise FyersDataError("DATA_VALIDATION_FAILED", "symbol is not an unambiguous supported MCX product")
    return matches[0]


class FyersExpiredRestClient:
    """Read-only transport; pass the app-id and token from existing auth."""
    def __init__(self, client_id: str, access_token=<REDACTED>, *, session=None, timeout=30):
        if not client_id or not access_token=<REDACTED> FyersDataError("AUTHENTICATION_FAILED", "FYERS credentials unavailable")
        self._session = session or requests.Session()
        self._authorization = f"{client_id}:{access_token}"
        self.timeout = timeout

    def _get(self, path: str, params: Mapping) -> dict:
        try:
            response = self._session.get(DATA_HOST + path,
                headers={"Authorization": self._authorization, "Content-Type": "application/json"},
                params=dict(params), timeout=self.timeout)
        except requests.RequestException as exc:
            raise FyersDataError("NETWORK_ERROR", type(exc).__name__) from None
        try:
            body = response.json()
        except (ValueError, json.JSONDecodeError):
            raise FyersDataError("DATA_VALIDATION_FAILED", "FYERS returned non-JSON response",
                                 http_status=response.status_code) from None
        status = classify_response(body, response.status_code)
        if status not in {"SUCCESS", "NO_DATA"}:
            error = FyersDataError(status, str(body.get("message", "FYERS request failed"))[:160],
                                   body.get("code"), response.status_code)
            error.provider_payload = _redact_provider_payload(body)
            raise error
        return body

    def expiry_dates(self, symbol: str, range_from: str, range_to: str) -> dict:
        return self._get(EXPIRY_PATH, {"symbol": symbol, "range_from": range_from,
            "range_to": range_to, "date_format": "1"})

    def expired_contracts(self, symbol: str, expiry_date: str) -> dict:
        return self._get(CONTRACTS_PATH, {"symbol": symbol, "expiry_date": expiry_date})

    def expired_history(self, symbol: str, resolution: str, range_from: str,
                        range_to: str, include_oi: bool = True) -> dict:
        return self._get(EXPIRED_DATA_PATH, {"symbol": symbol, "resolution": resolution,
            "date_format": "1", "range_from": range_from, "range_to": range_to,
            "include_oi": "1" if include_oi else "0", "include_greeks": "0"})

    def active_history(self, symbol: str, resolution: str, range_from: str,
                       range_to: str, include_oi: bool = True) -> dict:
        """Fetch an exact active dated contract; continuous mode is forced off."""
        return self._get(ACTIVE_DATA_PATH, {"symbol": symbol, "resolution": resolution,
            "date_format": "1", "range_from": range_from, "range_to": range_to,
            "cont_flag": "0", "oi_flag": "1" if include_oi else "0"})


def client_from_repository_auth():
    """Load existing FYERS token without printing it or invoking refresh flows."""
    import contextlib
    import io
    from data_fetchers.fyers.fyers_session import fyers_access_token_handler
    sink = io.StringIO()
    try:
        with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            value = fyers_access_token_handler().get_access_token()
    except Exception as exc:
        raise FyersDataError("AUTHENTICATION_FAILED", f"repository token lookup failed ({type(exc).__name__})") from None
    if not isinstance(value, str) or ":" not in value:
        raise FyersDataError("AUTHENTICATION_FAILED", "repository has no usable FYERS access token")
    client_id, token = value.rsplit(":", 1)
    if not client_id or not token:
        raise FyersDataError("AUTHENTICATION_FAILED", "repository token format is invalid")
    try:
        import base64
        claims = json.loads(base64.urlsafe_b64decode(token.split(".")[1] + "==="))
        if claims.get("exp") is not None and float(claims["exp"]) < time.time():
            raise FyersDataError("AUTHENTICATION_FAILED", "repository FYERS token is expired")
    except (IndexError, ValueError, json.JSONDecodeError):
        # Opaque tokens are delegated to FYERS for definitive validation.
        pass
    return FyersExpiredRestClient(client_id, token)


def split_date_range(start: date | str, end: date | str, max_days: int = 100):
    """Yield inclusive, nonoverlapping FYERS chunks of at most max_days."""
    start, end = pd.Timestamp(start).date(), pd.Timestamp(end).date()
    if end < start or max_days < 1 or max_days > 366:
        raise ValueError("invalid date range or unsupported chunk size (maximum 366 days)")
    cursor = start
    while cursor <= end:
        chunk_end = min(end, cursor + timedelta(days=max_days - 1))
        yield cursor.isoformat(), chunk_end.isoformat()
        cursor = chunk_end + timedelta(days=1)


def parse_expiry_dates(response: Mapping, requested_symbol: str) -> list[str]:
    status = classify_response(response)
    if status != "SUCCESS":
        raise FyersDataError(status, "expiry discovery did not succeed", response.get("code"))
    data = response.get("data") or {}
    if data.get("symbol") and str(data["symbol"]).upper() != _requested_product(requested_symbol):
        raise FyersDataError("DATA_VALIDATION_FAILED", "expiry response underlying does not match request")
    values = (data.get("expiry_dates") or {}).get("futures")
    if not isinstance(values, list):
        raise FyersDataError("DATA_VALIDATION_FAILED", "expiry response lacks futures expiry list")
    parsed = sorted({pd.Timestamp(x).date().isoformat() for x in values})
    return parsed


def parse_expired_symbols(response: Mapping, requested_symbol: str, expiry: str) -> list[str]:
    status = classify_response(response)
    if status != "SUCCESS":
        raise FyersDataError(status, "expired-symbol discovery did not succeed", response.get("code"))
    data = response.get("data") or {}
    if data.get("expiry_date") and pd.Timestamp(data["expiry_date"]).date().isoformat() != pd.Timestamp(expiry).date().isoformat():
        raise FyersDataError("DATA_VALIDATION_FAILED", "expired-symbol response expiry mismatch")
    if data.get("symbol") and str(data["symbol"]).upper() != _requested_product(requested_symbol):
        raise FyersDataError("DATA_VALIDATION_FAILED", "expired-symbol response underlying mismatch")
    values = (data.get("contracts") or {}).get("futures")
    if not isinstance(values, list):
        raise FyersDataError("DATA_VALIDATION_FAILED", "expired-symbol response lacks futures list")
    if any(not isinstance(x, str) or not x.startswith("MCX:") for x in values):
        raise FyersDataError("DATA_VALIDATION_FAILED", "response contains malformed/non-MCX contract symbol")
    return sorted(set(values))


def parse_candles(response: Mapping, symbol: str) -> pd.DataFrame:
    status = classify_response(response)
    if status == "NO_DATA":
        return pd.DataFrame(columns=(*OHLCV_REQUIRED, "open_interest"))
    if status != "SUCCESS":
        raise FyersDataError(status, "expired history request did not succeed", response.get("code"))
    if str(response.get("symbol", "")).upper() != symbol.upper():
        raise FyersDataError("DATA_VALIDATION_FAILED", "history response symbol does not match exact contract")
    columns = response.get("columns")
    candles = response.get("candles")
    if (not isinstance(columns, list) or not isinstance(candles, list)
            or any(not isinstance(name, str) for name in columns)):
        raise FyersDataError("DATA_VALIDATION_FAILED", "history response schema lacks required named columns")
    canonical = [name.strip().lower() for name in columns]
    if len(set(canonical)) != len(canonical) or not set(OHLCV_REQUIRED).issubset(canonical):
        raise FyersDataError("DATA_VALIDATION_FAILED", "history response schema lacks unique required OHLCV columns")
    if any(not isinstance(row, (list, tuple)) or len(row) != len(columns) for row in candles):
        raise FyersDataError("DATA_VALIDATION_FAILED", "candle rows do not match response columns")
    frame = pd.DataFrame(candles, columns=canonical)
    # FYERS guarantees the first six columns and documents optional columns by
    # name. In particular OI must never shift OHLCV positions.
    frame["timestamp"] = pd.to_datetime(pd.to_numeric(frame.timestamp), unit="s", utc=True).dt.tz_convert("Asia/Kolkata")
    for name in ("open", "high", "low", "close", "volume"):
        frame[name] = pd.to_numeric(frame[name], errors="coerce")
    if "open_interest" not in frame:
        frame["open_interest"] = pd.NA
    else:
        frame["open_interest"] = pd.to_numeric(frame.open_interest, errors="coerce")
    if frame[list(OHLCV_REQUIRED)].isna().any().any() or frame.timestamp.duplicated().any() or not frame.timestamp.is_monotonic_increasing:
        raise FyersDataError("DATA_VALIDATION_FAILED", "missing, duplicate, or unordered dated-contract bars")
    if ((frame.high < frame[["open", "low", "close"]].max(axis=1)) |
            (frame.low > frame[["open", "high", "close"]].min(axis=1)) | (frame.volume < 0)).any():
        raise FyersDataError("DATA_VALIDATION_FAILED", "invalid OHLC envelope or negative volume")
    frame["provider_columns"] = json.dumps(canonical, separators=(",", ":"))
    return frame[[*OHLCV_REQUIRED, "open_interest", "provider_columns"]]


def parse_active_candles(response: Mapping, exact_symbol: str) -> pd.DataFrame:
    """Parse standard /history arrays; identity is the exact noncontinuous request."""
    status = classify_response(response)
    if status == "NO_DATA":
        return pd.DataFrame(columns=(*OHLCV_REQUIRED, "open_interest"))
    if status != "SUCCESS":
        raise FyersDataError(status, "active dated-history request did not succeed", response.get("code"))
    if response.get("symbol") and str(response["symbol"]).upper() != exact_symbol.upper():
        raise FyersDataError("DATA_VALIDATION_FAILED", "active history response symbol mismatch")
    candles = response.get("candles")
    if not isinstance(candles, list) or any(not isinstance(row, (list, tuple)) or len(row) not in (6, 7) for row in candles):
        raise FyersDataError("DATA_VALIDATION_FAILED", "active-history candle arrays must contain 6 or 7 values")
    frame = pd.DataFrame([[*row[:6], row[6] if len(row) == 7 else pd.NA] for row in candles],
                         columns=[*OHLCV_REQUIRED, "open_interest"])
    if frame.empty:
        return frame
    frame["timestamp"] = pd.to_datetime(pd.to_numeric(frame.timestamp), unit="s", utc=True).dt.tz_convert("Asia/Kolkata")
    for name in ("open", "high", "low", "close", "volume", "open_interest"):
        frame[name] = pd.to_numeric(frame[name], errors="coerce")
    if frame[list(OHLCV_REQUIRED)].isna().any().any() or frame.timestamp.duplicated().any() or not frame.timestamp.is_monotonic_increasing:
        raise FyersDataError("DATA_VALIDATION_FAILED", "active history contains missing, duplicate, or unordered bars")
    if ((frame.high < frame[["open", "low", "close"]].max(axis=1)) |
            (frame.low > frame[["open", "high", "close"]].min(axis=1)) | (frame.volume < 0)).any():
        raise FyersDataError("DATA_VALIDATION_FAILED", "active history has invalid OHLC envelope or negative volume")
    return frame


@dataclass
class FyersContractCollector:
    client: object
    root: Path
    daily_request_limit: int = 10
    min_request_interval_seconds: float = 0.0
    _requests_used: int = 0
    _last_request_time: float = 0.0

    def _call(self, method, *args):
        self.root.mkdir(parents=True, exist_ok=True)
        budget_path = self.root / ".daily_request_budget.json"
        today = datetime.now().date().isoformat()
        try:
            budget = json.loads(budget_path.read_text())
        except (OSError, json.JSONDecodeError):
            budget = {"date": today, "count": 0}
        if budget.get("date") != today:
            budget = {"date": today, "count": 0}
        if int(budget.get("count", 0)) >= self.daily_request_limit:
            raise FyersDataError("RATE_LIMITED", "configured daily request budget exhausted; resume on the next quota window")
        delay = self.min_request_interval_seconds - (time.monotonic() - self._last_request_time)
        if delay > 0:
            time.sleep(delay)
        # Count attempted calls too, including auth/entitlement/HTTP errors.
        budget["count"] = int(budget.get("count", 0)) + 1
        budget_path.write_text(json.dumps(budget, sort_keys=True) + "\n")
        self._requests_used += 1
        self._last_request_time = time.monotonic()
        return method(*args)

    def discover(self, underlying_symbol: str, start: str, end: str) -> list[dict]:
        cache_dir = self.root / "discovery"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_key = hashlib.sha256(f"{underlying_symbol}|{start}|{end}".encode()).hexdigest()
        cache_path = cache_dir / f"{cache_key}.json"
        if cache_path.is_file():
            cached = json.loads(cache_path.read_text())
            expected = hashlib.sha256(json.dumps(cached.get("expiries", []), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if cached.get("provider") == "FYERS" and cached.get("status") == "SUCCESS" and cached.get("sha256") == expected:
                return cached["expiries"]
        records = []
        for lo, hi in split_date_range(start, end, 366):
            try:
                response = self._call(self.client.expiry_dates, underlying_symbol, lo, hi)
            except FyersDataError as exc:
                self._persist_discovery_rejection("expiry_dates", underlying_symbol, None,
                    lo, hi, exc.provider_payload, exc)
                raise
            for expiry in parse_expiry_dates(response, underlying_symbol):
                if lo <= expiry <= hi:
                    records.append({"underlying_symbol": underlying_symbol, "expiry_date": expiry,
                                    "product": _requested_product(underlying_symbol),
                                    "contracts": None, "status": "EXPIRY_DISCOVERED"})
        raw = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
        cache_path.write_text(json.dumps({"provider": "FYERS", "status": "SUCCESS",
            "requested_symbol": underlying_symbol, "range_from": start, "range_to": end,
            "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
            "expiries": records, "sha256": hashlib.sha256(raw).hexdigest()},
            indent=2, sort_keys=True) + "\n")
        return records

    def _persist_discovery_rejection(self, endpoint_kind: str, symbol: str,
                                     expiry: str | None, start: str, end: str,
                                     payload: Mapping | None, error: FyersDataError) -> None:
        safe = re.sub(r"[^A-Za-z0-9_-]", "_", symbol)
        root = self.root / "discovery" / "rejected"
        root.mkdir(parents=True, exist_ok=True)
        body = _redact_provider_payload(payload) if payload is not None else None
        raw = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode()
        digest = hashlib.sha256(raw).hexdigest()
        stem = f"{endpoint_kind}_{safe}_{start}_{end}_{digest[:12]}"
        (root / f"{stem}.json").write_bytes(raw)
        metadata = {"provider": "FYERS", "endpoint_kind": endpoint_kind,
            "requested_symbol": symbol, "expiry_date": expiry,
            "range_from": start, "range_to": end,
            "status": error.status, "provider_code": error.code,
            "http_status": error.http_status, "raw_response_sha256": digest,
            "response_captured": payload is not None,
            "authorization_headers_stored": False}
        (root / f"{stem}.metadata.json").write_text(json.dumps(metadata, sort_keys=True, indent=2) + "\n")

    def contracts_for_expiry(self, underlying_symbol: str, expiry: str) -> list[str]:
        key = hashlib.sha256(f"{underlying_symbol}|{expiry}".encode()).hexdigest()
        cache_path = self.root / "discovery" / f"contracts_{key}.json"
        if cache_path.is_file():
            cached = json.loads(cache_path.read_text())
            expected = hashlib.sha256(json.dumps(cached.get("contracts", []), sort_keys=True).encode()).hexdigest()
            if cached.get("provider") == "FYERS" and cached.get("status") == "SUCCESS" and cached.get("sha256") == expected:
                return list(cached["contracts"])
        try:
            response = self._call(self.client.expired_contracts, underlying_symbol, expiry)
        except FyersDataError as exc:
            self._persist_discovery_rejection("expired_contracts", underlying_symbol,
                expiry, expiry, expiry, exc.provider_payload, exc)
            raise
        contracts = parse_expired_symbols(response, underlying_symbol, expiry)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"provider": "FYERS", "status": "SUCCESS", "requested_symbol": underlying_symbol,
                   "expiry_date": expiry, "contracts": contracts,
                   "retrieved_at_utc": datetime.now(timezone.utc).isoformat()}
        payload["sha256"] = hashlib.sha256(json.dumps(contracts, sort_keys=True).encode()).hexdigest()
        cache_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return contracts

    def _persist(self, underlying: str, symbol: str, expiry: str, resolution: str,
                 range_from: str, range_to: str, response: Mapping, frame: pd.DataFrame,
                 *, endpoint=EXPIRED_DATA_PATH, price_identity="EXACT_DATED_SYMBOL_RETURNED_BY_FYERS") -> dict:
        raw = json.dumps(response, sort_keys=True, separators=(",", ":"), default=str).encode()
        raw_hash = hashlib.sha256(raw).hexdigest()
        safe_symbol = re.sub(r"[^A-Za-z0-9_-]", "_", symbol)
        target = self.root / underlying / safe_symbol / resolution / f"{range_from}_{range_to}_{raw_hash[:12]}"
        if target.exists():
            existing = json.loads((target / "metadata.json").read_text())
            if existing.get("raw_response_sha256") == raw_hash:
                return existing
            raise FyersDataError("DATA_VALIDATION_FAILED", "hash-keyed cache directory contains inconsistent metadata")
        target.mkdir(parents=True, exist_ok=False)
        (target / "provider_response.json").write_bytes(raw)
        enriched = frame.copy()
        enriched.insert(0, "underlying", underlying)
        enriched.insert(1, "contract_symbol", symbol)
        enriched.insert(2, "contract_expiry", expiry)
        enriched.insert(3, "resolution", resolution)
        csv_bytes = enriched.to_csv(index=False).encode()
        (target / "bars.csv").write_bytes(csv_bytes)
        metadata = {"provider": "FYERS", "source_endpoint": endpoint,
                    "underlying": underlying, "contract_symbol": symbol, "expiry_date": expiry,
                    "resolution": resolution, "range_from": range_from, "range_to": range_to,
                    "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                    "status": "SUCCESS", "bar_count": len(enriched), "raw_response_sha256": raw_hash,
                    "normalized_bars_sha256": hashlib.sha256(csv_bytes).hexdigest(),
                    "metadata_path": str(target / "metadata.json"),
                    "price_identity": price_identity,
                    "continuous_flag": 0 if endpoint == ACTIVE_DATA_PATH else None}
        (target / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
        return metadata

    def _persist_rejected_response(self, underlying: str, symbol: str, resolution: str,
                                   range_from: str, range_to: str, response: Mapping,
                                   reason: str, *, endpoint=EXPIRED_DATA_PATH) -> dict:
        """Retain a failed provider payload as rejected evidence without normalization."""
        raw = json.dumps(response, sort_keys=True, separators=(",", ":"), default=str).encode()
        digest = hashlib.sha256(raw).hexdigest()
        safe_symbol = re.sub(r"[^A-Za-z0-9_-]", "_", symbol)
        target = self.root / "rejected" / underlying / safe_symbol / resolution / f"{range_from}_{range_to}_{digest[:12]}"
        target.mkdir(parents=True, exist_ok=True)
        (target / "provider_response.json").write_bytes(raw)
        metadata = {"provider": "FYERS", "source_endpoint": endpoint,
                    "underlying": underlying, "contract_symbol": symbol,
                    "resolution": resolution, "range_from": range_from, "range_to": range_to,
                    "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                    "status": "REJECTED", "reason": reason,
                    "raw_response_sha256": digest}
        (target / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
        return metadata

    def _persist_no_data_response(self, underlying: str, symbol: str, expiry: str,
                                  resolution: str, range_from: str, range_to: str,
                                  response: Mapping, *, endpoint=EXPIRED_DATA_PATH) -> dict:
        raw = json.dumps(response, sort_keys=True, separators=(",", ":"), default=str).encode()
        digest = hashlib.sha256(raw).hexdigest()
        target = self.root / "no_data" / underlying / re.sub(r"[^A-Za-z0-9_-]", "_", symbol) / resolution / f"{range_from}_{range_to}_{digest[:12]}"
        target.mkdir(parents=True, exist_ok=True)
        (target / "provider_response.json").write_bytes(raw)
        metadata = {"provider": "FYERS", "source_endpoint": endpoint,
            "underlying": underlying, "contract_symbol": symbol, "expiry_date": expiry,
            "resolution": resolution, "range_from": range_from, "range_to": range_to,
            "retrieved_at_utc": datetime.now(timezone.utc).isoformat(), "status": "NO_DATA",
            "raw_response_sha256": digest}
        (target / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
        return metadata

    def collect_history(self, underlying: str, contract_symbol: str, expiry: str,
                        resolution: str, start: str, end: str, *, include_oi=True) -> list[dict]:
        if underlying not in UNDERLYING_PRODUCTS:
            raise ValueError(f"unsupported MCX underlying: {underlying}")
        output = []
        intraday = resolution not in {"1D", "1W", "1M"}
        state_path = self.root / ".collection_state.json"
        try:
            state = json.loads(state_path.read_text())
        except (OSError, json.JSONDecodeError):
            state = {}
        for lo, hi in split_date_range(start, end, 100 if intraday else 366):
            cache_key = "|".join((underlying, contract_symbol, resolution, lo, hi, str(bool(include_oi))))
            cached = state.get(cache_key)
            if cached and cached.get("status") == "SUCCESS":
                metadata_path = Path(cached.get("metadata_path", ""))
                if metadata_path.is_file():
                    meta = json.loads(metadata_path.read_text())
                    bars_path = metadata_path.with_name("bars.csv")
                    if hashlib.sha256(bars_path.read_bytes()).hexdigest() == meta.get("normalized_bars_sha256"):
                        output.append(meta)
                        continue
            if cached and cached.get("status") == "NO_DATA" and Path(cached.get("metadata_path", "")).is_file():
                output.append(json.loads(Path(cached["metadata_path"]).read_text()))
                continue
            try:
                response = self._call(self.client.expired_history, contract_symbol, resolution, lo, hi, include_oi)
            except FyersDataError as exc:
                if exc.provider_payload is not None:
                    self._persist_rejected_response(underlying, contract_symbol, resolution, lo, hi,
                        exc.provider_payload, f"{exc.status} code={exc.code} http={exc.http_status}",
                        endpoint=EXPIRED_DATA_PATH)
                raise
            try:
                frame = parse_candles(response, contract_symbol)
                if not frame.empty:
                    self._check_frame_bounds(frame, lo, hi)
            except FyersDataError as exc:
                self._persist_rejected_response(underlying, contract_symbol, resolution, lo, hi,
                                                _redact_provider_payload(response),
                                                f"{exc.status}: {exc}", endpoint=EXPIRED_DATA_PATH)
                raise
            if frame.empty:
                no_data = self._persist_no_data_response(underlying, contract_symbol, expiry,
                    resolution, lo, hi, response)
                output.append(no_data)
                state[cache_key] = {"status": "NO_DATA", "metadata_path": no_data["metadata_path"]}
                state_path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")
                continue
            metadata = self._persist(underlying, contract_symbol, expiry, resolution, lo, hi, response, frame)
            output.append(metadata)
            state[cache_key] = {"status": "SUCCESS", "metadata_path": metadata["metadata_path"]}
            state_path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")
        return output

    @staticmethod
    def _check_frame_bounds(frame: pd.DataFrame, start: str, end: str) -> None:
        local_dates = pd.to_datetime(frame.timestamp, errors="coerce").dt.date
        lo, hi = pd.Timestamp(start).date(), pd.Timestamp(end).date()
        if local_dates.isna().any() or (local_dates < lo).any() or (local_dates > hi).any():
            raise FyersDataError("DATA_VALIDATION_FAILED", "provider bars fall outside requested local-date bounds")

    def collect_active_history(self, underlying: str, contract_symbol: str, expiry: str,
                               resolution: str, start: str, end: str, *, include_oi=True) -> list[dict]:
        """Collect an active exact dated contract with cont_flag=0, never continuous data."""
        if underlying not in UNDERLYING_PRODUCTS or _requested_product(contract_symbol) != underlying:
            raise ValueError("active dated symbol does not match the requested supported MCX underlying")
        output = []
        intraday = resolution not in {"1D", "1W", "1M", "D", "W", "M"}
        state_path = self.root / ".collection_state.json"
        try:
            state = json.loads(state_path.read_text())
        except (OSError, json.JSONDecodeError):
            state = {}
        for lo, hi in split_date_range(start, end, 100 if intraday else 366):
            key = "ACTIVE|" + "|".join((underlying, contract_symbol, resolution, lo, hi, str(bool(include_oi))))
            cached = state.get(key)
            if cached and cached.get("status") == "SUCCESS":
                metadata_path = Path(cached.get("metadata_path", ""))
                if metadata_path.is_file():
                    meta = json.loads(metadata_path.read_text())
                    bars_path = metadata_path.with_name("bars.csv")
                    if hashlib.sha256(bars_path.read_bytes()).hexdigest() == meta.get("normalized_bars_sha256"):
                        output.append(meta)
                        continue
            if cached and cached.get("status") == "NO_DATA" and Path(cached.get("metadata_path", "")).is_file():
                output.append(json.loads(Path(cached["metadata_path"]).read_text()))
                continue
            response = self._call(self.client.active_history, contract_symbol, resolution, lo, hi, include_oi)
            try:
                frame = parse_active_candles(response, contract_symbol)
                if not frame.empty:
                    self._check_frame_bounds(frame, lo, hi)
            except FyersDataError as exc:
                self._persist_rejected_response(underlying, contract_symbol, resolution, lo, hi,
                                                response, f"{exc.status}: {exc}")
                raise
            if frame.empty:
                record = self._persist_no_data_response(underlying, contract_symbol, expiry,
                    resolution, lo, hi, response, endpoint=ACTIVE_DATA_PATH)
                output.append(record)
                state[key] = {"status": "NO_DATA", "metadata_path": record["metadata_path"]}
            else:
                meta = self._persist(underlying, contract_symbol, expiry, resolution, lo, hi,
                    response, frame, endpoint=ACTIVE_DATA_PATH,
                    price_identity="EXACT_REQUESTED_DATED_SYMBOL_CONT_FLAG_0")
                output.append(meta)
                state[key] = {"status": "SUCCESS", "metadata_path": meta["metadata_path"]}
            state_path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")
        return output


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("check-access", "collect"):
        p = sub.add_parser(name)
        p.add_argument("--underlying", required=True, help="FYERS underlying symbol, e.g. MCX:CRUDEOILM")
        p.add_argument("--from-date", required=True)
        p.add_argument("--to-date", required=True)
        p.add_argument("--data-root", type=Path, default=Path("research/mcx_fyers_expired"))
        p.add_argument("--daily-request-limit", type=int, default=10)
    collect = sub.choices["collect"]
    collect.add_argument("--product", required=True, choices=UNDERLYING_PRODUCTS)
    collect.add_argument("--resolution", required=True)
    collect.add_argument("--max-contracts", type=int, default=1)
    args = parser.parse_args(argv)
    try:
        product = _requested_product(args.underlying)
        if args.command == "collect" and args.product != product:
            raise FyersDataError("DATA_VALIDATION_FAILED", "--product does not match the FYERS underlying symbol")
        client = client_from_repository_auth()
        collector = FyersContractCollector(client, args.data_root, daily_request_limit=args.daily_request_limit)
        expiry_rows = collector.discover(args.underlying, args.from_date, args.to_date)
        if args.command == "check-access":
            print(json.dumps({"status": "SUCCESS", "provider": "FYERS", "underlying": args.underlying,
                              "product": product,
                              "expiry_count": len(expiry_rows), "expiries": [x["expiry_date"] for x in expiry_rows],
                              "requests_this_process": collector._requests_used, "credentials_printed": False}, sort_keys=True))
            return 0
        contracts = []
        for item in expiry_rows:
            found = collector.contracts_for_expiry(args.underlying, item["expiry_date"])
            item["contracts"] = found
            item["status"] = "CONTRACTS_DISCOVERED" if found else "NO_DATA"
            contracts.extend((item["expiry_date"], symbol) for symbol in found)
        contracts = sorted(contracts)[:max(1, args.max_contracts)]
        results = []
        for expiry, symbol in contracts:
            results.extend(collector.collect_history(args.product, symbol, expiry, args.resolution,
                args.from_date, args.to_date))
        print(json.dumps({"status": "SUCCESS" if results else "NO_DATA", "provider": "FYERS",
                          "contracts_requested": len(contracts), "results": results,
                          "requests_this_process": collector._requests_used,
                          "note": "bounded request budget; partial results remain resumable"}, sort_keys=True))
        return 0
    except FyersDataError as exc:
        print(json.dumps({"status": exc.status, "code": exc.code, "http_status": exc.http_status,
                          "message": str(exc), "credentials_printed": False}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
