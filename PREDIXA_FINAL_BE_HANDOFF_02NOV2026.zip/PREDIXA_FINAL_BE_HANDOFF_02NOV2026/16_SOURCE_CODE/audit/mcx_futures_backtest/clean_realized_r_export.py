"""Fail-closed MCX BUY trade export from verified contract-aware inputs.

This module does not discover signals or fetch data. Signal discovery must use
the existing PREDIXA engine on the E1-segmented research series. This boundary
accepts those candidate setups plus dated-contract executable bars and refuses
to write an authoritative export unless the Task-2 evidence manifest is fully
verified. Synthetic inputs are appropriate for unit tests only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Mapping, Sequence

import pandas as pd

from .contract_roll import UNDERLYINGS
from scripts.mcx_session import mcx_e1_session_ids

EXPORT_COLUMNS = [
    "symbol", "strategy_tf", "E_regime", "A_regime", "X_regime",
    "entry_price", "stop_price", "target_price", "exit_price", "outcome",
    "gross_r", "mfe_R", "partition", "bars_held",
]

READINESS_REQUIREMENTS = {
    "dated_contract_ohlcv_verified": "verified dated-contract OHLCV is required",
    "historical_contract_attribution_verified": "point-in-time historical contract attribution is required",
    "roll_transitions_verified": "explicit verified roll transitions are required",
    "roll_prices_verified": "source-verified outgoing and incoming roll prices are required",
    "roll_policy_approved": "approved roll policy and adjustment methodology are required",
    "trading_calendar_verified": "complete verified historical MCX trading calendar is required",
    "e1_enforced": "Task-1 E1 session segmentation must be enforced",
    "executable_price_mapping_verified": "dated-contract executable-price mapping is required",
    "point_in_time_integrity_verified": "point-in-time/no-lookahead validation is required",
    "coverage_verified": "required underlying/timeframe/date coverage must be verified",
}


class ExportBlocked(ValueError):
    def __init__(self, reasons: Sequence[str]):
        self.reasons = list(reasons)
        super().__init__("clean MCX export blocked: " + "; ".join(self.reasons))


def readiness_issues(report: Mapping) -> list[str]:
    """Return explicit blockers; a generic VALID status alone is insufficient."""
    if not isinstance(report, Mapping):
        return ["Task-2 validation evidence must be a JSON object"]
    issues = []
    if report.get("status") != "VALID":
        issues.append(f"Task-2 data validation status is {report.get('status')!r}, expected 'VALID'")
    if report.get("source_mode") != "RAW_DATED":
        issues.append("source_mode must be RAW_DATED; stitched/continuous inputs are rejected")
    for key, message in READINESS_REQUIREMENTS.items():
        if report.get(key) is not True:
            issues.append(f"{key}: {message}")
    if report.get("underlyings") is None or set(report.get("underlyings", [])) != set(UNDERLYINGS):
        issues.append("coverage must contain exactly the five separate required MCX underlyings")
    if set(report.get("strategy_timeframes") or []) != {1, 2, 3, 4}:
        issues.append("coverage must verify all configured MCX strategy timeframes [1, 2, 3, 4]")
    if not report.get("coverage_start") or not report.get("coverage_end"):
        issues.append("verified historical coverage_start and coverage_end are required")
    if not report.get("roll_policy_version"):
        issues.append("roll_policy_version is required")
    if not report.get("calendar_version"):
        issues.append("calendar_version is required")
    if not isinstance(report.get("input_hashes"), Mapping) or not report.get("input_hashes"):
        issues.append("input_hashes provenance is required")
    return issues


def _timestamp(value, name: str) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    if pd.isna(ts):
        raise ValueError(f"{name} is missing or invalid")
    if ts.tzinfo is None:
        raise ValueError(f"{name} must be timezone-aware")
    return ts.tz_convert("Asia/Kolkata")


def assign_partition(signal_timestamp, split_date: str) -> str:
    """Date-based deterministic partition; signal date before split is IS."""
    if not split_date:
        raise ValueError("an approved explicit IS/OOS split_date is required")
    signal = _timestamp(signal_timestamp, "signal_timestamp")
    split = pd.Timestamp(split_date)
    if split.tzinfo is None:
        split = split.tz_localize("Asia/Kolkata")
    else:
        split = split.tz_convert("Asia/Kolkata")
    return "IS" if signal.normalize() < split.normalize() else "OOS"


def _setup_exclusion(setup: Mapping) -> str | None:
    if setup.get("side") is None:
        return "MISSING_SIDE"
    if str(setup.get("side")).upper() != "BUY":
        return "SELL_NOT_INCLUDED"
    symbol = str(setup.get("underlying", setup.get("symbol", ""))).upper()
    if symbol not in UNDERLYINGS:
        return "UNSUPPORTED_OR_MERGED_UNDERLYING"
    if not setup.get("setup_id"):
        return "MISSING_STABLE_SETUP_ID"
    if not setup.get("historical_contract"):
        return "MISSING_HISTORICAL_CONTRACT_MAPPING"
    if setup.get("contract_mapping_status") != "VERIFIED":
        return "UNVERIFIED_HISTORICAL_CONTRACT_MAPPING"
    if setup.get("expiry_window_status") != "VALID":
        return "UNVERIFIED_EXPIRY_CALENDAR"
    if setup.get("roll_boundary_candidate") is not False:
        return "ROLL_BOUNDARY_OR_UNVERIFIED_ELIGIBILITY"
    if setup.get("executable_price_status") != "VERIFIED":
        return "UNVERIFIED_EXECUTABLE_PRICE_MAPPING"
    if setup.get("price_basis") != "RAW_EXECUTABLE":
        return "ADJUSTED_OR_UNVERIFIED_EXECUTABLE_PRICE_BASIS"
    for key in ("E_regime", "A_regime", "X_regime", "entry_price", "stop_price", "target_price",
                "signal_timestamp", "source_id", "roll_policy_version", "expiry_date", "remaining_trading_days"):
        if setup.get(key) is None:
            return f"MISSING_{key.upper()}"
    try:
        expiry = pd.Timestamp(setup["expiry_date"]).date()
        signal_date = _timestamp(setup["signal_timestamp"], "signal_timestamp").date()
        if signal_date > expiry:
            return "SIGNAL_AFTER_CONTRACT_EXPIRY"
        if int(setup["remaining_trading_days"]) < 3:
            return "ROLL_BOUNDARY_TRADE_EXCLUDED"
    except (TypeError, ValueError):
        return "UNVERIFIED_EXPIRY_CALENDAR"
    return None


def _resolve_buy(setup: Mapping, bars: pd.DataFrame) -> tuple[dict | None, str | None]:
    required = {"timestamp", "open", "high", "low", "close", "contract_symbol", "e1_session_id"}
    if required - set(bars.columns):
        return None, "MISSING_EXECUTABLE_BAR_FIELDS"
    contract = str(setup["historical_contract"])
    if set(bars.contract_symbol.astype(str)) != {contract}:
        return None, "WRONG_OR_CROSS_CONTRACT_EXECUTABLE_BARS"
    if "underlying" in bars and set(bars.underlying.astype(str).str.upper()) != {str(setup["underlying"]).upper()}:
        return None, "UNDERLYING_MISMATCH"
    try:
        times = [_timestamp(x, "bar timestamp") for x in bars.timestamp]
    except (TypeError, ValueError):
        return None, "INVALID_EXECUTABLE_BAR_TIMESTAMPS"
    if any(times[i] <= times[i - 1] for i in range(1, len(times))):
        return None, "DUPLICATE_OR_UNORDERED_EXECUTABLE_BARS"
    if bars.e1_session_id.isna().any():
        return None, "E1_SESSION_IDS_MISMATCH"
    derived_e1 = mcx_e1_session_ids(times)
    if derived_e1 is None:
        return None, "INVALID_E1_TIMESTAMPS"
    supplied = bars.e1_session_id.tolist()
    if any((supplied[i] != supplied[i - 1]) != (derived_e1[i] != derived_e1[i - 1])
           for i in range(1, len(supplied))):
        return None, "E1_SESSION_IDS_MISMATCH"
    signal = _timestamp(setup["signal_timestamp"], "signal_timestamp")
    expiry = pd.Timestamp(setup["expiry_date"]).date()
    if any(ts.date() > expiry for ts in times):
        return None, "EXECUTABLE_BARS_AFTER_CONTRACT_EXPIRY"
    # Signal time is the completed candle's close. FYERS bars are candle-start
    # stamped, so the next bar may start exactly at that timestamp and must be
    # eligible as the first executable bar.
    prior_mask = [x < signal for x in times]
    prior_sessions = bars.loc[prior_mask, "e1_session_id"]
    after = bars.loc[[x >= signal for x in times]].reset_index(drop=True)
    after_times = [x for x in times if x >= signal]
    if after.empty:
        return None, "NO_POST_SIGNAL_EXECUTABLE_BARS"
    try:
        entry, stop, target = (float(setup[k]) for k in ("entry_price", "stop_price", "target_price"))
    except (TypeError, ValueError):
        return None, "INVALID_SETUP_PRICES"
    risk = entry - stop
    if not all(math.isfinite(x) for x in (entry, stop, target)) or risk <= 0:
        return None, "NONPOSITIVE_INITIAL_RISK"
    if not (stop < entry < target):
        return None, "INVALID_BUY_PRICE_ORDER"
    entered_at = None
    entry_idx = None
    mfe_price = 0.0
    previous_session = prior_sessions.iloc[-1] if not prior_sessions.empty else None
    prior_times = [times[i] for i, is_prior in enumerate(prior_mask) if is_prior]
    previous_ts = prior_times[-1] if prior_times else None
    for i, bar in after.iterrows():
        ts = after_times[i]
        try:
            o, hi, lo, close = (float(bar[k]) for k in ("open", "high", "low", "close"))
        except (TypeError, ValueError):
            return None, "INVALID_EXECUTABLE_OHLC"
        if not all(math.isfinite(x) for x in (o, hi, lo, close)):
            return None, "INVALID_EXECUTABLE_OHLC"
        if lo > hi or lo > min(o, close) or hi < max(o, close):
            return None, "INVALID_EXECUTABLE_OHLC"
        session = bar.e1_session_id
        # MCX E1 IDs deliberately remain continuous on daily/weekly/monthly
        # structural frames. Execution bars still need a calendar-session
        # seam, so detect date transitions directly in IST as well.
        boundary = ((previous_session is not None and session != previous_session)
                    or (previous_ts is not None and ts.date() != previous_ts.date()))
        if entered_at is None:
            if lo <= entry <= hi:
                if boundary and o < entry:
                    return None, "E1_GAP_OPEN_ENTRY_AMBIGUOUS"
                entered_at, entry_idx = ts, i
                mfe_price = entry
            else:
                previous_session = session
                previous_ts = ts
                continue
        stop_hit, target_hit = lo <= stop, hi >= target
        if boundary and (o <= stop or o >= target):
            return None, "E1_GAP_EXIT_AMBIGUOUS"
        if target_hit or stop_hit:
            # Offline clean replay resolves an unknowable same-bar sequence
            # conservatively: stop first. The favorable target-first historic
            # convention remains visible in older evidence, but cannot decide
            # the clean export. Do not claim exit-bar MFE on an ambiguous bar.
            outcome = "LOSS" if stop_hit else "WIN"
            exit_price = stop if stop_hit else target
            if target_hit and not stop_hit:
                mfe_price = max(mfe_price, target)
            gross_r = (exit_price - entry) / risk
            return ({"entry_timestamp": entered_at.isoformat(), "exit_timestamp": ts.isoformat(),
                     "exit_price": exit_price, "outcome": outcome, "gross_r": gross_r,
                     "mfe_R": max(0.0, mfe_price - entry) / risk, "bars_held": i - entry_idx + 1,
                     "exit_resolution": "STOP_FIRST_SAME_BAR_AMBIGUOUS" if target_hit and stop_hit else "OHLC_LEVEL"}, None)
        mfe_price = max(mfe_price, hi)
        previous_session = session
        previous_ts = ts
    return None, "UNRESOLVED_END_OF_AVAILABLE_HISTORY"


def build_clean_export(setups: Sequence[Mapping], bars_by_setup: Mapping[str, pd.DataFrame],
                       data_validation: Mapping, split_date: str) -> dict[str, pd.DataFrame]:
    """Build in memory only after all prerequisites and per-trade checks pass."""
    blockers = readiness_issues(data_validation)
    if blockers:
        raise ExportBlocked(blockers)
    if not split_date:
        raise ExportBlocked(["approved explicit IS/OOS split date is missing"])
    rows, provenance, excluded = [], [], []
    seen = set()
    for setup in setups:
        sid = str(setup.get("setup_id", ""))
        if sid in seen:
            excluded.append({"setup_id": sid, "reason": "DUPLICATE_SETUP_ID"})
            continue
        if sid:
            seen.add(sid)
        reason = _setup_exclusion(setup)
        if reason:
            excluded.append({"setup_id": sid, "reason": reason})
            continue
        if sid not in bars_by_setup:
            excluded.append({"setup_id": sid, "reason": "MISSING_EXECUTABLE_PRICE_MAPPING"})
            continue
        trade, reason = _resolve_buy(setup, bars_by_setup[sid])
        if reason:
            excluded.append({"setup_id": sid, "reason": reason})
            continue
        partition = assign_partition(setup["signal_timestamp"], split_date)
        underlying = str(setup["underlying"]).upper()
        row = {"symbol": underlying, "strategy_tf": setup["strategy_tf"],
               "E_regime": setup["E_regime"], "A_regime": setup["A_regime"], "X_regime": setup["X_regime"],
               "entry_price": float(setup["entry_price"]), "stop_price": float(setup["stop_price"]),
               "target_price": float(setup["target_price"]), "exit_price": trade["exit_price"],
               "outcome": trade["outcome"], "gross_r": trade["gross_r"], "mfe_R": trade["mfe_R"],
               "partition": partition, "bars_held": trade["bars_held"]}
        rows.append(row)
        provenance.append({"export_row_index": len(rows) - 1, "setup_id": sid,
                           "signal_timestamp": _timestamp(setup["signal_timestamp"], "signal_timestamp").isoformat(),
                           "entry_timestamp": trade["entry_timestamp"], "exit_timestamp": trade["exit_timestamp"],
                           "historical_contract": setup["historical_contract"], "underlying": underlying,
                           "roll_policy_version": setup["roll_policy_version"], "data_source_id": setup["source_id"],
                           "partition": partition, "expiry_date": setup.get("expiry_date"),
                           "remaining_trading_days": setup.get("remaining_trading_days"),
                           "exit_resolution": trade["exit_resolution"]})
    frame = pd.DataFrame(rows, columns=EXPORT_COLUMNS)
    _validate_export(frame, provenance)
    if len(rows) + len(excluded) != len(setups):
        raise ValueError("detected setup population does not reconcile to exported plus excluded records")
    return {"trades": frame, "provenance": pd.DataFrame(provenance), "excluded": pd.DataFrame(excluded)}


def _validate_export(frame: pd.DataFrame, provenance: Sequence[Mapping]) -> None:
    if list(frame.columns) != EXPORT_COLUMNS:
        raise ValueError("export schema or column order mismatch")
    if len(frame) != len(provenance):
        raise ValueError("export/provenance reconciliation failure")
    if frame.empty:
        return
    ids = [str(x.get("setup_id", "")) for x in provenance]
    if not all(ids) or len(ids) != len(set(ids)):
        raise ValueError("missing or duplicate trade provenance identifiers")
    if [int(x.get("export_row_index", -1)) for x in provenance] != list(range(len(frame))):
        raise ValueError("trade provenance row-order join keys are missing or inconsistent")
    for row in frame.to_dict("records"):
        risk = float(row["entry_price"]) - float(row["stop_price"])
        if risk <= 0 or abs(float(row["gross_r"]) - (float(row["exit_price"]) - float(row["entry_price"])) / risk) > 1e-10:
            raise ValueError("invalid initial risk or realized gross_r")
        if row["outcome"] not in {"WIN", "LOSS"} or row["partition"] not in {"IS", "OOS"}:
            raise ValueError("invalid outcome or partition")
        if float(row["mfe_R"]) < 0:
            raise ValueError("MFE_R cannot be negative for BUY trades")
        if int(row["bars_held"]) < 1:
            raise ValueError("invalid bars_held")
        if row["symbol"] not in UNDERLYINGS:
            raise ValueError("invalid/merged underlying")


def write_versioned_export(bundle: Mapping, setups, bars_by_setup, *, split_date: str,
                           output_root: Path, run_id: str, git_revision: str,
                           data_validation: Mapping) -> Path:
    """Write only after validation; refuse to overwrite any prior run folder."""
    result = build_clean_export(setups, bars_by_setup, data_validation, split_date)
    if not run_id or not git_revision:
        raise ExportBlocked(["run_id and git_revision are required provenance"])
    target = Path(output_root) / run_id
    if target.exists():
        raise FileExistsError(f"refusing to overwrite existing export run: {target}")
    target.mkdir(parents=True)
    result["trades"].to_csv(target / "clean_mcx_trade_export.csv", index=False)
    result["provenance"].to_csv(target / "trade_provenance.csv", index=False)
    result["excluded"].to_csv(target / "excluded_setups.csv", index=False)
    (target / "data_validation.json").write_text(json.dumps(data_validation, indent=2, sort_keys=True) + "\n")
    manifest = {**dict(bundle), "run_id": run_id, "git_revision": git_revision,
                "split_date": split_date, "export_schema_version": 1,
                "source_class": "AUTHORITATIVE_CLEAN", "synthetic_or_test_only": False,
                "export_rows": len(result["trades"]), "excluded_setups": len(result["excluded"]),
                "output_sha256": hashlib.sha256((target / "clean_mcx_trade_export.csv").read_bytes()).hexdigest()}
    (target / "run_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True, default=str) + "\n")
    (target / "export_validation.json").write_text(json.dumps({"status": "VALID", "rows": len(result["trades"]),
        "schema_columns": EXPORT_COLUMNS, "reconciled": len(result["trades"]) + len(result["excluded"]) == len(setups)}, indent=2) + "\n")
    return target


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-json", required=True, type=Path,
                        help="Task-2 validation, setups and raw dated-contract bars bundle")
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--git-revision", required=True)
    parser.add_argument("--split-date", required=True)
    args = parser.parse_args(argv)
    try:
        payload = json.loads(args.input_json.read_text())
        bars = {key: pd.DataFrame(value) for key, value in payload["bars_by_setup"].items()}
        output = write_versioned_export(payload.get("run_manifest", {}), payload["setups"], bars,
            split_date=args.split_date, output_root=args.output_root, run_id=args.run_id,
            git_revision=args.git_revision, data_validation=payload["data_validation"])
    except (ExportBlocked, KeyError, ValueError, OSError) as exc:
        print(f"BLOCKED_MISSING_DATA: {exc}")
        return 2
    print(f"CLEAN_EXPORT_GENERATED_AND_VALIDATED: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
