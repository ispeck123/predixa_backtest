"""Offline adapter from contract-aware MCX research candles to PREDIXA setups.

The adapter calls the existing ``SDEnginePipeline`` and never invokes its
formatter, gate-to-order adapter, scanner, or broker. Inputs are per-timeframe
research bars already produced by the Task-2 builder; executable bars remain
separate and are passed to ``clean_realized_r_export``.
"""
from __future__ import annotations

from contextlib import redirect_stdout, redirect_stderr
from dataclasses import asdict, is_dataclass
from datetime import timedelta
import hashlib
import io
from pathlib import Path
import tempfile
from typing import Callable, Mapping

import pandas as pd

from scripts.mcx_session import mcx_e1_session_ids


class ReplayInputError(ValueError):
    pass


def _frame_for_engine(frame: pd.DataFrame, name: str) -> pd.DataFrame:
    required = {"timestamp", "research_open", "research_high", "research_low", "research_close"}
    missing = required - set(frame.columns)
    if missing:
        raise ReplayInputError(f"{name} research frame missing fields: {sorted(missing)}")
    result = frame.copy()
    result["timestamp"] = pd.to_datetime(result.timestamp, errors="coerce")
    if result.timestamp.isna().any():
        raise ReplayInputError(f"{name} has invalid timestamps")
    if result.timestamp.dt.tz is None:
        raise ReplayInputError(f"{name} timestamps must be timezone-aware")
    result["timestamp"] = result.timestamp.dt.tz_convert("Asia/Kolkata")
    result = result.sort_values("timestamp", kind="stable").reset_index(drop=True)
    if result.timestamp.duplicated().any():
        raise ReplayInputError(f"{name} contains duplicate timestamps")
    result["open"] = pd.to_numeric(result.research_open, errors="coerce")
    result["high"] = pd.to_numeric(result.research_high, errors="coerce")
    result["low"] = pd.to_numeric(result.research_low, errors="coerce")
    result["close"] = pd.to_numeric(result.research_close, errors="coerce")
    result["qty"] = pd.to_numeric(result.get("volume", 0), errors="coerce").fillna(0)
    if result[["open", "high", "low", "close"]].isna().any().any():
        raise ReplayInputError(f"{name} has missing research OHLC")
    if ((result.high < result[["open", "low", "close"]].max(axis=1)) |
            (result.low > result[["open", "high", "close"]].min(axis=1))).any():
        raise ReplayInputError(f"{name} has invalid research OHLC envelopes")
    # Existing ``load_preprocess_data`` parses with dayfirst=True; use its
    # established DD/MM/YYYY wire format and retain the IST numeric offset.
    # ISO year-first strings can be misparsed or rejected by that loader.
    result["tradeDate"] = result.timestamp.map(lambda x: x.strftime("%d/%m/%Y %H:%M:%S%z"))
    return result[["open", "high", "low", "close", "qty", "tradeDate"]]


def _enum_value(value):
    return value.value if hasattr(value, "value") else value


def _payload(value):
    if value is None:
        return None
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Mapping):
        return dict(value)
    return dict(vars(value))


def _clock_after_bar(timestamp: pd.Timestamp, frame_name: str) -> pd.Timestamp:
    # The existing loader drops the currently forming period. Advance its
    # clock by that frame's duration so this just-completed bar is available.
    if frame_name == "daily":
        return timestamp + pd.Timedelta(days=1)
    if frame_name == "weekly":
        return timestamp + pd.Timedelta(days=7)
    if frame_name == "monthly":
        return timestamp + pd.offsets.MonthBegin(1)
    minutes = {"sixty": 60, "one_twenty": 120, "two_forty": 240,
               "seventy_five": 75, "fifteen": 15}
    if frame_name not in minutes:
        raise ReplayInputError(f"unsupported PREDIXA timeframe name: {frame_name}")
    return timestamp + pd.Timedelta(minutes=minutes[frame_name])


def replay_existing_strategy(
    underlying: str,
    frames_by_name: Mapping[str, pd.DataFrame] | Callable[[pd.Timestamp], Mapping[str, pd.DataFrame]],
    *,
    strategy_tf: int,
    contract_selector: Callable[[pd.Timestamp], Mapping],
    calendar_classifier: Callable[[pd.Timestamp, Mapping], Mapping],
    source_id: str,
    roll_policy_version: str,
    exp_num: str = "CLEAN_RESEARCH",
    engine_factory=None,
    snapshot_limit: int | None = None,
    snapshot_timestamps=None,
) -> list[dict]:
    """Replay the repository strategy on each completed execute-TF bar.

    ``contract_selector`` and ``calendar_classifier`` must return verified
    Task-2 mappings. This function only emits BUY candidates; the global MCX
    gate, all scanners and order paths remain untouched and are never called.
    """
    from shared.config.settings import stock_data_dir_config, stock_logic_config
    if underlying not in {"GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"}:
        raise ReplayInputError("unsupported MCX underlying")
    stack = getattr(stock_logic_config, f"COMMODITY_TIME_FRAME_{int(strategy_tf)}", None)
    if not stack:
        raise ReplayInputError(f"strategy timeframe {strategy_tf} is not configured")
    execute_name = stack[-1]
    names = set((stack[0], stack[1], stack[-1]))
    if callable(frames_by_name):
        if snapshot_timestamps is None:
            raise ReplayInputError("point-in-time frame loader requires explicit snapshot timestamps")
        execute_times = [pd.Timestamp(x) for x in snapshot_timestamps]
    else:
        if any(name not in frames_by_name for name in names):
            raise ReplayInputError(f"strategy timeframe {strategy_tf} lacks configured E/A/X research frames")
        static_execute = _frame_for_engine(frames_by_name[execute_name], execute_name)
        execute_times = pd.to_datetime(static_execute.tradeDate).tolist()
        if len(execute_times) > 1:
            raise ReplayInputError("multiple historical snapshots require a point-in-time Task-2 frame loader")
    if snapshot_limit is not None:
        execute_times = execute_times[-max(1, int(snapshot_limit)):]

    if engine_factory is None:
        from scripts.setup_engine_new import SDEnginePipeline
        engine_factory = SDEnginePipeline
    prior_root = stock_data_dir_config.indian_commodity_data
    setups: dict[str, dict] = {}
    with tempfile.TemporaryDirectory(prefix="predixa_mcx_replay_") as tmp:
        root = Path(tmp)
        latest = root / "latest_data_csv"
        latest.mkdir()
        stock_data_dir_config.indian_commodity_data = str(root)
        try:
            # Avoid noisy loader prints in a long offline replay; no trading
            # event or network method is invoked by this strategy engine.
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                for timestamp in execute_times:
                    timestamp = pd.Timestamp(timestamp)
                    if timestamp.tzinfo is None:
                        raise ReplayInputError("replay timestamps must include a timezone")
                    timestamp = timestamp.tz_convert("Asia/Kolkata")
                    clock = _clock_after_bar(timestamp, execute_name)
                    current_frames = frames_by_name(clock) if callable(frames_by_name) else frames_by_name
                    if any(name not in current_frames for name in names):
                        raise ReplayInputError("point-in-time snapshot lacks a configured E/A/X frame")
                    normalized = {name: _frame_for_engine(current_frames[name], name) for name in names}
                    for name in names:
                        source = current_frames[name]
                        if "is_point_in_time_snapshot" not in source or not source.is_point_in_time_snapshot.astype(bool).all():
                            raise ReplayInputError("adjusted research history is not a point-in-time Task-2 snapshot")
                        if "snapshot_as_of" not in source:
                            raise ReplayInputError("point-in-time snapshot timestamp is missing")
                        as_of = pd.to_datetime(source.snapshot_as_of, errors="coerce", utc=True).dropna().unique()
                        expected = clock.tz_convert("UTC")
                        if len(as_of) != 1 or pd.Timestamp(as_of[0]).tz_convert("UTC") != expected:
                            raise ReplayInputError("Task-2 snapshot_as_of does not match the strategy decision clock")
                        normalized[name].to_csv(latest / f"{underlying}_{exp_num}_{name}.csv", index=False)
                    result = engine_factory().run(
                        symbol=underlying,
                        time_list=stack,
                        last_d_time=clock,
                        segment="MCX",
                        exp_num=exp_num,
                        is_future=False,
                    )
                    candidate = _payload(result.get("best_setup_long")) if isinstance(result, Mapping) else None
                    if not candidate:
                        continue
                    signal_epoch = result.get("entry_ts")
                    signal_bar_start = pd.Timestamp(signal_epoch, unit="s", tz="UTC").tz_convert("Asia/Kolkata")
                    signal_ts = _clock_after_bar(signal_bar_start, execute_name)
                    contract = dict(contract_selector(signal_ts))
                    expiry_result = dict(calendar_classifier(signal_ts, contract))
                    factor = float(contract.get("adjustment_factor", 1.0))
                    offset = float(contract.get("adjustment_offset", 0.0))
                    if factor <= 0:
                        raise ReplayInputError("invalid adjustment factor for strategy level mapping")
                    # Engine prices are analytical adjusted-series levels.
                    # Map levels back into the selected dated contract basis.
                    raw_price = lambda x: (float(x) - offset) / factor
                    regime = result.get("trend_context")
                    zone_id = str(candidate.get("zone_id", ""))
                    stable = hashlib.sha256(
                        f"{underlying}|{strategy_tf}|{signal_ts.isoformat()}|{zone_id}".encode()
                    ).hexdigest()[:24]
                    if stable in setups:
                        continue
                    setups[stable] = {
                        "setup_id": stable, "side": "BUY", "underlying": underlying,
                        "symbol": underlying, "strategy_tf": int(strategy_tf),
                        "E_regime": _enum_value(getattr(regime, "regime_E", None)),
                        "A_regime": _enum_value(getattr(regime, "regime_A", None)),
                        "X_regime": _enum_value(getattr(regime, "regime_X", None)),
                        "entry_price": raw_price(candidate["entry_price"]),
                        "stop_price": raw_price(candidate["stop_price"]),
                        "target_price": raw_price(candidate["target_price"]),
                        "signal_timestamp": signal_ts.isoformat(),
                        "historical_contract": contract.get("contract_symbol"),
                        "contract_mapping_status": contract.get("attribution_status"),
                        "expiry_date": contract.get("expiry_date"),
                        "remaining_trading_days": expiry_result.get("remaining_trading_days"),
                        "expiry_window_status": expiry_result.get("status"),
                        "roll_boundary_candidate": expiry_result.get("roll_boundary_candidate"),
                        "executable_price_status": contract.get("executable_price_status"),
                        "price_basis": "RAW_EXECUTABLE",
                        "source_id": source_id,
                        "roll_policy_version": roll_policy_version,
                    }
        finally:
            stock_data_dir_config.indian_commodity_data = prior_root
    return list(setups.values())
