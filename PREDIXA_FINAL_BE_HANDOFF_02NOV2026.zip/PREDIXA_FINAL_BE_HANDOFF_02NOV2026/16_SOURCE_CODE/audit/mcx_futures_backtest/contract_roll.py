"""Contract-aware MCX research series construction.

This module is deliberately offline. It never fetches data, chooses a roll
date, or treats a broker's current instrument master as historical truth.
Callers must provide point-in-time contract coverage and an explicit roll
schedule. Back-adjusted values are research prices; raw executable prices are
retained in separate columns.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date, datetime
from math import isclose
from typing import Mapping, Sequence

import pandas as pd

from scripts.mcx_session import mcx_e1_session_ids


UNDERLYINGS = frozenset({"GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"})
OHLCV = ("open", "high", "low", "close", "volume")


class ContractDataError(ValueError):
    """Raised when contract identity or price inputs cannot be trusted."""

    def __init__(self, message: str):
        super().__init__(message)
        self.validation_summary = {
            "status": "REJECTED",
            "issues": [{"status": "REJECTED", "reason": message}],
        }


@dataclass(frozen=True)
class DatedContract:
    underlying: str
    contract_symbol: str
    provider_instrument_id: str
    exchange: str
    expiry_date: date
    active_from: pd.Timestamp
    active_to: pd.Timestamp | None
    source_id: str
    attribution_status: str = "VERIFIED"
    listed_from: pd.Timestamp | None = None

    def __post_init__(self):
        object.__setattr__(self, "underlying", self.underlying.upper())
        if isinstance(self.expiry_date, datetime):
            object.__setattr__(self, "expiry_date", self.expiry_date.date())
        elif not isinstance(self.expiry_date, date):
            try:
                object.__setattr__(self, "expiry_date", date.fromisoformat(str(self.expiry_date)))
            except ValueError as exc:
                raise ContractDataError("contract expiry must be an explicit ISO date") from exc
        if self.underlying not in UNDERLYINGS:
            raise ContractDataError(f"unsupported or merged MCX underlying: {self.underlying}")
        if not all((self.contract_symbol, self.provider_instrument_id, self.source_id)):
            raise ContractDataError("contract symbol, provider identifier and provenance are required")
        if self.exchange.upper() != "MCX":
            raise ContractDataError("MCX contract record has a non-MCX exchange")
        if self.attribution_status != "VERIFIED":
            raise ContractDataError("historical contract attribution is not VERIFIED")
        start = _ist_timestamp(self.active_from, "active_from")
        end = _ist_timestamp(self.active_to, "active_to") if self.active_to is not None else None
        listed = _ist_timestamp(self.listed_from, "listed_from") if self.listed_from is not None else None
        if end is not None and end <= start:
            raise ContractDataError("contract active interval must have positive duration")
        if start.date() > self.expiry_date:
            raise ContractDataError("contract selection starts after its stated expiry")
        if listed is not None and listed > start:
            raise ContractDataError("contract selection starts before the verified listing time")
        object.__setattr__(self, "active_from", start)
        object.__setattr__(self, "active_to", end)
        object.__setattr__(self, "listed_from", listed)


@dataclass(frozen=True)
class RollTransition:
    underlying: str
    outgoing_symbol: str
    incoming_symbol: str
    decision_at: pd.Timestamp
    effective_at: pd.Timestamp
    outgoing_price: float
    incoming_price: float
    source_id: str
    verified: bool

    def __post_init__(self):
        object.__setattr__(self, "underlying", self.underlying.upper())
        object.__setattr__(self, "decision_at", _ist_timestamp(self.decision_at, "decision_at"))
        object.__setattr__(self, "effective_at", _ist_timestamp(self.effective_at, "effective_at"))
        if self.decision_at > self.effective_at:
            raise ContractDataError("roll decision uses information after its effective time")
        if not self.verified or not self.source_id:
            raise ContractDataError("roll transition requires verified price provenance")
        if not (pd.notna(self.outgoing_price) and pd.notna(self.incoming_price)):
            raise ContractDataError("observed outgoing and incoming roll prices are required")
        if self.outgoing_price <= 0 or self.incoming_price <= 0:
            raise ContractDataError("roll prices must be positive")


@dataclass(frozen=True)
class RollPolicy:
    policy_id: str
    adjustment_method: str
    approval_status: str

    def __post_init__(self):
        if not self.policy_id:
            raise ContractDataError("an explicit roll policy identifier is required")
        if self.adjustment_method not in {"additive", "ratio"}:
            raise ContractDataError("adjustment method must be explicitly additive or ratio")
        if self.approval_status not in {"APPROVED", "PENDING_APPROVAL"}:
            raise ContractDataError("invalid roll-policy approval status")


@dataclass(frozen=True)
class TradingCalendar:
    """Explicit exchange sessions, including the dates covered by the source."""
    session_dates: frozenset[date]
    coverage_start: date
    coverage_end: date
    source_id: str
    verified: bool

    def __post_init__(self):
        if self.coverage_end < self.coverage_start:
            raise ContractDataError("calendar coverage end precedes its start")
        if not self.source_id or not self.verified:
            raise ContractDataError("trading calendar requires verified provenance")
        if any(d < self.coverage_start or d > self.coverage_end for d in self.session_dates):
            raise ContractDataError("calendar contains a session outside declared coverage")


@dataclass
class BuildResult:
    series: pd.DataFrame
    roll_metadata: list[dict]
    contract_mapping: list[dict]
    validation_summary: dict
    snapshot_as_of: str | None


def _ist_timestamp(value, field: str) -> pd.Timestamp:
    try:
        ts = pd.Timestamp(value)
    except Exception as exc:
        raise ContractDataError(f"invalid {field} timestamp") from exc
    if pd.isna(ts):
        raise ContractDataError(f"invalid {field} timestamp")
    if ts.tzinfo is None:
        ts = ts.tz_localize("Asia/Kolkata")
    else:
        ts = ts.tz_convert("Asia/Kolkata")
    return ts


def _validate_ohlcv(frame: pd.DataFrame, key: tuple[str, str], naive_timezone: str | None) -> pd.DataFrame:
    required = {"timestamp", *OHLCV}
    missing = required - set(frame.columns)
    if missing:
        raise ContractDataError(f"{key}: missing fields {sorted(missing)}")
    out = frame.copy()
    try:
        parsed = pd.to_datetime(out.timestamp, errors="coerce")
        if parsed.isna().any():
            raise ContractDataError(f"{key}: invalid timestamps")
        if parsed.dt.tz is None:
            if not naive_timezone:
                raise ContractDataError(f"{key}: naive timestamps require a declared source timezone")
            parsed = parsed.dt.tz_localize(naive_timezone).dt.tz_convert("Asia/Kolkata")
        else:
            parsed = parsed.dt.tz_convert("Asia/Kolkata")
        out["timestamp"] = parsed
    except (AttributeError, TypeError, ValueError) as exc:
        if isinstance(exc, ContractDataError):
            raise
        raise ContractDataError(f"{key}: timestamps are not consistently timezone-aware") from exc
    if out.timestamp.duplicated().any():
        raise ContractDataError(f"{key}: duplicate timestamps")
    if not out.timestamp.is_monotonic_increasing:
        raise ContractDataError(f"{key}: timestamps are unsorted")
    prices = out[list(OHLCV)].apply(pd.to_numeric, errors="coerce")
    if prices[list(OHLCV[:4])].isna().any().any() or prices.volume.isna().any():
        raise ContractDataError(f"{key}: non-numeric or missing OHLCV")
    if (prices.volume < 0).any():
        raise ContractDataError(f"{key}: negative volume")
    if ((prices.high < prices[["open", "close", "low"]].max(axis=1)) |
        (prices.low > prices[["open", "close", "high"]].min(axis=1))).any():
        raise ContractDataError(f"{key}: invalid OHLC envelope")
    out[list(OHLCV)] = prices
    return out


def select_historical_contract(contracts: Sequence[DatedContract], underlying: str,
                              timestamp) -> DatedContract:
    """Select only from explicit historical intervals, never a live contract list."""
    ts = _ist_timestamp(timestamp, "selection")
    symbol = underlying.upper()
    matches = [c for c in contracts if c.underlying == symbol
               and c.active_from <= ts and (c.active_to is None or ts < c.active_to)
               and ts.date() <= c.expiry_date
               and (c.listed_from is None or c.listed_from <= ts)]
    if not matches:
        raise ContractDataError(f"UNRESOLVED: no verified {symbol} contract at {ts.isoformat()}")
    if len(matches) != 1:
        raise ContractDataError(f"REJECTED: overlapping {symbol} active contracts at {ts.isoformat()}")
    return matches[0]


def classify_expiry_window(timestamp, contract: DatedContract,
                           calendar: TradingCalendar | None, threshold: int = 3) -> dict:
    """Count exchange sessions strictly after the signal date through expiry."""
    ts = _ist_timestamp(timestamp, "signal")
    if threshold < 1:
        raise ContractDataError("expiry threshold must be positive")
    if calendar is None or not calendar.verified:
        return {"status": "UNVERIFIED", "remaining_trading_days": None,
                "roll_boundary_candidate": None, "reason": "verified trading calendar unavailable"}
    if (ts.date() < calendar.coverage_start or ts.date() > calendar.coverage_end
            or contract.expiry_date < calendar.coverage_start
            or contract.expiry_date > calendar.coverage_end):
        return {"status": "UNVERIFIED", "remaining_trading_days": None,
                "roll_boundary_candidate": None, "reason": "signal or expiry outside calendar coverage"}
    if ts.date() > contract.expiry_date:
        return {"status": "REJECTED", "remaining_trading_days": None,
                "roll_boundary_candidate": None, "reason": "signal occurs after contract expiry"}
    if ts.date() not in calendar.session_dates:
        return {"status": "UNVERIFIED", "remaining_trading_days": None,
                "roll_boundary_candidate": None, "reason": "signal date is not a verified session"}
    if contract.expiry_date not in calendar.session_dates:
        return {"status": "UNVERIFIED", "remaining_trading_days": None,
                "roll_boundary_candidate": None, "reason": "expiry is not a verified session"}
    remaining = sum(ts.date() < d <= contract.expiry_date for d in calendar.session_dates)
    return {"status": "VALID", "remaining_trading_days": remaining,
            "roll_boundary_candidate": remaining < threshold,
            "reason": f"fewer than {threshold} verified trading days remain" if remaining < threshold else None}


def _interval_check(contracts: Sequence[DatedContract]) -> None:
    by_underlying: dict[str, list[DatedContract]] = {}
    for contract in contracts:
        by_underlying.setdefault(contract.underlying, []).append(contract)
    for underlying, items in by_underlying.items():
        ordered = sorted(items, key=lambda x: x.active_from)
        seen_symbols = set()
        for item in ordered:
            if item.contract_symbol in seen_symbols:
                raise ContractDataError(f"duplicate contract record: {underlying} {item.contract_symbol}")
            seen_symbols.add(item.contract_symbol)
        for left, right in zip(ordered, ordered[1:]):
            if left.active_to is None or left.active_to > right.active_from:
                raise ContractDataError(f"overlapping active contract intervals for {underlying}")


def build_back_adjusted_series(
    contracts: Sequence[DatedContract],
    contract_bars: Mapping[tuple[str, str], pd.DataFrame],
    rolls: Sequence[RollTransition],
    policy: RollPolicy,
    *,
    as_of=None,
    naive_timezone: str | None = None,
    expected_interval=None,
) -> BuildResult:
    """Build explicit-schedule continuous research bars with raw-price mapping.

    ``as_of`` creates a causal snapshot: bars and roll decisions after that
    timestamp are excluded before factors are calculated. A no-``as_of``
    back-adjusted history is retrospective and is not suitable for replaying
    historical decisions without snapshotting each decision time.
    """
    if not contracts:
        raise ContractDataError("no dated-contract metadata supplied")
    _interval_check(contracts)
    contract_by_key = {(c.underlying, c.contract_symbol): c for c in contracts}
    if len(contract_by_key) != len(contracts):
        raise ContractDataError("duplicate underlying/contract identifiers")
    snapshot = _ist_timestamp(as_of, "as_of") if as_of is not None else None
    relevant_rolls = [r for r in rolls if snapshot is None or r.effective_at <= snapshot]
    normalized_frames: dict[tuple[str, str], pd.DataFrame] = {}
    for key, frame in contract_bars.items():
        canonical = (key[0].upper(), key[1])
        if canonical not in contract_by_key:
            raise ContractDataError(f"bars have no verified contract mapping: {canonical}")
        checked = _validate_ohlcv(frame, canonical, naive_timezone)
        expiry = contract_by_key[canonical].expiry_date
        if checked.timestamp.dt.date.gt(expiry).any():
            raise ContractDataError(f"{canonical}: OHLCV extends beyond stated contract expiry")
        normalized_frames[canonical] = checked
    if not normalized_frames:
        raise ContractDataError("no dated-contract OHLCV supplied")

    for roll in relevant_rolls:
        out_key = (roll.underlying, roll.outgoing_symbol)
        in_key = (roll.underlying, roll.incoming_symbol)
        if out_key not in contract_by_key or in_key not in contract_by_key:
            raise ContractDataError("roll references a missing dated contract")
        outgoing, incoming = contract_by_key[out_key], contract_by_key[in_key]
        if outgoing.active_to != roll.effective_at or incoming.active_from != roll.effective_at:
            raise ContractDataError("roll effective time must match outgoing/incoming selection intervals")
        if roll.effective_at > pd.Timestamp(outgoing.expiry_date, tz="Asia/Kolkata") + pd.Timedelta(days=1):
            raise ContractDataError("roll occurs after outgoing contract expiry")

    # Prove that the stated roll prices are present in the dated OHLC sources:
    # outgoing close is the last observed bar before the interval switch and
    # incoming open is the first observed bar at/after that switch.
    for roll in relevant_rolls:
        outgoing_frame = normalized_frames.get((roll.underlying, roll.outgoing_symbol))
        incoming_frame = normalized_frames.get((roll.underlying, roll.incoming_symbol))
        if outgoing_frame is None or incoming_frame is None:
            raise ContractDataError("roll transition is missing one contract's executable-price bars")
        outgoing_rows = outgoing_frame[outgoing_frame.timestamp < roll.effective_at]
        incoming_rows = incoming_frame[incoming_frame.timestamp >= roll.effective_at]
        if outgoing_rows.empty or incoming_rows.empty:
            raise ContractDataError("roll transition has no observed outgoing close or incoming open")
        observed_out = float(outgoing_rows.iloc[-1].close)
        observed_in = float(incoming_rows.iloc[0].open)
        if not isclose(observed_out, float(roll.outgoing_price), rel_tol=0, abs_tol=1e-8):
            raise ContractDataError("outgoing roll price does not match the dated-contract close")
        if not isclose(observed_in, float(roll.incoming_price), rel_tol=0, abs_tol=1e-8):
            raise ContractDataError("incoming roll price does not match the dated-contract open")

    outputs: list[pd.DataFrame] = []
    roll_metadata: list[dict] = []
    mapping: list[dict] = []
    issues: list[dict] = []
    for underlying in sorted({c.underlying for c in contracts}):
        selected_contracts = sorted((c for c in contracts if c.underlying == underlying
                                     and (snapshot is None or c.active_from <= snapshot)),
                                    key=lambda c: c.active_from)
        for contract in selected_contracts:
            if contract.listed_from is None:
                issues.append({"status": "UNVERIFIED", "code": "LISTING_DATE_MISSING",
                               "underlying": underlying, "contract": contract.contract_symbol})
        ur = sorted((r for r in relevant_rolls if r.underlying == underlying),
                    key=lambda r: r.effective_at)
        roll_keys = {(r.outgoing_symbol, r.incoming_symbol, r.effective_at) for r in ur}
        for left, right in zip(selected_contracts, selected_contracts[1:]):
            if left.active_to == right.active_from and (
                left.contract_symbol, right.contract_symbol, right.active_from
            ) not in roll_keys:
                issues.append({"status": "UNVERIFIED", "code": "ROLL_EVENT_MISSING",
                               "underlying": underlying, "outgoing": left.contract_symbol,
                               "incoming": right.contract_symbol})
        for left, right in zip(selected_contracts, selected_contracts[1:]):
            if left.active_to is not None and left.active_to < right.active_from:
                issues.append({"status": "UNVERIFIED", "code": "CONTRACT_SELECTION_GAP",
                               "underlying": underlying, "from": left.active_to.isoformat(),
                               "to": right.active_from.isoformat()})
        # Each bar is kept only in the explicitly effective contract interval.
        selected_parts = []
        for contract in selected_contracts:
            key = (underlying, contract.contract_symbol)
            frame = normalized_frames.get(key)
            if frame is None:
                issues.append({"status": "UNVERIFIED", "code": "MISSING_CONTRACT_BARS", "contract": contract.contract_symbol})
                continue
            if snapshot is not None:
                frame = frame[frame.timestamp <= snapshot].copy()
            start = contract.active_from
            end = contract.active_to
            active = frame[frame.timestamp >= start]
            if end is not None:
                active = active[active.timestamp < end]
            if contract.listed_from is not None and (active.timestamp < contract.listed_from).any():
                raise ContractDataError("selected contract contains bars before verified listing")
            if active.empty:
                continue
            active = active.copy()
            active["underlying"] = underlying
            active["contract_symbol"] = contract.contract_symbol
            active["provider_instrument_id"] = contract.provider_instrument_id
            active["contract_expiry"] = contract.expiry_date.isoformat()
            active["source_id"] = contract.source_id
            selected_parts.append(active)
            mapping.append({"underlying": underlying, "contract_symbol": contract.contract_symbol,
                            "provider_instrument_id": contract.provider_instrument_id,
                            "expiry_date": contract.expiry_date.isoformat(),
                            "active_from": contract.active_from.isoformat(),
                            "active_to": contract.active_to.isoformat() if contract.active_to else None,
                            "listed_from": contract.listed_from.isoformat() if contract.listed_from else None,
                            "listing_date_status": "VERIFIED" if contract.listed_from else "UNVERIFIED",
                            "source_id": contract.source_id, "attribution_status": contract.attribution_status})
        if not selected_parts:
            issues.append({"status": "UNVERIFIED", "code": "NO_SELECTED_BARS", "underlying": underlying})
            continue
        selected = pd.concat(selected_parts, ignore_index=True).sort_values("timestamp", kind="stable")
        if selected.timestamp.duplicated().any():
            raise ContractDataError(f"overlapping selected contract bars for {underlying}")
        # A series may contain time gaps; they are never interpolated.
        selected["e1_session_id"] = mcx_e1_session_ids(selected.timestamp.tolist())
        selected["roll_transition_before"] = selected.timestamp.isin([r.effective_at for r in ur])
        interval = pd.Timedelta(expected_interval) if expected_interval is not None else None
        if interval is None:
            issues.append({"status": "WARNING", "code": "EXPECTED_BAR_INTERVAL_NOT_DECLARED",
                           "underlying": underlying})
        else:
            within = selected.e1_session_id.eq(selected.e1_session_id.shift())
            elapsed = selected.timestamp.diff()
            missing_bar_gaps = within & elapsed.gt(interval)
            if missing_bar_gaps.any():
                issues.append({"status": "WARNING", "code": "INTRASESSION_BAR_GAPS",
                               "underlying": underlying,
                               "count": int(missing_bar_gaps.sum()),
                               "interpretation": "unfilled; may reflect source gaps or no-trade intervals"})

        offsets = {c.contract_symbol: 0.0 for c in selected_contracts}
        factors = {c.contract_symbol: 1.0 for c in selected_contracts}
        known_at: dict[str, pd.Timestamp | None] = {c.contract_symbol: None for c in selected_contracts}
        # The later contract is the reference. Walk backward to adjust older
        # contracts; only explicitly observed roll prices enter the factors.
        for roll in reversed(ur):
            old, new = roll.outgoing_symbol, roll.incoming_symbol
            if policy.adjustment_method == "additive":
                offsets[old] = offsets[new] + roll.incoming_price - roll.outgoing_price
                factors[old] = factors[new]
            else:
                if roll.outgoing_price == 0:
                    raise ContractDataError("ratio adjustment cannot use a zero outgoing price")
                factors[old] = factors[new] * roll.incoming_price / roll.outgoing_price
                offsets[old] = 0.0
            known_at[old] = roll.effective_at
            later = [x for x in ur if x.effective_at > roll.effective_at]
            if later:
                known_at[old] = max(x.effective_at for x in later)
            roll_metadata.append({**asdict(roll), "decision_at": roll.decision_at.isoformat(),
                                  "effective_at": roll.effective_at.isoformat(),
                                  "policy_id": policy.policy_id,
                                  "adjustment_method": policy.adjustment_method,
                                  "outgoing_adjustment": offsets[old],
                                  "outgoing_factor": factors[old],
                                  "approval_status": policy.approval_status})
        selected["raw_open"] = selected.open
        selected["raw_high"] = selected.high
        selected["raw_low"] = selected.low
        selected["raw_close"] = selected.close
        selected["adjustment_factor"] = selected.contract_symbol.map(factors).astype(float)
        selected["adjustment_offset"] = selected.contract_symbol.map(offsets).astype(float)
        for field in ("open", "high", "low", "close"):
            selected[f"research_{field}"] = selected[f"raw_{field}"] * selected.adjustment_factor + selected.adjustment_offset
        selected["adjustment_known_at"] = selected.contract_symbol.map(
            {key: value.isoformat() if value is not None else None for key, value in known_at.items()})
        selected["is_point_in_time_snapshot"] = snapshot is not None
        selected["snapshot_as_of"] = snapshot.isoformat() if snapshot is not None else None
        outputs.append(selected)

    series = (pd.concat(outputs, ignore_index=True).sort_values(["underlying", "timestamp"], kind="stable")
              if outputs else pd.DataFrame())
    if not series.empty:
        if series.duplicated(["underlying", "timestamp"]).any():
            raise ContractDataError("duplicate underlying/timestamp after series construction")
        # Adjustment arithmetic must preserve valid OHLC envelopes.
        for prefix in ("research",):
            if ((series[f"{prefix}_high"] < series[[f"{prefix}_open", f"{prefix}_close", f"{prefix}_low"]].max(axis=1)) |
                (series[f"{prefix}_low"] > series[[f"{prefix}_open", f"{prefix}_close", f"{prefix}_high"]].min(axis=1))).any():
                raise ContractDataError("adjusted OHLC envelope invalid")
    if policy.approval_status != "APPROVED":
        issues.append({"status": "UNVERIFIED", "code": "ROLL_POLICY_PENDING_APPROVAL", "policy_id": policy.policy_id})
    if not relevant_rolls:
        issues.append({"status": "UNVERIFIED", "code": "NO_VERIFIED_ROLL_TRANSITIONS"})
    status = ("REJECTED" if any(i["status"] == "REJECTED" for i in issues) else
              "UNVERIFIED" if any(i["status"] == "UNVERIFIED" for i in issues) else
              "WARNING" if issues else "VALID")
    return BuildResult(series=series.reset_index(drop=True), roll_metadata=roll_metadata,
                       contract_mapping=mapping,
                       validation_summary={"status": status, "issues": issues,
                                           "policy_id": policy.policy_id,
                                           "adjustment_method": policy.adjustment_method,
                                           "input_contracts": len(contracts),
                                           "verified_roll_transitions": len(relevant_rolls),
                                           "contract_source_ids": sorted({c.source_id for c in contracts}),
                                           "roll_source_ids": sorted({r.source_id for r in relevant_rolls}),
                                           "output_rows": len(series),
                                           "expected_interval": str(pd.Timedelta(expected_interval)) if expected_interval is not None else None,
                                           "naive_source_timezone": naive_timezone,
                                           "underlyings": sorted(series.underlying.unique()) if not series.empty else [],
                                           "e1_session_ids_attached": not series.empty,
                                           "synthetic_gap_or_roll_candles_created": False,
                                           "research_prices_are_executable": False},
                       snapshot_as_of=snapshot.isoformat() if snapshot is not None else None)
