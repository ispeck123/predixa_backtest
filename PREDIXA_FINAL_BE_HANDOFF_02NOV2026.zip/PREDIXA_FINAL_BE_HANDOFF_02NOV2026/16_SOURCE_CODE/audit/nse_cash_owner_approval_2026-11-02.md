# NSE_CASH permission-reduction approval record

Provenance: BE-initiated on edge-reproduction evidence (fix-sheet row 6). NOT pre-authorized by the owner; the 02-Nov 'complete the remediation' instruction did not cover this item, which row 6 flagged owner-decision. Owner-ratified after the fact on 02-Nov-2026.

This repository record documents scope; it does not replace the separately
protected release-baseline approval artifact.

Approved removals from `NSE_CASH.permit_cells`:

- `SW/UP/2` (`CORE`; recorded OOS realized R `-0.13R`)
- `UP/UP/2` (`CORE`; recorded OOS realized R `-0.05R`)
- `UP/UP/5` (`CORE`; recorded OOS realized R `-0.19R`)
- `UP/UP/25` (`MARGINAL`; recorded OOS realized R `-0.08R`)

No NSEFO or MCX permission increase is authorized. MCX remains an empty,
operationally held gate. The release operator must publish the candidate
baseline through the independently protected approval location and invoke
`scripts/release_preflight.py --mode reduction` with both external baseline
paths before controlled deployment.

## Standing change-control rule

The owner permits independent application of changes that do not alter live
trading behaviour (code correctness, gate/sizing wiring, guardrails, tests,
documentation, and analysis), plus emergency safety stops that turn a segment
off or apply a kill-switch. Any change to what trades live or at what size —
including adding, removing, or re-tiering live permit cells, enabling a
segment, or changing sizing/risk rails — requires explicit owner sign-off
before deployment. Completing a remediation does not imply that sign-off for
an item explicitly flagged as an owner decision.
