from fastapi import APIRouter, HTTPException, Request
from shared.db.db_model import OMSOrderBucketCommodity, Commodity_Order, TradeSignal
from shared.db.req_model import BucketOrderBase, Update_BucketOrderBase, GetOrder, ApproveReject_BucketOrderBase
from shared.db.fyers_req_model import GttLeg, GttOrderInfo, get_fyers, SingleGttOrderRequest
from shared.db.dbconn import DBConnection
from shared.db.api_responce import APIResponse
import logging
from datetime import datetime
from pathlib import Path
from sqlalchemy import text, or_
import ast, re
import pandas as pd
from data_fetchers.fyers.get_stock_prices import StockPriceFetcher
from data_fetchers.fyers.fyers_utils import normalize_cash_oco_prices
from scripts.graduated_live_config import (FUTURES_LOT_SIZES,
                                           OPTION3_LIQUIDITY_THRESHOLD,
                                           OPTION3_SINGLE_TRADE_RISK_CAP_INR,
                                           mcx_execution_permitted)
from scripts.position_sizing import SEGMENTS
from scripts.sizing_bridge import evaluate_mcx_execution_lot, translate_mcx_levels
from shared.config.settings import stock_data_dir_config


logger = logging.getLogger("fyers_orders")
logging.basicConfig(level=logging.INFO)

db = DBConnection()
router = APIRouter()
#spf = StockPriceFetcher()


@router.get("/paper-observation/mcx/orders", tags=["paper_observation"])
async def get_mcx_paper_observation_orders(request: Request):
    """Read-only view of records in the isolated local-paper SQLite store."""
    from scripts.paper_observation import (
        PaperObservationConfig, PaperObservationStore, local_paper_session_factory,
    )
    response = APIResponse(request)
    session_factory = local_engine = None
    try:
        # Monitoring remains available when the MCX paper kill switch is off,
        # but only in an explicitly identified local-paper runtime.
        config = PaperObservationConfig.from_environment()
        session_factory, local_engine = local_paper_session_factory(
            config, require_enabled=False)
        response.setMsg("success")
        response.setResponse(PaperObservationStore(session_factory).orders("MCX"))
    except Exception as exc:
        logger.warning("MCX_PAPER_OBSERVATION_MONITOR_UNAVAILABLE: %s", exc)
        response.setMsg("failed")
        response.setResponse("LOCAL_PAPER_MONITORING_UNAVAILABLE")
    finally:
        if local_engine is not None:
            local_engine.dispose()
    return response


def _parse_commodity_expiry(value):
    """Accept the expiry formats already persisted by commodity scanners."""
    if isinstance(value, datetime):
        return value
    if value is None:
        return None
    expiry = str(value).strip()
    for date_format in ("%d%m%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(expiry, date_format)
        except ValueError:
            continue
    return None


def format_commodity_contract(symbol, expiry):
    """Build the exact FYERS MCX futures contract for a bucket row."""
    if not symbol:
        return None
    symbol = str(symbol).strip().upper()
    if symbol.startswith("MCX:") and symbol.endswith("FUT"):
        return symbol
    expiry = _parse_commodity_expiry(expiry)
    if expiry is None:
        return None
    return f"MCX:{symbol}{expiry.strftime('%y%b').upper()}FUT"


def _broker_success(response):
    return isinstance(response, dict) and response.get("s") == "ok"


def _mcx_quote(fyers, contract):
    """Return the live price and traded volume required for MCX execution."""
    try:
        response = fyers._client.quotes({"symbols": contract})
        values = response["d"][0]["v"]
        price = values.get("lp", values.get("ltp"))
        volume = next((values[key] for key in (
            "vol_traded_today", "volume", "vol", "vtt"
        ) if values.get(key) is not None), None)
        price, volume = float(price), float(volume)
    except (AttributeError, KeyError, IndexError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=502, detail="MCX_QUOTE_UNAVAILABLE") from exc
    if price <= 0 or volume < 0:
        raise HTTPException(status_code=502, detail="MCX_QUOTE_UNAVAILABLE")
    return {"ltp": price, "volume": volume}


def _seven_day_average_quantity(symbol, expiry):
    """Read the active execution contract's seven completed daily quantities."""
    parsed_expiry = _parse_commodity_expiry(expiry)
    if parsed_expiry is None:
        raise HTTPException(status_code=422, detail="COMMODITY_INVALID_CONTRACT")
    path = Path(stock_data_dir_config.indian_commodity_data) / "latest_data_csv" / (
        f"{symbol}_{parsed_expiry.strftime('%d%m%Y')}_daily.csv"
    )
    try:
        candles = pd.read_csv(path)
        candles["_date"] = pd.to_datetime(candles["tradeDate"], dayfirst=True, errors="coerce")
        candles["_qty"] = pd.to_numeric(candles["qty"], errors="coerce")
        candles = candles.dropna(subset=["_date", "_qty"])
        candles = candles[candles["_date"].dt.date < datetime.now().date()]
        quantities = candles.sort_values("_date")["_qty"].tail(7)
        if len(quantities) != 7 or (quantities <= 0).any():
            raise ValueError("insufficient daily quantity history")
        return float(quantities.mean())
    except (OSError, KeyError, TypeError, ValueError, pd.errors.ParserError) as exc:
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_LIQUIDITY_UNAVAILABLE") from exc


def _translated_mcx_execution(session, row, *, quote_provider, liquidity_provider):
    """Translate a GOLDM setup to GOLDGUINEA and preflight its real lot.

    GOLDM remains the signal/gate/zone series.  This function is deliberately
    invoked before risk/margin checks so those checks see only executable
    GOLDGUINEA prices and its eight-unit lot.
    """
    execution_symbol = str(row.stock_tick or "").strip().upper()
    if execution_symbol != "GOLDGUINEA":
        return None
    signal = session.query(TradeSignal).filter(TradeSignal.id == row.trade_signal_id).first()
    source_symbol = str(getattr(signal, "stock_name", "") or "").strip().upper()
    source_data = getattr(signal, "trade_data", None) or {}
    if source_symbol != "GOLDM":
        raise HTTPException(status_code=409, detail="MCX_TRANSLATION_SOURCE_INVALID")
    try:
        e_regime = source_data["e_regime"]
        a_regime = source_data["a_regime"]
    except (KeyError, TypeError):
        raise HTTPException(status_code=409, detail="MCX_TRANSLATION_PROVENANCE_MISSING") from None

    source_contract = format_commodity_contract(source_symbol, row.expiry_date)
    execution_contract = format_commodity_contract(execution_symbol, row.expiry_date)
    if source_contract is None or execution_contract is None:
        raise HTTPException(status_code=422, detail="COMMODITY_INVALID_CONTRACT")
    source_quote = quote_provider(source_contract)
    execution_quote = quote_provider(execution_contract)
    translated = translate_mcx_levels(
        source_entry=row.entry_price,
        source_stop=row.stoploss_price,
        source_target=row.target_price,
        source_ltp=source_quote["ltp"],
        execution_ltp=execution_quote["ltp"],
    )
    average_quantity = liquidity_provider(execution_symbol, row.expiry_date)
    required_volume = average_quantity * float(OPTION3_LIQUIDITY_THRESHOLD)
    if execution_quote["volume"] < required_volume:
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_LIQUIDITY_FAILURE")

    lot_size = FUTURES_LOT_SIZES["GOLDGUINEA"]
    if int(row.stock_quantity or 0) != lot_size:
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_LOT_MISMATCH")
    position = evaluate_mcx_execution_lot(
        source_symbol=source_symbol, e_regime=e_regime, a_regime=a_regime,
        strategy_tf=signal.time_fr or row.time_frame, translated_entry=translated["entry"],
        translated_stoploss=translated["stoploss"],
        translated_target=translated["target"], execution_lot_size=lot_size,
    )
    if position is None:
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_SIZING_REJECTED")
    if position.risk_rupees > float(OPTION3_SINGLE_TRADE_RISK_CAP_INR):
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_RISK_CAP_EXCEEDED")
    if position.margin > SEGMENTS["MCX"].exposure_cap:
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_MARGIN_CAP_EXCEEDED")
    return {
        "contract": execution_contract,
        "entry": translated["entry"], "stoploss": translated["stoploss"],
        "target": translated["target"], "scale": translated["scale"],
        "risk_rupees": position.risk_rupees, "notional": position.notional,
        "modelled_margin": position.margin,
        "live_volume": execution_quote["volume"],
        "seven_day_average_quantity": average_quantity,
        "required_volume": required_volume,
    }


def approve_existing_commodity_candidate(*, bucket_id, status, approved_by,
                                         session_factory=None,
                                         fyers_factory=None,
                                         quote_provider=None,
                                         liquidity_provider=None,
                                         now_factory=datetime.now):
    """Submit or cancel the real FYERS GTT associated with an MCX bucket.

    Approval state is only persisted after FYERS confirms the entry GTT.  This
    prevents an OMS row from appearing live when the broker rejected it.
    """
    # A hold prevents new broker submissions, including approval of a bucket
    # created before the hold.  Rejection/cancellation remains available so an
    # operator can reduce exposure.
    if str(status or "").strip().lower() == "approved" and not mcx_execution_permitted():
        raise HTTPException(status_code=409, detail="MCX_EXECUTION_BLOCKED")
    session = session_factory() if session_factory else db.get_session()
    fyers_factory = fyers_factory or get_fyers
    liquidity_provider = liquidity_provider or _seven_day_average_quantity
    row = None
    try:
        row = session.query(OMSOrderBucketCommodity).filter(
            OMSOrderBucketCommodity.bucket_id == bucket_id
        ).first()
        if row is None:
            raise HTTPException(status_code=404, detail="COMMODITY_BUCKET_NOT_FOUND")
        if str(getattr(row, "execution_mode", "") or "").strip().upper() != "REAL":
            raise HTTPException(status_code=409, detail="COMMODITY_EXECUTION_MODE_NOT_REAL")

        normalized_status = str(status or "").strip().lower()
        if normalized_status not in {"approved", "rejected"}:
            raise HTTPException(status_code=422, detail="COMMODITY_INVALID_STATUS")

        if normalized_status == "approved":
            if row.approval_status == "approved" and row.gtt_id:
                return {
                    "decision": "ALREADY_SUBMITTED", "bucket_id": row.bucket_id,
                    "gtt_id": row.gtt_id, "id_fyers": row.id_fyers,
                    "symbol": format_commodity_contract(row.stock_tick, row.expiry_date),
                }
            if int(row.is_trade_started or 0) != 0:
                raise HTTPException(status_code=409, detail="COMMODITY_ORDER_ALREADY_STARTED")
            if row.approval_status == "rejected" and not row.gtt_id:
                # A confirmed cancellation can be deliberately re-approved.
                row.order_status = "pending"
            if str(row.order_status or "pending").lower() not in {"pending", "", "pending_quote_translation"}:
                raise HTTPException(status_code=409, detail="COMMODITY_CANDIDATE_NOT_ACTIONABLE")

            order_type = str(row.order_type or "").strip().upper()
            if order_type not in {"BUY", "SELL"}:
                raise HTTPException(status_code=422, detail="COMMODITY_INVALID_ORDER_TYPE")
            try:
                quantity = int(row.stock_quantity)
                entry = float(row.entry_price)
                target = float(row.target_price)
                stoploss = float(row.stoploss_price)
            except (TypeError, ValueError):
                raise HTTPException(status_code=422, detail="COMMODITY_INCOMPLETE_CANDIDATE") from None
            if quantity <= 0:
                raise HTTPException(status_code=422, detail="COMMODITY_INVALID_QUANTITY")
            if order_type == "BUY" and not stoploss < entry < target:
                raise HTTPException(status_code=422, detail="COMMODITY_INVALID_BUY_PRICES")
            if order_type == "SELL" and not target < entry < stoploss:
                raise HTTPException(status_code=422, detail="COMMODITY_INVALID_SELL_PRICES")

            if quote_provider is None and str(row.stock_tick or "").strip().upper() == "GOLDGUINEA":
                quote_broker = fyers_factory()
                quote_provider = lambda contract: _mcx_quote(quote_broker, contract)
            translation = _translated_mcx_execution(
                session, row, quote_provider=quote_provider,
                liquidity_provider=liquidity_provider,
            )
            if translation:
                entry = translation["entry"]
                stoploss = translation["stoploss"]
                target = translation["target"]
                contract = translation["contract"]
            else:
                contract = format_commodity_contract(row.stock_tick, row.expiry_date)
            if contract is None:
                raise HTTPException(status_code=422, detail="COMMODITY_INVALID_CONTRACT")

            prices = normalize_cash_oco_prices(
                entry=entry, target=target, stoploss=stoploss, order_type=order_type
            )
            payload = SingleGttOrderRequest(
                side=1 if order_type == "BUY" else -1,
                symbol=contract,
                productType="MARGIN",
                orderInfo=GttOrderInfo(leg1=GttLeg(
                    price=float(prices["entry"]),
                    triggerPrice=float(prices["entry"]),
                    qty=quantity,
                )),
                orderTag=str(row.bucket_id),
            ).model_dump()

            try:
                response = fyers_factory().place_cash_gtt(payload, execution_mode="REAL")
            except Exception as exc:
                logger.exception("Failed to submit MCX GTT for bucket %s", row.bucket_id)
                raise HTTPException(status_code=502, detail="COMMODITY_GTT_SUBMISSION_FAILED") from exc
            if not _broker_success(response) or not response.get("id"):
                raise HTTPException(status_code=502, detail="COMMODITY_GTT_REJECTED")

            row.gtt_id = str(response["id"])
            row.id_fyers = response.get("id_fyers")
            row.approval_status = "approved"
            row.approved_by = approved_by
            row.approved_at = now_factory()
            row.order_status = "pending"
            row.is_trade_started = 0
            if translation:
                row.entry_price = entry
                row.stoploss_price = stoploss
                row.target_price = target
                linked_order = session.query(Commodity_Order).filter(
                    Commodity_Order.order_id == row.order_id
                ).first() if row.order_id is not None else None
                if linked_order is not None:
                    linked_order.entry_price = entry
                    linked_order.stoploss_price = stoploss
                    linked_order.target_price = target
                    session.add(linked_order)
            session.add(row)
            session.commit()
            return {
                "decision": "SUBMITTED", "bucket_id": row.bucket_id,
                "gtt_id": row.gtt_id, "id_fyers": row.id_fyers,
                "symbol": contract,
                **({"translation": translation} if translation else {}),
            }

        # Rejecting a pre-submission candidate is a database-only state change.
        if int(row.is_trade_started or 0) != 0:
            raise HTTPException(status_code=409, detail="COMMODITY_FILLED_ORDER")
        gtt_id = row.gtt_id
        if gtt_id:
            broker = fyers_factory()
            try:
                response = broker.cancel_gtt_order({"id": str(gtt_id)})
            except AttributeError:
                response = broker._client.cancel_gtt_order(data={"id": str(gtt_id)})
            except Exception as exc:
                logger.exception("Failed to cancel MCX GTT %s", gtt_id)
                raise HTTPException(status_code=502, detail="COMMODITY_GTT_CANCELLATION_FAILED") from exc
            if not _broker_success(response):
                raise HTTPException(status_code=502, detail="COMMODITY_GTT_CANCELLATION_FAILED")

        row.approval_status = "rejected"
        row.approved_by = approved_by
        row.approved_at = now_factory()
        row.order_status = "cancelled"
        row.is_trade_started = 0
        row.gtt_id = None
        row.id_fyers = None
        session.add(row)
        session.commit()
        return {
            "decision": "REJECTED_BY_USER", "bucket_id": row.bucket_id,
            "cancelled_gtt_id": str(gtt_id) if gtt_id else None,
        }
    except HTTPException:
        session.rollback()
        raise
    except Exception:
        session.rollback()
        logger.exception("Failed to process MCX bucket %s", bucket_id)
        raise HTTPException(status_code=502, detail="COMMODITY_APPROVAL_PROCESSING_ERROR") from None
    finally:
        session.close()


def safe_parse_order_status(order_status):
    if not isinstance(order_status, str):
        return order_status  # Already a dict

    if order_status.strip().startswith("{"):
        try:
            # Clean Timestamp if present
            order_status = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_status)
            return ast.literal_eval(order_status)
        except Exception as e:
            logging.error(f"Failed to eval order_status: {order_status} — {e}")
            return {"status": "unknown", "error": str(e)}
    else:
        # It's a simple status string like 'PENDING'
        return {"status": order_status.strip().lower()}


@router.post("/get/bucket/order/count/commodity", tags=["bucket_orders"])
async def get_bucket_orders_count_commodity(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"
        
        req_model.status = req_model.status.strip().lower()

        if req_model.status == 'all':
            print('1')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and time_frame like '{req_model.time_frame}' 
                                and order_type in {order_types}
                                {prediction_type};"""))
        else:
            print('2')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and order_status like '%{req_model.status}%'
                                and time_frame like '{req_model.time_frame}' 
                                and order_type in {order_types}
                                {prediction_type};"""))
        
        print("total_count:", total_count)
        if total_count and len(total_count) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse(total_count)
        else:
            apiresponce.setMsg("success")
            apiresponce.setResponse([{"count": 0}])
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get/bucket/orders/commodity", tags=["bucket_orders"])
async def get_bucket_orders_commodity(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        # if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
        #     req_model.stock_tick = ''
        # req_model.stock_tick = '%' + req_model.stock_tick + '%'
        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        
        try:
            req_model.trade_id = int(req_model.trade_id)
        except Exception as er:
            req_model.trade_id = None

        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_by_purchased_cmp_date:
            order_by = "purchased_cmp_date desc"
        else:
            order_by = "stock_tick asc"
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"
        
        req_model.status = req_model.status.strip().lower()

        res = []


        if (req_model.trade_id != None and req_model.trade_id != 'null' and req_model.trade_id != ''):
            if req_model.status == 'all':
                print('1')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            else:
                print('2')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            
            #print("total_res:", total_res)
            found = False
            for i in range(len(total_res)):
                if req_model.trade_id == total_res[i]['trade_signal_id']:
                    found = i+1
                    break
            print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("page_no:", req_model.page_no)
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
            else:
                pass

        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
            req_model.page_no = 1
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('5')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                
            else:
                print('6')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            
                   
        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('9')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                
            else:
                print('10')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):            
            if req_model.status == 'all':
                print('13')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            else:
                print('14')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            
            found = False
            for i in range(len(total_res)):
                if total_res[i]['stock_tick'].lower().startswith(req_model.stock_tick.lower()):
                    found = i+1
                    break
            if not found:
                for i in range(len(total_res)):
                    if req_model.stock_tick.lower() in total_res[i]['stock_tick'].lower():
                        found = i+1
                        break
            #print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
            else:
                pass
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('17')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            else:
                print('18')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            
         
        
        apiresponce.setMsg("success")
        apiresponce.setResponse({"orders": res, "page_no": req_model.page_no})
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/bucket/orders/commodity/{order_id}", tags=["bucket_orders"])
async def get_bucket_order_commodity_by_id(order_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        res = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.order_id == order_id).first()
        if res is None:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Order Not Found")
            return apiresponce
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
        return apiresponce
    except Exception as e:
        logger.exception("Failed to fetch bucket order by id")
        raise HTTPException(status_code=502, detail=f"Error fetching bucket order by id: {e}")
    finally:
        session.close()


@router.post("/create/bucket/orders/commodity", tags=["bucket_orders"])
async def create_bucket_order_commodity(body: BucketOrderBase, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if body.trade_id != None:
            bucket_order = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.trade_signal_id == body.trade_id).all()
            if bucket_order and len(bucket_order) > 0:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Bucket order already exists for the given trade")
                session.close()
                return apiresponce
        order_id = None
        if body.trade_id != None:
            order = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == body.trade_id).all()
            if order and len(order) > 0 and order[0].order_id != None:
                order_id = order[0].order_id
            else:
                order_id = body.order_id
        oms_order_bucket = OMSOrderBucketCommodity(
            order_id = order_id,
            trade_signal_id = body.trade_id,
            country_id = body.country_id,
            stock_tick = body.stock_tick,
            stock_id = body.stock_id,
            time_frame = body.time_frame,
            order_type = body.order_type,
            entry_price = body.entry_price,
            stoploss_price = body.stoploss_price,
            target_price = body.target_price,
            stock_quantity = body.stock_quantity,
            purchased_cmp_date = body.purchased_cmp_date,
            purchased_on = datetime.now(),
            order_status = "pending",
            expiry_date = body.expiry_date)
        session.add(oms_order_bucket)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse(oms_order_bucket)
    except Exception as e:
        logger.exception("Failed to create bucket order")
        raise HTTPException(status_code=502, detail=f"Error creating bucket order: {e}")
    finally:
        session.close()
    return apiresponce


@router.post("/approve/reject/bucket/orders/commodity", tags=["bucket_orders"])
async def approve_reject_bucket_orders_commodity(body: ApproveReject_BucketOrderBase, request: Request):
    apiresponce = APIResponse(request)
    try:
        result = approve_existing_commodity_candidate(
            bucket_id=body.bucket_id,
            status=body.status,
            approved_by=body.approved_by,
        )
        # The UI needs a distinct top-level message after cancelling an
        # already-approved order; ``success`` alone cannot describe the flow.
        if result["decision"] == "REJECTED_BY_USER" and result["cancelled_gtt_id"]:
            apiresponce.setMsg("Order successfully canceled")
        elif result["decision"] == "REJECTED_BY_USER":
            apiresponce.setMsg("Order rejected successfully")
        else:
            apiresponce.setMsg("success")
        apiresponce.setResponse(result)
    except HTTPException:
        raise
    except Exception as ex:
        logger.exception("Failed to update bucket order")
        raise HTTPException(status_code=502, detail=f"Error updating bucket order: {ex}")
    return apiresponce
