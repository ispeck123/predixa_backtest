"""T2 contract-roll tests use synthetic rows only; they are not market evidence."""
from datetime import date

import pandas as pd
import pytest

from audit.mcx_futures_backtest.contract_roll import (
    ContractDataError,
    DatedContract,
    RollPolicy,
    RollTransition,
    TradingCalendar,
    build_back_adjusted_series,
    classify_expiry_window,
    select_historical_contract,
)


def ts(value):
    return pd.Timestamp(value, tz="Asia/Kolkata")


def contract(symbol="CRUDEOILM", dated="CRUDEOILM26OCTFUT", start="2026-10-01 09:00",
             end="2026-10-06 09:00", expiry=date(2026, 10, 19), iid="FYERS:MCX:dated"):
    return DatedContract(symbol, dated, iid, "MCX", expiry, ts(start), ts(end) if end else None,
                         f"source:{dated}", "VERIFIED", ts(start))


def bars(rows):
    return pd.DataFrame([{"timestamp": ts(t), "open": o, "high": max(o, h, l, c),
                          "low": min(o, h, l, c), "close": c, "volume": v}
                         for t, o, h, l, c, v in rows])


def roll_fixture(close_old=100.0, open_new=110.0, close_new=112.0):
    boundary = ts("2026-10-06 09:00")
    old = contract(dated="CRUDEOILM26OCTFUT", start="2026-10-05 09:00",
                   end="2026-10-06 09:00", expiry=date(2026, 10, 19))
    new = contract(dated="CRUDEOILM26NOVFUT", start="2026-10-06 09:00", end=None,
                   expiry=date(2026, 11, 19), iid="FYERS:MCX:next")
    old_bars = bars([("2026-10-05 23:00", close_old-1, close_old+2, close_old-2, close_old, 10)])
    new_bars = bars([("2026-10-06 09:00", open_new, open_new+3, open_new-2, close_new, 20),
                     ("2026-10-06 10:00", close_new, close_new+4, close_new-1, close_new+2, 30)])
    event = RollTransition("CRUDEOILM", old.contract_symbol, new.contract_symbol,
                           ts("2026-10-05 22:00"), boundary, close_old, open_new,
                           "verified-roll-price-record", True)
    return [old, new], {(old.underlying, old.contract_symbol): old_bars,
                        (new.underlying, new.contract_symbol): new_bars}, [event]


def build(fixtures=None, *, method="additive", as_of=None, policy_status="APPROVED"):
    contracts, source, rolls = fixtures or roll_fixture()
    return build_back_adjusted_series(
        contracts, source, rolls, RollPolicy("explicit-schedule-test", method, policy_status),
        as_of=as_of, naive_timezone="Asia/Kolkata", expected_interval="60min")


def test_t2_01_explicit_historical_interval_selects_contract():
    contracts, _, _ = roll_fixture()
    assert select_historical_contract(contracts, "CRUDEOILM", ts("2026-10-05 23:00")).contract_symbol.endswith("26OCTFUT")
    assert select_historical_contract(contracts, "CRUDEOILM", ts("2026-10-06 09:00")).contract_symbol.endswith("26NOVFUT")


def test_t2_02_future_current_chain_does_not_rewrite_prior_attribution():
    contracts, _, _ = roll_fixture()
    before = select_historical_contract(contracts, "CRUDEOILM", ts("2026-10-05 23:00")).contract_symbol
    added_future_listing = contract(dated="CRUDEOILM27JANFUT", start="2027-01-01 09:00",
                                   end=None, expiry=date(2027, 1, 19), iid="future-master-row")
    assert select_historical_contract(contracts + [added_future_listing], "CRUDEOILM",
                                      ts("2026-10-05 23:00")).contract_symbol == before


def test_t2_03_underlyings_remain_separate():
    items = [contract(symbol=s, dated=f"{s}26OCTFUT", start="2026-10-01 09:00", end=None,
                      iid=f"ID:{s}") for s in ("GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI")]
    for item in items:
        assert select_historical_contract(items, item.underlying, ts("2026-10-02 09:00")) == item
    with pytest.raises(ContractDataError, match="UNRESOLVED"):
        select_historical_contract(items, "GOLDM", ts("2026-09-30 09:00"))


def test_t2_04_verified_roll_switches_at_effective_timestamp():
    result = build()
    assert result.series.iloc[0].contract_symbol == "CRUDEOILM26OCTFUT"
    assert result.series.iloc[1].contract_symbol == "CRUDEOILM26NOVFUT"
    assert result.series.iloc[1].roll_transition_before


def test_t2_05_unverified_or_missing_contract_information_fails_closed():
    with pytest.raises(ContractDataError, match="not VERIFIED") as exc:
        DatedContract("CRUDEOILM", "UNKNOWN", "ID", "MCX", date(2026, 11, 19),
                      ts("2026-10-01 09:00"), None, "unknown", "UNVERIFIED")
    assert exc.value.validation_summary["status"] == "REJECTED"
    with pytest.raises(ContractDataError, match="no verified"):
        select_historical_contract([], "CRUDEOILM", ts("2026-10-02 09:00"))


def test_t2_06_additive_back_adjustment_uses_observed_roll_prices():
    result = build()
    old = result.series.iloc[0]
    assert old.adjustment_offset == pytest.approx(10)
    assert old.research_close == pytest.approx(110)
    assert result.roll_metadata[0]["outgoing_adjustment"] == pytest.approx(10)


def test_explicit_ratio_adjustment_is_deterministic_and_keeps_raw_prices():
    result = build(method="ratio")
    old = result.series.iloc[0]
    assert old.adjustment_factor == pytest.approx(1.1)
    assert old.research_close == pytest.approx(110)
    assert old.raw_close == 100


def test_t2_07_adjusted_roll_seam_has_no_synthetic_price_jump_or_pnl():
    result = build()
    # The outgoing close and incoming open align in research space. Raw bars
    # remain distinct; no intervening bridging candle is constructed.
    old, new = result.series.iloc[:2].itertuples(), None
    rows = result.series.iloc[:2]
    assert rows.iloc[0].research_close == pytest.approx(rows.iloc[1].research_open)
    assert rows.iloc[0].raw_close == 100
    assert rows.iloc[1].raw_open == 110
    assert len(result.series) == 3


def test_t2_08_genuine_within_contract_movement_is_preserved():
    result = build()
    second = result.series.iloc[2]
    assert second.research_close - second.research_open == pytest.approx(
        second.raw_close - second.raw_open)


def test_t2_09_raw_executable_prices_are_unchanged_and_mapped():
    result = build()
    row = result.series.iloc[1]
    assert (row.raw_open, row.raw_high, row.raw_low, row.raw_close) == (110, 113, 108, 112)
    assert row.provider_instrument_id == "FYERS:MCX:next"
    assert result.validation_summary["research_prices_are_executable"] is False


def test_t2_10_fewer_than_three_remaining_sessions_is_flagged():
    c = contract(start="2026-10-01 09:00", end=None, expiry=date(2026, 10, 8))
    sessions = frozenset(date(2026, 10, d) for d in (1, 2, 5, 6, 7, 8))
    cal = TradingCalendar(sessions, date(2026, 10, 1), date(2026, 10, 8), "calendar-v1", True)
    result = classify_expiry_window(ts("2026-10-05 10:00"), c, cal)
    assert result == {"status": "VALID", "remaining_trading_days": 3,
                      "roll_boundary_candidate": False, "reason": None}
    assert classify_expiry_window(ts("2026-10-06 10:00"), c, cal)["roll_boundary_candidate"]


def test_t2_11_verified_holiday_is_not_counted_as_trading_day():
    c = contract(start="2026-10-01 09:00", end=None, expiry=date(2026, 10, 8))
    sessions = frozenset(date(2026, 10, d) for d in (1, 2, 5, 7, 8))  # Oct 6 is a verified closure.
    cal = TradingCalendar(sessions, date(2026, 10, 1), date(2026, 10, 8), "calendar-with-closure", True)
    assert classify_expiry_window(ts("2026-10-05 10:00"), c, cal)["remaining_trading_days"] == 2


def test_t2_12_missing_calendar_is_unverified_not_calendar_day_guess():
    c = contract(start="2026-10-01 09:00", end=None)
    result = classify_expiry_window(ts("2026-10-05 10:00"), c, None)
    assert result["status"] == "UNVERIFIED"
    assert result["remaining_trading_days"] is None
    assert result["roll_boundary_candidate"] is None


def test_t2_13_asof_snapshot_does_not_use_future_roll_or_future_bars():
    fixtures = roll_fixture()
    result = build(fixtures, as_of=ts("2026-10-05 23:30"))
    assert set(result.series.contract_symbol) == {"CRUDEOILM26OCTFUT"}
    assert result.series.timestamp.max() <= ts("2026-10-05 23:30")
    assert result.validation_summary["verified_roll_transitions"] == 0


def test_t2_14_missing_roll_prices_and_future_decision_are_rejected():
    with pytest.raises(ContractDataError, match="decision uses information after"):
        RollTransition("CRUDEOILM", "A", "B", ts("2026-10-06 10:00"),
                       ts("2026-10-06 09:00"), 100, 110, "src", True)
    with pytest.raises(ContractDataError, match="roll prices"):
        RollTransition("CRUDEOILM", "A", "B", ts("2026-10-05 10:00"),
                       ts("2026-10-06 09:00"), float("nan"), 110, "src", True)


def test_roll_price_must_match_the_contract_ohlc_source():
    contracts, source, rolls = roll_fixture()
    event = rolls[0]
    rolls[0] = RollTransition(event.underlying, event.outgoing_symbol, event.incoming_symbol,
                              event.decision_at, event.effective_at, 99, event.incoming_price,
                              event.source_id, True)
    with pytest.raises(ContractDataError, match="does not match the dated-contract close"):
        build((contracts, source, rolls))


def test_overlapping_contract_selection_intervals_are_rejected():
    contracts, _, _ = roll_fixture()
    overlapping = contract(dated="CRUDEOILM27JANFUT", start="2026-10-05 12:00", end=None,
                           expiry=date(2027, 1, 19))
    with pytest.raises(ContractDataError, match="overlapping CRUDEOILM active contracts"):
        select_historical_contract(contracts + [overlapping], "CRUDEOILM", ts("2026-10-05 15:00"))


def test_adjacent_contract_intervals_without_roll_event_remain_unverified():
    contracts, source, _ = roll_fixture()
    result = build((contracts, source, []))
    assert result.validation_summary["status"] == "UNVERIFIED"
    assert "ROLL_EVENT_MISSING" in {issue["code"] for issue in result.validation_summary["issues"]}


def test_expired_contract_cannot_be_selected_or_contain_later_bars():
    expired = contract(start="2026-10-01 09:00", end=None, expiry=date(2026, 10, 5))
    with pytest.raises(ContractDataError, match="no verified"):
        select_historical_contract([expired], "CRUDEOILM", ts("2026-10-06 09:00"))
    after_expiry = bars([("2026-10-06 09:00", 100, 102, 98, 101, 1)])
    with pytest.raises(ContractDataError, match="extends beyond stated contract expiry"):
        build_back_adjusted_series([expired], {("CRUDEOILM", expired.contract_symbol): after_expiry}, [],
                                   RollPolicy("expiry-test", "additive", "APPROVED"),
                                   naive_timezone="Asia/Kolkata")


@pytest.mark.parametrize("invalid", ["duplicate", "unsorted", "bad_ohlc"])
def test_t2_15_duplicate_unsorted_or_invalid_ohlc_rejected(invalid):
    fixtures = roll_fixture()
    frame = fixtures[1][("CRUDEOILM", "CRUDEOILM26NOVFUT")].copy()
    if invalid == "duplicate":
        frame = pd.concat([frame, frame.iloc[[0]]], ignore_index=True)
    elif invalid == "unsorted":
        frame = frame.iloc[::-1].reset_index(drop=True)
    else:
        frame.loc[0, "high"] = 1
    fixtures[1][("CRUDEOILM", "CRUDEOILM26NOVFUT")] = frame
    with pytest.raises(ContractDataError):
        build(fixtures)


def test_t2_16_contract_roll_and_e1_boundary_are_independent():
    result = build()
    assert result.series.iloc[0].e1_session_id != result.series.iloc[1].e1_session_id
    assert result.series.iloc[1].roll_transition_before
    assert result.validation_summary["synthetic_gap_or_roll_candles_created"] is False


@pytest.mark.parametrize("close_bucket", ["21:00", "23:00", "23:15"])
def test_t2_17_supported_mcx_bucket_paths_retain_e1_ids(close_bucket):
    contracts, source, rolls = roll_fixture()
    day = "2026-10-05 " + close_bucket
    source[("CRUDEOILM", "CRUDEOILM26OCTFUT")] = bars([(day, 99, 102, 98, 100, 10)])
    result = build((contracts, source, rolls))
    assert result.series.iloc[0].e1_session_id != result.series.iloc[1].e1_session_id


def test_t2_18_non_mcx_calendar_inference_is_untouched():
    from audit.derivatives_backtest_common.calendar_contracts import nsefo_contract_live
    assert nsefo_contract_live("NIFTY", "2026-10-01") == ("NIFTY@27102026", False)


def test_t2_19_existing_mcx_gate_and_allocator_stay_blocked():
    from scripts.position_sizing import CapitalAllocator, PortfolioPolicy, SEGMENTS
    from scripts.tf_regime_gate_by_exchange import gate
    assert gate("MCX", 4, "SW", "SW", "CRUDEOILM")[:2] == ("DENY", 0.0)
    assert CapitalAllocator(PortfolioPolicy(1_000_000, 5, 10, 3, 10), SEGMENTS).segment_status("MCX") == "BLOCKED"


def test_t2_20_same_inputs_and_explicit_policy_are_repeatable():
    one, two = build(), build()
    pd.testing.assert_frame_equal(one.series, two.series)
    assert one.roll_metadata == two.roll_metadata
    assert one.validation_summary == two.validation_summary


def test_pending_policy_and_absent_roll_do_not_claim_valid_continuous_data():
    contracts, source, rolls = roll_fixture()
    result = build((contracts[:1], {k: v for k, v in source.items() if k[1] == contracts[0].contract_symbol}, []),
                   policy_status="PENDING_APPROVAL")
    assert result.validation_summary["status"] == "UNVERIFIED"
    assert {issue["code"] for issue in result.validation_summary["issues"]} == {
        "ROLL_POLICY_PENDING_APPROVAL", "NO_VERIFIED_ROLL_TRANSITIONS"}


def test_naive_candle_times_require_declared_timezone():
    contracts, source, rolls = roll_fixture()
    source = {k: v.copy() for k, v in source.items()}
    for frame in source.values():
        frame["timestamp"] = frame.timestamp.dt.tz_localize(None)
    with pytest.raises(ContractDataError, match="declared source timezone"):
        build_back_adjusted_series(contracts, source, rolls,
                                   RollPolicy("explicit", "additive", "APPROVED"))
