import pytest

from scripts import nsefo_instrument_metadata as metadata


ROW = "101126112361466,BANKNIFTY 23 Nov 26 FUT,11,30,0.2,,0915-1540|1815-1915:,2026-10-30,1795428600,NSE:BANKNIFTY26NOVFUT,10"


def test_fyers_master_parser_provides_exact_dated_lot_and_tick(monkeypatch):
    class Response:
        text = ROW + "\n"
        def raise_for_status(self):
            return None
    monkeypatch.setattr(metadata.requests, "get", lambda *_args, **_kwargs: Response())
    metadata._master.cache_clear()
    result = metadata.resolve_nsefo_contract_metadata("BANKNIFTY", "23112026", now=1)
    assert result["fyers_symbol"] == "NSE:BANKNIFTY26NOVFUT"
    assert result["lot_size"] == 30
    assert result["tick_size"] == 0.2


def test_missing_dated_contract_metadata_fails_closed(monkeypatch):
    monkeypatch.setattr(metadata, "_master", lambda *_: {})
    with pytest.raises(ValueError, match="CONTRACT_METADATA_MISSING"):
        metadata.resolve_nsefo_contract_metadata("CANBK", "30112026", now=1)
