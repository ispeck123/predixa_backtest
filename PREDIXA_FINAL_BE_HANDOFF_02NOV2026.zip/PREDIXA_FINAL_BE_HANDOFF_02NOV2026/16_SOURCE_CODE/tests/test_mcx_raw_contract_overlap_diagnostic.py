import pandas as pd

from audit.mcx_futures_backtest.compare_raw_contract_overlap import compare_overlap


def test_overlap_diagnostic_keeps_raw_contracts_separate_and_creates_no_roll(tmp_path):
    left = tmp_path / "aug.csv"
    right = tmp_path / "oct.csv"
    pd.DataFrame({"timestamp": ["2026-08-03T09:00:00+05:30", "2026-08-03T10:00:00+05:30"],
        "open": [10, 11], "high": [12, 13], "low": [9, 10], "close": [11, 12], "volume": [1, 2]}).to_csv(left,index=False)
    pd.DataFrame({"timestamp_ist": ["2026-08-03T09:00:00+05:30", "2026-08-03T10:00:00+05:30"],
        "open": [20, 21], "high": [22, 23], "low": [19, 20], "close": [21, 22], "volume": [3, 4]}).to_csv(right,index=False)
    result = compare_overlap(left, right, left_symbol="MCX:CRUDEOILM26AUGFUT",
        right_symbol="MCX:CRUDEOILM26OCTFUT", output_dir=tmp_path / "diagnostic")
    assert result["exact_overlap_rows"] == 2
    assert result["status"] == "NON_AUTHORITATIVE_RAW_OVERLAP_DIAGNOSTIC"
    assert result["roll_selected"] is False and result["pnl_or_realized_r_calculated"] is False
