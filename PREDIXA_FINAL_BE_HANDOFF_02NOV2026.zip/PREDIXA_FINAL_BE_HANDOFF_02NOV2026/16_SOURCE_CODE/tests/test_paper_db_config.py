import os
import pytest

from scripts.paper_db_config import PaperDatabaseConfig


def test_paper_db_config_rejects_missing_or_shared_schema(monkeypatch):
    for key in tuple(os.environ):
        if key.startswith("PREDIXA_PAPER_DB_"):
            monkeypatch.delenv(key, raising=False)
    with pytest.raises(RuntimeError, match="CONFIGURATION_INCOMPLETE"):
        PaperDatabaseConfig.from_environment()
    values = {"HOST":"192.168.1.16", "SCHEMA":"Fin_product", "USER":"paper",
              "PASSWORD":"x", "CA":"/tmp/ca.pem", "SERVER_UUID":"uuid"}
    for suffix, value in values.items():
        monkeypatch.setenv("PREDIXA_PAPER_DB_" + suffix, value)
    with pytest.raises(RuntimeError, match="SHARED_SCHEMA_REJECTED"):
        PaperDatabaseConfig.from_environment()


def test_paper_db_config_requires_tls_identity(monkeypatch):
    values = {"HOST":"192.168.1.16", "SCHEMA":"Fin_product_paper", "USER":"paper",
              "PASSWORD":"secret", "CA":"/tmp/ca.pem", "SERVER_UUID":"uuid"}
    for suffix, value in values.items(): monkeypatch.setenv("PREDIXA_PAPER_DB_" + suffix, value)
    config = PaperDatabaseConfig.from_environment()
    assert config.connect_args()["ssl"]["check_hostname"] is True
    assert "Fin_product_paper" in config.sqlalchemy_url()
