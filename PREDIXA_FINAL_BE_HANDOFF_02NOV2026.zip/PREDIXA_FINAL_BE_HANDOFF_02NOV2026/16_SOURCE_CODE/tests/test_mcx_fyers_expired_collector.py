"""Offline-only tests for FYERS expired MCX collector response handling."""
from __future__ import annotations

from datetime import date
import json

import pytest

from audit.mcx_futures_backtest.fyers_expired_contract_collector import (
    FyersContractCollector, FyersDataError, classify_response, parse_candles,
    parse_active_candles, parse_expired_symbols, parse_expiry_dates, split_date_range,
)


UNDERLYING = "MCX:CRUDEOILM26OCTFUT"
CONTRACT = "MCX:CRUDEOILM26OCTFUT"


def test_expiry_parser_accepts_fyers_normalized_product_root():
    response = {"s": "ok", "code": 200, "data": {"symbol": "CRUDEOILM",
        "expiry_dates": {"futures": ["2026-10-19"], "options": []}}}
    assert parse_expiry_dates(response, UNDERLYING) == ["2026-10-19"]


def test_expiry_parser_rejects_wrong_product_identity():
    response = {"s": "ok", "code": 200, "data": {"symbol": "GOLDM",
        "expiry_dates": {"futures": []}}}
    with pytest.raises(FyersDataError, match="does not match"):
        parse_expiry_dates(response, UNDERLYING)


def test_expired_contract_parser_keeps_exact_fyers_symbols():
    response = {"s": "ok", "code": 200, "data": {"symbol": "CRUDEOILM",
        "expiry_date": "2026-10-19", "contracts": {"futures": [CONTRACT], "options": []}}}
    assert parse_expired_symbols(response, UNDERLYING, "2026-10-19") == [CONTRACT]


def test_expired_contract_parser_rejects_non_mcx_or_wrong_expiry():
    response = {"s": "ok", "code": 200, "data": {"symbol": "CRUDEOILM",
        "expiry_date": "2026-09-21", "contracts": {"futures": ["NSE:SBIN26OCTFUT"]}}}
    with pytest.raises(FyersDataError):
        parse_expired_symbols(response, UNDERLYING, "2026-10-19")


def test_error_classification_distinguishes_auth_entitlement_quota_and_no_data():
    assert classify_response({"code": -8}, 401) == "AUTHENTICATION_FAILED"
    assert classify_response({"code": -5}, 403) == "ENTITLEMENT_DENIED"
    assert classify_response({"code": 429}, 429) == "RATE_LIMITED"
    assert classify_response({"s": "no_data", "code": 200}) == "NO_DATA"
    assert classify_response({"code": -50, "data": {"symbol": "Invalid symbol provided"}}, 422) == "SYMBOL_NOT_FOUND"


def test_intraday_date_chunks_respect_100_day_limit_and_are_nonoverlapping():
    chunks = list(split_date_range("2026-01-01", "2026-04-10", 100))
    assert chunks == [("2026-01-01", "2026-04-10")]
    chunks = list(split_date_range("2026-01-01", "2026-04-11", 100))
    assert chunks == [("2026-01-01", "2026-04-10"), ("2026-04-11", "2026-04-11")]


def test_expired_ohlcv_parser_validates_identity_timestamp_and_ohlc():
    response = {"s": "ok", "code": 200, "symbol": CONTRACT,
        "columns": ["timestamp", "open", "high", "low", "close", "volume"],
        "candles": [[1791325800, 100, 104, 99, 103, 12]]}
    frame = parse_candles(response, CONTRACT)
    assert frame.iloc[0].open == 100
    assert str(frame.iloc[0].timestamp.tz) == "Asia/Kolkata"


def test_expired_ohlcv_rejects_bad_envelope_without_repair():
    response = {"s": "ok", "code": 200, "symbol": CONTRACT,
        "columns": ["timestamp", "open", "high", "low", "close", "volume"],
        "candles": [[1791325800, 100, 98, 99, 97, 12]]}
    with pytest.raises(FyersDataError, match="invalid OHLC"):
        parse_candles(response, CONTRACT)


def test_observed_fyers_sep26_response_is_rejected_for_two_open_above_high_rows():
    # Values below came from the retained FYERS response for
    # MCX:CRUDEOILM26SEPFUT, 60-minute, 2026-08-01..2026-10-08.
    # Optional OI is the seventh named field and must not shift OHLCV.
    response = {"s": "ok", "symbol": "MCX:CRUDEOILM26SEPFUT",
        "columns": ["timestamp", "open", "high", "low", "close", "volume", "open_interest"],
        "candles": [[1787542200, 8357, 8224, 8195, 8206, 9952, 38409],
                    [1788406200, 8597, 8591, 8557, 8568, 6961, 46296]]}
    with pytest.raises(FyersDataError, match="invalid OHLC"):
        parse_candles(response, "MCX:CRUDEOILM26SEPFUT")


def test_optional_columns_are_parsed_by_name_without_shifting_fixed_ohlcv():
    response = {"s": "ok", "code": 200, "symbol": CONTRACT,
        "columns": ["timestamp", "open", "high", "low", "close", "volume",
                    "open_interest", "delta"],
        "candles": [[1791325800, 100, 104, 99, 103, 12, 200, None]]}
    frame = parse_candles(response, CONTRACT)
    assert frame.iloc[0].volume == 12
    assert frame.iloc[0].open_interest == 200
    assert frame.iloc[0].provider_columns == '["timestamp","open","high","low","close","volume","open_interest","delta"]'


def test_active_history_parser_accepts_standard_candles_with_exact_request_symbol():
    response = {"s": "ok", "code": 200,
        "candles": [[1791325800, 100, 104, 99, 103, 12]]}
    frame = parse_active_candles(response, CONTRACT)
    assert frame.iloc[0].close == 103
    assert pd_is_na(frame.iloc[0].open_interest)


def pd_is_na(value):
    import pandas as pd
    return pd.isna(value)


def test_active_history_parser_rejects_mismatched_echoed_symbol():
    response = {"s": "ok", "code": 200, "symbol": "MCX:GOLDM26OCTFUT",
        "candles": [[1791325800, 100, 104, 99, 103, 12]]}
    with pytest.raises(FyersDataError, match="symbol mismatch"):
        parse_active_candles(response, CONTRACT)


class FakeFyers:
    def __init__(self):
        self.expiry_calls = 0
        self.contract_calls = 0
        self.history_calls = 0

    def expiry_dates(self, symbol, start, end):
        self.expiry_calls += 1
        return {"s": "ok", "code": 200, "data": {"symbol": "CRUDEOILM",
            "expiry_dates": {"futures": ["2026-10-19"]}}}

    def expired_contracts(self, symbol, expiry):
        self.contract_calls += 1
        return {"s": "ok", "code": 200, "data": {"symbol": "CRUDEOILM",
            "expiry_date": expiry, "contracts": {"futures": [CONTRACT]}}}

    def expired_history(self, symbol, resolution, start, end, include_oi):
        self.history_calls += 1
        return {"s": "ok", "code": 200, "symbol": symbol,
            "columns": ["timestamp", "open", "high", "low", "close", "volume"],
            "candles": [[1791325800, 100, 104, 99, 103, 12]]}


def test_discovery_and_history_are_cached_idempotently(tmp_path):
    client = FakeFyers()
    collector = FyersContractCollector(client, tmp_path, daily_request_limit=10)
    collector.discover(UNDERLYING, "2026-10-01", "2026-10-31")
    collector.contracts_for_expiry(UNDERLYING, "2026-10-19")
    first = collector.collect_history("CRUDEOILM", CONTRACT, "2026-10-19", "60",
                                      "2026-10-01", "2026-10-31")
    second = collector.collect_history("CRUDEOILM", CONTRACT, "2026-10-19", "60",
                                       "2026-10-01", "2026-10-31")
    assert first == second
    assert (client.expiry_calls, client.contract_calls, client.history_calls) == (1, 1, 1)
    saved = json.loads((tmp_path / "discovery" / next(p.name for p in (tmp_path / "discovery").glob("*.json") if not p.name.startswith("contracts_"))).read_text())
    assert saved["provider"] == "FYERS" and saved["sha256"]


def test_daily_request_budget_fails_closed(tmp_path):
    client = FakeFyers()
    collector = FyersContractCollector(client, tmp_path, daily_request_limit=1)
    collector.discover(UNDERLYING, "2026-10-01", "2026-10-31")
    with pytest.raises(FyersDataError) as exc:
        collector.contracts_for_expiry(UNDERLYING, "2026-10-19")
    assert exc.value.status == "RATE_LIMITED"


def test_supported_products_remain_distinct_in_collection_paths():
    from audit.mcx_futures_backtest.fyers_expired_contract_collector import UNDERLYING_PRODUCTS
    assert set(UNDERLYING_PRODUCTS) == {"GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"}
