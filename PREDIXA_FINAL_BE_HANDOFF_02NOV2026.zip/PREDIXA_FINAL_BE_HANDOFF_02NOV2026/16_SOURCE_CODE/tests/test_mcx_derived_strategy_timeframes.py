"""TEST_ONLY assertions for OHLC derivation from exact 60m MCX candles."""
import pandas as pd
import pytest

from audit.mcx_futures_backtest.derive_strategy_timeframes import derive_strategy_timeframes


def candles(timestamps):
    return pd.DataFrame({"timestamp": pd.DatetimeIndex(timestamps),
        "open": range(100, 100 + len(timestamps)),
        "high": [x + 2 for x in range(100, 100 + len(timestamps))],
        "low": [x - 1 for x in range(100, 100 + len(timestamps))],
        "close": [x + 1 for x in range(100, 100 + len(timestamps))],
        "volume": [10] * len(timestamps),
        "contract_symbol": ["MCX:CRUDEOILM26OCTFUT"] * len(timestamps),
        "underlying": ["CRUDEOILM"] * len(timestamps)})


def test_60m_derivation_keeps_intraday_buckets_inside_e1_session():
    times = [pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata") + pd.Timedelta(hours=i)
        for i in range(15)] + [pd.Timestamp("2026-10-02 09:00", tz="Asia/Kolkata")]
    result = derive_strategy_timeframes(candles(times))
    two_forty = result["two_forty"]
    assert list(two_forty.source_bar_count) == [4, 4, 4, 3, 1]
    assert two_forty.e1_session_id.nunique() == 2
    assert result["sixty"].contract_symbol.nunique() == 1


def test_60m_daily_weekly_monthly_are_ohlc_aggregations_without_fill():
    times = [pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata") + pd.Timedelta(hours=i)
        for i in range(15)] + [pd.Timestamp("2026-10-02 09:00", tz="Asia/Kolkata")]
    result = derive_strategy_timeframes(candles(times))
    assert len(result["daily"]) == 2
    assert len(result["weekly"]) == 1
    assert len(result["monthly"]) == 1
    assert result["daily"].iloc[0].volume == 150
    assert result["daily"].iloc[1].volume == 10
    assert all("e1_session_id" in result[name] for name in result)


def test_60m_derivation_rejects_bad_ohlc_and_naive_timestamps():
    frame = candles([pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata")])
    frame.loc[0, "high"] = 99
    with pytest.raises(ValueError, match="invalid OHLCV"):
        derive_strategy_timeframes(frame)
    frame = candles([pd.Timestamp("2026-10-01 09:00")])
    with pytest.raises(ValueError, match="timezone-aware"):
        derive_strategy_timeframes(frame)
