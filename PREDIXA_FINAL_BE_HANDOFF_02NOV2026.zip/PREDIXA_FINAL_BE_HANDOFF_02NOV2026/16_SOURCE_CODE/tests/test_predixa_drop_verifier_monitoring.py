import json
import subprocess
import sys
from pathlib import Path

from scripts import predixa_drop_verifier as verifier


ROOT = Path(__file__).resolve().parents[1]


def test_source_manifest_detects_added_removed_and_modified_paths():
    previous = [
        {"path": "scripts/a.py", "sha256": "old", "size_bytes": 1},
        {"path": "scripts/gone.py", "sha256": "gone", "size_bytes": 1},
    ]
    current = [
        {"path": "scripts/a.py", "sha256": "new", "size_bytes": 2},
        {"path": "scripts/new.py", "sha256": "fresh", "size_bytes": 1},
    ]
    assert verifier.compare_source_manifests(previous, current) == {
        "added": ["scripts/new.py"],
        "removed": ["scripts/gone.py"],
        "modified": ["scripts/a.py"],
    }


def test_verifier_writes_structured_report_and_jsonl_event(tmp_path):
    report_dir = tmp_path / "report"
    event_log = tmp_path / "events" / "drop-verifier.jsonl"
    result = subprocess.run(
        [sys.executable, "scripts/predixa_drop_verifier.py", ".",
         "--report-dir", str(report_dir), "--event-log", str(event_log)],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    report = json.loads((report_dir / "verify_report.json").read_text(encoding="utf-8"))
    event = json.loads(event_log.read_text(encoding="utf-8").strip())
    assert report["verdict"] == "CLEAR FOR PAPER"
    assert report["source_manifest"]
    assert event["event_type"] == "predixa_drop_verifier"
    assert event["exit_code"] == 0
    assert event["counts"]["PASS"] == 12


def test_invalid_previous_report_fails_closed(tmp_path):
    bad_report = tmp_path / "broken.json"
    bad_report.write_text("not-json", encoding="utf-8")
    result = subprocess.run(
        [sys.executable, "scripts/predixa_drop_verifier.py", ".",
         "--previous-report", str(bad_report), "--no-report"],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    assert result.returncode == 2
    assert "HOLD: invalid source-change baseline" in result.stdout


def test_requested_event_log_write_failure_fails_closed(tmp_path):
    event_log_as_directory = tmp_path / "event-directory"
    event_log_as_directory.mkdir()
    result = subprocess.run(
        [sys.executable, "scripts/predixa_drop_verifier.py", ".",
         "--event-log", str(event_log_as_directory), "--no-report"],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    assert result.returncode == 2
    assert "HOLD: automated event log was not written" in result.stdout
