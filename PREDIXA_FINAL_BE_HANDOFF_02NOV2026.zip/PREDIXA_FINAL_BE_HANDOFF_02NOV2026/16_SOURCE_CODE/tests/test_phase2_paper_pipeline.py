"""Isolated Phase 2 coverage for orchestration and the existing PAPER lifecycle."""
from datetime import date, datetime
from pathlib import Path

from sqlalchemy import create_engine, inspect

from apps.backend.api.bucket_orders_future import bucket_status_date_column
from apps.pipelines import miscellaneous_jobs as jobs
from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
from data_fetchers.fyers.liquid_futures_data_updater import GraduatedPaperFuturesDataHandler
from scripts import futures_graduated_live_scanner as futures_scanner
from scripts import mcx_graduated_live_scanner as mcx_scanner
from shared.db.db_model import Base


class _Connection:
    def __init__(self, state):
        self.state, self.executed = state, []

    def execute(self, statement, parameters=None):
        self.executed.append((str(statement), parameters or {}))
        sql = str(statement)
        if f"{self.state['table']} set is_trade_started=1" in sql.lower():
            self.state["started"] = True
        if "set order_status" in sql.lower():
            self.state["evaluated"] = True

    def commit(self):
        return None

    def close(self):
        return None


class _PaperEvaluatorDB:
    def __init__(self, state):
        self.state, self.connection = state, _Connection(state)

    def raw_connection(self):
        return self.connection

    def raw_query(self, statement):
        sql = str(statement)
        if self.state["table"] not in sql:
            return []
        if "is_trade_started=0" in sql:
            return [] if self.state["started"] else [self.state["order"]]
        if "is_evaluated=0" in sql:
            return ([self.state["order"]]
                    if self.state["started"] and not self.state["evaluated"] else [])
        return []


def _state(table="future_order_master"):
    return {
        "table": table,
        "started": False,
        "evaluated": False,
        "order": {
            "order_id": 77, "stock_tick": "TEST", "expiry_date": "30-12-2030",
            "entry_price": 100.0, "stoploss_price": 90.0, "target_price": 120.0,
            "stock_quantity": 650, "time_frame": 1,
            "purchased_cmp_date": "2030-01-01T09:15", "entry_timestamp": "2030-01-01 09:20:00",
            "order_type": "BUY",
        },
    }


def test_existing_evaluator_runs_one_paper_entry_and_one_target_completion(monkeypatch):
    state = _state()
    fake_db = _PaperEvaluatorDB(state)
    monkeypatch.setattr(jobs, "db", fake_db)
    monkeypatch.setattr(jobs, "check_entry_hit_fc", lambda *args: (True, "2030-01-01 09:20:00"))
    monkeypatch.setattr(jobs, "evaluate_order_status_fc", lambda **kwargs: {
        "status": "success", "reason": "Target hit", "completed_on": datetime(2030, 1, 1, 10, 0),
    })

    jobs.update_order_entry_stats()
    jobs.update_order_entry_stats()  # repeat is idempotent after the simulated start
    jobs.update_order_status()
    jobs.update_order_status()  # repeat is idempotent after completion

    assert state["started"] and state["evaluated"]
    entry_updates = [sql for sql, _ in fake_db.connection.executed
                     if "future_order_master set is_trade_started=1" in sql.lower()]
    completion_updates = [params for sql, params in fake_db.connection.executed
                          if "set order_status" in sql.lower()]
    assert len(entry_updates) == len(completion_updates) == 1
    assert completion_updates[0]["is_eval"] == 1
    assert completion_updates[0]["order_status"] == "{'status': 'success', 'reason': 'Target hit'}"


def test_existing_evaluator_records_stop_and_keeps_no_entry_monitored(monkeypatch):
    state = _state()
    fake_db = _PaperEvaluatorDB(state)
    monkeypatch.setattr(jobs, "db", fake_db)
    monkeypatch.setattr(jobs, "check_entry_hit_fc", lambda *args: (False, None))
    jobs.update_order_entry_stats()
    assert not state["started"]
    assert not fake_db.connection.executed

    state["started"] = True
    monkeypatch.setattr(jobs, "evaluate_order_status_fc", lambda **kwargs: {
        "status": "failed", "reason": "Stoploss hit", "completed_on": datetime(2030, 1, 1, 10, 0),
    })
    jobs.update_order_status()
    completion = [params for sql, params in fake_db.connection.executed
                  if "set order_status" in sql.lower()]
    assert len(completion) == 1
    assert completion[0]["is_eval"] == 1
    assert "Stoploss hit" in completion[0]["order_status"]


def test_existing_evaluator_runs_mcx_entry_and_stop_completion(monkeypatch):
    state = _state("commodity_order_master")
    fake_db = _PaperEvaluatorDB(state)
    monkeypatch.setattr(jobs, "db", fake_db)
    monkeypatch.setattr(jobs, "check_entry_hit_fc", lambda *args: (True, "2030-01-01 09:20:00"))
    monkeypatch.setattr(jobs, "evaluate_order_status_fc", lambda **kwargs: {
        "status": "failed", "reason": "Stoploss hit", "completed_on": datetime(2030, 1, 1, 10, 0),
    })

    jobs.update_order_entry_stats()
    jobs.update_order_status()

    entry_updates = [sql for sql, _ in fake_db.connection.executed
                     if "commodity_order_master set is_trade_started=1" in sql.lower()]
    completion = [params for sql, params in fake_db.connection.executed
                  if "set order_status" in sql.lower()]
    assert len(entry_updates) == len(completion) == 1
    assert completion[0]["is_eval"] == 1
    assert "Stoploss hit" in completion[0]["order_status"]


def test_phase1_migration_columns_match_models_in_isolated_sqlite():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    for table in ("future_order_master", "commodity_order_master",
                  "oms_order_bucket_future", "oms_order_bucket_commodity"):
        columns = {column["name"] for column in inspect(engine).get_columns(table)}
        assert {"execution_mode", "candidate_source"}.issubset(columns)
    migration = Path("scripts/db_migrations/20261025_phase1_execution_provenance.sql").read_text()
    for table in ("future_order_master", "commodity_order_master",
                  "oms_order_bucket_future", "oms_order_bucket_commodity"):
        assert f"ALTER TABLE {table}" in migration


def test_full_universe_paper_updater_reuses_base_source_and_near_next_cutoff(monkeypatch):
    calls = []
    monkeypatch.setattr(Indian_future_data_handler, "get_all_stock_symbols",
                        lambda self, exchange=None: calls.append(exchange) or ["AAA", "BBB"])
    monkeypatch.setattr(Indian_future_data_handler, "get_latest_fyers_futures_symbol", lambda self, symbol, max_contracts=3: [
        {"symbol": f"NSE:{symbol}30OCTFUT", "expiry": "30-10-2030"},
        {"symbol": f"NSE:{symbol}27NOVFUT", "expiry": "27-11-2030"},
        {"symbol": f"NSE:{symbol}25DECFUT", "expiry": "25-12-2030"},
    ])
    handler = GraduatedPaperFuturesDataHandler.__new__(GraduatedPaperFuturesDataHandler)
    assert handler.get_all_stock_symbols() == ["AAA", "BBB"]
    assert calls == ["NSEFO"]
    selected = handler.get_latest_fyers_futures_symbol("AAA")
    assert [row["expiry"] for row in selected] == ["30-10-2030", "27-11-2030"]


def test_programmatic_scanners_do_not_parse_cli_or_activate_broker(monkeypatch, tmp_path):
    futures_calls, mcx_calls = [], []

    class Futures:
        def run(self, **kwargs):
            futures_calls.append(kwargs)
            return "futures-output"

    class MCX:
        def run(self, jobs, output):
            mcx_calls.append((list(jobs), output))
            return "mcx-output"

    monkeypatch.setattr(futures_scanner, "FuturesGraduatedLiveReadonlyScanner", Futures)
    monkeypatch.setattr(mcx_scanner, "MCXGraduatedLiveScanner", MCX)
    monkeypatch.setattr(mcx_scanner, "default_mcx_jobs", lambda *args: ["mcx-job"])

    assert futures_scanner.run_graduated_futures_scan(
        timeframe_ids=[1], output_dir=tmp_path, write_files=False) == "futures-output"
    assert futures_calls == [{"timeframe_ids": [1], "max_symbols": None, "last_d_time": None,
                              "min_expiry_days": 5, "output_dir": tmp_path, "write_files": False}]
    assert mcx_scanner.run_graduated_mcx_scan(timeframes=(3, 4), output_path=tmp_path / "mcx.jsonl") == "mcx-output"
    assert mcx_calls == [(["mcx-job"], tmp_path / "mcx.jsonl")]


def test_bucket_paper_status_uses_candidate_date_and_current_api_default():
    from shared.db.req_model import GetOrder

    assert bucket_status_date_column("paper_monitoring") == "purchased_cmp_date"
    assert bucket_status_date_column("success") == "entry_timestamp"
    assert GetOrder().end_date == date.today().isoformat()


def test_stock_process_registers_disabled_programmatic_graduated_jobs():
    source = Path("apps/pipelines/stock_process.py").read_text()
    assert "raise SystemExit(futureScanner)" not in source
    assert "return run_graduated_futures_scan()" in source
    assert "return run_graduated_mcx_scan()" in source
    assert "mcx_graduated_scanner_schedule" in source
    assert "future_graduated_scanner_schedule" in source
