"""Offline/local SQLite tests for the brokerless MCX observation path.

All prices and setups in this module are deterministic test fixtures and are
not market data or strategy-performance evidence.
"""
from datetime import datetime

from scripts.graduated_live_config import PAPER, mcx_execution_permitted
from scripts.mcx_graduated_live_scanner import MCXScanJob, run_mcx_paper_observation
from scripts.paper_observation import (
    MCX_OBSERVATION_SOURCE,
    PaperObservationConfig,
    PaperObservationStore,
    classify_observation_setups,
    initialize_local_paper_database,
    local_paper_session_factory,
    validate_local_paper_config,
)
from shared.db.db_model import Commodity_Order, CommoditiesMaster, OMSOrderBucketCommodity, TradeSignal


def _local_database(tmp_path):
    # Historical/offline fixtures may exercise the research implementation,
    # but this is not an operational authorization path.
    import scripts.paper_observation as observation
    observation.MCX_PAPER_OBSERVATION_AUTHORIZED = True
    path = tmp_path / "paper-observation.sqlite3"
    initialize_local_paper_database(path, local_root=tmp_path)
    config = PaperObservationConfig(True, "LOCAL_PAPER", path, tmp_path)
    factory, engine = local_paper_session_factory(config)
    session = factory()
    try:
        session.add(CommoditiesMaster(
            symbol="CRUDEOILM", full_name="test fixture", exchange="MCX",
            unit="TEST_ONLY", category="ENERGY", contract_type="Mini", is_active=True,
        ))
        session.commit()
    finally:
        session.close()
        engine.dispose()
    return config


def _job(mode=PAPER, symbol="CRUDEOILM"):
    return MCXScanJob(symbol, "30112026", 4, ["daily", "sixty"], datetime(2026, 11, 2), mode)


def _formatted():
    return {
        "BUY": {"entry_price": 100.0, "stop_loss": 90.0, "target_price": 120.0},
        "BUY_TIMESTAMPS": {"entry_price_timestamp": "2026-11-02T10:15:00+05:30"},
        "BUY_RRR": 2.0,
        "e_regime": "SW", "a_regime": "UP", "x_regime": "SW",
    }


def test_local_config_requires_flag_local_environment_and_existing_sqlite(tmp_path):
    assert not mcx_execution_permitted()
    with __import__("pytest").raises(RuntimeError, match="OPERATIONALLY_HELD"):
        validate_local_paper_config(PaperObservationConfig(False, "LOCAL_PAPER", tmp_path / "x.sqlite"))
    with __import__("pytest").raises(RuntimeError, match="OPERATIONALLY_HELD"):
        validate_local_paper_config(PaperObservationConfig(True, "PRODUCTION", tmp_path / "x.sqlite"))
    with __import__("pytest").raises(RuntimeError, match="OPERATIONALLY_HELD"):
        validate_local_paper_config(PaperObservationConfig(True, "LOCAL_PAPER", tmp_path / "x.sqlite", tmp_path))
    with __import__("pytest").raises(RuntimeError, match="OPERATIONALLY_HELD"):
        validate_local_paper_config(PaperObservationConfig(True, "LOCAL_PAPER", tmp_path / "x.sqlite", tmp_path / "safe"))
    unmarked = tmp_path / "unmarked.sqlite"
    import sqlite3
    sqlite3.connect(unmarked).close()
    with __import__("pytest").raises(RuntimeError, match="OPERATIONALLY_HELD"):
        local_paper_session_factory(PaperObservationConfig(True, "LOCAL_PAPER", unmarked, tmp_path))


def test_disabled_observation_kill_switch_stops_before_strategy_or_database_write(tmp_path):
    config = _local_database(tmp_path)
    disabled = PaperObservationConfig(False, "LOCAL_PAPER", config.database_path, config.local_root)
    from scripts.paper_observation import MCXPaperObservationRunner
    calls = []
    runner = MCXPaperObservationRunner(
        lambda *args: calls.append(args), lambda *args, **kwargs: _formatted(),
        PaperObservationStore(lambda: None), disabled)
    import pytest
    with pytest.raises(RuntimeError, match="DISABLED"):
        runner.run([_job()])
    assert calls == []


def test_mcx_observation_pipeline_persists_and_monitor_reads_idempotently(tmp_path, monkeypatch):
    config = _local_database(tmp_path)
    factory, engine = local_paper_session_factory(config)
    engine.dispose()
    store = PaperObservationStore(factory)
    strategy_calls = []
    forbidden_broker_calls = []

    def setup_engine(*args):
        strategy_calls.append(args)
        return {"fixture": "strategy-output"}

    def formatter(raw, **kwargs):
        assert raw == {"fixture": "strategy-output"}
        return _formatted()

    from shared.db import fyers_req_model
    def forbidden(*args, **kwargs):
        forbidden_broker_calls.append((args, kwargs))
        raise AssertionError("paper observation reached broker mutation")
    for name in ("place_order", "place_gtt_order", "place_futures_entry_gtt",
                 "cancel_gtt_order", "exit_positions"):
        monkeypatch.setattr(fyers_req_model.FyersClient, name, forbidden, raising=False)

    # Exercise the scanner's separate observation entry point using a marked
    # test-only SQLite file, not the shared application database.
    from scripts.mcx_graduated_live_scanner import run_mcx_paper_observation
    output = run_mcx_paper_observation(
        [_job(), _job()], config=config, engine=setup_engine, formatter=formatter)

    assert [row["persistence"]["status"] for row in output] == ["CREATED", "EXISTING"]
    assert len(strategy_calls) == 2
    assert forbidden_broker_calls == []
    session = factory()
    try:
        assert session.query(TradeSignal).count() == 1
        order = session.query(Commodity_Order).one()
        bucket = session.query(OMSOrderBucketCommodity).one()
        assert order.execution_mode == bucket.execution_mode == "PAPER"
        assert order.candidate_source == bucket.candidate_source == MCX_OBSERVATION_SOURCE
        assert order.edge_validation == bucket.edge_validation == "UNVALIDATED"
        assert order.trading_status == bucket.trading_status == "SIMULATED"
        assert order.order_status == bucket.order_status == "paper_monitoring"
        assert order.stock_quantity == bucket.stock_quantity == 1
        assert bucket.gtt_id is None and bucket.id_fyers is None
        assert (order.entry_price, order.stoploss_price, order.target_price) == (100.0, 90.0, 120.0)
    finally:
        session.close()
    visible = store.orders("MCX")
    assert len(visible) == 1
    assert visible[0]["segment"] == "MCX"
    assert visible[0]["execution_mode"] == "PAPER"
    assert visible[0]["trading_status"] == "SIMULATED"
    assert visible[0]["edge_validation"] == "UNVALIDATED"
    assert visible[0]["signal_timestamp"] == "2026-11-02T04:45:00+00:00"
    assert visible[0]["fyers_symbol"] == "MCX:CRUDEOILM26NOVFUT"
    assert visible[0]["updated_at"]

    # Exercise the mounted monitoring handler against the same explicit local
    # test database without touching the shared application DB connection.
    import asyncio
    from starlette.requests import Request
    from apps.backend.api.bucket_orders_commodity import get_mcx_paper_observation_orders
    import scripts.paper_observation as observation_module
    monkeypatch.setattr(observation_module.PaperObservationConfig,
                        "from_environment", classmethod(lambda cls: config))
    scope = {"type": "http", "method": "GET", "path": "/paper-observation/mcx/orders",
             "headers": [], "query_string": b"", "scheme": "http",
             "server": ("testserver", 80), "client": ("testclient", 123)}
    monitored = asyncio.run(get_mcx_paper_observation_orders(Request(scope)))
    assert monitored.msg == "success"
    assert len(monitored.response) == 1
    assert monitored.response[0]["candidate_source"] == MCX_OBSERVATION_SOURCE
    from fastapi.encoders import jsonable_encoder
    encoded_monitor_response = jsonable_encoder(monitored)
    assert encoded_monitor_response["response"][0]["trading_status"] == "SIMULATED"


def test_paper_flag_cannot_enter_mcx_real_scanner_or_persist_real(tmp_path):
    config = _local_database(tmp_path)
    calls = []
    result = run_mcx_paper_observation(
        [_job(mode="REAL")], config=config,
        engine=lambda *args: calls.append(args), formatter=lambda *args, **kwargs: _formatted(),
    )
    assert calls == []
    assert result[0]["status"] == "REJECTED"
    assert "REQUIRES_PAPER_MODE" in result[0]["reason"]
    assert not mcx_execution_permitted()


def test_observation_classification_keeps_live_gate_denied_and_rejects_unknown_symbol():
    setup = classify_observation_setups(_formatted(), _job())[0]
    assert setup["gate_size_multiplier"] == 0
    assert setup["gate_tier"] == "DENY"
    assert setup["edge_validation"] == "UNVALIDATED"
    import pytest
    with pytest.raises(ValueError, match="SYMBOL_NOT_SUPPORTED"):
        classify_observation_setups(_formatted(), _job(symbol="UNKNOWN"))


def test_sell_setup_uses_existing_sell_levels_and_is_stored_as_simulated():
    formatted = {
        "SELL": {"entry_price": 100, "stop_loss": 110, "target_price": 80},
        "SELL_TIMESTAMPS": {"entry_price_timestamp": "2026-11-02T10:15:00+05:30"},
        "e_regime": "DOWN", "a_regime": "SW",
    }
    setup = classify_observation_setups(formatted, _job())[0]
    assert setup["side"] == "SELL"
    assert setup["quantity"] == 1
    assert setup["trading_status"] == "SIMULATED"


def test_failed_write_rolls_back_and_does_not_fallback_to_broker(tmp_path):
    config = _local_database(tmp_path)
    factory, engine = local_paper_session_factory(config)
    engine.dispose()
    session = factory()
    try:
        session.query(CommoditiesMaster).delete()
        session.commit()
    finally:
        session.close()
    store = PaperObservationStore(factory)
    setup = classify_observation_setups(_formatted(), _job())[0]
    import pytest
    with pytest.raises(ValueError, match="ACTIVE_COMMODITY_MASTER_REQUIRED"):
        store.persist(setup)
    session = factory()
    try:
        assert session.query(TradeSignal).count() == 0
        assert session.query(Commodity_Order).count() == 0
        assert session.query(OMSOrderBucketCommodity).count() == 0
    finally:
        session.close()


def test_same_signal_identity_with_changed_levels_is_rejected_not_duplicated(tmp_path):
    config = _local_database(tmp_path)
    factory, engine = local_paper_session_factory(config)
    engine.dispose()
    store = PaperObservationStore(factory)
    setup = classify_observation_setups(_formatted(), _job())[0]
    store.persist(setup)
    changed = dict(setup, entry=101.0)
    import pytest
    with pytest.raises(ValueError, match="IDENTITY_LEVEL_MISMATCH"):
        store.persist(changed)
    session = factory()
    try:
        assert session.query(Commodity_Order).count() == 1
        assert session.query(OMSOrderBucketCommodity).count() == 1
    finally:
        session.close()
