import json

from audit.mcx_futures_backtest.run_clean_phase1 import assemble_cached_inputs, validate_bundle


def test_clean_runner_requires_complete_fyers_dated_contract_manifest_before_replay():
    underlyings = ["GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"]
    bundle = {"schema_version": 1, "provider": "FYERS", "coverage_start": "2025-11-01",
        "coverage_end": "2026-11-01", "validation_as_of": "2026-11-01T23:30:00+05:30",
        "underlyings": [{"underlying": name} for name in underlyings]}
    report = validate_bundle(bundle)
    assert report["status"] == "UNVERIFIED"
    assert any("missing" in error.lower() or "keyerror" in error.lower() for error in report["errors"])
    assert not report["input_hashes"]


def test_runner_schema_and_contract_response_assets_are_checked_in():
    from pathlib import Path
    schema = Path("audit/mcx_futures_backtest/clean_phase1_bundle.schema.json")
    assert json.loads(schema.read_text())["properties"]["provider"]["const"] == "FYERS"


def test_automatic_assembly_reports_cached_sources_and_does_not_forge_missing_intervals(tmp_path):
    import hashlib
    root = tmp_path / "cache"
    discovery = root / "discovery"
    discovery.mkdir(parents=True)
    contracts = ["MCX:CRUDEOILM26AUGFUT"]
    (discovery / "contracts_fixture.json").write_text(json.dumps({
        "provider": "FYERS", "status": "SUCCESS", "requested_symbol": "MCX:CRUDEOILM26OCTFUT",
        "expiry_date": "2026-08-19", "contracts": contracts,
        "sha256": hashlib.sha256(json.dumps(contracts, sort_keys=True).encode()).hexdigest()}))
    report = assemble_cached_inputs(root, tmp_path / "assembled")
    assert report["status"] == "BLOCKED_MISSING_DATA"
    contract = report["discovered_contracts"]["CRUDEOILM"][0]
    assert contract["contract_symbol"] == contracts[0]
    assert contract["active_from"] is None and contract["active_to"] is None
    assert report["authoritative_bundle_emitted"] is False
    assert (tmp_path / "assembled" / "bundle_readiness.json").is_file()
    assert (tmp_path / "assembled" / "contract_acquisition_manifest.csv").is_file()


def test_automatic_assembly_verifies_source_hashes_and_marks_only_inventory_ready(tmp_path):
    import hashlib
    root = tmp_path / "cache"
    discovery = root / "discovery"
    source = root / "CRUDEOILM" / "contract" / "60"
    discovery.mkdir(parents=True)
    source.mkdir(parents=True)
    symbol = "MCX:CRUDEOILM26AUGFUT"
    contracts_path = discovery / "contracts_fixture.json"
    contracts_path.write_text(json.dumps({"provider": "FYERS", "status": "SUCCESS",
        "requested_symbol": "MCX:CRUDEOILM26OCTFUT", "expiry_date": "2026-08-19",
        "contracts": [symbol], "sha256": hashlib.sha256(json.dumps([symbol], sort_keys=True).encode()).hexdigest()}))
    bars_path = source / "bars.csv"
    bars_path.write_text("underlying,contract_symbol,contract_expiry,resolution,timestamp,open,high,low,close,volume\n"
        "CRUDEOILM,MCX:CRUDEOILM26AUGFUT,2026-08-19,60,2026-08-03T09:00:00+05:30,100,102,99,101,10\n")
    bars_hash = hashlib.sha256(bars_path.read_bytes()).hexdigest()
    response_path = source / "provider_response.json"
    response_path.write_text('{"s":"ok"}')
    response_hash = hashlib.sha256(response_path.read_bytes()).hexdigest()
    (source / "metadata.json").write_text(json.dumps({"provider": "FYERS", "status": "SUCCESS",
        "underlying": "CRUDEOILM", "contract_symbol": symbol, "expiry_date": "2026-08-19",
        "resolution": "60", "normalized_bars_sha256": bars_hash,
        "raw_response_sha256": response_hash, "source_endpoint": "/history/fno/expired/historical-data"}))
    report = assemble_cached_inputs(root, tmp_path / "assembled")
    item = next(x for x in report["source_files"] if x["bars_path"] == str(bars_path))
    assert item["cache_hashes_valid"] is True
    assert item["exact_symbol_rows_valid"] is True
    assert report["authoritative_bundle_emitted"] is False
    assert any("listing/effective intervals" in issue for issue in report["blockers"])


def test_sidecar_source_can_be_derived_for_diagnostics_without_hash_promotion(tmp_path, monkeypatch):
    root = tmp_path / "cache"
    (tmp_path / "research/zone_series_comparison/metadata").mkdir(parents=True)
    (tmp_path / "research/zone_series_comparison/data").mkdir(parents=True)
    monkeypatch.chdir(tmp_path)
    bars = tmp_path / "research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv"
    bars.write_text(
        "timestamp,open,high,low,close,volume\n"
        "2026-10-05T09:00:00+05:30,100,102,99,101,10\n"
        "2026-10-05T10:00:00+05:30,101,103,100,102,11\n")
    (tmp_path / "research/zone_series_comparison/metadata/fyers_raw.json").write_text(json.dumps({
        "source_broker": "FYERS", "api_symbol": "MCX:CRUDEOILM26OCTFUT", "pull_type": "dated_raw",
        "continuous_flag": "0", "contract_expiry": "2026-10-19", "resolution": "60",
        "total_rows": 2, "actual_first_timestamp_ist": "2026-10-05T09:00:00+05:30",
        "actual_last_timestamp_ist": "2026-10-05T10:00:00+05:30"}))
    report = assemble_cached_inputs(root, tmp_path / "assembled")
    source = next(x for x in report["source_files"] if x["contract_symbol"] == "MCX:CRUDEOILM26OCTFUT")
    assert source["exact_symbol_rows_valid"] is True
    assert source["cache_hashes_valid"] is False
    derived = [x for x in report["derived_strategy_frames"] if x["contract_symbol"] == source["contract_symbol"]]
    assert derived
    assert all(x["authoritative_series"] is False for x in derived)
    assert all(x["provenance_class"] == "SIDECAR_VERIFIED_NO_RAW_PROVIDER_RESPONSE" for x in derived)
