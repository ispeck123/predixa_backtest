"""Offline monitoring API contract tests for simulated derivatives orders."""
import asyncio

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from starlette.requests import Request

from apps.backend.api import bucket_orders_future
from shared.db.db_model import Base, OMSOrderBucketFuture


def _request(path):
    return Request({"type": "http", "method": "GET", "path": path,
                    "headers": [], "query_string": b"", "scheme": "http",
                    "server": ("testserver", 80), "client": ("testclient", 123)})


def test_existing_nsefo_paper_order_is_visible_through_monitoring_api(monkeypatch):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    session = factory()
    try:
        bucket = OMSOrderBucketFuture(
            order_id=44, trade_signal_id=55, stock_tick="CANBK", country_id=1,
            time_frame=25, order_type="BUY", entry_price=100.0,
            stoploss_price=95.0, target_price=110.0, stock_quantity=1,
            purchased_cmp_date="2026-11-02T10:00", order_status="paper_monitoring",
            execution_mode="PAPER", candidate_source="GRADUATED_LIVE",
            approval_status="not_required", is_trade_started=0, is_evaluated=0,
        )
        session.add(bucket)
        session.commit()
        order_id = bucket.order_id
    finally:
        session.close()
    monkeypatch.setattr(bucket_orders_future, "db", type(
        "LocalDB", (), {"get_session": staticmethod(factory)})())
    response = asyncio.run(bucket_orders_future.get_bucket_order_future_by_id(
        order_id, _request(f"/bucket/orders/future/{order_id}")))
    assert response.msg == "success"
    assert response.response.execution_mode == "PAPER"
    assert response.response.candidate_source == "GRADUATED_LIVE"
    assert response.response.order_status == "paper_monitoring"
    engine.dispose()
