from datetime import date
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from apps.backend.api.bucket_orders_future import approve_existing_futures_candidate
from scripts.paper_execution import derivative_paper_orders_sql
from scripts import graduated_live_config as config
from scripts import scanner_fc
from scripts.futures_graduated_live_scanner import (
    FuturesScanJob,
    persist_futures_candidate,
)
from scripts.mcx_graduated_live_scanner import MCXScanJob, persist_mcx_candidate
from shared.db import db_utils
from shared.db.db_model import (
    Base,
    CommoditiesMaster,
    Commodity_Order,
    Future_Order,
    FuturesMaster,
    OMSOrderBucketCommodity,
    OMSOrderBucketFuture,
    TradeSignal,
)
from shared.db.fyers_req_model import FyersClient


class _RowsQuery:
    def __init__(self, rows):
        self.rows = rows

    def filter(self, *_args):
        return self

    def all(self):
        return self.rows

    def first(self):
        return None


class _InventorySession:
    def __init__(self, futures_rows=(), commodity_rows=()):
        self.futures_rows = list(futures_rows)
        self.commodity_rows = list(commodity_rows)

    def query(self, *entities):
        owner = getattr(entities[0], "class_", None)
        if owner is FuturesMaster:
            return _RowsQuery(self.futures_rows)
        if owner is CommoditiesMaster:
            return _RowsQuery(self.commodity_rows)
        return _RowsQuery([])

    def close(self):
        pass


def test_nsefo_full_universe_near_next_rollover_and_diagnostics(monkeypatch):
    rows = [
        ("AAA", date(2026, 10, 24)),
        ("AAA", date(2026, 11, 26)),
        ("AAA", date(2026, 11, 26)),
        ("AAA", date(2026, 12, 31)),
        ("AAA", date(2027, 1, 28)),
        ("BBB", date(2026, 12, 31)),
    ]
    monkeypatch.setattr(scanner_fc.dbc, "get_session", lambda: _InventorySession(futures_rows=rows))
    diagnostics = {}

    result = scanner_fc.build_futures_expiry_map(
        min_days=0, today=date(2026, 10, 25), diagnostics=diagnostics)

    assert result == [
        {"symbol": "AAA", "expiry": ["26112026", "31122026"]},
        {"symbol": "BBB", "expiry": ["31122026"]},
    ]
    assert diagnostics["configured_underlyings"] == 2
    assert diagnostics["near_selected"] == 2
    assert diagnostics["next_selected"] == 1
    assert diagnostics["far_excluded"] == 1
    assert diagnostics["expired_or_cutoff_excluded"] == 1


def test_mcx_full_universe_near_next_deduplicates_and_reports_missing(monkeypatch):
    monkeypatch.setattr(
        scanner_fc.dbc,
        "get_session",
        lambda: _InventorySession(commodity_rows=[
            ("CRUDEOILM",), ("SILVERM",), ("GOLDM",), ("GOLDGUINEA",),
        ]),
    )
    monkeypatch.setattr(scanner_fc, "ldb", {
        "indian_commodity_expiries": [
            {"symbol": "CRUDEOILM", "expiry": [
                "24-10-2026", "26-11-2026", "26-11-2026", "31-12-2026", "28-01-2027"]},
            {"symbol": "SILVERM", "expiry": ["31-12-2026"]},
            {"symbol": "GOLDGUINEA", "expiry": ["31-12-2026"]},
        ]
    })
    diagnostics = {}

    result = scanner_fc.build_commodity_expiry_map(
        min_days=0, today=date(2026, 10, 25), include_existing=True,
        diagnostics=diagnostics)

    assert result == [
        {"symbol": "CRUDEOILM", "expiry": ["26112026", "31122026"]},
        {"symbol": "SILVERM", "expiry": ["31122026"]},
    ]
    # GOLDGUINEA remains active for execution quotes, not detection/zones.
    assert diagnostics["configured_underlyings"] == 3
    assert diagnostics["missing_contracts"] == 1
    assert diagnostics["far_excluded"] == 1


def test_expiry_session_buffer_excludes_boundary_and_rolls_forward():
    expiries = [date(2026, 10, 30), date(2026, 11, 26), date(2026, 12, 31)]
    assert scanner_fc.select_near_next_expiries(
        expiries, min_days=5, today=date(2026, 10, 25)) == [
            date(2026, 11, 26), date(2026, 12, 31)]
    assert scanner_fc.select_near_next_expiries([], today=date(2026, 10, 25)) == []


def _database():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)


def _signal(exchange_id, symbol, timeframe, expiry):
    return TradeSignal(
        exchange_id=exchange_id, stock_name=symbol, time_fr=timeframe,
        country_id=1, price_cmp=100.0, trade_type="BUY", rrr=2.2,
        trade_data={}, prediction="NA", probability=0.0, is_active=True,
        is_send=0, exp_date=expiry,
    )


def test_positive_quantity_paper_routes_to_monitor_without_approval_or_broker(monkeypatch):
    factory = _database()
    session = factory()
    session.add(FuturesMaster(
        symbol="HDFCBANK", exchange="NSEFO", expiry_date=date(2026, 11, 26),
        instrument="FUTURES"))
    signal = _signal(11, "HDFCBANK", 1, "26112026")
    session.add(signal)
    session.commit()
    signal_id = signal.id
    session.close()
    monkeypatch.setattr(db_utils.dbc, "get_session", factory)
    job = FuturesScanJob(
        "HDFCBANK", "26112026", "26112026", 1,
        ["monthly", "weekly", "daily"], lot_size=650,
        execution_mode="PAPER")
    candidate = {"paper_target_price": 105.5, "setup_result": {"BUY": {
        "entry_price": 100.0, "stop_loss": 95.0, "target_price": 111.0}}}

    first = persist_futures_candidate(candidate, job, (True, signal_id))
    second = persist_futures_candidate(candidate, job, (False, signal_id))

    session = factory()
    order = session.query(Future_Order).one()
    bucket = session.query(OMSOrderBucketFuture).one()
    assert first["status"] == second["status"] == "PAPER_PENDING_APPROVAL"
    assert order.stock_quantity == bucket.stock_quantity == 650
    assert order.execution_mode == bucket.execution_mode == "PAPER"
    assert order.order_status == bucket.order_status == "paper_pending_approval"
    assert bucket.approval_status == "pending"
    assert session.query(Future_Order).count() == 1
    assert session.query(OMSOrderBucketFuture).count() == 1
    with pytest.raises(HTTPException) as exc:
        approve_existing_futures_candidate(
            bucket_id=bucket.bucket_id, status="approved", approved_by="7",
            session_factory=factory,
            risk_factory=lambda: pytest.fail("paper reached risk approval"),
            fyers_factory=lambda: pytest.fail("paper reached Fyers"),
        )
    assert exc.value.detail["reason_code"] == "FUT_REJECT_EXECUTION_MODE_NOT_REAL"
    session.close()


def test_mcx_paper_candidate_is_blocked_before_persistence(monkeypatch):
    factory = _database()
    session = factory()
    session.add(CommoditiesMaster(
        symbol="CRUDEOILM", exchange="MCX", contract_type="Mini", is_active=True))
    signal = _signal(10, "CRUDEOILM", 4, "26112026")
    session.add(signal)
    session.commit()
    signal_id = signal.id
    session.close()
    monkeypatch.setattr(db_utils.dbc, "get_session", factory)
    job = MCXScanJob("CRUDEOILM", "26112026", 4, [], None, "PAPER")
    candidate = {
        "execution_symbol": "CRUDEOILM", "entry": 100.0,
        "stop_loss": 95.0, "target": 111.0, "lot_size": 10,
        "status": "FIRE_PENDING_OPTION3", "requires_quote_translation": False,
    }

    import pytest
    with pytest.raises(RuntimeError, match="MCX_EXECUTION_BLOCKED"):
        persist_mcx_candidate(candidate, job, (True, signal_id))
    session = factory()
    assert session.query(Commodity_Order).count() == 0
    assert session.query(OMSOrderBucketCommodity).count() == 0
    session.close()


def test_broker_entry_boundary_rejects_paper_and_unknown_modes():
    client = FyersClient.__new__(FyersClient)
    client._client = SimpleNamespace(
        place_gtt_order=lambda **_kwargs: pytest.fail("broker mutation reached"))
    risk = SimpleNamespace(store=SimpleNamespace(snapshot=lambda: {}))
    nse_payload = {"symbol": "NSE:HDFCBANK26NOVFUT"}
    mcx_payload = {"symbol": "MCX:CRUDEOILM26NOVFUT"}

    for mode in ("PAPER", None, "bad"):
        with pytest.raises(RuntimeError, match="PAPER_OR_UNKNOWN"):
            client.place_futures_entry_gtt(
                nse_payload, risk=risk, execution_mode=mode)
        with pytest.raises(RuntimeError, match="PAPER_OR_UNKNOWN"):
            client.place_cash_gtt(mcx_payload, execution_mode=mode)


def test_evaluator_query_excludes_real_rejected_and_unknown_oms_rows():
    factory = _database()
    session = factory()
    rows = [
        Future_Order(order_id=1, trade_signal_id=1, execution_mode="PAPER",
                     candidate_source="GRADUATED_LIVE", order_status="paper_monitoring",
                     is_trade_started=False),
        Future_Order(order_id=2, trade_signal_id=2, execution_mode="REAL",
                     candidate_source="GRADUATED_LIVE", order_status="pending",
                     is_trade_started=False),
        Future_Order(order_id=3, trade_signal_id=3, execution_mode="PAPER",
                     candidate_source="GRADUATED_LIVE", order_status="cancelled",
                     is_trade_started=False),
        Future_Order(order_id=4, trade_signal_id=4, execution_mode=None,
                     candidate_source=None, order_status=None, is_trade_started=False),
        Future_Order(order_id=5, trade_signal_id=5, execution_mode=None,
                     candidate_source=None, order_status=None, is_trade_started=False),
        Future_Order(order_id=6, trade_signal_id=6, execution_mode="PAPER",
                     candidate_source="LEGACY_PAPER", order_status=None,
                     is_trade_started=False),
    ]
    session.add_all(rows)
    session.add(OMSOrderBucketFuture(order_id=5, trade_signal_id=5))
    session.commit()

    selected = session.execute(derivative_paper_orders_sql(
        "future_order_master", "oms_order_bucket_future",
        "candidate.is_trade_started=0")).mappings().all()

    assert [row["order_id"] for row in selected] == [1, 6]
    session.close()


def test_segment_modes_are_independent_and_invalid_values_fail_closed(monkeypatch):
    monkeypatch.setattr(config, "NSEFO_EXECUTION_MODE", "PAPER")
    monkeypatch.setattr(config, "MCX_EXECUTION_MODE", "REAL")
    assert config.execution_mode_for("NSEFO") == "PAPER"
    assert config.execution_mode_for("MCX") == "REAL"
    monkeypatch.setattr(config, "MCX_EXECUTION_MODE", "")
    with pytest.raises(RuntimeError, match="INVALID_GRADUATED_EXECUTION_MODE"):
        config.execution_mode_for("MCX")
