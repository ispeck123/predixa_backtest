from pathlib import Path

from scripts import release_preflight


def test_reviewed_safety_baseline_matches_active_gate():
    active = release_preflight.active_permissions(
        Path("scripts/tf_regime_gate_by_exchange.py"))
    baseline = release_preflight.baseline_permissions(
        Path("config/predixa_release_permission_baseline.json"))
    assert active == baseline
    assert active["MCX"] == set()


def test_permission_change_is_detectable_for_evidence_enforcement(tmp_path):
    gate = tmp_path / "gate.py"
    gate.write_text("TF_REGIME_GATE = {'MCX': ExchangeGate(permit_cells={('SW', 'SW', 4): 'CORE'})}\n")
    assert release_preflight.active_permissions(gate)["MCX"] == {
        ("SW", "SW", 4, "CORE")
    }


def test_external_approval_reference_rejects_a_checkout_path():
    baseline = Path("config/predixa_release_permission_baseline.json")
    try:
        release_preflight.external_baseline_permissions(baseline, label="test baseline")
    except ValueError as exc:
        assert "outside the repository checkout" in str(exc)
    else:
        raise AssertionError("checkout baseline must not count as independent approval")


def test_external_approval_reference_accepts_matching_artifact(tmp_path):
    source = Path("config/predixa_release_permission_baseline.json")
    approved = tmp_path / "approved-permissions.json"
    approved.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    assert release_preflight.external_baseline_permissions(
        approved, label="test baseline") == release_preflight.baseline_permissions(source)


def test_reduction_contract_requires_strict_removal_and_promotion_requires_evidence():
    previous = {"NSE_CASH": {("SW", "UP", 2, "CORE"), ("SW", "UP", 6, "CORE")}}
    active = {"NSE_CASH": {("SW", "UP", 6, "CORE")}}
    assert active["NSE_CASH"] < previous["NSE_CASH"]
    assert not (previous["NSE_CASH"] < active["NSE_CASH"])
