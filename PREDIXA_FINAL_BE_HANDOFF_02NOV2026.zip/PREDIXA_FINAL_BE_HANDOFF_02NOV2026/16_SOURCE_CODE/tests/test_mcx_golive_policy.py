from datetime import datetime
from zoneinfo import ZoneInfo

from scripts.graduated_live_exports import evaluate_mcx_tracks
from scripts.mcx_policy import mcx_disposition, mcx_weight
from scripts.mcx_session import mcx_e1_session_ids
from scripts.sizing_bridge import size_for_mcx_proving
from scripts.mcx_graduated_live_scanner import MCXScanJob, classify_mcx_setup
from scripts.futures_state_store import StateStore
from scripts.futures_risk_engine import RiskEngine
from sqlalchemy import create_engine
import asyncio
from starlette.requests import Request


def test_mcx_weights_and_proving_quantity_are_binary():
    assert mcx_weight("GOLDM", "SW", "SW", 4) == 0.0
    assert size_for_mcx_proving("GOLDM", "SW", "SW", 4, 8) is None
    assert size_for_mcx_proving("GOLDM", "UP", "SW", 3, 8) is None
    assert size_for_mcx_proving("GOLDM", "SW", "UP", 4, 8) is None
    assert size_for_mcx_proving("NATGASMINI", "SW", "SW", 4, 1) is None


def test_mcx_fire_is_narrower_than_positive_observe_weight():
    assert mcx_disposition("GOLDM", "SW", "SW", 4) == ("EXCLUDED", 0.0, None)
    assert mcx_disposition("GOLDGUINEA", "SW", "SW", 4)[0] == "EXCLUDED"
    assert mcx_disposition("CRUDEOILM", "UP", "SW", 3)[0] == "EXCLUDED"
    assert mcx_disposition("SILVERM", "UP", "SW", 3)[0] == "EXCLUDED"
    assert mcx_disposition("SILVERM", "SW", "SW", 4)[0] == "EXCLUDED"


def test_e1_marks_only_2330_to_0900_seam():
    tz = ZoneInfo("Asia/Kolkata")
    values = [
        datetime(2026, 10, 1, 23, 30, tzinfo=tz).timestamp(),
        datetime(2026, 10, 2, 9, 0, tzinfo=tz).timestamp(),
        datetime(2026, 10, 2, 10, 0, tzinfo=tz).timestamp(),
    ]
    assert mcx_e1_session_ids(values) == [0, 1, 1]


def test_mcx_tracking_is_cell_isolated():
    row = {
        "segment": "MCX", "symbol": "CRUDEOILM", "tf": 4, "side": "BUY",
        "zone_type": "BZ", "entry_price": 100, "stoploss_price": 90,
        "target_price": 120, "real_entry_price": 100, "real_exit_price": 120,
        "applicable_stop": 90, "exit_leg": "TARGET", "status": "COMPLETED",
        "underlying": "CRUDE", "e_regime": "SW", "a_regime": "SW",
        "strategy_tf": 4,
    }
    output = evaluate_mcx_tracks([row], ci_critical=lambda n: 1.96)
    assert output[("CRUDE", "SW", "SW", "4")]["n"] == 1


def test_paper_scanner_is_denied_by_operational_mcx_gate():
    job = MCXScanJob("GOLDM", "30102026", 4, ["daily", "two_forty", "sixty"], None, "PAPER")
    formatted = {"BUY": {"entry_price": 100, "stop_loss": 90, "target_price": 122},
                 "BUY_RRR": 2.2, "e_regime": "SW", "a_regime": "SW"}
    fire = classify_mcx_setup(formatted, job)
    assert fire["status"] == "TF_REGIME_GATE_DENIED"
    assert fire["gate_tier"] == "DENY"
    assert fire["gate_size_multiplier"] == 0.0
    observe = classify_mcx_setup(formatted | {"e_regime": "UP"},
                                 MCXScanJob("GOLDM", "30102026", 3, [], None, "PAPER"))
    assert observe["status"] == "TF_REGIME_GATE_DENIED"
    assert observe["gate_tier"] == "DENY"


def test_scanner_rejects_stale_or_impossible_rr_before_persistence():
    job = MCXScanJob("CRUDEOILM", "30102026", 4, [], None, "PAPER")
    stale_rr = {"BUY": {"entry_price": 8342, "stop_loss": 8178.443839523632,
                          "target_price": 8655},
                "BUY_RRR": 21.1077, "e_regime": "SW", "a_regime": "SW"}
    result = classify_mcx_setup(stale_rr, job)
    assert result["status"] == "TF_REGIME_GATE_DENIED"


def test_paper_scanner_persists_mechanical_setup_for_unvalidated_symbol(tmp_path):
    from scripts.mcx_graduated_live_scanner import MCXGraduatedLiveScanner
    job = MCXScanJob("SILVERM", "26022027", 4, [], None, "PAPER")
    formatted = {"BUY": {"entry_price": 100, "stop_loss": 90, "target_price": 122},
                 "BUY_RRR": 2.2, "e_regime": "UP", "a_regime": "UP"}
    calls = []
    scanner = MCXGraduatedLiveScanner(
        engine=lambda *_: {}, formatter=lambda *_args, **_kwargs: formatted,
        signal_inserter=lambda payload, *_: calls.append(payload) or (True, 23),
        candidate_persister=lambda candidate, *_: {
            "status": "paper_monitoring", "quantity": candidate["lot_size"]},
    )
    row = scanner.run([job], tmp_path / "scan.jsonl")[0]
    assert row["status"] == "MCX_EXECUTION_BLOCKED"
    assert calls == []


def test_paper_accepts_low_rr_valid_buy_setup():
    job = MCXScanJob("CRUDEOILM", "30102026", 4, [], None, "PAPER")
    formatted = {"BUY": {"entry_price": 100, "stop_loss": 90, "target_price": 105},
                 "BUY_RRR": 0.5, "e_regime": "SW", "a_regime": "SW"}
    result = classify_mcx_setup(formatted, job)
    assert result["status"] == "TF_REGIME_GATE_DENIED"
    assert result["gate_tier"] == "DENY"


def test_fire_record_calls_signal_and_candidate_persistence(tmp_path):
    from scripts.mcx_graduated_live_scanner import MCXGraduatedLiveScanner
    job = MCXScanJob("CRUDEOILM", "30102026", 4, [], None, "PAPER")
    formatted = {"BUY": {"entry_price": 100, "stop_loss": 90, "target_price": 122},
                 "BUY_RRR": 2.2, "e_regime": "SW", "a_regime": "SW"}
    calls = []
    scanner = MCXGraduatedLiveScanner(
        engine=lambda *_: {}, formatter=lambda *_args, **_kwargs: formatted,
        signal_inserter=lambda payload, *_: calls.append(payload) or (True, 19),
        candidate_persister=lambda candidate, scanned_job, result: {
            "bucket_id": 31, "signal": result[1], "symbol": candidate["execution_symbol"]},
    )
    row = scanner.run([job], tmp_path / "scan.jsonl")[0]
    assert row["status"] == "MCX_EXECUTION_BLOCKED"
    assert calls == []


def test_real_scanner_rejects_out_of_scope_symbol_before_persistence(tmp_path):
    from scripts.mcx_graduated_live_scanner import MCXGraduatedLiveScanner
    job = MCXScanJob("SILVERM", "26022027", 3, [], None, "REAL")
    formatted = {"BUY": {"entry_price": 100, "stop_loss": 90, "target_price": 122},
                 "BUY_RRR": 2.2, "e_regime": "UP", "a_regime": "SW"}
    calls = []
    scanner = MCXGraduatedLiveScanner(
        engine=lambda *_: {}, formatter=lambda *_args, **_kwargs: formatted,
        signal_inserter=lambda payload, *_: calls.append(payload) or (True, 23),
        candidate_persister=lambda candidate, *_: {
            "bucket_id": 32, "status": "pending_observation",
            "quantity": candidate["lot_size"]},
    )
    row = scanner.run([job], tmp_path / "scan.jsonl")[0]
    assert row["status"] == "MCX_EXECUTION_BLOCKED"
    assert calls == []


def test_live_scanner_uses_execution_time_and_reconciles_stale_candidates(tmp_path):
    from scripts.mcx_graduated_live_scanner import MCXGraduatedLiveScanner
    old_job_time = datetime(2000, 1, 1)
    job = MCXScanJob("CRUDEOILM", "19102026", 4, [], old_job_time, "PAPER")
    seen, reconciled = [], []
    scanner = MCXGraduatedLiveScanner(
        engine=lambda *_args: seen.append(_args[3]) or {},
        formatter=lambda *_args, **_kwargs: {},
        candidate_reconciler=lambda scanned_job, status: reconciled.append((scanned_job, status)) or 1,
    )
    record = scanner.run([job], tmp_path / "scan.jsonl")[0]
    assert seen == []
    assert reconciled == []
    assert record["status"] == "MCX_EXECUTION_BLOCKED"


def test_mcx_realized_loss_is_part_of_global_ceiling(tmp_path):
    store = StateStore(create_engine(f"sqlite:///{tmp_path / 'risk.sqlite'}"))
    store.initialize()
    risk = RiskEngine(store)
    risk.record_realized("mcx-loss", "MCX", -50_000, cash_loss=0,
                         futures_loss=0, mcx_loss=50_000)
    assert risk.cash_entry_allowed() == "GLOBAL_REALIZED_LOSS_CEILING"


def test_commodity_manual_approval_updates_the_single_bucket(monkeypatch):
    from apps.backend.api import bucket_orders_commodity as api
    from shared.db.req_model import ApproveReject_BucketOrderBase

    class Row:
        bucket_id = 9
        approval_status = "pending"
        approved_by = None
        approved_at = None
        gtt_id = None
        id_fyers = None
        is_trade_started = 0
        order_status = "pending"
        order_type = "BUY"
        stock_tick = "CRUDEOILM"
        expiry_date = "30102026"
        stock_quantity = 10
        entry_price = 100.0
        stoploss_price = 95.0
        target_price = 115.0
        execution_mode = "REAL"

    class Fyers:
        def place_cash_gtt(self, payload, *, execution_mode=None):
            assert execution_mode == "REAL"
            assert payload["symbol"] == "MCX:CRUDEOILM26OCTFUT"
            return {"s": "ok", "id": "gtt-9", "id_fyers": "fyers-9"}

    class Query:
        def filter(self, *_):
            return self
        def first(self):
            return row

    class Session:
        committed = False
        def query(self, *_):
            return Query()
        def add(self, value):
            assert value is row
        def commit(self):
            self.committed = True
        def rollback(self):
            pass
        def close(self):
            pass

    row, session = Row(), Session()
    monkeypatch.setattr(api, "db", type("DB", (), {"get_session": lambda _self: session})())
    monkeypatch.setattr(api, "get_fyers", lambda: Fyers())
    monkeypatch.setattr(api, "mcx_execution_permitted", lambda: True)
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    asyncio.run(api.approve_reject_bucket_orders_commodity(
        ApproveReject_BucketOrderBase(bucket_id=9, approved_by="7", status="approved"), request))
    assert session.committed is True
    assert row.approval_status == "approved"
    assert row.approved_by == "7"
    assert row.gtt_id == "gtt-9"
