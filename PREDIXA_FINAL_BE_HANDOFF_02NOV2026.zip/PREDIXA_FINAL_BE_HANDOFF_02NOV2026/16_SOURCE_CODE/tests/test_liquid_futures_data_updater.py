from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data_fetchers.fyers.liquid_futures_data_updater import (
    LIQUID_NSEFO_SYMBOLS,
    LiquidFuturesDataHandler,
)
from data_fetchers.fyers.indian_futures_data_updater import future_data_processer


def test_liquid_universe_matches_the_approved_symbols_exactly():
    assert len(LIQUID_NSEFO_SYMBOLS) == 30
    assert {"BANKNIFTY", "NIFTY", "HDFCBANK", "M&M", "COALINDIA"}.issubset(
        LIQUID_NSEFO_SYMBOLS)


def test_liquid_handler_does_not_query_the_full_futures_master():
    handler = LiquidFuturesDataHandler.__new__(LiquidFuturesDataHandler)
    assert handler.get_all_stock_symbols() == list(LIQUID_NSEFO_SYMBOLS)


def test_derived_bar_processor_filters_to_the_requested_symbols(tmp_path):
    (tmp_path / "NIFTY_27102026_fifteen.csv").touch()
    (tmp_path / "NIFTY_27102026_daily.csv").touch()
    (tmp_path / "RELIANCE_27102026_fifteen.csv").touch()

    processor = future_data_processer.__new__(future_data_processer)
    processor.input_dir = str(tmp_path)
    calls = []
    processor.create_75munite_from_15munite = lambda item: calls.append(("75", item))
    processor.create_monthly_and_weekly_from_daily = lambda item, freq: calls.append((freq, item))
    processor.create_25munite_from_5munite = lambda item: calls.append(("25", item))
    processor.create_125munite_from_5munite = lambda item: calls.append(("125", item))

    processor.process_all_files(symbols=("NIFTY",))

    assert set(calls) == {
        ("75", "NIFTY_27102026_fifteen.csv"),
        ("W", "NIFTY_27102026_daily.csv"),
        ("ME", "NIFTY_27102026_daily.csv"),
    }
