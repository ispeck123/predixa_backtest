from scripts.sizing_bridge import size_for_order
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE, gate


def test_cash_gate_drops_tf1_and_scales_marginal_cells():
    assert gate("NSE_CASH", 1, "SW", "SW")[1] == 0.0
    assert gate("NSE_CASH", 2, "SW", "SW")[:2] == ("CORE", 1.0)
    assert gate("NSE_CASH", 2, "UP", "SW")[:2] == ("MARGINAL", 0.5)


def test_owner_approved_nonpositive_cash_cells_now_deny_without_affecting_retained_cells():
    for e_regime, a_regime, strategy_tf in (
        ("SW", "UP", 2), ("UP", "UP", 2), ("UP", "UP", 5), ("UP", "UP", 25),
    ):
        assert gate("NSE_CASH", strategy_tf, e_regime, a_regime)[:2] == ("DENY", 0.0)
    for e_regime, a_regime, strategy_tf, expected in (
        ("SW", "SW", 2, "CORE"), ("SW", "SW", 6, "CORE"), ("SW", "SW", 25, "CORE"),
        ("SW", "UP", 6, "CORE"), ("UP", "SW", 2, "MARGINAL"), ("UP", "SW", 5, "MARGINAL"),
    ):
        assert gate("NSE_CASH", strategy_tf, e_regime, a_regime)[0] == expected


def test_mcx_is_scoped_to_goldm_and_crude_with_its_own_cells():
    assert TF_REGIME_GATE["MCX"].tf_set == (1, 2, 3, 4)
    assert gate("MCX", 4, "SW", "SW", "GOLDM")[:2] == ("DENY", 0.0)
    assert gate("MCX", 4, "SW", "SW", "GOLDGUINEA")[:2] == ("DENY", 0.0)
    assert gate("MCX", 3, "UP", "SW", "CRUDEOILM")[:2] == ("DENY", 0.0)
    assert gate("MCX", 4, "SW", "SW", "SILVERM")[:2] == ("DENY", 0.0)
    assert gate("MCX", 4, "SW", "SW")[:2] == ("DENY", 0.0)


def test_nsefo_is_limited_to_its_labeled_oos_core_cell():
    assert gate("NSEFO", 25, "SW", "SW", "HDFCBANK")[:2] == ("CORE", 1.0)
    assert gate("NSEFO", 1, "SW", "SW", "HDFCBANK")[:2] == ("DENY", 0.0)
    assert gate("NSEFO", 2, "UP", "UP", "HDFCBANK")[:2] == ("DENY", 0.0)


def test_permitted_marginal_cash_cell_keeps_the_one_share_wet_run_unit():
    formatted = {"STOCK_NAME": "RELIANCE", "e_regime": "UP", "a_regime": "SW"}
    levels = {"entry_price": 100.0, "stop_loss": 95.0, "target_price": 115.0}
    assert gate("NSE_CASH", 2, "UP", "SW", "RELIANCE")[:2] == ("MARGINAL", 0.5)
    assert size_for_order(formatted, levels, "2", "NSE_CASH") == 1
