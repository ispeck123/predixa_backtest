from pathlib import Path

from data_fetchers.fyers.fyers_utils import commodity_symbol_format
from scripts.graduated_live_config import FUTURES_LOT_SIZES
from scripts.mcx_graduated_live_scanner import MCX_LOT_SIZE
from scripts.mcx_policy import MCX_EXECUTION_ONLY_SYMBOLS, mcx_disposition
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE, gate


def test_goldguinea_is_an_execution_only_mcx_contract():
    assert "GOLDGUINEA" not in TF_REGIME_GATE["MCX"].universe
    assert "GOLDGUINEA" in MCX_EXECUTION_ONLY_SYMBOLS
    assert MCX_LOT_SIZE["GOLDGUINEA"] == 8
    assert FUTURES_LOT_SIZES["GOLDGUINEA"] == 8
    assert gate("MCX", 4, "SW", "SW", "GOLDGUINEA")[:2] == ("DENY", 0.0)
    # MCX execution alias mapping remains dormant while the segment gate is DENY.
    assert mcx_disposition("GOLDM", "SW", "SW", 4) == ("EXCLUDED", 0.0, None)


def test_goldguinea_contract_format_supports_persisted_expiry():
    assert commodity_symbol_format("GOLDGUINEA", "30-10-2026") == "MCX:GOLDGUINEA26OCTFUT"
    assert commodity_symbol_format("GOLDGUINEA", "30102026") == "MCX:GOLDGUINEA26OCTFUT"


def test_goldguinea_master_migration_is_idempotent():
    migration = Path("scripts/db_migrations/20261029_add_mcx_goldguinea.sql").read_text()
    assert "'GOLDGUINEA'" in migration
    assert "WHERE NOT EXISTS" in migration
