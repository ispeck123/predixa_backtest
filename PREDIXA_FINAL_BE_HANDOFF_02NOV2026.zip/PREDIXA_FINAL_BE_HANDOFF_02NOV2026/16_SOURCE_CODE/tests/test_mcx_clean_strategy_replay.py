"""TEST_ONLY integration for existing setup engine -> realized-R exporter adapter."""
from dataclasses import dataclass

import pandas as pd

from audit.mcx_futures_backtest.clean_strategy_replay import replay_existing_strategy


@dataclass
class Regimes:
    regime_E: str = "SW"
    regime_A: str = "UP"
    regime_X: str = "UP"


@dataclass
class Setup:
    zone_id: str = "zone-1"
    entry_price: float = 110.0
    stop_price: float = 100.0
    target_price: float = 130.0


class FakeResearchEngine:
    calls = 0

    def run(self, **kwargs):
        type(self).calls += 1
        interval = {"sixty": 60, "two_forty": 240, "one_twenty": 120,
                    "daily": 1440}[kwargs["time_list"][-1]]
        signal_epoch = int((pd.Timestamp(kwargs["last_d_time"]) - pd.Timedelta(minutes=interval)).timestamp())
        return {"best_setup_long": Setup(), "best_setup_short": Setup(zone_id="short"),
                "trend_context": Regimes(), "entry_ts": signal_epoch}


def research_frame(name, as_of):
    start = pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata")
    return pd.DataFrame({
        "timestamp": [start, start + pd.Timedelta(hours=1), start + pd.Timedelta(hours=2)],
        "research_open": [100, 101, 102], "research_high": [102, 103, 104],
        "research_low": [99, 100, 101], "research_close": [101, 102, 103],
        "volume": [10, 11, 12], "adjustment_factor": [1.0] * 3,
        "adjustment_offset": [10.0] * 3,
        "is_point_in_time_snapshot": [True] * 3,
        "snapshot_as_of": [as_of.isoformat()] * 3,
    })


def test_existing_engine_adapter_emits_buy_only_stable_setup_and_restores_config():
    from shared.config.settings import stock_data_dir_config
    original = stock_data_dir_config.indian_commodity_data
    FakeResearchEngine.calls = 0
    setups = replay_existing_strategy(
        "CRUDEOILM",
        lambda as_of: {"daily": research_frame("daily", as_of),
            "two_forty": research_frame("two_forty", as_of), "sixty": research_frame("sixty", as_of)},
        strategy_tf=4,
        contract_selector=lambda ts: {"underlying": "CRUDEOILM", "contract_symbol": "MCX:CRUDEOILM26OCTFUT",
            "attribution_status": "VERIFIED", "expiry_date": "2026-10-19", "adjustment_factor": 1,
            "adjustment_offset": 10, "executable_price_status": "VERIFIED"},
        calendar_classifier=lambda ts, contract: {"status": "VALID", "remaining_trading_days": 8,
            "roll_boundary_candidate": False},
        source_id="TEST_ONLY", roll_policy_version="TEST_ONLY",
        engine_factory=FakeResearchEngine,
        snapshot_timestamps=[pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata")],
    )
    assert FakeResearchEngine.calls == 1
    assert stock_data_dir_config.indian_commodity_data == original
    assert len(setups) == 1
    setup = setups[0]
    assert setup["side"] == "BUY"
    assert setup["entry_price"] == 100  # adjusted level 110 maps back by offset 10
    assert setup["E_regime"] == "SW" and setup["A_regime"] == "UP"
    assert setup["source_id"] == "TEST_ONLY"


def test_strategy_adapter_to_realized_r_export_in_memory_test_only():
    from audit.mcx_futures_backtest.clean_realized_r_export import build_clean_export
    from scripts.mcx_session import mcx_e1_session_ids
    frames = {"daily": research_frame("daily", pd.Timestamp("2026-10-01 10:00", tz="Asia/Kolkata")),
        "two_forty": research_frame("two_forty", pd.Timestamp("2026-10-01 10:00", tz="Asia/Kolkata")),
        "sixty": research_frame("sixty", pd.Timestamp("2026-10-01 10:00", tz="Asia/Kolkata"))}
    setups = replay_existing_strategy(
        "CRUDEOILM", lambda as_of: {name: frame.assign(snapshot_as_of=as_of.isoformat())
            for name, frame in frames.items()}, strategy_tf=4,
        contract_selector=lambda ts: {"underlying": "CRUDEOILM", "contract_symbol": "MCX:CRUDEOILM26OCTFUT",
            "attribution_status": "VERIFIED", "expiry_date": "2026-10-19", "adjustment_factor": 1,
            "adjustment_offset": 10, "executable_price_status": "VERIFIED"},
        calendar_classifier=lambda ts, contract: {"status": "VALID", "remaining_trading_days": 8,
            "roll_boundary_candidate": False}, source_id="TEST_ONLY", roll_policy_version="TEST_ONLY",
        engine_factory=FakeResearchEngine,
        snapshot_timestamps=[pd.Timestamp("2026-10-01 09:00", tz="Asia/Kolkata")])
    signal = pd.Timestamp(setups[0]["signal_timestamp"])
    timestamps = [signal + pd.Timedelta(hours=1), signal + pd.Timedelta(hours=2)]
    exec_bars = pd.DataFrame({"timestamp": timestamps, "open": [99, 119], "high": [101, 121],
        "low": [95, 115], "close": [100, 120], "underlying": "CRUDEOILM",
        "contract_symbol": "MCX:CRUDEOILM26OCTFUT",
        "e1_session_id": mcx_e1_session_ids(timestamps)})
    validation = {"status": "VALID", "source_mode": "RAW_DATED",
        "dated_contract_ohlcv_verified": True, "historical_contract_attribution_verified": True,
        "roll_transitions_verified": True, "roll_prices_verified": True, "roll_policy_approved": True,
        "trading_calendar_verified": True, "e1_enforced": True, "executable_price_mapping_verified": True,
        "point_in_time_integrity_verified": True, "coverage_verified": True,
        "underlyings": ["GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"],
        "strategy_timeframes": [1, 2, 3, 4], "coverage_start": "2026-01-01",
        "coverage_end": "2026-11-01", "roll_policy_version": "TEST_ONLY",
        "calendar_version": "TEST_ONLY", "input_hashes": {"fixture": "TEST_ONLY"}}
    out = build_clean_export(setups, {setups[0]["setup_id"]: exec_bars}, validation, "2026-10-02")
    assert list(out["trades"].columns) == ["symbol", "strategy_tf", "E_regime", "A_regime", "X_regime",
        "entry_price", "stop_price", "target_price", "exit_price", "outcome", "gross_r", "mfe_R",
        "partition", "bars_held"]
    assert out["trades"].iloc[0].gross_r == 2
    assert out["trades"].iloc[0].mfe_R == 2
    assert out["provenance"].iloc[0].data_source_id == "TEST_ONLY"


def test_actual_predixa_setup_engine_executes_offline_without_trade_side_effects():
    import numpy as np
    # TEST_ONLY deterministic inputs exercise SDEnginePipeline.run itself.
    def actual_frame(name, as_of):
        if name == "daily":
            times = pd.date_range("2025-10-01", periods=100, freq="B", tz="Asia/Kolkata")
        elif name == "two_forty":
            times = pd.date_range("2025-10-01 09:00", periods=100, freq="4h", tz="Asia/Kolkata")
        else:
            times = pd.date_range("2025-10-01 09:00", periods=120, freq="h", tz="Asia/Kolkata")
        close = 100 + np.sin(np.arange(len(times)) / 4) * 3 + np.arange(len(times)) * 0.1
        return pd.DataFrame({"timestamp": times, "research_open": close - .2,
            "research_high": close + 1, "research_low": close - 1, "research_close": close,
            "volume": 100, "is_point_in_time_snapshot": True, "snapshot_as_of": as_of.isoformat()})
    output = replay_existing_strategy("CRUDEOILM",
        lambda as_of: {name: actual_frame(name, as_of) for name in ("daily", "two_forty", "sixty")},
        strategy_tf=4,
        contract_selector=lambda ts: {"underlying": "CRUDEOILM", "contract_symbol": "MCX:CRUDEOILM26OCTFUT",
            "attribution_status": "VERIFIED", "expiry_date": "2026-10-19", "adjustment_factor": 1,
            "adjustment_offset": 0, "executable_price_status": "VERIFIED"},
        calendar_classifier=lambda ts, contract: {"status": "VALID", "remaining_trading_days": 9,
            "roll_boundary_candidate": False}, source_id="TEST_ONLY", roll_policy_version="TEST_ONLY",
        snapshot_timestamps=[pd.Timestamp("2026-02-25 09:00", tz="Asia/Kolkata")])
    assert isinstance(output, list)  # No signal is required from a synthetic fixture.
