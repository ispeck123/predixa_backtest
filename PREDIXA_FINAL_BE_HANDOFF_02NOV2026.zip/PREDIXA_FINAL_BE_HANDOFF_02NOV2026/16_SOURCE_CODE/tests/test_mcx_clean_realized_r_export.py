"""Synthetic unit fixtures only; they are not historical market evidence."""
from __future__ import annotations

import json

import pandas as pd
import pytest

from audit.mcx_futures_backtest.clean_realized_r_export import (
    EXPORT_COLUMNS,
    ExportBlocked,
    assign_partition,
    build_clean_export,
    readiness_issues,
    write_versioned_export,
)


CONTRACT = "MCX:CRUDEOILM26OCTFUT"
SIGNAL = "2026-01-05T10:00:00+05:30"


def clean_readiness():
    return {
        "status": "VALID", "source_mode": "RAW_DATED",
        "dated_contract_ohlcv_verified": True,
        "historical_contract_attribution_verified": True,
        "roll_transitions_verified": True, "roll_prices_verified": True,
        "roll_policy_approved": True, "trading_calendar_verified": True,
        "e1_enforced": True, "executable_price_mapping_verified": True,
        "point_in_time_integrity_verified": True, "coverage_verified": True,
        "underlyings": ["GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"],
        "strategy_timeframes": [1, 2, 3, 4], "coverage_start": "2025-09-01", "coverage_end": "2026-09-30",
        "roll_policy_version": "approved-test-policy", "calendar_version": "test-calendar-v1",
        "input_hashes": {"test-bars": "sha256:test-only"},
    }


def setup(**overrides):
    value = {
        "setup_id": "trade-001", "side": "BUY", "underlying": "CRUDEOILM",
        "strategy_tf": 4, "E_regime": "SW", "A_regime": "SW", "X_regime": "UP",
        "signal_timestamp": SIGNAL, "entry_price": 100., "stop_price": 95., "target_price": 110.,
        "historical_contract": CONTRACT, "contract_mapping_status": "VERIFIED",
        "executable_price_status": "VERIFIED", "expiry_window_status": "VALID",
        "price_basis": "RAW_EXECUTABLE",
        "roll_boundary_candidate": False, "source_id": "sha256:test-only",
        "roll_policy_version": "approved-test-policy", "expiry_date": "2026-10-19",
        "remaining_trading_days": 9,
    }
    value.update(overrides)
    return value


def bars(rows, sessions=None, contracts=None):
    sessions = sessions or [1] * len(rows)
    contracts = contracts or [CONTRACT] * len(rows)
    frame = pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close"])
    frame["contract_symbol"] = contracts
    frame["e1_session_id"] = sessions
    return frame


def sample_win():
    return bars([
        ("2026-01-05T10:15:00+05:30", 100, 102, 99, 101),
        ("2026-01-05T10:30:00+05:30", 101, 111, 100, 109),
    ])


def make_export(one_setup=None, one_bars=None, readiness=None, split="2026-02-01"):
    one_setup = one_setup or setup()
    one_bars = one_bars if one_bars is not None else sample_win()
    return build_clean_export([one_setup], {one_setup["setup_id"]: one_bars}, readiness or clean_readiness(), split)


def test_valid_buy_realized_r_is_calculated_from_exit():
    result = make_export()
    row = result["trades"].iloc[0]
    assert row.gross_r == pytest.approx(2.0)
    assert row.outcome == "WIN"


def test_losing_trade_realized_r_is_minus_one():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 101, 99, 100),
                  ("2026-01-05T10:30:00+05:30", 98, 99, 94, 95)])
    row = make_export(one_bars=frame)["trades"].iloc[0]
    assert row.gross_r == pytest.approx(-1)
    assert row.outcome == "LOSS"


def test_breakeven_exit_is_not_fabricated_as_win_or_loss():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 101, 99, 100),
                  ("2026-01-05T10:30:00+05:30", 100, 101, 99, 100)])
    out = make_export(one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "UNRESOLVED_END_OF_AVAILABLE_HISTORY"


@pytest.mark.parametrize("entry,stop", [(100, 100), (100, 101)])
def test_invalid_or_zero_initial_risk_is_excluded(entry, stop):
    out = make_export(one_setup=setup(entry_price=entry, stop_price=stop))
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "NONPOSITIVE_INITIAL_RISK"


def test_mfe_is_separate_and_does_not_use_exit_bar_high_after_stop():
    frame = bars([
        ("2026-01-05T10:15:00+05:30", 100, 103, 99, 102),
        ("2026-01-05T10:30:00+05:30", 102, 108, 101, 107),
        ("2026-01-05T10:45:00+05:30", 100, 109, 94, 95),
    ])
    row = make_export(one_bars=frame)["trades"].iloc[0]
    assert row.gross_r == pytest.approx(-1)
    assert row.mfe_R == pytest.approx(1.6)


def test_bars_held_counts_entry_bar_through_exit_bar():
    row = make_export()["trades"].iloc[0]
    assert row.bars_held == 2


def test_candle_start_equal_to_completed_signal_time_is_first_executable_bar():
    frame = bars([("2026-01-05T10:00:00+05:30", 99, 101, 98, 100),
                  ("2026-01-05T10:15:00+05:30", 109, 111, 108, 110)])
    out = make_export(one_bars=frame)
    assert len(out["trades"]) == 1
    assert out["trades"].iloc[0].bars_held == 2


def test_same_bar_stop_target_uses_conservative_stop_first_convention():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 111, 94, 100)])
    out = make_export(one_bars=frame)
    assert out["trades"].iloc[0].outcome == "LOSS"
    assert out["trades"].iloc[0].exit_price == 95
    assert out["provenance"].iloc[0].exit_resolution == "STOP_FIRST_SAME_BAR_AMBIGUOUS"


def test_e1_gap_open_cannot_trigger_false_exit():
    frame = bars([("2026-01-05T23:00:00+05:30", 104, 106, 103, 104),
                  ("2026-01-06T09:00:00+05:30", 90, 112, 89, 100)], sessions=[1, 2])
    # First candle is after signal but not an entry fill; second crosses entry,
    # therefore this sample is unresolved at the E1 boundary.
    out = make_export(one_setup=setup(signal_timestamp="2026-01-05T22:00:00+05:30"), one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "E1_GAP_OPEN_ENTRY_AMBIGUOUS"


def test_e1_boundary_exit_is_unresolved_not_a_false_break():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 102, 99, 101),
                  ("2026-01-05T23:00:00+05:30", 101, 105, 100, 103),
                  ("2026-01-06T09:00:00+05:30", 112, 113, 111, 112)], sessions=[1, 1, 2])
    out = make_export(one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "E1_GAP_EXIT_AMBIGUOUS"


def test_valid_same_session_breakout_is_preserved():
    assert len(make_export()["trades"]) == 1


def test_wrong_historical_contract_rejected():
    frame = sample_win()
    frame["contract_symbol"] = "MCX:OTHER"
    assert make_export(one_bars=frame)["excluded"].iloc[0].reason == "WRONG_OR_CROSS_CONTRACT_EXECUTABLE_BARS"


def test_missing_executable_mapping_rejected():
    assert make_export(one_setup=setup(executable_price_status="UNKNOWN"))["excluded"].iloc[0].reason == "UNVERIFIED_EXECUTABLE_PRICE_MAPPING"


def test_missing_calendar_fails_readiness_closed():
    report = clean_readiness(); report["trading_calendar_verified"] = False
    with pytest.raises(ExportBlocked, match="trading_calendar_verified"):
        make_export(readiness=report)


def test_missing_roll_policy_approval_fails_readiness_closed():
    report = clean_readiness(); report["roll_policy_approved"] = False
    with pytest.raises(ExportBlocked, match="roll_policy_approved"):
        make_export(readiness=report)


def test_missing_split_date_fails_closed():
    with pytest.raises(ExportBlocked, match="split date"):
        build_clean_export([setup()], {"trade-001": sample_win()}, clean_readiness(), "")


def test_partition_assignment_is_date_based_and_deterministic():
    assert assign_partition("2026-01-31T23:59:00+05:30", "2026-02-01") == "IS"
    assert assign_partition("2026-02-01T09:00:00+05:30", "2026-02-01") == "OOS"


def test_sell_setup_is_not_exported():
    out = make_export(one_setup=setup(side="SELL"))
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "SELL_NOT_INCLUDED"


def test_each_underlying_is_kept_separate():
    other = setup(setup_id="goldm-1", underlying="GOLDM", historical_contract="MCX:GOLDM26OCTFUT")
    f = sample_win(); f["contract_symbol"] = "MCX:GOLDM26OCTFUT"
    out = build_clean_export([setup(), other], {"trade-001": sample_win(), "goldm-1": f}, clean_readiness(), "2026-02-01")
    assert set(out["trades"].symbol) == {"GOLDM", "CRUDEOILM"}


def test_duplicate_setup_is_audited_not_silently_exported_twice():
    out = build_clean_export([setup(), setup()], {"trade-001": sample_win()}, clean_readiness(), "2026-02-01")
    assert len(out["trades"]) == 1
    assert out["excluded"].iloc[0].reason == "DUPLICATE_SETUP_ID"


def test_unresolved_end_of_data_is_audited():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 102, 99, 101)])
    out = make_export(one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "UNRESOLVED_END_OF_AVAILABLE_HISTORY"


def test_exact_export_schema_and_order():
    assert list(make_export()["trades"].columns) == EXPORT_COLUMNS
    assert len(EXPORT_COLUMNS) == 14


def test_output_is_reproducible():
    first = make_export()["trades"].to_csv(index=False)
    second = make_export()["trades"].to_csv(index=False)
    assert first == second


def test_stitched_only_data_fails_closed():
    report = clean_readiness(); report["source_mode"] = "STITCHED_OR_CONTINUOUS"
    with pytest.raises(ExportBlocked, match="stitched/continuous"):
        make_export(readiness=report)


@pytest.mark.parametrize("field", list({
    "dated_contract_ohlcv_verified", "historical_contract_attribution_verified", "roll_transitions_verified",
    "roll_prices_verified", "roll_policy_approved", "trading_calendar_verified", "e1_enforced",
    "executable_price_mapping_verified", "point_in_time_integrity_verified", "coverage_verified",
}))
def test_each_missing_mandatory_prerequisite_fails_closed(field):
    report = clean_readiness(); report[field] = False
    assert any(field in issue for issue in readiness_issues(report))
    with pytest.raises(ExportBlocked):
        make_export(readiness=report)


def test_versioned_output_refuses_to_overwrite(tmp_path):
    output = write_versioned_export({}, [setup()], {"trade-001": sample_win()}, split_date="2026-02-01",
                                    output_root=tmp_path, run_id="run-1", git_revision="abc123",
                                    data_validation=clean_readiness())
    assert (output / "clean_mcx_trade_export.csv").exists()
    with pytest.raises(FileExistsError):
        write_versioned_export({}, [setup()], {"trade-001": sample_win()}, split_date="2026-02-01",
                               output_root=tmp_path, run_id="run-1", git_revision="abc123",
                               data_validation=clean_readiness())


def test_failed_readiness_writes_no_export_directory(tmp_path):
    report = clean_readiness(); report["status"] = "UNVERIFIED"
    with pytest.raises(ExportBlocked):
        write_versioned_export({}, [setup()], {"trade-001": sample_win()}, split_date="2026-02-01",
                               output_root=tmp_path, run_id="blocked-run", git_revision="abc123",
                               data_validation=report)
    assert not (tmp_path / "blocked-run").exists()


def test_invalid_e1_gap_retest_style_transition_is_not_exported():
    frame = bars([("2026-01-05T10:15:00+05:30", 100, 102, 99, 101),
                  ("2026-01-05T23:00:00+05:30", 101, 105, 100, 103),
                  ("2026-01-06T09:00:00+05:30", 111, 112, 110, 111)], sessions=[1, 1, 2])
    out = make_export(one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "E1_GAP_EXIT_AMBIGUOUS"


def test_inconsistent_e1_session_metadata_is_rejected():
    frame = bars([("2026-01-05T23:00:00+05:30", 104, 106, 103, 104),
                  ("2026-01-06T09:00:00+05:30", 100, 102, 99, 101)], sessions=[1, 1])
    out = make_export(one_setup=setup(signal_timestamp="2026-01-05T22:00:00+05:30"), one_bars=frame)
    assert out["excluded"].iloc[0].reason == "E1_SESSION_IDS_MISMATCH"


def test_fewer_than_three_verified_trading_days_is_excluded():
    out = make_export(one_setup=setup(remaining_trading_days=2))
    assert out["excluded"].iloc[0].reason == "ROLL_BOUNDARY_TRADE_EXCLUDED"


def test_daily_execution_gap_is_blocked_even_if_htf_e1_ids_are_continuous():
    frame = bars([("2026-01-05T15:30:00+05:30", 100, 102, 99, 101),
                  ("2026-01-06T15:30:00+05:30", 90, 92, 89, 91)], sessions=[1, 1])
    out = make_export(one_setup=setup(strategy_tf=1, signal_timestamp="2026-01-05T15:00:00+05:30"), one_bars=frame)
    assert out["trades"].empty
    assert out["excluded"].iloc[0].reason == "E1_GAP_EXIT_AMBIGUOUS"


@pytest.mark.parametrize("timestamps", [
    ["2026-01-05T10:30:00+05:30", "2026-01-05T10:15:00+05:30"],
    ["2026-01-05T10:15:00+05:30", "2026-01-05T04:45:00Z"],
])
def test_duplicate_or_unordered_instants_are_excluded(timestamps):
    frame = bars([(timestamps[0], 100, 102, 99, 101), (timestamps[1], 101, 111, 100, 109)])
    out = make_export(one_bars=frame)
    assert out["excluded"].iloc[0].reason == "DUPLICATE_OR_UNORDERED_EXECUTABLE_BARS"
