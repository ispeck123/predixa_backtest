import csv
import json

import pytest

from scripts.edge_repro_check import load


def write_case(tmp_path, *, partition="OOS", duplicate=False, clean=True):
    export = tmp_path / "mcx_trade_export.csv"
    with export.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["symbol", "strategy_tf", "E_regime", "A_regime", "X_regime",
            "entry_price", "stop_price", "target_price", "exit_price", "outcome",
            "gross_r", "mfe_R", "partition", "bars_held"])
        writer.writerow(["GOLDM", 4, "SW", "UP", "UP", 100, 90, 120, 120, "WIN", 2, 2.4, partition, 3])
    provenance = tmp_path / "trade_provenance.csv"
    with provenance.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["export_row_index", "setup_id", "signal_timestamp", "partition"])
        writer.writeheader()
        writer.writerow({"export_row_index": 0, "setup_id": "stable-id", "signal_timestamp": "2026-01-05T10:00:00+05:30", "partition": partition})
        if duplicate:
            writer.writerow({"export_row_index": 0, "setup_id": "stable-id-2", "signal_timestamp": "2026-01-05T10:00:00+05:30", "partition": partition})
    manifest = tmp_path / "run_manifest.json"
    manifest.write_text(json.dumps({"source_class": "AUTHORITATIVE_CLEAN" if clean else "NON_AUTHORITATIVE_DIAGNOSTIC",
                                    "synthetic_or_test_only": not clean,
                                    "data_validation": {"status": "VALID"}}))
    return export, provenance, manifest


def test_14_column_export_joins_timestamp_and_preserves_oos(tmp_path):
    export, provenance, manifest = write_case(tmp_path)
    rows = load(export, None, provenance, manifest, "2026-01-01")
    assert len(rows) == 1
    assert rows[0]["d"] == "2026-01-05"
    assert rows[0]["cell"] == ("GOLDM", "SW", "UP", 4, "UP")


@pytest.mark.parametrize("kwargs", [
    {"duplicate": True},
    {"clean": False},
    {"partition": "IS"},
])
def test_invalid_provenance_or_non_authoritative_evidence_fails_closed(tmp_path, kwargs):
    export, provenance, manifest = write_case(tmp_path, **kwargs)
    with pytest.raises(ValueError):
        load(export, None, provenance, manifest, "2026-01-01")


def test_missing_provenance_is_not_inferred_from_row_order(tmp_path):
    export, provenance, manifest = write_case(tmp_path)
    with pytest.raises(ValueError, match="timestamp"):
        load(export, None)
