"""Persistent, segment-scoped expiry refresh coordination for FYERS histories.

The updaters own downloading and writing candles.  This module only remembers
instrument-master snapshots, creates one event per expiry date, and decides
when an already-pending event may run.  Keeping this separate makes it usable
by NSE futures and MCX without changing their normal delta paths.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Iterable
from zoneinfo import ZoneInfo

import pandas as pd


IST = ZoneInfo("Asia/Kolkata")
LOG = logging.getLogger(__name__)


class ExchangeCalendar:
    """Calendar backed by an operations-maintained JSON override file.

    The file is intentionally exchange specific so an MCX evening session can
    be represented independently from NSE.  Example::

      {"NSE": {"2026-10-20": []},
       "MCX": {"2026-10-20": [["17:00", "23:30"]]}}
    """

    DEFAULTS = {"NSE": ((time(9, 15), time(15, 30)),),
                "MCX": ((time(9, 0), time(23, 30)),)}

    def __init__(self, calendar_file: str | os.PathLike | None = None, refresh_delay_minutes: int | None = None):
        self.calendar_file = Path(calendar_file) if calendar_file else None
        self._overrides = self._load()
        self.refresh_delay_minutes = (int(os.getenv("FYERS_EXPIRY_REFRESH_DELAY_MINUTES", "0"))
                                      if refresh_delay_minutes is None else refresh_delay_minutes)

    def _load(self) -> dict:
        if not self.calendar_file:
            return {}
        try:
            with self.calendar_file.open(encoding="utf-8") as handle:
                return json.load(handle)
        except FileNotFoundError:
            LOG.warning("[MARKET] Calendar file %s is absent; using regular-session defaults", self.calendar_file)
        except (OSError, ValueError) as exc:
            LOG.error("[MARKET] Cannot read calendar file %s: %s", self.calendar_file, exc)
        return {}

    def sessions(self, exchange: str, session_date: date):
        raw = self._overrides.get(exchange, {}).get(session_date.isoformat())
        if raw is None:
            if session_date.weekday() >= 5:
                return ()
            return self.DEFAULTS[exchange]
        try:
            return tuple((time.fromisoformat(start), time.fromisoformat(end)) for start, end in raw)
        except (TypeError, ValueError) as exc:
            LOG.error("[MARKET] Invalid %s calendar entry for %s: %s", exchange, session_date, exc)
            return ()

    def is_open(self, exchange: str, now: datetime) -> bool:
        now = ensure_ist(now)
        for start, end in self.sessions(exchange, now.date()):
            delayed_start = (datetime.combine(now.date(), start, IST)
                             + timedelta(minutes=self.refresh_delay_minutes)).time()
            if delayed_start <= now.time() <= end:
                return True
        return False

    def final_close(self, exchange: str, session_date: date) -> time | None:
        sessions = self.sessions(exchange, session_date)
        return max((end for _, end in sessions), default=None)


def ensure_ist(value: datetime | None = None) -> datetime:
    value = value or datetime.now(IST)
    return value.replace(tzinfo=IST) if value.tzinfo is None else value.astimezone(IST)


def validate_history(frame: pd.DataFrame, *, validate_ohlc: bool = True) -> None:
    """Reject failed, malformed, or obviously corrupt history before a swap."""
    expected = {"tradeDate", "open", "high", "low", "close", "qty"}
    if frame is None or frame.empty or not expected.issubset(frame.columns):
        raise ValueError("FYERS history is empty or missing expected candle columns")
    dates = pd.to_datetime(frame["tradeDate"], dayfirst=True, errors="coerce")
    if dates.isna().any() or dates.duplicated().any() or not dates.is_monotonic_increasing:
        raise ValueError("FYERS candle timestamps are invalid, duplicated, or unordered")
    prices = frame[["open", "high", "low", "close"]].apply(pd.to_numeric, errors="coerce")
    if prices.isna().any().any():
        raise ValueError("FYERS candles contain non-numeric OHLC prices")
    if validate_ohlc and ((prices["high"] < prices[["open", "close", "low"]].max(axis=1)).any() or (prices["low"] > prices[["open", "close", "high"]].min(axis=1)).any()):
        raise ValueError("FYERS candles contain inconsistent OHLC prices")


def normalize_fyers_ohlc(frame: pd.DataFrame, *, max_invalid_fraction: float = 0.01) -> pd.DataFrame:
    """Repair rare FYERS continuous-series envelope defects before validation.

    FYERS occasionally returns a stitched candle whose open or close sits
    outside its reported high/low envelope.  The candle's observed prices are
    retained and only the envelope is widened to contain them.  A material
    number of such defects still rejects the response rather than masking a
    malformed export.
    """
    required = {"open", "high", "low", "close"}
    if frame is None or frame.empty or not required.issubset(frame.columns):
        return frame
    prices = frame[["open", "high", "low", "close"]].apply(pd.to_numeric, errors="coerce")
    if prices.isna().any().any():
        return frame
    upper = prices.max(axis=1)
    lower = prices.min(axis=1)
    invalid = (prices["high"] < upper) | (prices["low"] > lower)
    invalid_count = int(invalid.sum())
    if not invalid_count:
        return frame
    fraction = invalid_count / len(frame)
    if fraction > max_invalid_fraction:
        raise ValueError(
            f"FYERS candles contain inconsistent OHLC prices in {invalid_count}/{len(frame)} rows")
    repaired = frame.copy()
    repaired.loc[invalid, "high"] = upper.loc[invalid]
    repaired.loc[invalid, "low"] = lower.loc[invalid]
    LOG.warning("[VALIDATION] Repaired FYERS OHLC envelopes for %d/%d stitched candles",
                invalid_count, len(frame))
    return repaired


def safe_replace_csv(frame: pd.DataFrame, destination: str | os.PathLike, *, validate_ohlc: bool = True) -> None:
    """Write and validate a sibling staging file, then atomically replace CSV."""
    validate_history(frame, validate_ohlc=validate_ohlc)
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{destination.stem}.", suffix=".staging", dir=destination.parent)
    os.close(fd)
    try:
        frame.to_csv(temporary, index=False)
        validate_history(pd.read_csv(temporary), validate_ohlc=validate_ohlc)
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class ExpiryRefreshCoordinator:
    """JSON-backed expiry event state with crash recovery and atomic writes."""

    def __init__(self, state_path: str | os.PathLike, exchange: str,
                 calendar: ExchangeCalendar | None = None, now_fn=None):
        self.state_path = Path(state_path)
        self.exchange = exchange
        self.calendar = calendar or ExchangeCalendar(os.getenv("FYERS_EXPIRY_CALENDAR_FILE"))
        self.now_fn = now_fn or (lambda: datetime.now(IST))
        self.state = self._load()
        for event in self.state["events"].values():
            if event["status"] == "in_progress":
                event["status"] = "pending"
                event["failure"] = "Recovered after interrupted refresh"
        self._save()

    def _load(self) -> dict:
        try:
            with self.state_path.open(encoding="utf-8") as handle:
                loaded = json.load(handle)
            return {
                "known_contracts": loaded.get("known_contracts", {}),
                "front_contracts": loaded.get("front_contracts", {}),
                "events": loaded.get("events", {}),
            }
        except FileNotFoundError:
            return {"known_contracts": {}, "front_contracts": {}, "events": {}}
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"Cannot safely read expiry-refresh state {self.state_path}: {exc}") from exc

    def _save(self) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".expiry-refresh-", suffix=".json", dir=self.state_path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(self.state, handle, indent=2, sort_keys=True)
                handle.flush(); os.fsync(handle.fileno())
            os.replace(temporary, self.state_path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def observe(self, contracts: Iterable[dict] | None, now: datetime | None = None) -> None:
        """Record master data and schedule a re-anchor after an expiry date.

        FYERS changes continuous history when its front contract rolls.  A
        refresh must therefore be based on the newly published front contract,
        never on the expiry day's last session.  ``front_contracts`` makes the
        transition explicit and survives master-file pruning/restarts.
        """
        if contracts is None:
            LOG.error("[EXPIRY] Valid %s expiry metadata unavailable; refresh detection deferred", self.exchange)
            return
        now = ensure_ist(now or self.now_fn())
        normalized = {}
        for contract in contracts:
            symbol, expiry = contract.get("symbol"), contract.get("expiry")
            if not symbol or not expiry:
                LOG.warning("[EXPIRY] Ignoring contract with incomplete expiry metadata: %r", contract)
                continue
            expiry_date = self._date(expiry)
            if not expiry_date:
                LOG.warning("[EXPIRY] Ignoring contract with invalid expiry metadata: %r", contract)
                continue
            normalized[symbol] = {
                "symbol": symbol,
                "expiry": expiry_date.isoformat(),
                "underlying": str(contract.get("underlying") or symbol),
            }

        known = self.state["known_contracts"]
        known.update(normalized)  # expired contracts remain available for later detection
        current_fronts = {}
        for item in normalized.values():
            underlying = item["underlying"]
            prior = current_fronts.get(underlying)
            if prior is None or item["expiry"] < prior["expiry"]:
                current_fronts[underlying] = item

        previous_fronts = self.state["front_contracts"]
        for underlying, front in current_fronts.items():
            previous = previous_fronts.get(underlying)
            if previous and previous.get("symbol") != front["symbol"]:
                LOG.info("[EXPIRY] Front contract changed for %s: %s -> %s",
                         underlying, previous.get("symbol"), front["symbol"])
            previous_fronts[underlying] = front

        for item in known.values():
            expiry_date = date.fromisoformat(item["expiry"])
            # The re-anchor belongs to the first eligible session *after* the
            # expiry date.  This also protects late MCX sessions on expiry day.
            if now.date() <= expiry_date:
                continue
            event_id = f"{self.exchange}:{expiry_date.isoformat()}"
            event = self.state["events"].setdefault(event_id, {
                "id": event_id, "exchange": self.exchange, "segment": self.exchange,
                "expiry_date": expiry_date.isoformat(), "expired_contracts": [],
                "status": "pending", "last_attempt": None, "completed_at": None,
                "failure": None, "retry_count": 0,
            })
            if item["symbol"] not in event["expired_contracts"]:
                event["expired_contracts"].append(item["symbol"])
                LOG.info("[EXPIRY] Contract expiry detected: %s %s", item["symbol"], expiry_date)
        self._save()

    def affected_underlyings(self, events: Iterable[dict]) -> set[str]:
        """Map persisted expired FYERS symbols to their source underlyings.

        Events intentionally retain contract symbols for auditability.  The
        updaters, however, operate by underlying and must refresh only the
        currently active contracts for an underlying that actually rolled.
        """
        expired_symbols = {
            symbol for event in events for symbol in event.get("expired_contracts", [])
        }
        return {
            item["underlying"] for symbol, item in self.state["known_contracts"].items()
            if symbol in expired_symbols and item.get("underlying")
        }

    def pending_and_eligible(self, now: datetime | None = None) -> list[dict]:
        now = ensure_ist(now or self.now_fn())
        if not self.calendar.is_open(self.exchange, now):
            return []
        # A completed expiry session schedules the rebuild for the *following*
        # eligible session, never during the expiry day's remaining clock time.
        return [event for event in self.state["events"].values()
                if event["status"] in {"pending", "failed"}
                and date.fromisoformat(event["expiry_date"]) < now.date()]

    def blocks_engine(self, now: datetime | None = None) -> bool:
        """Whether a rolled series must be rebuilt before setup evaluation."""
        now = ensure_ist(now or self.now_fn())
        return any(
            event["status"] in {"pending", "failed", "in_progress"}
            and date.fromisoformat(event["expiry_date"]) < now.date()
            for event in self.state["events"].values()
        )

    def start(self, events: Iterable[dict], now: datetime | None = None) -> None:
        stamp = ensure_ist(now or self.now_fn()).isoformat()
        for event in events:
            stored = self.state["events"][event["id"]]
            stored.update(status="in_progress", last_attempt=stamp, failure=None)
        self._save()

    def complete(self, events: Iterable[dict], now: datetime | None = None) -> None:
        stamp = ensure_ist(now or self.now_fn()).isoformat()
        for event in events:
            self.state["events"][event["id"]].update(status="completed", completed_at=stamp, failure=None)
        self._save()

    def fail(self, events: Iterable[dict], error: Exception | str, now: datetime | None = None) -> None:
        stamp = ensure_ist(now or self.now_fn()).isoformat()
        for event in events:
            stored = self.state["events"][event["id"]]
            stored.update(status="failed", last_attempt=stamp, failure=str(error), retry_count=stored["retry_count"] + 1)
        self._save()

    @staticmethod
    def _date(value) -> date | None:
        if isinstance(value, datetime): return value.date()
        if isinstance(value, date): return value
        for fmt in ("%d-%m-%Y", "%d-%m-%Y %H:%M:%S", "%Y-%m-%d"):
            try: return datetime.strptime(str(value), fmt).date()
            except ValueError: pass
        return None
