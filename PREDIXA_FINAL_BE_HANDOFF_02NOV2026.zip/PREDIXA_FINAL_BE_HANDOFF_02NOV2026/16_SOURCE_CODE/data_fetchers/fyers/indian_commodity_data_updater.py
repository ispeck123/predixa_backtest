import pandas as pd
from datetime import datetime
# from apps.finprod_backend.futures.nsep import start_date
from shared.config.settings import stock_data_dir_config as sddcfg
from shared.db.dbconn import DBConnection
from shared.db.db_model import CommoditiesMaster
from sqlitedict import SqliteDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from scripts.stock_logic import proc_delta_stock_items
import os, re, csv
from datetime import datetime, timedelta
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from fyers_apiv3 import fyersModel
import time
import requests
from io import StringIO
from tqdm import tqdm
import logging
from data_fetchers.fyers.expiry_refresh import normalize_fyers_ohlc, safe_replace_csv
from scripts.mcx_session import mcx_e1_session_ids

logger = logging.getLogger(__name__)

class MCXFutureDataHandler:
    def __init__(self):
        full_access_token=<REDACTED>
        self.fyers = fyersModel.FyersModel(client_id=full_access_token.rsplit(":", 1)[0], is_async=False, token=full_access_token.rsplit(":", 1)[1], log_path="")
        self.download_path = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv')
        self.output_path = os.path.join(sddcfg.indian_commodity_data, 'processed_data_files')
        self.commodities = self.get_commodity_symbols()
        self.lite_db = SqliteDict('finprod.sqlite')
        self.name_interval_dict = {
            "D" : "daily", 
            "60": "sixty", 
            "15": "fifteen",
            "120": "one_twenty",
            "240": "two_forty",
        }
        self.full_history_start = datetime(2020, 1, 1)
        self.update_latest_3_expiries_mcx()
    
    def get_commodity_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(CommoditiesMaster.symbol).filter(CommoditiesMaster.is_active == 1).all()
        sym_list = [s[0] for s in symbols]
        dbc.close_engine()
        return sym_list

    def get_latest_fyers_commodity_symbol_expiry(self, product: str):
        try:
            # Step 1: Download the latest file
            url = "https://public.fyers.in/sym_details/MCX_COM.csv"
            response = requests.get(url)
            response.raise_for_status()  # Raise error if request failed
            # Step 2: Read into DataFrame (no headers in file)
            df = pd.read_csv(StringIO(response.text), header=None)
            # Step 3: Filter for product
            df = df[df[9].astype(str).str.contains(f"MCX:{product}", na=False)]
            df = df[df[9].astype(str).str.contains("FUT", na=False)]
            # Step 4: Convert expiry column (index 10) to datetime
            df["parsed_date"] = df[1].apply(self.extract_date)
            df = df.drop_duplicates(subset=["parsed_date"], keep='last').reset_index(drop=True)
            df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date", ascending=True)
            df['parsed_date'] = df['parsed_date'].dt.strftime('%d-%m-%Y')
            # Step 5: Sort and return latest symbol
            print(df.tail()['parsed_date'])
            fdf = pd.DataFrame({
                "symbol": df[9].to_list()[:3],
                "expiry": df["parsed_date"].to_list()[:3]
            })
            # Step 5: Sort and return latest symbol
            return fdf.to_dict('records')

        except Exception as e:
            print(f"Error fetching latest symbol: {e}")
            return None

    def extract_date(self, entry):
        match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
        if match:
            # year, month, day = match.groups()
            day, month, year = match.groups()
            full_date_str = f"20{year} {month} {day}"
            return datetime.strptime(full_date_str, "%Y %b %d")
        return None

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        df['timstamp'] = pd.to_datetime(df['tradeDate'], dayfirst=True, errors='coerce')
        df = df.dropna(subset=['timstamp']).sort_values('timstamp').reset_index(drop=True)
        df.set_index('timstamp', inplace=True)
        # df = df.sort_values(by='tradeDate', ascending=True)
        # Resample to weekly frequency
        re_sample = 'W-FRI' if sample == 'W' else sample
        grouped = df.groupby(pd.Grouper(freq=re_sample))
        records = []
        for _, group in grouped:
            if group.empty:
                continue
            first_date = group.index[0]
            open_ = group['open'].iloc[0]
            high_ = group['high'].max()
            low_ = group['low'].min()
            close_ = group['close'].iloc[-1]
            qty_ = group['qty'].sum()

            records.append({
                "tradeDate": first_date,
                "open": open_,
                "high": high_,
                "low": low_,
                "close": close_,
                "qty": qty_
            })
        # print(records)
        result_df = pd.DataFrame(records)
        # print(result_df.columns, "#####################################", file_name)
        result_df['tradeDate'] = result_df['tradeDate'].dt.strftime("%d/%m/%Y %H:%M:%S")
        result_df = result_df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name)
    
    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        start_date = now_date - timedelta(days=365)
        # if frame == 'D' or frame == 'M' or frame == 'W':
        #     start_date = now_date - timedelta(days=365)
        # elif frame == '60':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '15':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '120':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '240':
        #     start_date = now_date - timedelta(days=100)
        return now_date, start_date


    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        df['_dt'] = pd.to_datetime(df['tradeDate'], dayfirst=True, errors='coerce')
        df = df.dropna(subset=['_dt']).sort_values('_dt').reset_index(drop=True)
        # E1: fixed-size positional chunks must never consume the final candle
        # from one MCX session and the 09:00 candle from the next.  That would
        # synthesize a 75-minute OHLC bar across the overnight void.
        df['_session_id'] = mcx_e1_session_ids(df['_dt'].tolist())
        df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate', '_session_id']]
        chunk_size = 5
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for _, session_df in df.groupby('_session_id', sort=False):
            for i in range(0, len(session_df), chunk_size):
                chunk = session_df.iloc[i:i + chunk_size]
                if len(chunk) < chunk_size:
                    # Preserve the existing partial-bar policy, but reset it at
                    # the session seam instead of carrying it into 09:00.
                    break

                new_row = {col: func(chunk) for col, func in agg_map.items()}
                output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")


    
    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(sddcfg.indian_commodity_data,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')

    def _max_days_for_interval(self, interval: str) -> int:
        if interval in ("D", "1D", "W", "M"):
            return 366
        return 100

    def _iter_date_chunks(self, start_date: datetime, end_date: datetime, chunk_days: int):
        current = start_date
        while current <= end_date:
            chunk_to = min(current + timedelta(days=chunk_days - 1), end_date)
            yield current, chunk_to
            current = chunk_to + timedelta(days=1)

    def update_latest_3_expiries_mcx(self):
        out_res = []
        for symbol in self.commodities:
            int_dict = {}
            int_dict['symbol'] = symbol
            contracts = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            expiry_list = [item["expiry"] for item in contracts]
            int_dict['expiry'] = expiry_list
            out_res.append(int_dict)
            
        self.lite_db['indian_commodity_expiries'] = out_res
        self.lite_db.commit()
        self.lite_db.close()

    def fetch_candle_data(self, instrument_token, from_date, to_date, interval, max_retries=10,
                          show_progress=False):
        chunk_days = self._max_days_for_interval(interval)
        dfs = []
        chunks = list(self._iter_date_chunks(from_date, to_date, chunk_days))
        iterator = tqdm(chunks, desc=f"MCX {instrument_token} {interval} chunks",
                        unit="chunk", leave=False) if show_progress else chunks
        for chunk_from, chunk_to in iterator:
            df_chunk = self._fetch_candle_data_once(
                instrument_token,
                chunk_from,
                chunk_to,
                interval,
                max_retries
            )

            if df_chunk is not None and not df_chunk.empty:
                dfs.append(df_chunk)

        if not dfs:
            return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'qty', 'tradeDate'])

        df = pd.concat(dfs, ignore_index=True)

        # remove duplicates (edge overlaps)
        df.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)

        # sort properly
        df['_dt'] = pd.to_datetime(df['tradeDate'], dayfirst=True, errors='coerce')
        df.sort_values('_dt', inplace=True)
        df.drop(columns=['_dt'], inplace=True)
        df.reset_index(drop=True, inplace=True)

        return df

    def _fetch_candle_data_once(self, instrument_token, from_date, to_date, interval, max_retries=10):
        for attempt in range(max_retries):
            try:
                data = {
                        "symbol": instrument_token,
                        "resolution":interval,
                        "date_format":"1",
                        "range_from":from_date.strftime("%Y-%m-%d"),
                        "range_to":to_date.strftime("%Y-%m-%d"),
                        "cont_flag":"1"
                    }

                response = self.fyers.history(data=data)
                if 'candles' in response.keys():
                    df = pd.DataFrame(response['candles'], columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
                    df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
                    df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                    df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
                    return df
                else:
                    logger.warning("[FYERS] MCX history response for %s %s; retry %d/%d: %s",
                                   instrument_token, interval, attempt + 1, max_retries, response)
                    wait = 2 ** attempt
                    time.sleep(wait)
            except Exception as e:
                logger.exception("[FYERS] MCX request failed for %s %s: %s", instrument_token, interval, e)
                return pd.DataFrame()

    def active_contracts(self):
        """Return the current valid master snapshot or None when it cannot be read."""
        contracts = []
        for symbol in self.commodities:
            discovered = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            if not discovered:
                return None
            contracts.extend({**contract, "underlying": symbol} for contract in discovered)
        return contracts

    def download_all(self, intervals=['D', '60', '15', '120', '240'], force_full_refresh=False,
                     underlyings=None):
        # today = datetime.now()
        selected_underlyings = set(underlyings) if underlyings is not None else None
        symbols = [symbol for symbol in self.commodities
                   if selected_underlyings is None or symbol in selected_underlyings]
        if force_full_refresh and not symbols:
            raise RuntimeError("No rolled MCX underlyings were selected for full refresh")
        operation = "full re-anchor" if force_full_refresh else "delta update"
        logger.info("[FYERS] Starting MCX %s for %d underlyings: %s",
                    operation, len(symbols), symbols)
        progress = tqdm(total=len(symbols), desc=f"MCX {operation}", unit="symbol")
        for symbol in symbols:
            contracts = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            if not contracts:
                message = f"No active FYERS MCX contract metadata for {symbol}"
                if force_full_refresh:
                    progress.close()
                    raise RuntimeError(message)
                logger.warning("[FYERS] %s", message)
                progress.update(1)
                continue
            logger.info("[FYERS] %s: discovered %d active contracts", symbol, len(contracts))
            for items in contracts:
                future_token = items['symbol']
                expiry = items['expiry']
                numbers = re.findall(r'\d+', expiry)
                # Join all found numbers into one string
                exp_num = ''.join(numbers)
                for interval in intervals:
                    # end_dt, start_dt = self.return_now_and_previous_date(interval)
                    # df = self.fetch_candle_data(future_token, start_dt, end_dt, interval)
                    # if not df.empty:
                    fname = f"{symbol}_{exp_num}_{self.name_interval_dict[interval]}.csv"
                    file_path = os.path.join(self.download_path, fname)
                    if os.path.exists(file_path) and not force_full_refresh:
                        try:
                            existing_df = pd.read_csv(file_path)
                            if not existing_df.empty:
                                last_date = pd.to_datetime(existing_df['tradeDate'], dayfirst=True, errors='coerce').max()
                                # fetch only recent data (small window instead of full history)
                                if pd.isna(last_date):
                                    delta_start = datetime.now() - timedelta(days=365)
                                else:
                                    delta_start = last_date - timedelta(days=5)

                                delta_end = datetime.now()
                                df_delta = self._fetch_candle_data_once(future_token, delta_start, delta_end, interval)
                                if df_delta is not None and not df_delta.empty:
                                    combined = pd.concat([existing_df, df_delta], ignore_index=True)
                                    # remove duplicates
                                    combined.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)
                                    # sort
                                    combined['_dt'] = pd.to_datetime(combined['tradeDate'], dayfirst=True, errors='coerce')
                                    combined.sort_values('_dt', inplace=True)
                                    combined.drop(columns=['_dt'], inplace=True)
                                    combined.reset_index(drop=True, inplace=True)

                                    combined.to_csv(file_path, index=False)
                                    logger.info("[FYERS] MCX delta updated %s (%d candles)", fname, len(combined))
                                else:
                                    logger.warning("[FYERS] MCX delta returned no candles for %s", fname)

                        except Exception as exx:
                            logger.exception("[FYERS] MCX delta failed for %s: %s", fname, exx)

                        # df.to_csv(os.path.join(self.download_path, fname), index=False)
                        # print(f"Saved: {fname}")
                    else:
                        
                        # Re-anchoring requests FYERS's entire continuous
                        # series from the current front contract.  A normal
                        # missing-file bootstrap retains the legacy one-year
                        # history window.
                        end_dt = datetime.now()
                        start_dt = (self.full_history_start if force_full_refresh
                                    else end_dt - timedelta(days=365))
                        logger.info("[REFRESH] MCX fetching %s from %s to %s",
                                    fname, start_dt.date(), end_dt.date())
                        df_full = self.fetch_candle_data(
                            future_token, start_dt, end_dt, interval,
                            show_progress=force_full_refresh,
                        )
                        if df_full is not None and not df_full.empty:
                            if force_full_refresh:
                                df_full = normalize_fyers_ohlc(df_full)
                            # Stage then atomically replace. Existing history remains readable on failure.
                            # Normal bootstrap preserves legacy FYERS acceptance;
                            # expiry refreshes additionally enforce OHLC bounds.
                            safe_replace_csv(df_full, file_path, validate_ohlc=force_full_refresh)
                            logger.info("[REFRESH] MCX replaced %s with %d candles", fname, len(df_full))
                        else:
                            logger.warning("[FYERS] MCX full history returned no candles for %s", fname)
                            if force_full_refresh:
                                raise RuntimeError(f"Full FYERS history unavailable for {symbol} {interval}")

            progress.update(1)
        progress.close()

        all_file_list = sorted(os.listdir(self.download_path))
        all_file_list = [
            item for item in all_file_list
            if any(str(item).startswith(f"{symbol}_") for symbol in symbols)
        ]
        logger.info("[FYERS] Building derived MCX bars for %d files", len(all_file_list))
        for items in tqdm(all_file_list, desc="MCX derived bars", unit="file"):
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            elif str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
    
    # def process_all(self):
    #     with ThreadPoolExecutor(max_workers=10) as executor:
    #         for stock_item in os.listdir(self.download_path):
    #             executor.submit(proc_delta_stock_items, stock_item, self.download_path, self.output_path)
    #     print("all_stock_process_complete...................")
    def process_all(self, underlyings=None):
        all_files = sorted(os.listdir(self.download_path))
        if underlyings is not None:
            selected = set(underlyings)
            all_files = [item for item in all_files
                         if any(str(item).startswith(f"{symbol}_") for symbol in selected)]
        logger.info("[FYERS] Processing %d MCX files into processed-data output", len(all_files))

        with ProcessPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(
                    proc_delta_stock_items,
                    stock_item,
                    self.download_path,
                    self.output_path
                )
                for stock_item in all_files
            ]

            for future in tqdm(
                as_completed(futures),
                total=len(futures),
                desc="MCX processed bars",
                unit="file",
            ):
                try:
                    future.result()
                except Exception as e:
                    logger.exception("[FYERS] Error processing MCX file: %s", e)

        logger.info("[FYERS] MCX processed-data build complete")
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = "path/to/directory"
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        
        chunk_size = 125 // 5
        output = []

        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }

        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "one_twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 125-minute chunks to save.")




