# PREDIXA MCX Phase-1 / Task 2B — Historical Dated-Contract Data Audit

Audit date: 02-Nov-2026 (Asia/Kolkata). **Provider scope: FYERS only**, per owner instruction. No Kite or Sharekhan source is treated as applicable evidence. Existing non-FYERS request artifacts are excluded; after the owner clarification, this execution made no non-FYERS provider calls. No strategy, order, scanner, deployment, or Task 3/4 work was performed.

## Status

**PARTIALLY_COMPLETED — BUILDER EXISTS; REAL HISTORICAL VALIDATION BLOCKED BY DATA AND POLICY.** The Task 2 builder and its synthetic fixture tests remain unchanged. The available exact dated FYERS evidence is a single CRUDEOILM contract history. No genuine outgoing/incoming pair with verified overlap and historical point-in-time master coverage was found for any required underlying.

The required underlying set is GOLDM, GOLDGUINEA, SILVERM, CRUDEOILM, NATGASMINI. The CSV inventory is machine-readable in `PREDIXA_MCX_PHASE1_TASK2B_CONTRACT_INVENTORY.csv` (a narrow `.gitignore` exception preserves this required artifact while the repository continues ignoring other CSVs); it preserves per-file paths, row counts, observed date bounds, classification, hashes, and provenance notes. It has 248 rows.

## Existing pipeline and FYERS capability audit

- `data_fetchers/fyers/indian_commodity_data_updater.py` obtains symbols from the current FYERS MCX symbol master and requests `cont_flag="1"`. It writes each continuous/stitched history under an expiry-looking filename. A current master plus that filename does not attribute each historical candle to an expired dated contract.
- The archived FYERS research collector `research/zone_series_comparison/scripts/fetch_fyers.py` accepts an explicit symbol and `cont_flag`; the repository contains one exact `cont_flag=0` dated contract capture. That proves a bounded raw request path existed for that symbol/capture, not that FYERS can retrieve arbitrary expired MCX contracts today or expose complete historical masters/listing intervals.
- FYERS official plan documentation lists expired F&O history as a supported data category: Standard plan lists expired intraday data at 10 requests/day and daily expired data from 2024 for two years; Prime lists intraday within Prime limits and 7+ years daily. This indicates a provider capability/entitlement path may exist, subject to the authorized account plan. It does not itself establish the endpoint parameters, required symbol-master lookup, coverage for each MCX underlying, or successful retrieval of arbitrary expired dated-contract bars. Repository evidence still does not include that complete point-in-time history or a two-contract roll-overlap sample. Verify the active FYERS plan and exact dated-symbol request path before collection. [Official FYERS plan and expired F&O limits](https://support.fyers.in/portal/en/kb/articles/what-are-the-fyers-api-rate-limits-for-standard-and-prime-plans).
- The 216 current data files have previously passed inventory classification as `STITCHED_OR_CONTINUOUS` (all 216); there are 27 filename contract keys across nine symbols. In the current archive, each required exact underlying has three expiry-named keys and eight frames (daily, 15m, 60m, 120m, 240m, 75m, weekly, monthly), with observed coverage 2025-11-03 through 2026-11-02. These are not raw dated-contract evidence.
- The separate legacy `data_old/indian_commodity_data/latest_data_csv` includes expiry-named groups for GOLDM (5), CRUDEOILM (5), and SILVERM (4), but no exact GOLDGUINEA or NATGASMINI files. Per-file provider ID, request mode, instrument master, and response provenance are absent, so those sources are `UNKNOWN`, not reclassified as raw dated contracts. A file's apparent coverage through a filename expiry is insufficient evidence of executability.

Official FYERS references reviewed: [History API](https://support.fyers.in/portal/en/kb/articles/how-can-i-get-historical-data-for-a-symbol-over-a-specific-date-range-using-the-history-api), [symbol master guidance](https://support.fyers.in/portal/en/kb/articles/where-can-i-find-the-most-recent-symbols-for-different-exchanges-using-fyers-api-v2-1), and [API limits / expired F&O coverage](https://support.fyers.in/portal/en/kb/articles/what-are-the-fyers-api-rate-limits-for-standard-and-prime-plans). The saved source files and response metadata remain the primary evidence; API docs do not fill missing historical contract IDs.

## Real dated-contract evidence

One FYERS raw dated contract is present. Five inventory file rows for CRUDEOILM carry this same contract across raw/extended copies and timeframes; they are one contract identity, not five contracts:

- Underlying: CRUDEOILM. Exact FYERS symbol: `MCX:CRUDEOILM26OCTFUT`; stated expiry: 2026-10-19; 60-minute bars; 1,302 rows; 2026-05-22 21:00 IST through 2026-10-08 23:00 IST. Metadata states `cont_flag=0`, epoch source timestamps converted to Asia/Kolkata, and candle-start semantics. CSV SHA-256: `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6`; metadata SHA-256: `bdbe2a271a03f8f56cce1301ad7c9333fce90659bc88a3f15f96bc74b0cf113b`.
- It has no verified `listed_from`, preceding/succeeding dated contract pair, roll effective time, transition overlap, or approved policy. It is partial single-contract source-integrity evidence only. It cannot validate a continuous series or a roll.
- GOLD symbols present in adjacent research are `GOLD`, not GOLDM, and are excluded from the required instrument set. No exact dated FYERS OHLCV was verified for GOLDM, GOLDGUINEA, SILVERM, or NATGASMINI.

Non-FYERS broker files or records in the wider research tree are excluded from this audit, inventory, and validation scope per owner direction.

## Contract inventory by underlying

| Underlying | Current stitched keys/frames | Legacy expiry-named groups | Verified dated FYERS contracts | Validated roll pair |
|---|---:|---:|---:|---|
| GOLDM | 3 / 8 frames each | 5 (unverified provenance) | 0 | No |
| GOLDGUINEA | 3 / 8 frames each | 0 (unverified provenance) | 0 | No |
| SILVERM | 3 / 8 frames each | 4 (unverified provenance) | 0 | No |
| CRUDEOILM | 3 / 8 frames each | 5 (unverified provenance) | 1 (CRUDEOILM only) | No |
| NATGASMINI | 3 / 8 frames each | 0 (unverified provenance) | 0 | No |

The full file-level detail and SHA-256 values are in the inventory CSV. The counts above describe distinct filename groups only; filename groups are not certified contract identities.

## Roll policy and calendar dependency

No owner-approved MCX historical roll policy was found in the repository. Task2's builder supports explicit schedules and named additive or ratio adjustment, but neither method is approved as the research convention. The existing CRUDEOILM expiry calendar is partial and expiry-oriented; it is not a verified complete MCX trading-session calendar for all instruments and years. The fewer-than-three-trading-days rule cannot be validated on actual historical signals without authoritative session dates and instrument-specific expiry changes. No weekday/calendar-day approximation was used.

Policy decision required before production research reconstruction:

1. Select a non-lookahead roll trigger (e.g., explicit preapproved schedule/fixed trading-session offset, or point-in-time volume/OI crossover with sourced observations).
2. Approve additive or ratio back-adjustment, and version the policy.
3. Define whether the roll uses a particular session close/open or another executable synchronized observation.
4. Supply a complete authoritative exchange trading calendar and contract expiry/listing history.

The final hindsight-adjusted series must be distinguished from a point-in-time strategy input snapshot. The raw dated contract prices remain the executable-price basis.

## Task2 builder validation against real data

The saved CRUDEOILM FYERS raw sample passes source-level checks reported in the existing Task2 report: 1,302 OHLCV rows, ordered unique timestamps, valid OHLC envelopes, and E1 session IDs attached. The builder result is correctly `UNVERIFIED`, because listing date, verified roll transitions, and policy approval are absent. No output was promoted or written as a clean series. No cross-contract arithmetic can be tested with only one contract.

No genuine roll price, adjustment factor, real roll continuity, expiry-window eligibility, or all-five-underlying readiness was validated. The existing Task2 tests use deterministic synthetic fixtures for arithmetic and failure behavior only.

## E1 compatibility and safety

`audit/mcx_futures_backtest/contract_roll.py` imports `scripts.mcx_session.mcx_e1_session_ids` and attaches session IDs after selection; it does not create bridging bars. Task1 E1 tests and the combined focused safety tests were rerun (see validation report). The Task2 builder was not modified. MCX regime, capital allocator, scanner, and broker holds were not changed or activated.

## Exact data package required

For every exact dated contract covering the required study interval per underlying, acquire and retain: (a) FYERS exact dated symbol and stable provider identifier, expiry and historical listing/selection interval from archived point-in-time masters; (b) native OHLCV at required timeframes or a declared native timeframe with session-aware resampling, candle start/end semantics and timezone; (c) source request/response, requested/actual ranges, gaps, timestamps, and immutable SHA-256; (d) outgoing/incoming contract OHLCV overlap around each preapproved roll; (e) actual roll decision/effective timestamps and source-observed prices; (f) authoritative session calendar including holidays/special sessions and expiry shifts; and (g) approved roll and adjustment policy. Capture instrument lot/multiplier/tick/scale only if later executable P&L is computed.

Do not use current contract master to infer expired identities, continuous history as per-contract raw bars, expiry filenames as identity, or derived frames as independent provenance. Do not overwrite the 216 current sources.

## Task3 readiness

**NOT READY — DATA BLOCKED.** Task3 requires verified all-underlying dated histories, point-in-time contract mapping, roll overlaps and approved methodology, complete calendar, E1-clean resampling, and executable raw-price mapping. Those conditions are not met. No `mcx_trade_export.csv`, realized-R estimate, OOS test, or edge claim was generated.
