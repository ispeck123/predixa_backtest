# PREDIXA MCX Phase-1 / Task 2B — Validation Report

Date: 02-Nov-2026. Scope is offline inventory and builder-source validation using saved source artifacts. Provider scope is FYERS only. No live/paper trading, broker order workflow, production deployment, or Task3/4 activity occurred.

## Results

- Regression command: `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_contract_roll_adjustment.py tests/test_mcx_e1_session_boundary.py tests/test_mcx_remediation_guardrails.py tests/test_tf_regime_gate_by_exchange.py tests/test_commodity_bucket_approval.py`
- Result: **65 passed, 7 warnings, exit 0**. Warnings are existing SQLAlchemy/Pydantic/pkg_resources deprecations. Included Task2 contract-roll tests, Task1 E1 tests, and MCX safety/regime/bucket coverage. These unit tests are synthetic for roll arithmetic; they are not historical market validation.
- Offline real-source diagnostic: `/home/ispeck/anaconda3/envs/finpro/bin/python audit/mcx_futures_backtest/validate_task2b_fyers_sample.py` returned **0**; source_integrity_status=VALID, series_status=UNVERIFIED, 1,302 bars, 81 E1 session IDs, raw prices unchanged, 0 verified rolls. No provider request or credential access was made in this execution.
- Task2B live-data coverage: **BLOCKED / UNVERIFIED**. One saved FYERS dated CRUDEOILM contract has 60m, 240m, and daily captures, all one expiry; no adjacent dated contract or roll is included. FYERS documentation lists expired F&O entitlements, but account entitlement and exact retrieval of expired MCX raw intraday contracts have not been verified.
- Current source inventory: 216/216 previously classified `STITCHED_OR_CONTINUOUS`. Strict preflight remains expected to exit 2.
- Legacy source inventory: 224 CSVs total; exact five-underlying names account for GOLDM 40, CRUDEOILM 40, SILVERM 32, with no exact GOLDGUINEA/NATGASMINI. These legacy files have insufficient per-file source metadata and remain `UNKNOWN`.
- Calendar/roll checks: UNVERIFIED on real data. No authoritative complete MCX historical session calendar or approved roll policy found.
- E1: regression suite PASS for fixture scenarios. Real contract-roll+overnight seam not empirically validated because no overlapping real outgoing/incoming contract data is present.
- MCX gate/allocator/scanner/broker safety: regression tests in the command passed; no safety code was changed.
- Compilation: `/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile audit/mcx_futures_backtest/contract_roll.py audit/mcx_futures_backtest/validate_task2b_fyers_sample.py scripts/mcx_session.py data_fetchers/fyers/indian_commodity_data_updater.py tests/test_mcx_contract_roll_adjustment.py` returned **0**.

## Real sample identity and limits

Source: `research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv`; metadata `research/zone_series_comparison/metadata/fyers_raw.json`. Exact symbol `MCX:CRUDEOILM26OCTFUT`, `cont_flag=0`, stated expiry 2026-10-19, 60m, 1,302 rows from 2026-05-22 21:00 IST to 2026-10-08 23:00 IST. CSV SHA-256 `f0d24cd49325492d901358ed5c66203a7c134be3b694658b9ddd20f7e18843e6`; metadata SHA-256 `bdbe2a271a03f8f56cce1301ad7c9333fce90659bc88a3f15f96bc74b0cf113b`. Timestamp source is epoch/UTC converted to IST; metadata documents candle-start semantics. The sample proves only that the saved bars correspond to a specifically requested dated FYERS symbol in that capture. It does not prove point-in-time listing availability, any other expired contract, active selection dates, actual roll time, or a contract roll price pair.

## Failed/blocked checks

No two-contract real roll arithmetic was attempted because the second compatible dated FYERS contract and verified effective schedule are unavailable. No trading-day count was computed because complete authoritative session-calendar coverage is missing. No `VALID` full historical series claim is made. No production output was created.

## Repeatable commands

The regression command above was executed in this run. The strict source preflight was executed with disposable output. Command:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.preflight \
  --root data/indian_commodity_data/latest_data_csv \
  --output /tmp/predixa_mcx_t2b_preflight --strict-contract-history
```

Output: `MCX source files: 216; contract keys: 27; symbols: 9`; mode counts `{"STITCHED_OR_CONTINUOUS": 216}`; strict failure states historical contract-live attribution is not evidenced. Exit code **2**. This is an expected data blocker, not a passing clean-series validation.

Inventory integrity check: **248 rows**, all referenced source files present, all SHA-256 hashes matched, and no nonempty-source row pointed to an empty file (exit 0).

## Repository diff hygiene note

`git diff --check` returned exit **2** because the already-dirty worktree contains trailing whitespace in tracked modifications outside the Task2B file scope listed in `PREDIXA_MCX_PHASE1_TASK2B_CHANGED_FILES.txt` (including order/API and socket files). They were not edited during this task. A separate direct hygiene scan of all seven Task2B changed files returned **PASS**: all present, nonempty, and no trailing whitespace. The required inventory CSV was initially hidden by the repository-wide `**/*.csv` ignore; `.gitignore` now contains one exact exception for that file. The worktree contains unrelated pre-existing changes; this Task2B run did not reset or rewrite them.
