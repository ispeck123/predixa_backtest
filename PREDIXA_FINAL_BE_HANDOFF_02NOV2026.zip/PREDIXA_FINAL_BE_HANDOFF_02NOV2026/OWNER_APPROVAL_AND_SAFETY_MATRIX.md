# Owner approval and safety matrix

- NSE_CASH: BE initiated; not pre-authorized; owner-ratified after the fact on 02-Nov-2026.
- NSEFO: PAPER-only SW/SW/25 BUY, one simulated lot, serial governor, per-order approval and TP50 shadow; no REAL authorization.
- MCX: PAPER OFF, REAL OFF; research only until clean realized-R OOS evidence and separate authorization.
- Database: selecting Fin_product did not authorize writes; it remains unapproved.
- Tracking error: mean > -0.15R, n>=20/n>=40 thresholds retained; CI interpretation conflict blocks promotion.
