# Final test and validation report

## Latest actual packaging-turn execution
`/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_phase1_graduated_execution.py tests/test_paper_order_monitoring.py tests/test_nsefo_tp50_paper_governor.py tests/test_nsefo_instrument_metadata.py tests/test_paper_db_config.py`

Result: **367 passed, 27 warnings, exit 0**. Compilation of packaged Python modules passed. A scoped `git diff --check` of packaging and handoff files passed. Repository-wide `git diff --check` reports trailing whitespace in unrelated existing dirty files (`bucket_orders_*`, `fyers_general_socket.py`, and `apps/finprod_backend/endpoints/order.py`); those files were not modified or normalized for this handoff. Historical drop verifier C1-C12 PASS is preserved in reports; it was not re-run during packaging. No broker or shared-DB writes occurred.
