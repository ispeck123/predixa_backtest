# Futures fresh-backtest runbook

## Scope and production path

The runner uses only futures OHLC from
`data/indian_stocks_future_data/latest_data_csv` and calls the current
production entry point:

```python
process_setup_fc(underlying, future_timeframe_stack, expiry, last_d_time, True)
```

It does not use prior orders as input and does not change production code. A
scan is frozen at the completed X-bar timestamp; setup/trend processing sees
only data through that timestamp. Entry and stop/target resolution use later
X bars only.

Configured futures stacks are read from `shared/config/settings.py`:

| TF | E / A / X |
|---:|---|
| 1 | monthly / weekly / daily |
| 2 | weekly / daily / sixty |
| 5 | daily / one_twenty_five / twenty_five |
| 25 | weekly / daily / seventy_five |

TF6 is deliberately unsupported: there is no `FUTURE_TIME_FRAME_6` in current
production configuration. The command fails rather than guessing a mapping.

## Contract selection

`--expiries 3` selects, for each requested underlying, the first three contract
expiries that have all files required by the selected timeframe stack and whose
expiry date is on or after `--end`. If fewer exist, it deterministically falls
back to the first three fully available expiries. Every row stores its contract
as `UNDERLYING@DDMMYYYY`; the exact selection is in the run's `config_json`.

## Commands

First check the exact task universe. This does not invoke production:

```bash
python -m audit.futures_trend_backtest.run_futures_backtest dry-run \
  --symbols all --tfs 1,2,5,25 --expiries 3 \
  --start 2024-09-29 --end 2026-09-16 \
  --executor process --workers 4 \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite
```

For a controlled validation run, use one known underlying and a small task cap:

```bash
python -m audit.futures_trend_backtest.run_futures_backtest run \
  --run-name futures_validation_reliance_tf2 \
  --symbols RELIANCE --tfs 2 --expiries 1 \
  --start 2026-09-01 --end 2026-09-05 --limit-tasks 20 \
  --executor process --workers 1 \
  --storage audit/futures_trend_backtest/storage/futures_validation.sqlite
```

Start the two-year baseline after validation. Substitute a file path for
`--symbols` when an approved instruments list is available; the file contains
one underlying per line and may include comments beginning with `#`.

```bash
python -m audit.futures_trend_backtest.run_futures_backtest run \
  --run-name current_production_futures_2y \
  --symbols all --tfs 1,2,5,25 --expiries 3 \
  --start 2024-09-29 --end 2026-09-16 \
  --executor process --workers 4 --max-retries 2 \
  --compute-reference-oracle --progress-seconds 10 \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite
```

The command prints `run_id=...` on its first line. Copy that actual value.
Check it while the run is active:

```bash
python -m audit.futures_trend_backtest.run_futures_backtest status RUN_ID \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite
```

If the process is stopped, resume the same persisted task universe:

```bash
python -m audit.futures_trend_backtest.run_futures_backtest resume RUN_ID \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite
```

After status is `COMPLETED`, create the analysis and report without rerunning
production calls:

```bash
python -m audit.futures_trend_backtest.analyze_futures \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite \
  --run RUN_ID \
  --output audit/futures_trend_backtest/results/current_production_futures_2y

python -m audit.futures_trend_backtest.report_futures \
  --storage audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite \
  --run RUN_ID \
  --analysis-dir audit/futures_trend_backtest/results/current_production_futures_2y \
  --output reports/FUTURES_TREND_ENGINE_2Y_BASELINE_REPORT.md
```

## Validation checks

- Confirm status has `COMPLETED == TOTAL` and `failed_count == 0` (or review
  the `errors` table before interpreting a partially completed run).
- Confirm output includes rows for the intended `UNDERLYING@EXPIRY` contracts.
- Confirm `scan_population.csv` has all requested TFs.
- Preserve the SQLite file: it is the durable raw evidence. CSV reports are
  derived views and can be regenerated without replaying production.

## Performance note

A 2026-09-29 dry run found 1,943,498 tasks for all 184 discoverable
underlyings, three expiries, TF1/2/5/25 and the specified two-year range.
Use the validation run to measure the actual host throughput before committing
to the full run. Process workers are the default safe executor; do not assume
linear speedup or select a higher worker count without monitoring CPU/RAM.
