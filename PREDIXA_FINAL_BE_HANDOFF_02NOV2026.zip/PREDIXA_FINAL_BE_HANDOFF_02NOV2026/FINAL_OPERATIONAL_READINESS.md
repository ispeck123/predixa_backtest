# Final operational readiness

NSEFO scanner and data inputs initialized in bounded read-only validation; no PAPER process runs, no orders exist, and tracking clock is not started. MCX PAPER and REAL are off. DBA must authorize isolated PAPER schema/account/TLS/migration and bounded writes before any actual startup.
