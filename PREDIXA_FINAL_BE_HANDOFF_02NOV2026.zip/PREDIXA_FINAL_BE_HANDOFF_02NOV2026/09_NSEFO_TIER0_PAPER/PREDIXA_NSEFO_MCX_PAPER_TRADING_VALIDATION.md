# PREDIXA NSEFO + MCX Paper Trading Validation

## Summary

The deterministic local database path passes. All tests below use SQLite fixtures and injected setup results; they do not constitute a live-feed scan or edge-performance evidence.

## Verified local flows

### NSEFO PAPER

`tests/test_futures_scanner_persistence.py` runs the existing `FuturesGraduatedLiveReadonlyScanner` with a deterministic BUY setup and an isolated SQLite database. The test repeats the same scanner signal, confirms one `TradeSignal`, one `Future_Order`, and one `OMSOrderBucketFuture`, verifies PAPER provenance/status/one-unit quantity/no broker identifiers, then reads the order through `/bucket/orders/future/{order_id}`. **PASS**.

### MCX PAPER_OBSERVATION

`tests/test_mcx_paper_observation.py` calls the separate `run_mcx_paper_observation` entry point with a deterministic strategy fixture and a marked isolated SQLite database. It confirms:

- Signal → commodity order → OMS bucket are written transactionally.
- Mode is PAPER; trading status is SIMULATED; edge validation is UNVALIDATED.
- The FYERS contract symbol and signal timestamp are retained.
- A scanner repeat is idempotent; changed levels for the same stable signal identity are rejected.
- The monitoring endpoint returns the persisted record.
- Broker write methods are spied and are never called.
- The MCX regime gate still reports DENY.
- A REAL-mode job, disabled observation flag, unmarked database, unsupported symbol, and missing active master fail closed.
- A persistence error leaves no partial database rows and has no broker fallback.

**PASS** for the isolated fixture workflow.

## Commands and results

Python environment: `/home/ispeck/anaconda3/envs/finpro/bin/python`.

Focused suites:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile scripts/paper_observation.py scripts/paper_observation_runtime.py scripts/mcx_graduated_live_scanner.py shared/db/db_model.py apps/backend/api/bucket_orders_commodity.py tests/test_mcx_paper_observation.py tests/test_paper_order_monitoring.py tests/test_futures_scanner_persistence.py
exit 0

/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_paper_observation.py tests/test_paper_order_monitoring.py tests/test_futures_scanner_persistence.py tests/test_phase2_paper_pipeline.py tests/test_mcx_remediation_guardrails.py tests/test_mcx_golive_policy.py
42 passed; exit 0
```

Broader relevant regression command before the date-fixture correction:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_paper_order_monitoring.py
349 passed, 1 failed; exit 1
```

The single failure was `tests/test_futures_approval.py::test_scanner_row_refreshes_a_stale_rollover_contract_map`: its fixed expiry date was 27-Oct-2026, already past the run date, so the application correctly returned `FUT_REJECT_INVALID_EXPIRY`. The fixture was corrected in the final pending-task closure; it now derives a future expiry at run time and has a separate expiry-rejection test.

The historical rerun below excluded only that date-expired test while the correction was in progress:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_paper_order_monitoring.py -k 'not test_scanner_row_refreshes_a_stale_rollover_contract_map'
349 passed, 1 deselected; exit 0
```

Final full relevant suite after the correction:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_mcx_*.py tests/test_tf_regime_gate_by_exchange.py tests/test_release_preflight.py tests/test_predixa_drop_verifier_monitoring.py tests/test_futures_*.py tests/test_commodity_bucket_approval.py tests/test_phase2_paper_pipeline.py tests/test_paper_order_monitoring.py
351 passed; exit 0
```

Existing deprecation warnings concern SQLAlchemy declarative defaults, Pydantic v1 validators, and `pkg_resources`; no new functional warning was treated as a pass criterion.

Additional checks:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile scripts/paper_observation.py scripts/paper_observation_runtime.py scripts/mcx_graduated_live_scanner.py shared/db/db_model.py apps/backend/api/bucket_orders_commodity.py tests/test_mcx_paper_observation.py tests/test_paper_order_monitoring.py tests/test_futures_scanner_persistence.py
exit 0

/home/ispeck/anaconda3/envs/finpro/bin/python -m scripts.paper_observation_runtime --help
exit 0; commands listed: init-local-db, scan-mcx-once, list-mcx

git diff --check -- scripts/mcx_graduated_live_scanner.py shared/db/db_model.py tests/test_futures_scanner_persistence.py
exit 0
```

The broader diff check including `apps/backend/api/bucket_orders_commodity.py` reports two trailing-whitespace lines at 588 and 631 in pre-existing working-tree changes in that already-modified API file. They are outside the added monitoring endpoint; they were not reformatted as part of this scoped change. The new endpoint hunk itself has no trailing whitespace.

## Not executed / pending

- No live FYERS market-data request or live-feed scanner run.
- No application-server startup or actual HTTP socket call; the handler was called directly and FastAPI JSON encoding was verified.
- No connection to the shared MySQL runtime database; repository DB settings do not provide verified proof that it is an approved local test target.
- No database migration was applied to a shared database.
- No order placement, modification, cancellation, GTT, or broker API write.

Therefore paper software integration is verified on isolated SQLite, while a local operational smoke test using a verified local DB and current local FYERS candles remains pending.
