# NSEFO SW/SW/25 TP@50% dual-exit validation — 02-Nov-2026

`scripts/nsefo_tp_overlay.py` applies only when all five fields exactly match:
`NSEFO`, `SW`, `SW`, `25`, `BUY`.  It preserves `original_target`, calculates
`entry + 0.50 * (original_target - entry)`, and rounds the requested result to
the supplied valid tick size.  Entry, stop, underlying, sizing, setup rules,
and universe filters remain unchanged.

The candidate target is a full-position TP@50% OCO counterpart to the
unchanged stop.  The control target is retained independently for shadow
measurement.  Both variants use the same signal and data sequence; they are
not two approved orders and do not double exposure.  Same-candle stop/target
touches are `UNRESOLVED_AMBIGUOUS_OHLC`, never a favorable target fill.

Engineering tests exercise exact scope, tick rounding, original-target
preservation, full-position target behavior, conservative ambiguity, serial
approval, and tracking-error separation.  No genuine PAPER observation has
started, so no live tracking sample, fill, slippage, cost, or realized-R
record has been collected.

The supplied evidence preference for TP@50% full exit over partial exit is a
methodology input, not newly reproduced performance evidence.
