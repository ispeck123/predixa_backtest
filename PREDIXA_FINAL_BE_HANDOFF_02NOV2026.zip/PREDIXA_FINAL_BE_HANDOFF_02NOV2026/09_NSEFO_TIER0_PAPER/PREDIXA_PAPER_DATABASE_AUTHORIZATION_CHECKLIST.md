# PAPER Database Authorization Checklist

Current status: **authorization not granted; no database writes are permitted by this audit.**

Before any migration, scanner, test insert, or monitoring write:

- [ ] Database owner confirms the observed server UUID/hostname belongs to the intended environment.
- [ ] Operator classifies it as dedicated test/PAPER, shared development, staging, or production and documents who owns it.
- [ ] Resolve the repository schema mismatch (`Fin_product` versus `Fin_prod`) and confirm the exact runtime deployment target.
- [ ] Approve the isolation design: dedicated PAPER instance/schema and separate runtime account, with no access to REAL order schemas.
- [ ] Provision an account with schema-scoped least privilege; no global admin rights, `GRANT OPTION`, DDL, or delete rights for runtime.
- [ ] Require TLS and verify the server certificate/hostname. The audit connection was plaintext although the server advertises TLS.
- [ ] Remove source-controlled credential literals and rotate credentials through the approved secret store.
- [ ] Review an exact schema diff and migration plan. `20261025_phase1_execution_provenance.sql` fields already exist in the observed target; do not rerun it. `20261102_mcx_paper_observation_idempotency.sql` is still needed for the four MCX fields/index if MySQL support is approved.
- [ ] Take and verify a database backup; document recovery/rollback and expected lock/downtime behavior.
- [ ] Confirm migrations are applied only to the approved isolated PAPER target and re-read schema before any insert.
- [ ] Approve bounded test-record identity, cleanup procedure, and transaction boundary; ensure no business order can be selected for cleanup.
- [ ] Confirm monitoring APIs and background consumers filter mode/source correctly. Generic existing order list/count endpoints currently do not consistently filter these fields.
- [ ] Re-run broker-write isolation and mode-filter tests after routing changes.
- [ ] Obtain explicit scoped authorization for schema changes and test inserts. Database selection alone is not this authorization.

Recommended runtime grants for an isolated MCX observation schema: `SELECT` on the required commodity master and signal/order/bucket tables; `INSERT` on signal/order/bucket; optionally column/table-scoped `UPDATE` only for an approved paper status lifecycle. Do not grant DDL, `DELETE`, cross-schema access, global admin privileges, or `GRANT OPTION`. NSEFO paper needs its own reviewed table set and routing plan.
