# PREDIXA NSEFO + MCX Paper Trading Implementation

## Scope and status

This change adds a brokerless MCX paper-observation path and retains the existing NSEFO PAPER candidate path. MCX paper observation is **not** a trading-edge validation and does not alter MCX REAL authorization. No scanner was run against a live feed and no production database or broker was contacted.

## Existing NSEFO PAPER flow

`FuturesGraduatedLiveReadonlyScanner` in `scripts/futures_graduated_live_scanner.py` runs the existing setup formatter and, for PAPER mode, persists a `TradeSignal`, `Future_Order`, and `OMSOrderBucketFuture` candidate through `persist_futures_candidate`. PAPER quantity remains one unit, status is `paper_monitoring`, approval is `not_required`, and broker identifiers remain empty. Existing candidate provenance is `GRADUATED_LIVE`.

The offline integration test now repeats a deterministic signal through the scanner, verifies a single signal/order/bucket in SQLite, and reads the bucket through the existing `/bucket/orders/future/{order_id}` handler. This validates the local ORM and monitoring path; it does not validate live FYERS feeds or the configured MySQL runtime target.

## MCX PAPER_OBSERVATION flow

The existing `MCXGraduatedLiveScanner.run` and `persist_mcx_candidate` remain suspended by `mcx_execution_permitted()`. A separate entry point, `run_mcx_paper_observation`, calls the existing `process_setup_fc` / `format_calculate_setup_response` interfaces with `is_future=False` so MCX E1 session processing remains in force. The paper classifier records the ordinary MCX gate result (currently DENY) and creates observation-only BUY/SELL setups without changing the gate or real eligibility.

The new path requires all of:

- `MCX_PAPER_OBSERVATION_ENABLED=true` (default off).
- `PREDIXA_RUNTIME_ENV=LOCAL_PAPER`.
- An explicit SQLite path under `var/local_paper` (or an injected test root).
- A pre-existing database marked `LOCAL_PAPER` by the explicit initialization command.
- An active matching `CommoditiesMaster` row and verified local candles for the requested contract/timeframe.
- PAPER execution mode and one-unit simulated quantity.

The database record is `execution_mode=PAPER`, `trading_status=SIMULATED`, `edge_validation=UNVALIDATED`, `candidate_source=MCX_PAPER_OBSERVATION`, and `order_status=paper_monitoring`. The exact dated FYERS symbol is stored with the signal provenance. The path imports no broker client and calls no allocator or approval workflow. It records only in the separate SQLite paper database.

## Database and monitoring changes

The established `commodity_order_master` and `oms_order_bucket_commodity` models gained nullable paper-observation fields: `idempotency_key`, `edge_validation`, `paper_updated_at`, and `trading_status`. The unique idempotency keys are independent in each table and nullable for legacy rows. The signal, order, and bucket are committed in one SQLAlchemy transaction; errors roll back and never fall back to broker execution.

MCX observation records are visible through the read-only `GET /paper-observation/mcx/orders` endpoint, which reads only a marked local SQLite database and only rows tagged with the observation source. The existing commodity monitoring endpoints continue to serve the shared application database and are not silently redirected.

Migration file: `scripts/db_migrations/20261102_mcx_paper_observation_idempotency.sql`. It is additive and **was not applied to any shared or production database**. The dedicated SQLite test database is created from the ORM model definitions.

## Safety boundaries

- `MCX.permit_cells` remains empty and MCX regime calls remain DENY.
- `SEGMENT_NET_R["MCX"]` remains `-0.18`; no capital allocator is called.
- Normal MCX PAPER/REAL scanner entry remains blocked.
- MCX approval, GTT, generic broker-entry, and real capital protections were not changed.
- Paper observation writes no `id_fyers` or `gtt_id` and cannot be approved as a REAL order because the existing approval path requires `execution_mode=REAL` and the global MCX execution hold.
- NSEFO REAL behavior, NSEFO gate permissions, and NSE_CASH behavior were not changed.

## Runtime limits

`scripts/paper_observation_runtime.py` provides `init-local-db`, `scan-mcx-once`, and `list-mcx`. The MCX one-shot command requires an explicit jobs JSON and locally available candles; it does not use the legacy default job builder because that builder queries the shared application DB. Only configured strategy timeframes are accepted. A local master record must be provisioned from a verified local source; the tool does not invent instrument metadata.

The live-feed / local runtime smoke test remains pending. No real scanner process, scheduler, broker write, or production deployment was started. The local fixture tests validate software integration only.

## Repository state

Reviewed starting HEAD: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba` on branch `prod`. The working tree already contained a large set of prior remediation modifications, reports, data artifacts, and unrelated changes. This execution did not reset or overwrite them. `PREDIXA_PAPER_TRADING_CHANGED_FILES.txt` lists only the paper-trading changes from this execution. No ZIP was produced.
