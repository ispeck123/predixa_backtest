# NSEFO PAPER database verification — 02-Nov-2026

`192.168.1.16:3306 / Fin_product` was not used. Prior read-only evidence shows
a shared MySQL schema, global `root@%` identity, no verified PAPER boundary,
and generic API queries that can mix PAPER and REAL rows. It is not PAPER write
authorization.

Isolated SQLite validation produced one signal, one `future_order_master`, and
one `oms_order_bucket_future` record with `execution_mode=PAPER`, source
`NSEFO_TIER0_PAPER`, and `paper_pending_approval`. Reprocessing is idempotent.
No migration or MySQL insert occurred.
