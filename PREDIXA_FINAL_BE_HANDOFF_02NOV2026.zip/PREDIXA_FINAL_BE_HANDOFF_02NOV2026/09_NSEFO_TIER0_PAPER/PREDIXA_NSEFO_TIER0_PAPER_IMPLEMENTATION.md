# NSEFO Tier-0 PAPER implementation — 02-Nov-2026

## Implemented repository controls

- Scope is the existing `NSEFO` gate cell `SW/SW/25`, BUY only.  The gate has
  no other NSEFO permit cell.
- `scripts/futures_graduated_live_scanner.py` retains the original far-target
  RRR check for PAPER as well as REAL.  PAPER cannot use TP@50% to evade G9.
- A qualifying PAPER signal is persisted with one simulated unit and source
  `NSEFO_TIER0_PAPER`, but with `approval_status=pending` and
  `order_status=paper_pending_approval`.  It is not a resting simulation.
- `scripts/nsefo_paper_governor.py` supplies the explicit per-order,
  brokerless approval transition.  It holds a strict Option-3 serial slot:
  an approved/open PAPER order prevents the next approval until terminal.
- No FYERS placement, GTT, amendment, cancellation, real allocation, or REAL
  approval route is called by this flow.

## Runtime status

Not started.  `192.168.1.16/Fin_product` remains an unverified shared MySQL
environment with an overprivileged account and no approved PAPER isolation.
The supplied Paper-Gating workbook and TP Overlay work-order spreadsheet were
not present in this checkout; their missing operational definitions remain a
launch blocker.  `FuturesScanJob.tick_size` must be supplied from a verified
instrument-master source; absent tick size fails the PAPER candidate closed.

## Change control

NSEFO REAL configuration and broker paths were not changed.  PAPER approval
is not REAL authorization.  A controlled runtime launch additionally needs an
isolated database, restricted account, monitoring separation, owner approval
for each candidate, and an approved tick-size source.

## Validation evidence

Executed locally with the repository `finpro` environment:

```text
python -m pytest -q tests/test_nsefo_tp50_paper_governor.py \
  tests/test_futures_scanner_persistence.py tests/test_futures_approval.py \
  tests/test_futures_risk_engine.py tests/test_phase2_paper_pipeline.py \
  tests/test_mcx_remediation_guardrails.py tests/test_mcx_golive_policy.py \
  tests/test_mcx_paper_observation.py tests/test_tf_regime_gate_by_exchange.py \
  tests/test_predixa_drop_verifier_monitoring.py tests/test_release_preflight.py
167 passed, 17 warnings, exit 0

python -m py_compile scripts/nsefo_tp_overlay.py scripts/nsefo_paper_governor.py \
  scripts/futures_graduated_live_scanner.py scripts/mcx_graduated_live_scanner.py \
  scripts/paper_observation.py
exit 0

python scripts/predixa_drop_verifier.py . --no-report
C1-C12 PASS; exit 0
```
