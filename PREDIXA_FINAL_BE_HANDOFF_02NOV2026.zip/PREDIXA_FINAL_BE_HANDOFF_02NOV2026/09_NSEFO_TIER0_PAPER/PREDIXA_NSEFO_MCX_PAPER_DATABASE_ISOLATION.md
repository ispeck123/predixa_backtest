# NSEFO and MCX PAPER Database Isolation Audit

## Connection routing

### NSEFO PAPER

The futures scanner (`scripts/futures_graduated_live_scanner.py`) classifies candidates with `execution_mode` and `candidate_source`, then persists through the repository's shared `DBConnection` path into `trade_signals`, `future_order_master`, and `oms_order_bucket_future`. That path resolves to the configured shared MySQL schema (`Fin_product` in the audit process). There is no distinct NSEFO PAPER DSN/schema/user routing in the inspected code.

Existing future order APIs and bucket list/count APIs read the same tables. The list/count SQL inspected in `apps/backend/api/future_orders.py` and `apps/backend/api/bucket_orders_future.py` filters by country/date/status/timeframe/side/prediction, but does not consistently filter `execution_mode` and `candidate_source`. Therefore PAPER and REAL records can appear in the same generic list results. The API needs explicit mode/source filters or separate views before these results can be relied on as distinct paper monitoring versus real positions.

### MCX PAPER_OBSERVATION

`scripts/paper_observation.py` remains deliberately independent of shared `DBConnection` and accepts only an explicitly enabled `LOCAL_PAPER` configuration whose database is a marked SQLite file under `var/local_paper`. The route `GET /paper-observation/mcx/orders` in `apps/backend/api/bucket_orders_commodity.py` reads that same isolated SQLite store.

Separately, the graduated MCX scanner now accepts explicit `PAPER` jobs while the MCX REAL hold is active. It records a mechanically valid BUY setup to the shared `trade_signals`, `commodity_order_master`, and `oms_order_bucket_commodity` persistence path with `execution_mode=PAPER`, `candidate_source=GRADUATED_LIVE`, `order_status=paper_monitoring`, and `approval_status=not_required`. The MCX regime gate still reports `DENY` on the record; that result is retained as monitoring metadata and does not authorize REAL trading. REAL jobs remain blocked before engine execution and before DB persistence.

The normal MCX scanner and shared commodity approval APIs remain separate from observation. Commodity approval checks require `execution_mode=REAL` and `mcx_execution_permitted()`; current MCX permission remains denied. The paper-observation source is excluded from the generic paper lifecycle selector, which only accepts `GRADUATED_LIVE` and `LEGACY_PAPER` sources. Thus current observation records are monitored candidates, not automatically filled/closed trades.

## Database evidence relevant to isolation

- Actual server: MySQL 8.0.45, schema `Fin_product`, writable server (`read_only=0`, `super_read_only=OFF`).
- Existing four futures/commodity order tables include execution provenance fields and aggregate rows labeled `PAPER / GRADUATED_LIVE`.
- The selected schema also contains OMS, trading signals, master, alert, and user/subscription tables. No operator evidence establishes it as a dedicated PAPER environment.
- The application connection authenticated as global `root@%`; grants include global DDL/DML/admin and grant option.
- Current client connection used no TLS; normal DB engines do not configure CA verification.
- The observed MySQL commodity schema lacks MCX observation idempotency/validation/status columns.

Conclusion: `SHARED_DB_REQUIRES_ISOLATION_DESIGN`; `ISOLATION_NOT_VERIFIED`; `UNSAFE_FOR_PAPER_WRITES`.

## REAL/PAPER consumer boundaries

| Consumer | Observed boundary | Remaining concern |
|---|---|---|
| NSEFO candidate persistence | Writes explicit mode/source fields | Same schema and tables serve the rest of application; no separate PAPER DB route |
| NSEFO approval/order submission | Futures approval rejects rows unless mode is `REAL`; GTT call passes explicit `REAL` | Generic listing/monitoring queries can mix modes |
| MCX local observation insert | Brokerless isolated SQLite store; explicit MCX source, PAPER and simulated labels; idempotency in SQLite schema | No MySQL adapter for the richer `UNVALIDATED/SIMULATED` observation schema; do not remove identity/SQLite guard |
| MCX graduated PAPER candidate | Shared scanner writes `PAPER / GRADUATED_LIVE / paper_monitoring` candidates to commodity order and bucket tables | Shared schema remains unverified for operational writes; generic lifecycle/monitoring needs mode/source filters |
| MCX approval/GTT | Requires `REAL`, and approval is blocked by MCX execution hold | Keep this independent of paper observation config |
| Shared paper evaluator (`scripts/paper_execution.py`) | Allows only PAPER rows from `GRADUATED_LIVE` or `LEGACY_PAPER` | MCX observation source intentionally excluded; generic query/API views still need mode/source filtering |
| Background status evaluator | Uses the same recognized-source selector for derivatives | MCX observation stays monitoring-only until lifecycle is explicitly designed |
| Generic broker client | Mutation calls require explicit `execution_mode="REAL"`; MCX checks remain in force | Retain test spies and independent REAL guards |

Offline regression evidence for these boundaries: focused PAPER/execution tests pass. The graduated MCX PAPER tests prove shared candidate persistence and idempotency with an isolated database; REAL scanner/approval/broker tests remain blocked. `tests/test_mcx_paper_observation.py` separately covers the richer SQLite observation persistence/idempotency path. These are isolated tests, not runtime access evidence for this MySQL server.

## Minimal future isolation design

1. Have the database owner classify and approve the target; the present identity is not enough.
2. Create/approve a dedicated PAPER schema (preferably on a separate instance if available), with no production order data or write access to production schemas.
3. Provision a PAPER-specific account scoped only to that schema. Grant `SELECT` on the required master and observation tables, `INSERT` for signal/order/bucket rows, and narrowly scoped `UPDATE` only if an approved paper lifecycle needs it. No `DELETE`, `CREATE`, `ALTER`, `DROP`, global privileges, or `GRANT OPTION` for the runtime account.
4. Require TLS with CA/hostname verification. Remove hardcoded credentials from deployment/helper files and rotate them through the approved secret process.
5. Add a separately configured SQLAlchemy backend for MCX observation that verifies host, schema, server identity, account and schema marker before use. Fail closed for any mismatch. Keep the current SQLite path intact.
6. Route NSEFO PAPER persistence and paper monitoring to an approved PAPER target separately from REAL routes; do not assume its existing global singleton can provide this isolation without explicit dependency injection.
7. Add execution mode/source filtering to order APIs and evaluators; test that generic monitoring cannot present simulated rows as REAL positions and that REAL handlers reject all PAPER rows.
8. Review/apply the additive MCX migration only on the approved PAPER target after schema backup, duplicate-key preflight, rollback plan, and explicit DDL approval.

No changes from this plan were implemented in this read-only audit.
