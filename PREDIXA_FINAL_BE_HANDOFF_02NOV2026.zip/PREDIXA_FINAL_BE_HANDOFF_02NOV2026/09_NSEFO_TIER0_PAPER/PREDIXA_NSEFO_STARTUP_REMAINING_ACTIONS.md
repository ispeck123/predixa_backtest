# NSEFO PAPER remaining actions

1. **DBA/operator:** authorize and provision the isolated `Fin_product_paper`
   schema, restricted TLS account, expected server UUID, backup and rollback.
2. **DBA/operator:** approve the reviewed migration and one bounded test write.
3. **Engineer/operator:** run MySQL compatibility test and verify mode/source
   filtered monitoring retrieval.
4. **Owner:** approve each genuine pending PAPER candidate. Do not use REAL API.
5. **Operator:** only then run the documented one-pass NSEFO scanner. A no-signal
   run proves startup only; it does not start the tracking clock.
