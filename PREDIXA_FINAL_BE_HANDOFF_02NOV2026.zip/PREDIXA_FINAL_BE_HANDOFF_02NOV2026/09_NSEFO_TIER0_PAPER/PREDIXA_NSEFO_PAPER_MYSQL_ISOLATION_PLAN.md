# NSEFO PAPER isolated MySQL plan

Proposed schema: `Fin_product_paper`; it has not been created. Review-only SQL
is in `scripts/db_migrations/20261102_nsefo_paper_isolated_schema.sql`.

1. DBA verifies server UUID, backup, TLS CA/hostname policy, and that the new
   schema is empty and isolated from `Fin_product`.
2. DBA creates a restricted PAPER account: `SELECT, INSERT` on the three
   PAPER tables and narrowly scoped `UPDATE` for approved lifecycle state.
   No DDL, DELETE, GRANT OPTION, or access to shared schemas.
3. DBA applies the reviewed migration in a maintenance window and records its
   checksum. Rollback is dropping only the still-empty isolated schema.
4. Operator supplies `PREDIXA_PAPER_DB_*` values, including CA path and
   expected server UUID. `paper_db_config.py` rejects `Fin_product`, incomplete
   configuration, and missing TLS identity data.
5. Run an approved bounded test write, verify mode/source filtered monitoring,
   then authorize the one-pass scanner. No unattended process is included.
