# NSEFO Tier-0 PAPER startup precheck — 02-Nov-2026

| Requirement | Result |
|---|---|
| Exact `NSEFO/SW/SW/25/BUY` gate | PASS |
| Original-target `BUY_RRR >= 2.1` | PASS |
| One verified simulated futures lot | PASS (code) |
| Dated FYERS tick metadata | PASS (code) |
| Option-3 serial governor | PASS (isolated) |
| Broker-write isolation | PASS (isolated) |
| MCX PAPER and REAL hold | PASS |
| Authenticated FYERS candle feed | BLOCKED |
| Isolated PAPER database | BLOCKED |

The 30-Oct Futures Runbook exists at `audit/futures_trend_backtest/FUTURES_RUNBOOK.md`.
The named two workbooks, TP Overlay markdown spec, and 28-Oct Paper-Gating
workbook are absent from this checkout. Operational startup is blocked before
scanner execution.
