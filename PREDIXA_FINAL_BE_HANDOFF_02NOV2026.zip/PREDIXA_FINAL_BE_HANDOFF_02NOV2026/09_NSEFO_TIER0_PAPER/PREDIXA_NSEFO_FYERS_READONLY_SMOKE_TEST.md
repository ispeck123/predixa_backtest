# NSEFO FYERS read-only smoke test — 02-Nov-2026

No broker mutation or database persistence was used.

| Check | Result | Evidence |
|---|---|---|
| FYERS_AUTHENTICATION | PASS | SDK `history` returned `s=ok`, HTTP code 200. |
| CONTRACT_RESOLUTION | PASS | Public FYERS master resolved `NSE:BANKNIFTY26NOVFUT`, 23-Nov-2026, lot 30, tick 0.2. |
| LIVE_CANDLE_READ | PASS | Exact-contract `cont_flag=0`, 60-minute, two-day request returned 7 candles. |
| Timestamp/OHLC/freshness | PASS | Ordered candle epochs map to 02-Nov-2026 09:15–15:15 Asia/Kolkata. |
| STRATEGY_INPUT_VALIDATION | PASS | Existing weekly/daily/seventy_five files for `BANKNIFTY_23112026` loaded successfully into `SDEnginePipeline`. |

The genuine engine run returned E=`UP`, A=`UP`, no BUY setup. This correctly
produced no candidate and no write. It is proof of initialization, not a PAPER
order observation.
