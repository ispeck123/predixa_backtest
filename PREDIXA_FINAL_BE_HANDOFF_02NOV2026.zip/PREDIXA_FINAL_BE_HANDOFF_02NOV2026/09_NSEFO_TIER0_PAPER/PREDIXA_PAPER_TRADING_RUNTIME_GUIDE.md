# PREDIXA Local Paper Runtime Guide

This guide describes local-only commands. No unattended scheduler is configured. The MCX observation command runs one pass and exits.

## 1. Configure a dedicated local SQLite database

Run from the repository root:

```bash
export PREDIXA_RUNTIME_ENV=LOCAL_PAPER
export PREDIXA_PAPER_DB_PATH="$PWD/var/local_paper/predixa_paper.sqlite3"
/home/ispeck/anaconda3/envs/finpro/bin/python -m scripts.paper_observation_runtime init-local-db --path "$PREDIXA_PAPER_DB_PATH"
```

The initializer refuses to overwrite or adopt an existing database. It creates a marked local-paper database and the relevant ORM tables. Provision only verified active `CommoditiesMaster` rows from an approved local source before scanning; the software does not synthesize instrument master data. Do not point this variable at the shared application or production database.

NSEFO PAPER uses the existing shared DBConnection path and is safe to run only after an operator independently verifies that its configured DB target is an isolated local test database. The current repository does not prove that the default runtime DB target is local, so do not run the NSEFO scanner against an unverified target.

After that DB verification and the existing NSEFO data prerequisites, the repository's one-pass PAPER scanner command is:

```bash
export NSEFO_EXECUTION_MODE=PAPER
/home/ispeck/anaconda3/envs/finpro/bin/python scripts/futures_graduated_live_scanner.py --timeframe 25 --output-dir outputs/local_paper/nsefo
```

This is a one-pass scan and exits when finished; press Ctrl-C to stop it early. Do not use the command with a database target that has not been verified as local and isolated. The scanner's persistence test and monitoring query were validated offline, but this command was not executed against a runtime database or live feed.

## 2. Run one local MCX paper-observation pass

Set the kill switch explicitly for the local paper process:

```bash
export MCX_PAPER_OBSERVATION_ENABLED=true
```

Prepare a local jobs JSON using verified active contract expiries and the existing timeframe lists. Each entry must contain `symbol`, `expiry`, `strategy_tf`, `time_list`, and may contain `last_d_time`. The requested `time_list` must exactly match `COMMODITY_TIME_FRAME_<strategy_tf>` in repository configuration. For example, timeframe 4 is configured as `daily`, `two_forty`, `sixty`; use a genuine current expiry, not a placeholder.

Before invoking the command, ensure the corresponding local candle files exist under the configured commodity `latest_data_csv` directory:

```text
<SYMBOL>_<EXPIRY>_<E-TF>.csv
<SYMBOL>_<EXPIRY>_<A-TF>.csv
<SYMBOL>_<EXPIRY>_<X-TF>.csv
```

Then execute a single pass:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m scripts.paper_observation_runtime scan-mcx-once --jobs-json /absolute/path/to/verified_local_mcx_jobs.json
```

It uses the existing strategy engine and MCX E1 processing, validates the marked local database/master records, inserts only brokerless PAPER observation records, and exits. **Stop:** the one-shot command exits on its own; for an interactive run, press Ctrl-C. There is no continuous process or scheduler to stop.

The command must not be launched unless `PREDIXA_RUNTIME_ENV=LOCAL_PAPER`, `PREDIXA_PAPER_DB_PATH` identifies the marked SQLite file under `var/local_paper`, and `MCX_PAPER_OBSERVATION_ENABLED=true`. Turning the flag off blocks subsequent writes.

## 3. Monitor and verify

Read from the command line:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m scripts.paper_observation_runtime list-mcx
```

Or, when the backend process has the same local-paper environment variables, call:

```text
GET /paper-observation/mcx/orders
```

For NSEFO, the existing single-order query is:

```text
GET /bucket/orders/future/{order_id}
```

The MCX API returns records only from the marked local SQLite database. Records remain `PAPER`, `SIMULATED`, `UNVALIDATED`, and `paper_monitoring`; this implementation does not simulate fills or realized P&L. Read-only FYERS feed availability and runtime scanner operation have not been smoke-tested in this exercise.

## 4. Safety checks and boundaries

- The existing `scripts/mcx_graduated_live_scanner.py` command remains suspended for PAPER and REAL execution.
- The new `scan-mcx-once` path is not a way to pass the MCX live regime gate. It only stores simulated records in local SQLite.
- MCX REAL gate, real allocator, approval, GTT, and generic broker-entry blocks remain active.
- Do not apply the additive MySQL migration to a shared/production database for this local test. A separately reviewed local application DB deployment would need its own migration approval and target verification.
- Do not enable a production scheduler or use MCX observation as evidence of a validated edge.
