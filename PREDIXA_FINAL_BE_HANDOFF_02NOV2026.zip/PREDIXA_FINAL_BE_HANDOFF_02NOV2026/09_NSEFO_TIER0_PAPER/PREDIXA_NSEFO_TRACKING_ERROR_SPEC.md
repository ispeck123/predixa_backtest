# NSEFO SW/SW/25 tracking-error specification

Each completed shadow record must retain signal/underlying identity, the exact
cell, timestamps, entry/stop/original target/TP50, exit variant, fill evidence,
fees and slippage assumptions, exit-specific `live_R`, matching
`backtest_R`, `tracking_error = live_R - backtest_R`, and data/run provenance.

Control (`ORIGINAL_TARGET_FULL_POSITION`) and candidate
(`TP50_FULL_POSITION`) are separate samples.  They must never be pooled with
each other, other NSEFO cells, NSE_CASH, or MCX.  The implemented summary
reports mean and separate 95% CI per supplied variant, `n >= 20` gross
divergence review, and `n >= 40` full review; mean must exceed `-0.15R`.

The hand-off and older runbook disagree on whether CI must contain or exclude
zero.  The implementation records the interval but returns
`BLOCKED_PENDING_CRITERION_RECONCILIATION` for automatic REAL promotion.  No
tests, fixtures, or historical backfills count toward the PAPER clock.
