# NSEFO Tier-0 PAPER start/stop guide

Do not run until an isolated PAPER database, restricted TLS account, and
monitoring route are operator-approved.

```bash
conda activate finpro
export NSEFO_EXECUTION_MODE=PAPER
python scripts/futures_graduated_live_scanner.py --timeframe 25 --output-dir outputs/nsefo_paper
```

This repository command is one pass and exits. Use `Ctrl-C` to stop it.
Do not set `NSEFO_EXECUTION_MODE=REAL`. PAPER approval must use the brokerless
`approve_paper_candidate` function, not the REAL approval/GTT endpoint.
