# NSEFO exit methodology change record — 02-Nov-2026

For the controlled NSEFO `SW/SW/25` BUY PAPER evaluation only, the deterministic
candidate exit is a full-position TP@50% of the original target distance.  The
original target remains the control exit and continues to determine the
existing G9/reward-to-risk selection requirement.

This replaces neither the entry strategy nor the general platform exit policy.
The prior commodity-specific conclusion concerning trailing/partial exits
continues to apply to MCX.  The supplied backtest evidence preferring a TP@50%
full exit over a half-position partial exit is recorded as a decision input;
it has not been reproduced in this execution.

No REAL promotion follows from this change.  It requires exit-specific OOS
evidence, per-variant genuine PAPER tracking error, reconciled CI criterion,
drop-any-symbol OOS positivity, release checks, and explicit owner approval.
