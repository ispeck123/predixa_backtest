# PREDIXA Paper Order Database and Monitoring Report

## Existing persistence

| Segment/path | Signal | Order | Monitoring bucket | PAPER provenance |
|---|---|---|---|---|
| NSEFO graduated scanner | `trade_signals` (`TradeSignal`) | `future_order_master` (`Future_Order`) | `oms_order_bucket_future` (`OMSOrderBucketFuture`) | `execution_mode=PAPER`, `candidate_source=GRADUATED_LIVE` |
| MCX observation | `trade_signals` (`TradeSignal`) | `commodity_order_master` (`Commodity_Order`) | `oms_order_bucket_commodity` (`OMSOrderBucketCommodity`) | `execution_mode=PAPER`, `candidate_source=MCX_PAPER_OBSERVATION`, `trading_status=SIMULATED`, `edge_validation=UNVALIDATED` |

The MCX path uses the established ORM entities in an isolated local SQLite database. The local identity marker table, `predixa_local_paper_identity`, must contain `environment=LOCAL_PAPER`. The database must reside under the configured local paper root. Unmarked, non-SQLite, missing, or out-of-root databases fail closed.

## MCX paper-observation fields

- Identity: `idempotency_key` (SHA-256, unique in order and bucket tables), `trade_signal_id`, order/bucket identifiers.
- Instrument: segment MCX in the monitoring projection, underlying `stock_tick`, exact dated FYERS symbol in `TradeSignal.trade_data`, expiry.
- Signal: UTC-normalized signal timestamp in `TradeSignal.timestamps`, strategy timeframe, BUY/SELL, E/A/X regime values in `TradeSignal.trade_data`.
- Levels: entry, stop, target, one-unit simulated quantity.
- Mode/status: `execution_mode=PAPER`, `trading_status=SIMULATED`, `order_status=paper_monitoring`, `edge_validation=UNVALIDATED`, `candidate_source=MCX_PAPER_OBSERVATION`.
- Broker fields: `id_fyers=NULL`, `gtt_id=NULL`.
- Timestamps: `purchased_on`, `paper_updated_at`.

Stable setup identity uses segment, underlying, expiry, timeframe, side, and normalized signal timestamp. A repeat with the same key returns the existing records. If the same identity arrives with different entry/stop/target values, it is rejected as a collision instead of creating another order.

## Transaction and lifecycle

Signal, order, and OMS bucket are inserted in one SQLAlchemy transaction. Any failure rolls back all rows. The existing simulation status updater is not connected to this separate SQLite store; new records remain `paper_monitoring` until an explicitly verified local price-update service is added. No fill, exit, or P&L is fabricated.

NSEFO PAPER continues to use its existing scanner and `paper_monitoring` lifecycle. The shared status evaluation jobs are not redirected to the MCX paper SQLite database.

## Monitoring

- Existing NSEFO record query: `GET /bucket/orders/future/{order_id}`.
- Existing shared commodity query remains unchanged.
- New local-only MCX observation query: `GET /paper-observation/mcx/orders`.

The new endpoint reads only the marked SQLite database from `PREDIXA_PAPER_DB_PATH` when `PREDIXA_RUNTIME_ENV=LOCAL_PAPER`; it is available for reads even after the MCX observation kill switch is disabled. It filters to `PAPER` and `MCX_PAPER_OBSERVATION` provenance and returns prices, mode, status, timestamp, timeframe, regimes, validation label, source, and dated symbol.

## Migration

`scripts/db_migrations/20261102_mcx_paper_observation_idempotency.sql` adds the new nullable idempotency/validation/status/timestamp columns and unique indexes to the established commodity tables. It was **not executed**. `initialize_local_paper_database()` creates the dedicated SQLite schema from the ORM models and marks the new DB. Do not apply the MySQL migration to any shared or production database as part of this exercise.

## Non-sensitive test evidence

The isolated integration fixture produced a single row triplet for test-only `CRUDEOILM` with entry 100, stop 90, target 120, quantity 1, PAPER, SIMULATED, UNVALIDATED, paper_monitoring, and no broker IDs. The monitoring API returned that row; a repeat produced `EXISTING` and no additional triplet. This is test data only and carries no market or profitability claim.
