# NSEFO TP@50% live-shadow status — 02-Nov-2026

TP@50% is implemented and isolated-test validated. Candidate and original-far
control share signal, entry, stop, and candle sequence without creating two
positions. Ambiguous OHLC exit ordering is unresolved, never a target fill.
There are no genuine completed observations or tracking-error samples yet.
