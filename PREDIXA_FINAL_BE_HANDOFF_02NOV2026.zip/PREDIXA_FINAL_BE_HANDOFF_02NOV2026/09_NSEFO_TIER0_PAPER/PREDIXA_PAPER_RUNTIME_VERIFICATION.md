# PREDIXA Paper Runtime Verification

## Status

Offline, brokerless integration is verified. Actual NSEFO and MCX local-runtime startup is **NOT VERIFIED** because this execution had no approved local database configuration and no FYERS runtime credentials in the process environment. No scanner was started.

## NSEFO PAPER

The established path is `FuturesGraduatedLiveReadonlyScanner` → existing setup engine → `persist_futures_candidate` → `Future_Order` / `OMSOrderBucketFuture` → existing future monitoring query. Isolated tests verify one-unit PAPER candidates, duplicate prevention across a repeat scan, empty GTT/FYERS IDs, and monitoring retrieval.

Runtime prerequisites not met here:

- an operator-verified isolated database for the ordinary NSEFO persistence path;
- current FYERS read-only credentials and entitlement;
- a current active contract/master mapping;
- current local NSEFO candle files for the configured symbol/timeframe.

The blocker is an environment/authorization dependency, not a failing scanner test.

## MCX PAPER observation

The separate observation path is `run_mcx_paper_observation` → `process_setup_fc(..., is_future=False)` → existing E1-aware setup engine → local `PaperObservationStore` → marked SQLite database → `GET /paper-observation/mcx/orders`.

Configuration is explicitly fail-closed:

```text
PREDIXA_RUNTIME_ENV=LOCAL_PAPER
PREDIXA_PAPER_DB_PATH=<approved path under var/local_paper>
MCX_PAPER_OBSERVATION_ENABLED=true
```

The flag defaults off. The runner requires `PAPER`, a marked local SQLite database, a matching active local `CommoditiesMaster` record, configured timeframe lists, and the actual local candle files. It never calls broker placement, modification, cancellation, GTT, allocation, or approval code.

## Local data audit

The expected commodity candle directory exists: `data/indian_commodity_data/latest_data_csv`. It has three expiry groups with eight frames each for each supported observation underlying:

| Underlying | Locally present expiry groups |
|---|---|
| GOLDM | 05112026, 04122026, 05012027 |
| GOLDGUINEA | 30112026, 31122026, 29012027 |
| SILVERM | 30112026, 26022027, 30042027 |
| CRUDEOILM | 19112026, 18122026, 19012027 |
| NATGASMINI | 24112026, 28122026, 25012027 |

Each group contains the strategy frames required for current TF3/TF4 replay (`daily`, `two_forty`, `one_twenty`, `sixty`, plus the other retained frames). This is a local-file presence check only: exact current instrument-master activation, timestamp freshness, and FYERS read-only ingestion were not verified.

## Lifecycle scope

| Capability | NSEFO PAPER | MCX observation | Evidence |
|---|---|---|---|
| Candidate creation and persistence | Implemented/tested | Implemented/tested | Scanner/SQLite tests |
| Duplicate prevention | Implemented/tested | Implemented/tested | Repeat-signal tests |
| Monitoring retrieval | Implemented/tested | Implemented/tested | Existing/new handler tests |
| Broker-write isolation | Tested | Tested | Mock/spies and mode guards |
| Simulated entry/fill | Existing shared evaluator path | Not connected to local observation SQLite | Separate MCX DB is intentionally brokerless/observation-only |
| Stop/target closure and paper P&L | Existing evaluator coverage | Not implemented for observation store | Outside current signal-monitoring acceptance scope |

The immediate requested acceptance requirements—brokerless signal/order persistence, idempotency, monitoring, and REAL isolation—are complete in isolation. A full MCX simulated position lifecycle is additional scope and has not been represented as complete.

## Next bounded runtime action

After an operator provides an approved local database, use the commands in `PREDIXA_PAPER_TRADING_RUNTIME_GUIDE.md` with one verified current contract job. Confirm database identity, master row, candle files, and output record before starting a scan. Keep `MCX_EXECUTION_SUSPENDED=True`; this path is never a MCX REAL activation.
