# Reconstruction guide

Use the canonical final snapshot under `16_SOURCE_CODE`. Current working-tree diffs are supplied where Git can reconstruct them. The available history does not establish a single pre-remediation baseline; no synthetic baseline was created. Apply no patch automatically to a live deployment.
