# Exclusions and redactions

Excluded: .env files, credentials, raw provider caches/market data, database dumps, virtual environments, node_modules, PID files, arbitrary logs, and unrelated dirty files.

The package copies of source files containing credential-handling declarations are sanitized with `<REDACTED>` values. The originals are not modified. Those archive copies are evidence/review snapshots and may not be byte-for-byte executable: audit/mcx_futures_backtest/fyers_expired_contract_collector.py, data_fetchers/fyers/indian_commodity_data_updater.py, data_fetchers/fyers/indian_futures_data_updater.py, shared/config/settings.py, shared/db/fyers_req_model.py.
