# PREDIXA MCX Phase-1 Task 3 — Validation Report

Date: 02-Nov-2026. All test bars in Task-3 unit tests are synthetic fixtures and are not historical market evidence.

## Commands and outcomes

1. Focused Task-3 tests:

```text
python -m pytest -q tests/test_mcx_clean_realized_r_export.py
```

Initial runs exposed test/implementation edge cases (invalid fixture expectation, entry-bar double-touch handling, MFE exit-bar sequencing, and E1 timestamp consistency); these were corrected. Final focused test run: **42 passed**, exit 0.

2. Combined Task-1/2/safety regression suite:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_mcx_clean_realized_r_export.py \
  tests/test_mcx_contract_roll_adjustment.py \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_mcx_remediation_guardrails.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_commodity_bucket_approval.py
```

Earlier reruns were 104 and 106 passes as coverage expanded. Final rerun after all cases, including daily-bar E1 gap handling: **107 passed, 7 warnings, exit 0**.

3. Compilation:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m py_compile \
  audit/mcx_futures_backtest/clean_realized_r_export.py \
  audit/mcx_futures_backtest/contract_roll.py scripts/mcx_session.py \
  tests/test_mcx_clean_realized_r_export.py
```

Result: **PASS**, exit 0.

4. CLI interface:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.clean_realized_r_export --help
```

Result: **PASS**, exit 0. CLI requires `--input-json`, `--output-root`, `--run-id`, `--git-revision`, and `--split-date`.

5. FYERS Task-2B source diagnostic:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python audit/mcx_futures_backtest/validate_task2b_fyers_sample.py
```

Result: exit 0 for source integrity; **series UNVERIFIED**; 1,302 dated-symbol bars, 81 E1 session IDs, zero verified rolls. Issues: `LISTING_DATE_MISSING`, `INTRASESSION_BAR_GAPS`, `ROLL_POLICY_PENDING_APPROVAL`, `NO_VERIFIED_ROLL_TRANSITIONS`.

6. Strict historical source preflight:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m audit.mcx_futures_backtest.preflight \
  --root data/indian_commodity_data/latest_data_csv \
  --output /tmp/predixa_task3_preflight --strict-contract-history
```

Result: expected fail-closed **exit 2**. The 216 source files across 27 expiry keys and 9 symbols are all `STITCHED_OR_CONTINUOUS`; historical contract-live attribution is not evidenced. Output was directed to `/tmp`; source files were not changed.

7. Final focused rerun after the last timestamp validation change:

```text
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_mcx_clean_realized_r_export.py \
  tests/test_mcx_contract_roll_adjustment.py \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_mcx_remediation_guardrails.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_commodity_bucket_approval.py
```

Final rerun output: **107 passed, 7 warnings**, exit 0. It includes 42 Task-3 cases.

## Coverage and remaining checks

Tested: realized-R arithmetic (win/loss), positive-risk rejection, MFE separation, bar counting, same-bar convention, E1 gap entry/exit suppression, E1 ID integrity including daily-frame date transitions, contract and underlying matching, expiry-window filtering, IS/OOS assignment, BUY-only scope, exact schema, duplicate detection, unresolved audit handling, non-overwrite, failed-readiness no-write, and strict source-mode/readiness failures.

Not run / blocked: a clean historical replay, actual Task-2 full readiness validation, real roll transition arithmetic on two FYERS contracts, full calendar verification, clean export validation, and Task-4 edge reproduction. They cannot be run without verified five-underlying dated history, explicit roll mappings and policy, a complete MCX calendar, and authorized split date. No clean export was produced.

The first broad invocation using system `python` failed test collection because that interpreter lacks `fastapi`; rerunning the repository’s established `/home/ispeck/anaconda3/envs/finpro/bin/python` environment completed successfully as reported above. No dependency installation was attempted.
