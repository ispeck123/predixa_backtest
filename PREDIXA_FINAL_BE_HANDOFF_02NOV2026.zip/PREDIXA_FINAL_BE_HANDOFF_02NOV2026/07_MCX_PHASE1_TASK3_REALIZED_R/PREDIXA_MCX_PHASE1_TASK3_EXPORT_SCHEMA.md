# PREDIXA MCX Phase-1 Task 3 Export Schema

Status: exporter contract implemented; authoritative export remains blocked by Task-2 data validation.

## CSV columns (exact order)

`symbol,strategy_tf,E_regime,A_regime,X_regime,entry_price,stop_price,target_price,exit_price,outcome,gross_r,mfe_R,partition,bars_held`

One row represents one resolved eligible BUY setup. `symbol` is one of the five separate underlying keys (`GOLDM`, `GOLDGUINEA`, `SILVERM`, `CRUDEOILM`, `NATGASMINI`). The historical contract identifier and source mapping are in `trade_provenance.csv`; the export remains at the specified 14-column contract. SELLs and unresolved/unfilled trades do not enter this CSV and must have an `excluded_setups.csv` audit record.

| Field | Meaning |
|---|---|
| `symbol` | Exact MCX underlying; no merged symbols. |
| `strategy_tf` | Existing MCX timeframe ID. |
| `E_regime`, `A_regime`, `X_regime` | Existing strategy regime labels at signal time. |
| `entry_price` | Existing setup entry level, matched against raw dated-contract OHLC. |
| `stop_price`, `target_price` | Existing strategy stop and target, unchanged. |
| `exit_price` | Simulated raw dated-contract stop or target fill. |
| `outcome` | `WIN` or `LOSS`; unresolved cases are audited outside the trade CSV. |
| `gross_r` | `(exit_price - entry_price) / (entry_price - stop_price)` for BUY. Must be recomputable. Gross means before fees/slippage; no cost assumption is added here. |
| `mfe_R` | Maximum favorable excursion in initial-risk units through the known holding path. Exit-bar OHLC beyond the known exit fill is excluded because bar ordering is unknowable. Kept distinct from realized `gross_r`. |
| `partition` | Deterministic `IS`/`OOS` from signal date vs the explicit required split date; the split date is recorded in the manifest. It is not evidence of an approved OOS finding by itself. |
| `bars_held` | Number of executable bars from entry-touch bar through exit bar, inclusive. |

## Input bundle contract

The CLI accepts a JSON bundle with `data_validation`, `setups`, `bars_by_setup`, and optional `run_manifest` objects. The Task-2 evidence must explicitly prove raw dated OHLCV, historical contract attribution, verified roll events and prices, approved roll policy, complete calendar, E1 enforcement, executable-price mapping, point-in-time integrity, full underlying/timeframe/date coverage, and source hashes. A generic `status: VALID` does not pass the gate. `source_mode` must be `RAW_DATED`; stitched/continuous-only inputs are rejected.

Every setup must identify a stable `setup_id`, explicit `side=BUY`, underlying, timeframe, E/A/X regimes, signal timestamp, existing entry/stop/target, historical dated contract, verified mapping and executable price statuses, `price_basis=RAW_EXECUTABLE`, expiry date, verified trading days remaining (at least three), source ID, and roll-policy version. Bars must be ordered timezone-aware raw OHLC with the same dated contract and underlying, plus E1 session IDs consistent with `scripts/mcx_session.py`.

## Provenance sidecar

`trade_provenance.csv` has one row per exported CSV row, in identical order, keyed by stable `setup_id`. It records signal/entry/exit timestamps, dated contract, underlying, policy version, input source, partition, expiry, days remaining, and exit resolution. The stable ID is intentionally not added to the required trade CSV. Consumers must join by row order or use a verified transformed view keyed with this sidecar.

The current `scripts/edge_repro_check.py` expects `setup_timestamp` for its date split. Task 4 should create a joined verification view from the sidecar (without changing this Task-3 CSV contract) and independently verify exact row reconciliation before running it.

## Execution conventions and exclusions

The existing Phase-A resolver in `audit/futures_trend_backtest/run_futures_backtest.py::_resolve` documents target-first handling when target and stop touch the same OHLC bar. The exporter preserves that convention and marks it `TARGET_FIRST_ON_SAME_BAR` in provenance. It verifies Task-1 E1 IDs and also detects calendar-date transitions on execution bars, because Task-1 leaves daily structural IDs continuous. If an opening price has gapped through an entry or exit level, the setup is unresolved and excluded with a reason; an observed same-session touch after an opening price that remains on the safe side can still resolve. No artificial gap fill is made. End-of-data, invalid risk, bad OHLC, cross-contract bars, uncertain expiry/calendar, and missing mapping are similarly audited. No price interpolation or adjusted-series execution price is accepted.
