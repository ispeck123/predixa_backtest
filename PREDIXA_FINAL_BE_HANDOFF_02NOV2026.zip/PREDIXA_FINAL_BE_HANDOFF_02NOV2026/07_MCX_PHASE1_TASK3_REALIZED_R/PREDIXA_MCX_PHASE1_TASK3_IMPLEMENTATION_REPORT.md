# PREDIXA MCX Phase-1 Task 3 — Realized-R Export Implementation

Date: 02-Nov-2026. Scope: implement and test the offline exporter and strict readiness gate. No strategy replay was launched, no broker/order path was called, and no clean trade export was created.

## Status

**PARTIALLY_COMPLETED.** `EXPORTER_IMPLEMENTED` and `EXPORTER_TESTED`; `CLEAN_EXPORT_BLOCKED` by missing validated Task-2 multi-contract data, approved policy/calendar, and split-date authorization. Task 3 is not complete until a valid clean backtest is executed and its export is independently validated.

## Root-cause and existing pipeline findings

- `audit/mcx_futures_backtest/run_phase_a.py::_source`, `generate_tasks`, and `execute_task` select one expiry-named file per symbol/timeframe from `data/indian_commodity_data/latest_data_csv`. Task-2B classified all 216 files there as `STITCHED_OR_CONTINUOUS`. The filename/current expiry is not historical per-bar contract identity.
- `audit/futures_trend_backtest/run_futures_backtest.py::_resolve` finds an entry touch in future OHLC bars, checks stop/target in the same bar, and uses a documented target-first convention on an ambiguous double-touch bar. It reports `gross_r` from exit minus entry divided by absolute entry-stop risk, but `bars_held` is the zero-based index in all post-signal bars, so pre-entry bars can affect the count. Its excursion is stored as absolute price movement under `max_favorable_excursion`, not `mfe_R`.
- `audit/derivatives_backtest_common/export_labeled.py::evaluate_path` computes a future path and also uses target-first baseline ordering. Its labeled output stores `max_favorable_excursion` as a price distance and does not add an `mfe_R` or IS/OOS `partition` column.
- `audit/derivatives_backtest_common/analyze_phase_a.py::summary` and `audit/mcx_futures_backtest/finalize_stitched_report.py` aggregate `gross_r` as average realized R. These located source expressions do **not** establish that Phase-A summaries mislabeled MFE as realized expectancy.
- The original compatible `mcx_trade_export.csv` is absent. The available `deliverables/mcx_phase_a_stitched_final/03_RESULTS/mcx_fut_regime_tf_backtest_labeled.csv` has fields such as `source_symbol`, lowercase `e_regime`, `max_favorable_excursion`, and no `partition` or `mfe_R`; it is not compatible with `scripts/confirm_peak_vs_realized.py`'s required fields (`symbol`/`stock_name`, `E_regime`, `partition`, `mfe_R`). The prior confirmation script states a suspected MFE mismatch but cannot establish it from this incompatible file. No numerical reproduction was attempted.
- Available run metadata identifies run `d6307703511b4d7b95434cd35712ab86`, variant `PHASE_A_MCX_STITCHED_CALENDAR_INFERRED`, on the Phase-A available-history artifacts. It is not asserted to be the unknown run that produced the reported Phase-A claims.

## Implementation

Added `audit/mcx_futures_backtest/clean_realized_r_export.py` with:

- A fail-closed `readiness_issues()` gate requiring `RAW_DATED` source mode, all Task-2 verification flags, approved roll policy, verified calendar, five independent underlyings, all strategy TFs 1–4, explicit date coverage, policy/calendar versions, and input hashes.
- `build_clean_export()` that accepts pre-discovered existing-engine BUY setups and per-setup raw dated-contract OHLC bars. It does not discover signals, call `process_setup_fc`, read stitched files, fetch data, or invoke an order workflow.
- An offline resolver preserving the existing target-first same-bar convention; calculates `gross_r` from the actual resolved exit fill and initial long risk; calculates a separate conservative `mfe_R`; counts bars from entry through exit inclusive; assigns deterministic date-based IS/OOS from a required split parameter; and preserves excluded/unresolved candidates with reasons.
- Contract/underlying equality, raw executable price-basis, expiry window, verified E1 session-ID consistency, unique setup IDs, and row/provenance reconciliation checks. Execution-date transitions are checked separately because Task-1 deliberately keeps daily structural E1 IDs continuous; an opening price gapped through an entry/exit level is recorded unresolved, while a same-session observed touch remains eligible.
- `write_versioned_export()` which validates before creating output and refuses to overwrite an existing run folder. No invocation used real data in this task.

The component intentionally stops short of orchestrating signal discovery. The current Phase-A runner reads stitched files and uses the current MCX gate (now deny-all); adapting that runner to a future validated contract-aware input path would require a separately reviewed historical-research adapter. No modifications were made to it or to trading gate behavior.

## Realized R and assumptions

For BUY, `risk = entry - stop` must be positive and `gross_r = (exit - entry) / risk`. Gross excludes fees/slippage; this exporter does not invent execution costs. Entry is an OHLC touch at the existing setup entry level. Stop/target exits use the existing recorded target-first policy when both are touched in one bar. An E1-seam entry or exit ambiguity is unresolved rather than filled. MFE excludes unknown movement in the exit bar beyond the known fill and never replaces realized R. Missing exits are retained in `excluded_setups.csv` by reason.

No documented approved IS/OOS date was found in the inspected Task-2/Phase-A specifications. `--split-date` is therefore explicit and mandatory. A supplied date creates labels only; it does not assert owner-approved OOS validity.

## Data readiness and export status

Task-2B documented 216 continuous/stitched files and one FYERS dated CRUDEOILM October 2026 sample (1,302 60m bars; one contract, no roll pair). The sample structural check remains `series_status=UNVERIFIED`; it has missing listing interval, no verified roll transitions, and pending roll-policy approval. The complete MCX calendar and full five-underlying dated history are not verified. Strict preflight exits 2 as expected. Therefore, the clean exporter rejects current evidence and no `clean_mcx_trade_export.csv`, synthetic diagnostic export, profitability result, or Task-4 reproduction was generated.

## MCX and non-MCX safeguards

This change is isolated under `audit/mcx_futures_backtest/` and tests. It does not change the gate, allocator, scanners, broker endpoints, NSEFO, or NSE_CASH. Existing MCX safety regression tests passed in the focused suite; no scanners, paper trading, live orders, or deployment were run.

## Test evidence

See `PREDIXA_MCX_PHASE1_TASK3_VALIDATION_REPORT.md`. The new test file contains 42 collected cases using synthetic test fixtures only. Combined Task-1, Task-2, gate, allocator, and scanner/bucket regression command passed 107 tests with 7 dependency deprecation warnings. Python compilation and the saved FYERS single-contract structural diagnostic passed; strict historical preflight correctly returned 2. These outcomes verify code behavior and source identity only, not clean historical data or edge.

## Task 4 readiness

**NOT READY.** There is no clean export. Task 4 requires a complete verified contract-aware series, actual executable mappings, approved roll/calendars/split, an export joined to timestamp provenance, then realized-R OOS reproduction. MCX remains disabled.

## End-to-end integration addendum — 2026-11-02

The earlier statement that the exporter did not discover signals describes the initial Task-3 implementation. The current integrated path is `audit/mcx_futures_backtest/run_clean_phase1.py` → `clean_strategy_replay.py` → existing `scripts.setup_engine_new.SDEnginePipeline.run` BUY candidate → `clean_realized_r_export.py`. `replay` and `full` require a Task-2 evidence bundle; `full` does not invent contract intervals, roll decisions, calendar records, or split approval. Provider discovery/collection is explicit through the same runner's `check-access` and `collect` modes. TEST_ONLY fixtures exercise the strategy-adapter-to-exporter path. This integration does not change the status of the historical clean export: it remains blocked by missing complete data and policy/approval prerequisites.

The clean resolver now applies conservative stop-first treatment when one OHLC candle touches both stop and target, flags that ambiguity, and does not count favorable movement from that ambiguous exit candle. This offline research correction does not alter the production trade engine. The Task-3 historical observations above remain historical; they should not be read as describing the newer offline resolver.
