# NSEFO raw evidence references

SQLite database (not copied): `audit/nsefo_futures_backtest/storage/nsefo_near_tf1_tf25_2023_2026.sqlite`
Run ID: `148d607f1d1b4899a8a0599e8d081d21`
Near expiry: `27102026`
The expected tuning manifest was not found; no manifest was fabricated.
