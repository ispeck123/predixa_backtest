# NSEFO Tuning 2023–2026 Evidence Package

This package is BASELINE_ONLY and was generated from existing SQLite results without replaying tasks. No tuning lock is recommended.
