# NSEFO Tuning 2023–2026 Full Report

## 1. Executive Summary

Run `148d607f1d1b4899a8a0599e8d081d21` is a completed current-production NSEFO near-expiry replay, classified **BASELINE_ONLY**. No 36-run manifest or candidate override runs were found. The correct decision is **NO_LOCK_INCOMPLETE_SWEEP**; no tuning lock or C7/C8 sign-off is allowed.

The run contains 160,128 tasks, 157,090 completed tasks, 3,038 failed tasks, 157,090 scans, 56,225 signals, 55,929 eligible setups, 48,395 entered trades, and 47,661 resolved trades.

## 2. Scope and Work-Order Compliance

- Universe: 30 configured symbols
- Expiry: near expiry `27102026` only
- TF1: monthly / weekly / daily
- TF25: weekly / daily / seventy_five
- Historical window: 2023-01-01 through 2026-10-22
- Normal replay decision cut: two-sided; BUY and SELL trades are retained
- Tuning metrics: BUY-only view, as required by the tuning protocol

## 3. Production-Code Non-Modification Statement

No production files under `scripts/` were modified for this report. No live Config defaults, replay database, or raw market data was changed. All metrics were generated from existing centralized SQLite results.

## 4. Universe, TF Mapping, and Data Coverage

All 30 configured symbols are represented with the near-expiry contract key `@27102026`. Actual source coverage is unequal:

```text
    symbol               start                 end  complete
  ADANIENT 2020-01-01T05:30:00 2026-10-22T13:30:00      True
  AXISBANK 2020-01-01T05:30:00 2026-10-22T14:15:00      True
BAJFINANCE 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 BANKNIFTY 2020-01-01T05:30:00 2026-10-22T13:45:00      True
BHARTIARTL 2020-01-01T05:30:00 2026-10-22T14:15:00      True
      BHEL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
       BSE 2024-11-29T05:30:00 2026-10-22T14:00:00      True
   ETERNAL 2025-04-09T05:30:00 2026-10-22T14:00:00      True
FEDERALBNK 2020-01-01T05:30:00 2026-10-22T14:30:00      True
  FINNIFTY 2021-01-11T05:30:00 2026-10-22T14:15:00      True
   HCLTECH 2020-01-01T05:30:00 2026-10-22T14:15:00      True
  HDFCBANK 2020-01-01T05:30:00 2026-10-22T13:45:00      True
  HINDALCO 2020-01-01T05:30:00 2026-10-22T13:30:00      True
 ICICIBANK 2020-01-01T05:30:00 2026-10-22T14:30:00      True
      INFY 2020-01-01T05:30:00 2026-10-22T13:45:00      True
       ITC 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 KOTAKBANK 2020-01-01T05:30:00 2026-10-22T14:00:00      True
LAURUSLABS 2021-10-29T05:30:00 2026-10-22T14:30:00      True
        LT 2020-01-01T05:30:00 2026-10-22T14:15:00      True
MIDCPNIFTY 2022-01-24T05:30:00 2026-10-22T13:30:00      True
     NIFTY 2020-01-01T05:30:00 2026-10-22T14:00:00      True
     PAYTM 2024-11-29T05:30:00 2026-10-22T14:00:00      True
PERSISTENT 2021-10-01T05:30:00 2026-10-22T13:30:00      True
   POLYCAB 2021-08-27T05:30:00 2026-10-22T14:30:00      True
  RELIANCE 2020-01-01T05:30:00 2026-10-22T14:15:00      True
      SBIN 2020-01-01T05:30:00 2026-10-22T14:15:00      True
 TATASTEEL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
       TCS 2020-01-01T05:30:00 2026-10-22T14:00:00      True
     TECHM 2020-01-01T05:30:00 2026-10-22T14:30:00      True
     WIPRO 2020-01-01T05:30:00 2026-10-22T13:30:00      True
```

The complete per-symbol/per-TF evidence is in `source_coverage_by_symbol_tf.csv`.

## 5. Stitched-Series Limitations

All source files are classified as `STITCHED_OR_CONTINUOUS`. Contract-live labels are calendar-inferred and do not establish exchange-verified historical contract identity. The production API does not expose a hard roll-boundary reset to this replay.

## 6. Run Inventory and Completion Evidence

| item | count |
|---|---:|
| tasks | 160,128 |
| completed | 157,090 |
| failed | 3,038 |
| scans | 157,090 |
| signals | 56,225 |
| eligible setups | 55,929 |
| entered trades | 48,395 |
| resolved WIN/LOSS | 47,661 |
| unresolved | 734 |

Scan coverage is `2023-01-02T05:30:00` through `2026-10-22T14:30:00`. Trade entries range from `2023-01-04T14:45:00` through `2026-10-22T10:45:00`.

Top failed-task categories:

```text
exception_type                          exception_message    n
  RuntimeError                     float division by zero 6615
  RuntimeError        E-TF has 2 bars, minimum 7 required  426
  RuntimeError        E-TF has 6 bars, minimum 7 required  414
  RuntimeError        E-TF has 5 bars, minimum 7 required  405
  RuntimeError        E-TF has 3 bars, minimum 7 required  399
  RuntimeError        E-TF has 1 bars, minimum 7 required  384
  RuntimeError        E-TF has 4 bars, minimum 7 required  366
  RuntimeError single positional indexer is out-of-bounds  105
```

## 7. Decision Cut

The normal replay was two-sided because `buy_only` is false in the persisted config. Raw evidence contains BUY and SELL rows. For tuning-protocol metrics, the analysis command applies `--side BUY`; SELL trades are not silently mixed into tuning metrics and remain available in `sell_side_records.csv`.

## 8. Baseline/Control Results

Persisted `engine_overrides` is `{}`. This is a production-default baseline, not a candidate.

BUY-only pooled 0-bps full-cost paper results:

```text
partition     n  win_rate  M1_give_back_rate  M2_wick_out_rate  gross_R_mean  net_R_mean_full_cost  full_cost_mean_inr
       IS 17706    0.3427             0.5452            0.1084      0.403579              0.343636           25.859065
      OOS 16750    0.2773             0.5093            0.1268      0.153104              0.086613           40.364643
   POOLED 34456    0.3109             0.5269            0.1164      0.281817              0.218690           32.910621
```

## 9. Embed and Proximity Sweep Results

No EMBED or PROXIMITY candidate runs exist. There is no baseline-versus-candidate comparison.

## 10. IS/OOS Results

The BUY-only analysis midpoint is `2025-02-18 15:15:00`. The 0/2/5 bps sensitivity and all TF1/TF25 regime cells are in `03_METRICS/per_cell_is_oos_metrics.csv`.

## 11. M1/M2 and Full-Cost Methodology

M1, M2, gross R, paper full-cost Net-R, mean INR cost, and bps-only sensitivity are persisted in the metrics CSV. The cost schedule is `FYERS_DERIVATIVES_2023_2026_V1`. No reviewed lot-size file was supplied; quantity mode is **PAPER_QTY_10**. These are not contract-accurate brokerage economics and do not represent a complete OI-4 cost stack.

## 12. Pass-Arithmetic Evaluation

The work-order arithmetic was not applied because the prerequisite 36-run set is absent. There is no evidence for 3pp M1/M2 reductions, pooled Net-R non-regression, cell limits, OOS sign checks, or tie-break selection.

## 13. Decision and C7/C8 Status

**NO_LOCK_INCOMPLETE_SWEEP**. Baseline retained for audit use only.

- C7: **NOT SIGNED OFF** — no complete candidate comparison.
- C8: **NOT SIGNED OFF** — no completed sweep or production lock evidence.

## 14. Limitations

The limitations are: no tuning manifest or candidate runs; 3,038 failed tasks; stitched/calendar-inferred contract identity; unequal symbol histories; 734 unresolved two-sided trades; paper quantity economics; no complete OI-4 cost stack; and the normal replay config is two-sided while the tuning view is BUY-only.

## 15. Reproducibility

Use `05_REPRODUCIBILITY/commands_executed.txt`. It contains SQLite-only analysis and test commands. No replay command is included.
