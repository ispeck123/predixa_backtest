# NSEFO Tuning Executive Summary

**Decision: NO_LOCK_INCOMPLETE_SWEEP**

Run `148d607f1d1b4899a8a0599e8d081d21` is baseline-only. No 36-run manifest or candidate runs were found.

- Tasks/completed/failed: 160,128 / 157,090 / 3,038
- Scans/signals/eligible setups: 157,090 / 56,225 / 55,929
- Entered/resolved trades: 48,395 / 47,661
- Symbols: 30; expiry: `27102026`; TFs: 1 and 25
- Normal replay: two-sided; tuning analysis: BUY-only
- Quantity mode: `PAPER_QTY_10`
- Tests: 13 passed
- Production files modified: **NONE**

No tuning parameter lock or C7/C8 sign-off is supported.
