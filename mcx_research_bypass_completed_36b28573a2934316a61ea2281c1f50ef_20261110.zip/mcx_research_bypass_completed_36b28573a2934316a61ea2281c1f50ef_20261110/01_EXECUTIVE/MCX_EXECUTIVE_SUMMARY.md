# MCX Research Replay — Executive Submission Summary

Run `36b28573a2934316a61ea2281c1f50ef` completed on `2026-11-08T15:02:08.880911+00:00`.

| Measure | Result |
|---|---:|
| Registered tasks | 137,610 |
| Completed tasks | 136,653 |
| Failed tasks | 957 |
| Signals / BUY setups | 42,269 |
| Entered trades | 30,750 |
| Resolved WIN/LOSS | 30,722 |
| Unresolved entered trades | 28 |
| Resolved wins | 7,729 |
| Resolved win rate | 25.158% |
| SQLite integrity check | `ok` |

## Work-order assessment

- Live policy was not opened by this replay. The persisted configuration has `research_gate_bypass=true`, and persisted scans are independently labelled in `03_METRICS/gate_summary.csv`.
- The research bypass admitted measurement cells without changing live/paper gate behaviour; the code snapshot is included in `06_CODE_AND_WORKORDER/`.
- The fixed trade export uses the approved exact schema and separates realized `gross_r` from path/peak fields. It is in `07_FIXED_EXPORT/` with a deterministic manifest and checksum.
- The approved within-contract post-filter is implemented as a separate read-only export layer. It cannot be executed or claimed for this package because the repository does not contain the required product-specific OFFICIAL_VERIFIED `symbol,roll_date` map. The local MCX session calendar validates E1 dates but does not supply roll boundaries.

## Limits retained in the evidence

This is a BUY-only, research-gate-bypass replay using continuous/stitched source series. Results are gross-R historical simulation evidence, before costs and slippage; they are not live-trading approval. No production trading or trend-engine file was modified.

All `957` terminal failures are retained. The predominant failure is `E-TF has 6 bars, minimum 7 required`. No failed or unresolved row was fabricated into a completed outcome.
