# MCX Completed Research Replay — Detailed Findings

## Run provenance

- Run ID: `36b28573a2934316a61ea2281c1f50ef`
- Run name: `mcx_stitched_grid_research_bypass_full_20261108`
- Status: `COMPLETED`
- Historical window: `2023-03-14` through `2026-11-02`
- Executor/workers: `process` / `24`
- Seed: `20260930`
- Research gate bypass: `True`
- Source database: `/home/ispeck/PROJECTS_DEV/STP_LATEST/fin_backend_final_latest/audit/mcx_futures_backtest/storage/mcx_stitched_grid_research_bypass_full_20261108.sqlite` (opened `mode=ro`; SHA-256 `55a938279629b3ed19f4d14259ed2878f7f56c493fff5d412986ff848f94e3c8`)

## Completion and data quality

| status    |   tasks |
|:----------|--------:|
| COMPLETED |  136653 |
| FAILED    |     957 |

`PRAGMA integrity_check` = `ok`; `PRAGMA quick_check` = `ok`; foreign-key findings = `0`.

### Terminal failure disclosure

| exception_type   | exception_message                          |   failed_tasks |   error_attempts |
|:-----------------|:-------------------------------------------|---------------:|-----------------:|
| RuntimeError     | E-TF has 6 bars, minimum 7 required        |            167 |              501 |
| RuntimeError     | E-TF has 4 bars, minimum 7 required        |            159 |              477 |
| RuntimeError     | E-TF has 2 bars, minimum 7 required        |            150 |              450 |
| RuntimeError     | E-TF has 5 bars, minimum 7 required        |            150 |              450 |
| RuntimeError     | E-TF has 3 bars, minimum 7 required        |            148 |              444 |
| RuntimeError     | E-TF has 1 bars, minimum 7 required        |             98 |              294 |
| RuntimeError     | single positional indexer is out-of-bounds |             85 |              255 |

The repeated minimum-bar failures occur where the production context cannot form the required E timeframe. They are source-window/data-availability limitations, not database corruption and not a restart interruption.

## Signal, gate, and setup evidence

### Scan population by strategy timeframe

|   strategy_tf |   scans |   signals |   setup_rows |   eligible_entries |   gate_denied |
|--------------:|--------:|----------:|-------------:|-------------------:|--------------:|
|             2 |   53508 |     18712 |        18712 |              18473 |             0 |
|             3 |   28952 |      7890 |         7890 |               7734 |             0 |
|             4 |   54193 |     15667 |        15667 |              15439 |             0 |

### Persisted gate disposition

| gate_tier       |   gate_denied | gate_reason                                                                         |   scans |
|:----------------|--------------:|:------------------------------------------------------------------------------------|--------:|
| RESEARCH_BYPASS |             0 | MCX research-only gate bypass: live/paper policy is not applied to offline evidence |  136653 |

### BUY setup eligibility / non-entry reasons

|   strategy_tf |   eligible | blocked_reason   |   setups |
|--------------:|-----------:|:-----------------|---------:|
|             2 |          1 | <NULL>           |    18473 |
|             2 |          0 | rr_below_2.1     |      239 |
|             3 |          1 | <NULL>           |     7734 |
|             3 |          0 | rr_below_2.1     |      156 |
|             4 |          1 | <NULL>           |    15439 |
|             4 |          0 | rr_below_2.1     |      228 |

## Realized trade outcomes

### Outcome distribution

| outcome    |   trades |   sum_gross_r |   average_gross_r |
|:-----------|---------:|--------------:|------------------:|
| LOSS       |    22993 |      -22993   |          -1       |
| UNRESOLVED |       28 |         nan   |         nan       |
| WIN        |     7729 |       25174.7 |           3.25717 |

### By strategy timeframe

|   strategy_tf |   entered_trades |   wins |   losses |   unresolved |   win_pct |   resolved_gross_r |   resolved_avg_r |
|--------------:|-----------------:|-------:|---------:|-------------:|----------:|-------------------:|-----------------:|
|             2 |            13330 |   3129 |    10201 |            0 |    23.473 |            275.85  |         0.020694 |
|             3 |             5619 |   1678 |     3929 |           12 |    29.927 |           1464.4   |         0.261174 |
|             4 |            11801 |   2922 |     8863 |           16 |    24.794 |            441.427 |         0.037457 |

### By symbol and strategy timeframe

| symbol              |   strategy_tf |   entered_trades |   wins |   losses |   unresolved |   win_pct |   resolved_gross_r |
|:--------------------|--------------:|-----------------:|-------:|---------:|-------------:|----------:|-------------------:|
| GOLDM@04122026      |             2 |             2439 |    611 |     1828 |            0 |    25.051 |            553.555 |
| SILVERM@30112026    |             2 |             2964 |    769 |     2195 |            0 |    25.945 |            529.743 |
| NATGASMINI@24112026 |             2 |             4393 |   1120 |     3273 |            0 |    25.495 |            133.49  |
| CRUDEOILM@19112026  |             2 |             3534 |    629 |     2905 |            0 |    17.799 |           -940.938 |
| GOLDM@04122026      |             3 |             1425 |    542 |      883 |            0 |    38.035 |            946.752 |
| CRUDEOILM@19112026  |             3 |             1780 |    554 |     1214 |           12 |    31.335 |            505.006 |
| SILVERM@30112026    |             3 |              992 |    362 |      630 |            0 |    36.492 |            413.138 |
| NATGASMINI@24112026 |             3 |             1422 |    220 |     1202 |            0 |    15.471 |           -400.494 |
| SILVERM@30112026    |             4 |             2643 |    833 |     1810 |            0 |    31.517 |            624.897 |
| GOLDM@04122026      |             4 |             2434 |    532 |     1901 |            1 |    21.866 |            311.456 |
| CRUDEOILM@19112026  |             4 |             3264 |    777 |     2472 |           15 |    23.915 |           -170.321 |
| NATGASMINI@24112026 |             4 |             3460 |    780 |     2680 |            0 |    22.543 |           -324.605 |

### By production E/A regime snapshot and strategy timeframe

| E_regime   | A_regime   |   strategy_tf |   entered_trades |   wins |   losses |   win_pct |   resolved_gross_r |
|:-----------|:-----------|--------------:|-----------------:|-------:|---------:|----------:|-------------------:|
| UP         | UP         |             2 |             6491 |   1682 |     4809 |    25.913 |           555.088  |
| UP         | SW         |             2 |             4238 |   1102 |     3136 |    26.003 |           929.894  |
| SW         | UP         |             2 |             1469 |    103 |     1366 |     7.012 |         -1051.57   |
| SW         | SW         |             2 |             1132 |    242 |      890 |    21.378 |          -157.565  |
| UP         | UP         |             3 |             2636 |    871 |     1753 |    33.194 |           849.294  |
| UP         | SW         |             3 |             1573 |    566 |     1007 |    35.982 |           994.317  |
| SW         | UP         |             3 |              964 |    199 |      765 |    20.643 |          -113.906  |
| SW         | SW         |             3 |              446 |     42 |      404 |     9.417 |          -265.304  |
| UP         | UP         |             4 |             5707 |   1415 |     4276 |    24.864 |           273.274  |
| UP         | SW         |             4 |             3063 |    721 |     2342 |    23.539 |           136.532  |
| SW         | UP         |             4 |             2034 |    570 |     1464 |    28.024 |           127.66   |
| SW         | SW         |             4 |              997 |    216 |      781 |    21.665 |           -96.0389 |

## Last-workorder implementation status

1. **Live gate revert:** live NSEFO remains validated-only and MCX remains hard-off; the snapshots in `06_CODE_AND_WORKORDER/` evidence that policy code is separate from the audit path.
2. **Research bypass:** this completed replay recorded `research_gate_bypass=true`; its persisted `RESEARCH_BYPASS` disposition is a research-only measurement marker, not a live/paper authorization.
3. **Fixed export and determinism:** `07_FIXED_EXPORT/` has the exact fixed BUY schema, manifest, and SHA-256. `gross_r` is populated only for persisted WIN/LOSS rows.
4. **Continuous-series filters:** no raw/expired-contract reconstruction was performed. The approved roll-span, prior-segment-zone, 12-month zone-age and MCX E1 filters are available in the separate read-only exporter, but final filtered findings are deliberately withheld until an official verified roll-date map is supplied.

## Conclusion

The replay completed and its successful task rows are durable. The package reports the measured gross-R outcomes and all material limitations: terminal source-window failures, unresolved rows, continuous-series provenance, and the missing official roll-boundary evidence. It does not recommend live promotion of any research cell.
