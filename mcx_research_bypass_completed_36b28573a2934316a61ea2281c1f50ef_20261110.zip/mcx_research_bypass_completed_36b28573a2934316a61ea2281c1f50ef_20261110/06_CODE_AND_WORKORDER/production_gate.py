"""Audit-only adapter for the live TF/regime permission gate.

Normal calls invoke the production ``gate`` function. Offline research
backtests may explicitly request a research-only bypass; this does not alter
the live gate or any live-order scanner. The adapter intentionally
retains a pre-gate setup record so an audit can distinguish ``no setup`` from
``setup suppressed by current gate``.  Only a positive multiplier is eligible
for simulated entry.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def regime_value(value: Any) -> str | None:
    """Convert production enums to the plain values accepted by ``gate``."""
    if value is None:
        return None
    return getattr(value, "value", value)


@dataclass(frozen=True)
class GateDecision:
    tier: str
    size_multiplier: float
    reason: str

    @property
    def denied(self) -> bool:
        return self.size_multiplier == 0.0


def evaluate_gate(
    exchange: str,
    strategy_tf: int,
    e_regime: Any,
    a_regime: Any,
    *,
    research_gate_bypass: bool = False,
) -> GateDecision:
    """Evaluate the live gate, unless an explicit audit-only bypass is set.

    ``research_gate_bypass`` exists only in audit runners. Live and paper
    scanners call ``scripts.tf_regime_gate_by_exchange.gate`` directly and
    therefore cannot enter through this path.
    """
    from scripts.tf_regime_gate_by_exchange import gate

    if research_gate_bypass:
        return GateDecision(
            "RESEARCH_BYPASS",
            1.0,
            f"{str(exchange or '').strip().upper() or 'UNKNOWN'} research-only gate bypass: "
            "live/paper policy is not applied to offline evidence",
        )

    tier, multiplier, reason = gate(
        exchange, strategy_tf, regime_value(e_regime), regime_value(a_regime)
    )
    return GateDecision(str(tier), float(multiplier), str(reason))
