Snapshots are included as review evidence. They are not applied to the source database and do not alter live/paper policy.
