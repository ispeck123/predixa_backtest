"""Read-only within-contract filters for continuous-series research exports.

The replay itself remains a continuous-series measurement.  This module is a
post-replay exporter: it reads a SQLite run in ``mode=ro``, assigns calendar
segments, and produces an exact-schema included export plus a complete filter
ledger.  It intentionally has no import from any live/paper execution path.

An official roll map is mandatory.  Session calendars and source filename
labels are not substitutes for a product-specific roll boundary.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import pandas as pd

from .fixed_trade_export import (
    FIXED_TRADE_EXPORT_COLUMNS,
    NSEFO_STACKS,
    _partition,
    _stack,
    midpoint,
    sha256,
)


MCX_STACKS = {
    2: ("weekly", "daily", "sixty"),
    3: ("daily", "two_forty", "one_twenty"),
    4: ("daily", "two_forty", "sixty"),
}
NSEFO_FRAME_STACKS = {
    1: ("monthly", "weekly", "daily"),
    2: ("weekly", "daily", "sixty"),
    3: ("daily", "seventy_five", "sixty", "fifteen"),
    4: ("weekly", "daily", "one_twenty_five"),
    5: ("daily", "one_twenty_five", "twenty_five"),
    25: ("weekly", "daily", "seventy_five"),
}
LEDGER_COLUMNS = [
    "setup_id", "filter_status", "exclusion_reason", "setup_segment_id",
    "entry_segment_id", "exit_segment_id", "zone_linkage_status",
    "zone_ids", "zone_created_timestamps", "zone_segment_ids",
    "e1_boundary", *FIXED_TRADE_EXPORT_COLUMNS,
]


class FilterEvidenceError(ValueError):
    """The supplied evidence cannot support a deterministic filter."""


@dataclass(frozen=True)
class RollMap:
    boundaries: dict[str, tuple[pd.Timestamp, ...]]
    source: Path
    sha256: str

    def segment(self, symbol: str, value: object) -> str:
        stamp = _ist(value)
        underlying = str(symbol).upper().split("@", 1)[0]
        dates = self.boundaries.get(underlying)
        if not dates:
            raise FilterEvidenceError(f"no OFFICIAL_VERIFIED roll boundaries for {underlying}")
        for boundary in dates:
            if stamp < boundary:
                return f"{underlying}:{boundary:%Y-%m-%d}"
        raise FilterEvidenceError(
            f"{underlying} timestamp {stamp.isoformat()} is after the last official roll boundary"
        )


@dataclass(frozen=True)
class SessionCalendar:
    verified_dates: frozenset[pd.Timestamp]
    source: Path
    sha256: str

    def covers(self, start: object, end: object) -> bool:
        left, right = _ist(start).normalize(), _ist(end).normalize()
        dates = pd.date_range(left, right, freq="D", tz="Asia/Kolkata")
        return all(day in self.verified_dates for day in dates)


def _ist(value: object) -> pd.Timestamp:
    stamp = pd.Timestamp(value)
    if pd.isna(stamp):
        raise FilterEvidenceError("missing or invalid timestamp")
    return stamp.tz_localize("Asia/Kolkata") if stamp.tzinfo is None else stamp.tz_convert("Asia/Kolkata")


def load_official_roll_map(path: Path) -> RollMap:
    """Load ``symbol,roll_date,verification_status`` CSV data fail-closed."""
    if not path.is_file():
        raise FilterEvidenceError(f"official roll map does not exist: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise FilterEvidenceError("official roll map is empty")
    names = set(rows[0] or {})
    symbol_field = next((x for x in ("symbol", "underlying", "variant") if x in names), None)
    date_field = next((x for x in ("roll_date", "roll_timestamp", "effective_roll_date") if x in names), None)
    if not symbol_field or not date_field or "verification_status" not in names:
        raise FilterEvidenceError(
            "official roll map requires symbol (or underlying), roll_date, verification_status columns"
        )
    grouped: dict[str, list[pd.Timestamp]] = {}
    rejected = 0
    for row in rows:
        if str(row.get("verification_status", "")).strip().upper() != "OFFICIAL_VERIFIED":
            rejected += 1
            continue
        symbol = str(row.get(symbol_field, "")).strip().upper().split("@", 1)[0]
        if not symbol:
            raise FilterEvidenceError("official roll map contains an empty symbol")
        try:
            # A date starts the next segment: [previous roll, roll).
            roll = _ist(row[date_field]).normalize()
        except (TypeError, ValueError) as exc:
            raise FilterEvidenceError(f"invalid roll date for {symbol}: {row.get(date_field)!r}") from exc
        grouped.setdefault(symbol, []).append(roll)
    if not grouped:
        raise FilterEvidenceError("official roll map has no OFFICIAL_VERIFIED rows")
    boundaries = {key: tuple(sorted(set(value))) for key, value in grouped.items()}
    return RollMap(boundaries=boundaries, source=path.resolve(), sha256=sha256(path))


def load_official_session_calendar(path: Path) -> SessionCalendar:
    """Load a per-exchange-date OFFICIAL_VERIFIED MCX session calendar."""
    if not path.is_file():
        raise FilterEvidenceError(f"official session calendar does not exist: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or "exchange_date" not in rows[0] or "verification_status" not in rows[0]:
        raise FilterEvidenceError("session calendar requires exchange_date and verification_status columns")
    dates = set()
    for row in rows:
        if str(row.get("verification_status", "")).strip().upper() == "OFFICIAL_VERIFIED":
            dates.add(_ist(row["exchange_date"]).normalize())
    if not dates:
        raise FilterEvidenceError("session calendar has no OFFICIAL_VERIFIED exchange dates")
    return SessionCalendar(frozenset(dates), path.resolve(), sha256(path))


def _frame_stack(segment: str, strategy_tf: int) -> tuple[str, ...]:
    values = MCX_STACKS if segment == "MCX" else NSEFO_FRAME_STACKS
    try:
        return values[int(strategy_tf)]
    except KeyError as exc:
        raise FilterEvidenceError(f"no source-frame stack for {segment} TF{strategy_tf}") from exc


def _source_file(data_root: Path, symbol: str, frame: str) -> Path:
    parts = str(symbol).upper().split("@", 1)
    if len(parts) != 2:
        raise FilterEvidenceError(f"source label is not SYMBOL@EXPIRY: {symbol}")
    name = f"{parts[0]}_{parts[1]}_{frame}.csv"
    matches = [data_root / "latest_data_csv" / name, data_root / "processed_data_files" / name, data_root / name]
    match = next((candidate for candidate in matches if candidate.is_file()), None)
    if match is None:
        raise FilterEvidenceError(f"missing continuous source needed to resolve zone creation index: {name}")
    return match


@lru_cache(maxsize=48)
def _source_timestamps(path_text: str) -> tuple[pd.Timestamp, ...]:
    source = Path(path_text)
    preview = pd.read_csv(source, nrows=1)
    field = next((name for name in ("tradeDate", "timestamp_ist", "timestamp", "date") if name in preview.columns), None)
    if field is None:
        raise FilterEvidenceError(f"source has no timestamp column: {source}")
    raw = pd.read_csv(source, usecols=[field])[field]
    values = pd.to_datetime(raw, dayfirst=True, errors="coerce")
    if values.isna().any() or values.duplicated().any() or not values.is_monotonic_increasing:
        raise FilterEvidenceError(f"source timestamps are invalid: {source}")
    if values.dt.tz is None:
        values = values.dt.tz_localize("Asia/Kolkata")
    else:
        values = values.dt.tz_convert("Asia/Kolkata")
    return tuple(values)


def _created_timestamp(data_root: Path, segment: str, symbol: str, strategy_tf: int,
                       timeframe: str, created_idx: object, stored: object) -> pd.Timestamp:
    if stored not in (None, "") and not pd.isna(stored):
        return _ist(stored)
    if created_idx is None or pd.isna(created_idx):
        raise FilterEvidenceError("selected zone has neither created_timestamp nor created_idx")
    frame_names = _frame_stack(segment, int(strategy_tf))
    role_index = {"E": 0, "A": 1, "X": 2}.get(str(timeframe).upper())
    if role_index is None:
        raise FilterEvidenceError(f"unexpected zone timeframe label: {timeframe!r}")
    source = _source_file(data_root, symbol, frame_names[role_index])
    timestamps = _source_timestamps(str(source.resolve()))
    index = int(created_idx)
    if index < 0 or index >= len(timestamps):
        raise FilterEvidenceError(f"zone created_idx {index} lies outside {source.name}")
    return timestamps[index]


def _within_tolerance(left: object, right: object) -> bool:
    try:
        a, b = float(left), float(right)
    except (TypeError, ValueError):
        return False
    return abs(a - b) <= max(1e-8, max(abs(a), abs(b)) * 1e-8)


def _linked_zones(zone_rows: pd.DataFrame, stop: object, target: object) -> pd.DataFrame:
    """Keep only persisted zones whose boundary exactly anchors stop/target.

    The replay schema does not persist a separate stop-zone/target-zone ID.
    Price-boundary equality is therefore the only deterministic link available;
    rows with no such link are recorded as ``NO_EXACT_PERSISTED_LINK`` rather
    than silently treated as a zone reference.
    """
    if zone_rows.empty:
        return zone_rows
    mask = zone_rows.apply(
        lambda row: any(_within_tolerance(price, boundary)
                        for price in (stop, target)
                        for boundary in (row.proximal, row.distal)),
        axis=1,
    )
    return zone_rows.loc[mask].drop_duplicates(subset=["zone_id", "timeframe", "created_idx"])


def _e1_crossing(entry: object, exit_: object) -> str | None:
    if entry in (None, "") or exit_ in (None, "") or pd.isna(entry) or pd.isna(exit_):
        return None
    start, end = _ist(entry), _ist(exit_)
    if end <= start:
        return None
    # The approved E1 seam is 23:30 IST -> 09:00 IST.  A holding period that
    # reaches a later exchange date has crossed at least one such close/open
    # interval; the timestamp names the first crossed seam deterministically.
    first_seam = start.normalize() + pd.Timedelta(hours=23, minutes=30)
    if start >= first_seam:
        first_seam += pd.Timedelta(days=1)
    return first_seam.isoformat() if first_seam < end else None


def _read_rows(db: sqlite3.Connection, run_id: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    setups = pd.read_sql_query(
        """SELECT su.setup_id, su.symbol, su.strategy_tf, su.setup_timestamp, su.zone_id,
                  su.proposed_entry, su.proposed_stop, su.proposed_target, su.eligible,
                  task.strategy_tf_name, r.E_regime, r.A_regime, t.entry_timestamp,
                  t.exit_timestamp, t.exit_price, t.outcome AS trade_outcome, t.gross_r,
                  t.bars_held, p.max_favorable_excursion, p.max_favorable_pct_of_target,
                  s.scan_id
           FROM setup_results su
           JOIN scan_results s ON s.scan_id=su.scan_id
           JOIN scan_tasks task ON task.task_id=s.task_id
           LEFT JOIN regime_snapshots r ON r.scan_id=s.scan_id
           LEFT JOIN simulated_trades t ON t.setup_id=su.setup_id
           LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id
           WHERE s.run_id=? AND su.direction='BUY'
           ORDER BY su.setup_id""",
        db, params=(run_id,),
    )
    zones = pd.read_sql_query(
        """SELECT z.scan_id, z.timeframe, z.zone_role, z.zone_id, z.proximal, z.distal,
                  z.created_idx, z.created_timestamp
           FROM zone_snapshots z
           JOIN scan_results s ON s.scan_id=z.scan_id
           WHERE s.run_id=?
           ORDER BY z.zone_snapshot_id""",
        db, params=(run_id,),
    )
    return setups, zones


def export_continuous_segment_filtered(
    storage: Path, run_id: str, segment: str, output: Path, roll_calendar: Path, *,
    data_root: Path, session_calendar: Path | None = None, apply_e1: bool | None = None,
) -> dict:
    """Write the included fixed export and a full decision ledger, read-only."""
    segment = segment.upper()
    if segment not in {"MCX", "NSEFO"}:
        raise ValueError("segment must be MCX or NSEFO")
    roll_map = load_official_roll_map(roll_calendar)
    if apply_e1 is None:
        apply_e1 = segment == "MCX"
    if apply_e1 and session_calendar is None:
        raise FilterEvidenceError("MCX E1 filtering requires an OFFICIAL_VERIFIED session calendar")
    sessions = load_official_session_calendar(session_calendar) if apply_e1 else None
    ledger_path = output.with_suffix(output.suffix + ".filter_ledger.csv")
    manifest_path = output.with_suffix(output.suffix + ".manifest.json")
    checksum_path = output.with_suffix(output.suffix + ".sha256")
    for target in (output, ledger_path, manifest_path, checksum_path):
        if target.exists():
            raise FileExistsError(f"refusing to overwrite export artifact: {target}")

    uri = f"file:{storage.resolve()}?mode=ro"
    with sqlite3.connect(uri, uri=True) as db:
        db.row_factory = sqlite3.Row
        run = db.execute(
            "SELECT config_json,historical_start,historical_end,status FROM backtest_runs WHERE run_id=?", (run_id,)
        ).fetchone()
        if run is None:
            raise ValueError(f"unknown run_id: {run_id}")
        config = json.loads(run["config_json"])
        setups, zones = _read_rows(db, run_id)
        gate_reasons = [x[0] for x in db.execute(
            "SELECT DISTINCT gate_reason FROM scan_results WHERE run_id=? AND gate_reason IS NOT NULL ORDER BY gate_reason",
            (run_id,),
        )]

    split = midpoint(run["historical_start"], run["historical_end"])
    fixed_rows: list[dict] = []
    ledger_rows: list[dict] = []
    for row in setups.itertuples(index=False):
        outcome = row.trade_outcome or ("UNFILLED" if int(row.eligible) else "BLOCKED")
        resolved = outcome in {"WIN", "LOSS"}
        fixed = {
            "symbol": str(row.symbol).split("@", 1)[0], "E_regime": row.E_regime,
            "A_regime": row.A_regime, "strategy_tf": _stack(segment, int(row.strategy_tf), row.strategy_tf_name),
            "entry": row.proposed_entry, "stop": row.proposed_stop, "target": row.proposed_target,
            "exit": row.exit_price, "outcome": outcome, "gross_r": row.gross_r if resolved else None,
            "mfe": row.max_favorable_excursion,
            "max_favorable_pct_of_target": row.max_favorable_pct_of_target,
            "bars_held": row.bars_held, "entry_timestamp": row.entry_timestamp,
            "partition": _partition(row.setup_timestamp, split),
            "overnight_dir": "UNKNOWN" if segment == "MCX" else "NOT_APPLICABLE",
        }
        reasons: list[str] = []
        try:
            setup_segment = roll_map.segment(row.symbol, row.setup_timestamp)
            entry_segment = roll_map.segment(row.symbol, row.entry_timestamp) if row.entry_timestamp else "NOT_ENTERED"
            exit_segment = roll_map.segment(row.symbol, row.exit_timestamp) if row.exit_timestamp else "NOT_EXITED"
            if row.entry_timestamp and row.exit_timestamp and entry_segment != exit_segment:
                reasons.append("roll_span")
        except FilterEvidenceError as exc:
            setup_segment = entry_segment = exit_segment = "UNVERIFIED"
            reasons.append(f"roll_calendar_unverified:{exc}")

        scan_zones = zones[zones.scan_id == row.scan_id]
        linked = _linked_zones(scan_zones, row.proposed_stop, row.proposed_target)
        linkage = "EXACT_PERSISTED_PRICE_BOUNDARY" if not linked.empty else "NO_EXACT_PERSISTED_LINK"
        zone_ids: list[str] = []
        created_values: list[str] = []
        zone_segments: list[str] = []
        for zone in linked.itertuples(index=False):
            zone_ids.append(str(zone.zone_id))
            try:
                created = _created_timestamp(data_root, segment, row.symbol, int(row.strategy_tf), zone.timeframe,
                                             zone.created_idx, zone.created_timestamp)
                created_values.append(created.isoformat())
                zone_segment = roll_map.segment(row.symbol, created)
                zone_segments.append(zone_segment)
                if zone_segment != setup_segment:
                    reasons.append("prior_segment_zone")
                if created < _ist(row.setup_timestamp) - pd.DateOffset(months=12):
                    reasons.append("zone_age_over_12_months")
            except FilterEvidenceError as exc:
                reasons.append(f"zone_origin_unverified:{exc}")

        seam = _e1_crossing(row.entry_timestamp, row.exit_timestamp) if apply_e1 else None
        if seam:
            if sessions is not None and sessions.covers(row.entry_timestamp, row.exit_timestamp):
                reasons.append("e1_gap")
            else:
                reasons.append("session_calendar_unverified")
        # A stable priority makes an overlapping roll/E1 exclusion reproducible.
        ordered = [reason for reason in ("roll_span", "prior_segment_zone", "zone_age_over_12_months", "e1_gap") if reason in reasons]
        ordered.extend(sorted(reason for reason in reasons if reason not in ordered))
        reason = ";".join(dict.fromkeys(ordered))
        status = "EXCLUDED" if reason else "INCLUDED"
        record = {
            "setup_id": row.setup_id, "filter_status": status, "exclusion_reason": reason or None,
            "setup_segment_id": setup_segment, "entry_segment_id": entry_segment,
            "exit_segment_id": exit_segment, "zone_linkage_status": linkage,
            "zone_ids": "|".join(zone_ids) or None,
            "zone_created_timestamps": "|".join(created_values) or None,
            "zone_segment_ids": "|".join(zone_segments) or None,
            "e1_boundary": seam, **fixed,
        }
        ledger_rows.append(record)
        if status == "INCLUDED":
            fixed_rows.append(fixed)

    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(fixed_rows, columns=FIXED_TRADE_EXPORT_COLUMNS).to_csv(output, index=False)
    ledger = pd.DataFrame(ledger_rows, columns=LEDGER_COLUMNS)
    ledger.to_csv(ledger_path, index=False)
    counts = ledger.groupby(["filter_status", "exclusion_reason"], dropna=False).size().to_dict()
    manifest = {
        "schema": "PREDIXA_FIXED_BUY_SETUP_EXPORT_V1_WITH_CONTINUOUS_SEGMENT_FILTERS",
        "fixed_export_columns": FIXED_TRADE_EXPORT_COLUMNS,
        "ledger_columns": LEDGER_COLUMNS,
        "segment": segment, "run_id": run_id, "run_status_at_export": run["status"],
        "source_mode": "CONTINUOUS_SERIES_RESEARCH", "sqlite_open_mode": "ro",
        "roll_calendar": str(roll_map.source), "roll_calendar_sha256": roll_map.sha256,
        "session_calendar": str(sessions.source) if sessions else None,
        "session_calendar_sha256": sessions.sha256 if sessions else None,
        "roll_boundary_rule": "[previous roll date, roll date); OFFICIAL_VERIFIED rows only",
        "zone_linkage_rule": "only exact persisted stop/target-to-zone-boundary matches are evaluated",
        "zone_origin_rule": "persisted timestamp or created_idx resolved against immutable continuous source",
        "e1_rule": "MCX entry-to-exit periods crossing 23:30 IST -> 09:00 IST are excluded" if apply_e1 else "not applicable",
        "filters": ["roll_span", "prior_segment_zone", "zone_age_over_12_months", "e1_gap"],
        "historical_start": run["historical_start"], "historical_end": run["historical_end"],
        "partition_split_timestamp": split.isoformat(), "random_seed": config.get("random_seed"),
        "research_gate_bypass_config": bool(config.get("research_gate_bypass", False)),
        "research_gate_bypass_evidence": gate_reasons,
        "fixed_rows_included": len(fixed_rows), "ledger_rows_all_buy_setups": len(ledger),
        "filter_counts": {f"{key[0]}|{key[1]}": value for key, value in counts.items()},
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    checksum_path.write_text(f"{sha256(output)}  {output.name}\n", encoding="utf-8")
    return {"included_rows": len(fixed_rows), "ledger_rows": len(ledger), "output": str(output),
            "ledger": str(ledger_path), "manifest": str(manifest_path), "sha256": sha256(output)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--run", required=True)
    parser.add_argument("--segment", required=True, choices=("MCX", "NSEFO"))
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--roll-calendar", required=True, type=Path,
                        help="official CSV: symbol,roll_date,verification_status=OFFICIAL_VERIFIED")
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--session-calendar", type=Path,
                        help="MCX OFFICIAL_VERIFIED exchange-date calendar; required unless --no-e1")
    parser.add_argument("--no-e1", action="store_true", help="only valid for NSEFO exports")
    args = parser.parse_args(argv)
    print(json.dumps(export_continuous_segment_filtered(
        args.storage, args.run, args.segment, args.output, args.roll_calendar,
        data_root=args.data_root, session_calendar=args.session_calendar,
        apply_e1=False if args.no_e1 else None,
    ), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
