# MCX completed replay submission

Start with `01_EXECUTIVE/MCX_EXECUTIVE_SUMMARY.md`, then `02_FULL_REPORT/MCX_DETAILED_FINDINGS.md`.

The source SQLite database was opened read-only and was **not** copied into this package. Its absolute path and SHA-256 are recorded in `05_REPRODUCIBILITY/`. All metrics are derived from persisted replay evidence.
