# PREDIXA Custom Interval Stitcher Fix — Submission

This package contains the current source snapshots and validation evidence for the custom-interval stitcher corrections across NSE cash, NSE futures, and MCX commodity data paths.

## Changes

- Shared timestamp-based aggregation in `source/data_fetchers/interval_stitching.py`.
- NSE intraday buckets anchored at 09:15 and filtered to the 09:15–15:30 session.
- MCX bars anchored at 09:00, separated by exchange date and the existing E1 session boundary; an evening-only input date anchors at 17:00. MCX builders preserve their complete-base-bar policy.
- Daily-to-weekly/monthly aggregation sorts timestamps before selecting open/close and writes without the DataFrame index.
- Updater delta merges are sorted chronologically before row-position-dependent selection.

## Validation

Focused command: `PYTHONPATH=. pytest -q tests/test_interval_stitching.py tests/test_mcx_e1_session_boundary.py tests/test_liquid_futures_data_updater.py` — **26 passed, 5 warnings**. Python compilation passed. Scoped `git diff --check` passed. A repository-wide `git diff --check` reports an unrelated pre-existing whitespace issue at `apps/pipelines/stock_process.py:903`; it is outside this submission and was not changed.

No market-data CSVs were regenerated, no database was accessed for writes, and no scanner or broker process was started.

## Important scope note

Several source paths had pre-existing local modifications before this stitcher task. The package includes current file snapshots for context and does not represent every included file as a clean, isolated patch. See `metadata/REPOSITORY_STATE.md` and `metadata/CHANGED_FILES.csv`.
