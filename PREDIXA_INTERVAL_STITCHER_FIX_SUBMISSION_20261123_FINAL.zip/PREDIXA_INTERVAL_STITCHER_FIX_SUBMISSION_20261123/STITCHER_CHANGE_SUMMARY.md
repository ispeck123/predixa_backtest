# Stitcher Change Summary

## NSE cash and NSE futures

25-minute, 75-minute, and 125-minute builders now assign each candle to a timestamp-derived bucket from the 09:15 session open. Out-of-session candles are excluded, and missing candles do not shift later bars. Aggregates use chronological first open, maximum high, minimum low, last close, and summed quantity.

## MCX commodities

The MCX 75-minute and 125-minute builders use 09:00 session anchoring and existing E1 session IDs, with an exchange-date partition to prevent cross-date aggregation if a close-side candle is absent. The helper supports an evening-only input date anchored at 17:00. Production MCX call sites specify the base interval and retain the existing complete-bucket requirement.

## Weekly/monthly bars

The shared aggregation sorts parsed dates stably before resampling, making first open and last close deterministic when source daily data is unsorted. All updated weekly/monthly writes use `index=False`, eliminating the synthetic CSV index column.

## Ingestion ordering

Relevant delta merge paths sort the merged timestamp column before persisting or using row positions. Existing data and output files were not rewritten as part of this change.

## Source coverage

Included snapshots cover FYERS stock/futures/commodity, Kite stock/futures/commodity, Indian YFinance stock ingestion, and the backend CSV path used for India. Legacy FYERS updater modules were updated to use the same shared helpers.
