# Archive Sanitization

Repository files were not edited for sanitization. The following archive-only substitutions were applied to prevent credential leakage:

- `data_fetchers/fyers/candle_data.py`: Embedded commented FYERS token replaced in archive copy only.
- `data_fetchers/kiteconnect/indian_stock_data_updater.py`: Runtime access-token print removed in archive copy only.

The archive source copies should be treated as review snapshots; the sanitizations are documented deviations from byte-identical working-tree source. No actual credentials are included.
