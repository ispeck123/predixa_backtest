# NSEFO TF2/TF4 Executive Submission Summary

## Run result

Run `92f13c51fae94bdcbb0e7e376328ad92` completed with the repaired NSEFO TF2/TF4 gate active.

| Measure | Result |
|---|---:|
| Registered tasks | 726,420 |
| Completed tasks | 714,260 |
| Failed tasks | 12,160 |
| BUY signals/setup rows | 186,233 |
| Eligible setups | 184,647 |
| Entered trades | 166,273 |
| Resolved WIN/LOSS | 164,760 |
| Unresolved entered trades | 1,513 |
| Resolved wins | 42,727 |
| Resolved losses | 122,033 |
| Resolved win rate | 25.933% |
| Resolved gross R | 14241.413 |
| Average resolved gross R | 0.086437 |
| Gate denied scans | 0 |
| SQLite integrity | `ok` |

## Submission interpretation

The former TF2/TF4 `not in permit set` blocker is absent: all persisted scan rows are `PERMIT`. The remaining blocked setups are normal `rr_below_2.1` rows, not gate denials.

The results are pre-cost gross replay evidence. The run still has `12,160` failed tasks, uses stitched/calendar-inferred source history, and has `1,513` unresolved trades at source-history end. These limitations are fully documented and exported rather than hidden.
