# Outcome resolution note

Resolved outcomes are exported as WIN/LOSS from persisted replay rows. Entered rows marked `UNRESOLVED` have an entry but no later target/stop event before the source file ended. They are not assigned a fabricated exit, mark-to-market value, or outcome. A genuine resolution requires later historical bars and a separate approved replay or analysis procedure.
