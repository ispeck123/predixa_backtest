# NSEFO TF2/TF4 Repaired-Gate Run Evaluation

## Executive conclusion

Run `92f13c51fae94bdcbb0e7e376328ad92` confirms that the NSEFO TF2/TF4 gate repair is active in the replay path.

- All persisted scan rows returned `PERMIT`.
- Gate-denied scans: `0`.
- The replay generated `186,233` BUY signals/setup rows.
- `184,647` setups passed the entry eligibility threshold.
- `166,273` simulated BUY trades were entered.
- The prior failure mode—TF2/TF4 setups being rejected as `not in permit set`—is no longer present.

This is a valid repaired-gate baseline, not a final live-performance approval. The run has `12,160` failed tasks, `1,513` entered trades unresolved at source-history end, uses stitched/calendar-inferred futures data, and has not had trading costs applied in this report.

## 1. Run identity and source

| Field | Value |
|---|---|
| Run ID | `92f13c51fae94bdcbb0e7e376328ad92` |
| Run name | `nsefo_tf2_tf4_buy_only_full_20261107` |
| SQLite database | `/home/ispeck/PROJECTS_DEV/STP_LATEST/fin_backend_final_latest/audit/nsefo_futures_backtest/storage/nsefo_tf2_tf4_buy_only_full_20261107.sqlite` |
| SQLite SHA-256 | `f12ebde95d17f552cdc070b01ec3c7de775ae75c48cf03cd01b5d0e9e1d919a6` |
| Status | `COMPLETED` |
| Historical range | `2024-10-01` through `2026-09-30` |
| Scan coverage | `2024-10-01 09:15` through `2026-09-30 15:30` |
| Symbols scanned | `152` |
| Source label | `@27102026` near-expiry stitched/continuous source |
| Strategy TFs | TF2 and TF4 |
| Executor | Process |
| Workers | 24 |
| BUY-only | Yes |
| Run duration | 2026-11-07 19:10:13 UTC through 2026-11-08 02:17:57 UTC |

The database was opened read-only for this evaluation. No SQLite rows, market data, production code, or run state were changed.

## 2. Completion and persistence

| Population | Count |
|---|---:|
| Registered tasks | 726,420 |
| Completed tasks | 714,260 |
| Failed tasks | 12,160 |
| Completion rate | 98.326% |
| Scan rows | 714,260 |
| BUY signals/setup rows | 186,233 |
| Eligible setup rows | 184,647 |
| Entered trades | 166,273 |
| Resolved WIN/LOSS trades | 164,760 |
| Unresolved entered trades | 1,513 |

The run's `COMPLETED` status means the runner finished its task lifecycle. It does not mean that every registered task succeeded; `12,160` tasks remain failed after retries and are excluded from the completed scan population.

## 3. Gate-repair validation

The repaired gate behaved as intended:

| Gate tier | Size multiplier | Gate denied | Scans |
|---|---:|---:|---:|
| `PERMIT` | 1.0 | 0 | 714,260 |

No row contains the former reasons:

```text
NSEFO .../tf2 not in permit set
NSEFO .../tf4 not in permit set
```

The prior permit-set blocker has therefore been removed from this replay. TF2 and TF4 signals were allowed to continue to the normal BUY eligibility and replay-entry checks.

## 4. TF-level results

| TF | Scans | Signals | Eligible | RR-blocked | Entered | Resolved | Wins | Losses | Win rate | Avg resolved gross R | Sum resolved gross R |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| TF2 | 502,813 | 138,303 | 137,023 | 1,280 | 123,762 | 122,621 | 31,702 | 90,919 | 25.854% | 0.084449 | 10,355.160 |
| TF4 | 211,447 | 47,930 | 47,624 | 306 | 42,511 | 42,139 | 11,025 | 31,114 | 26.163% | 0.092225 | 3,886.253 |
| **Total** | **714,260** | **186,233** | **184,647** | **1,586** | **166,273** | **164,760** | **42,727** | **122,033** | **25.933%** | **0.086437** | **14,241.413** |

Win rate is calculated only over resolved `WIN` and `LOSS` trades. Gross R excludes brokerage, slippage, taxes, lot-size conversion, and other execution costs.

## 5. Remaining setup blocks

The remaining `1,586` blocked setup rows were not gate denials. They failed the normal BUY reward/risk threshold:

| TF | Blocked reason | Rows |
|---:|---|---:|
| TF2 | `rr_below_2.1` | 1,280 |
| TF4 | `rr_below_2.1` | 306 |

The gate was `PERMIT` for these rows; the scanner's RRR threshold was the blocking condition.

## 6. Entry conversion

There were `184,647` eligible setup candidates and `166,273` entered trades. The difference is `18,374` candidates:

| TF | Eligible candidates without an entered trade |
|---:|---:|
| TF2 | 13,261 |
| TF4 | 5,113 |
| **Total** | **18,374** |

The replay defines an entry as the first future execute-timeframe candle whose `[low, high]` range contains the proposed entry. An eligible candidate that never receives that price touch is not recorded as an entered trade. This is an unfilled-entry result, not a gate denial.

Among entered trades, `1,513` reached the end of available source history after entry and remain `UNRESOLVED`:

| Exit state | Count |
|---|---:|
| Target hit / `WIN` | 42,727 |
| Stoploss hit / `LOSS` | 122,033 |
| Source history ended / `UNRESOLVED` | 1,513 |

## 7. Regime population

All BUY signals came from these E/A regime combinations:

| E regime | A regime | Scans | Signals | Eligible candidates |
|---|---|---:|---:|---:|
| UP | UP | 242,600 | 87,331 | 86,510 |
| UP | SW | 115,829 | 46,022 | 45,604 |
| SW | UP | 85,293 | 34,974 | 34,739 |
| SW | SW | 45,502 | 17,906 | 17,794 |

DN-containing E/A cells produced no BUY signals in this run. This is a population observation, not a separate gate denial.

## 8. Failure analysis

The failed tasks were caused by source/warm-up and indexing exceptions, not by the TF2/TF4 permit gate:

| Exception | Error events | Affected tasks |
|---|---:|---:|
| `E-TF has 2 bars, minimum 7 required` | 6,420 | 2,140 |
| `E-TF has 5 bars, minimum 7 required` | 6,000 | 2,000 |
| `E-TF has 6 bars, minimum 7 required` | 6,000 | 2,000 |
| `E-TF has 3 bars, minimum 7 required` | 5,970 | 1,990 |
| `E-TF has 1 bars, minimum 7 required` | 5,610 | 1,870 |
| `E-TF has 4 bars, minimum 7 required` | 5,100 | 1,700 |
| `single positional indexer is out-of-bounds` | 1,380 | 460 |
| **Total** | **36,480** | **12,160** |

The error-event count is three times the failed-task count because failed tasks reached the configured third attempt after two retries.

These failures should be addressed before treating the run as a complete historical population. They do not invalidate the persisted completed rows, and they did not produce the former permit-set denial.

## 9. Data and interpretation boundaries

- The run uses a stitched/continuous futures source under the near-expiry label `27102026`; the label is not proof of exchange-verified historical contract identity for every bar.
- The production trend/setup engine was evaluated as supplied to the audit runner; this report does not claim hard zone resets at inferred contract-roll boundaries.
- The reported gross R is before costs and does not establish live profitability.
- The run is a baseline evaluation, not a parameter sweep, OOS sign-off, or production sizing approval.
- Failed tasks and unresolved trades must be handled explicitly in any final decision.

## 10. Decision

### Gate status

**PASS for the specific issue under investigation.** The NSEFO TF2/TF4 permit-set blocker is fixed in this run: all scan rows were `PERMIT`, and signals converted into persisted BUY setups and trades.

### Backtest status

**VALID REPAIRED-GATE BASELINE, NOT FINAL APPROVAL.** The run has substantial persisted trade evidence, but its 1.674% failed-task population, stitched-source limitation, unresolved trades, and pre-cost gross metrics prevent it from being used alone as a final live deployment or performance verdict.

Recommended next analysis is a read-only cost/OOS report on the completed trades plus a separate remediation/replay plan for the `E-TF` warm-up and indexer failures. Do not overwrite this database or relabel the historical run.

## 11. Reproducibility references

- Gate implementation: `scripts/tf_regime_gate_by_exchange.py`
- NSEFO runner: `audit/nsefo_futures_backtest/run_phase_a.py`
- Read-only storage: `audit/fresh_trend_backtest/storage/sqlite_storage.py`
- Source database: `audit/nsefo_futures_backtest/storage/nsefo_tf2_tf4_buy_only_full_20261107.sqlite`
