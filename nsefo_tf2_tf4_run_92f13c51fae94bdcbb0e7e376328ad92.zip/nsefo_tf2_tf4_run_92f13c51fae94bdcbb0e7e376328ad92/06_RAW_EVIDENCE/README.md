Persisted trade, setup, unresolved, unfilled, and error evidence exported from the source SQLite database using read-only queries. The database itself is referenced, not copied.
