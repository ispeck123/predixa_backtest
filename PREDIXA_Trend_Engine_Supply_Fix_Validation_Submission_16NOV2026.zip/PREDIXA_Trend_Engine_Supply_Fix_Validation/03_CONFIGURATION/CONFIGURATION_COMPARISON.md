# Configuration comparison

Flag OFF: legacy shape filtering. Flag ON: daily-or-higher single inverted-hammer supply context is retained; Rule-C membership code is also enabled. No strategy setup selection or real trading permission is changed. The paired replay records the flag value per task.
