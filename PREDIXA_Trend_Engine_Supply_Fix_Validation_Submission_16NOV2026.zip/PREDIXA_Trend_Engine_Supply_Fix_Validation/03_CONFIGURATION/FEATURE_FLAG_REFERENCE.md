# Feature flag

`PREDIXA_TREND_SUPPLY_FIX_ENABLED` is read by Config and defaults to false (`0`). Set to `1` only in an isolated research process to reproduce the flagged diagnostic. Production must remain OFF pending acceptance and release approval.
