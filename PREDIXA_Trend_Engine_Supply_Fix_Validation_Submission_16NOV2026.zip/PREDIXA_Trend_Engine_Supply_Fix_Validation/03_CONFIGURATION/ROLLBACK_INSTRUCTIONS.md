# Rollback

Keep `PREDIXA_TREND_SUPPLY_FIX_ENABLED=0` or unset. To revert source changes in a separate clean worktree, review `02_SOURCE_CODE_CHANGES/patches/predixa_trend_supply_fix.patch` before applying a reverse patch. Do not use blanket checkout/reset in the dirty project tree. No deployment occurred.
