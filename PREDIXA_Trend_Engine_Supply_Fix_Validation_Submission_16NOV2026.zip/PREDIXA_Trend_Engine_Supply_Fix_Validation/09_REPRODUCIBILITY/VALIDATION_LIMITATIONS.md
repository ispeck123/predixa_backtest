# Limitations

The archive lacks its SQLite database and exact archived weekly input. The paired rerun uses supplied local files with functional anchor checks and is not byte-identical. No formal cross-market performance comparison or production acceptance is claimed.
