# Environment and dependencies

Python reported: `Python 3.13.5`. Tests and compile used `/home/ispeck/anaconda3/envs/finpro/bin/python`. Runtime dependencies are repository-managed; no environment lockfile is included. No services or database were accessed.
