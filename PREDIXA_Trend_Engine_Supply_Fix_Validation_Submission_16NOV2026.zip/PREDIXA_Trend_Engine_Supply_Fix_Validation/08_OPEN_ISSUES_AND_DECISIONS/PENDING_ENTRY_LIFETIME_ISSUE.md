# Pending-entry lifetime issue

The archive evidence records 42–296 hours from setup evaluation to entry (all 99 >24 hours; 78 >72 hours). This establishes delay, not causal attribution to losses. No approved order lifetime was identified or changed. Stakeholder must decide whether setups expire and define that policy before a separate replay.
