# Open issues

1. Rule-C decision: restored A supply appears in only 23 task contexts; all 99 labels remain UP/UP and all longs remain permitted. Specify the intended rule when opposing supply and demand coexist.
2. Pending entry lifetime: evidence reports 42–296-hour evaluation-to-entry delays; no threshold was implemented. Stakeholder must define expected lifetime/cancellation semantics.
3. Weekly provenance: archived weekly file hash/source is missing; provide exact file or immutable artifact.
4. Downstream MCX/NSEFO validation: not run due to failed GOLDM gate.
