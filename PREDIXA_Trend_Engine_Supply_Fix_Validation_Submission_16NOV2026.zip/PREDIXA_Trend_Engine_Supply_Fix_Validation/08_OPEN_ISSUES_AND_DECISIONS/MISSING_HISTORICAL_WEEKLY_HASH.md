# Missing weekly provenance

The original weekly OHLC hash referenced by archived replay evidence is unavailable. A current weekly file was used for the functional run, with the archived E demand-zone anchor matching, but file identity is not proven. Provide the exact archived weekly bytes and hash for byte-identical replay verification.
