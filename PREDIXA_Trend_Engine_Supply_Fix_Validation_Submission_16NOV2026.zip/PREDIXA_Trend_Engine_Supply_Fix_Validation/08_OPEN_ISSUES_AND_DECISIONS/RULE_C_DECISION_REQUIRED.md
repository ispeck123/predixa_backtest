# Rule C decision required

Observed: in flagged replay all 99 remain UP/UP and permitted; A nearest supply is present in 23. The source shows candidate restoration but does not establish that Rule C should emit DN/SW whenever supply and demand coexist. Stakeholder/methodology owner must specify how dominance, violation, and the Rule-C cascade should resolve this state. No new rule was assumed or implemented for this package.
