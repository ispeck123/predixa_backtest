# Next actions

1. Supply archived weekly source and hash.
2. Obtain a written Rule-C interpretation for the restored-supply/coexisting-demand case.
3. Decide pending-order lifetime policy independently.
4. Implement only the approved change behind the existing flag and rerun all 99 cohort tasks.
5. Continue to NSEFO/MCX comparison only after the GOLDM hard gate passes.
6. Keep all trading permissions disabled until separate release approval.
