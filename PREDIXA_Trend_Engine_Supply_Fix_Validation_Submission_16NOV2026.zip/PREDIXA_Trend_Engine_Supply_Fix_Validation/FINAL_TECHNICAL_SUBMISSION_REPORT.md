# Final technical submission report

## 1. Purpose and scope
Package the evidence-backed supply-detection investigation and partial correction for the 14-Nov-2026 Unified Fix work order. No additional engine behavior was changed for packaging.

## 2. Original production issue
The supplied cohort contains 99 GOLDM March 2026 BUY losses. Archived E/A labels were UP/UP with no nearest overhead supply.

## 3. Investigation performed
Archive integrity passed. The source package itself lacks engine revision and weekly source bytes. Current supplied candles were compared to archived candle windows and zone anchors. Lifecycle was audited at all cohort evaluation timestamps.

## 4. Root cause and evidence
A relevant A-layer SZ (`GOLDM_A_SZ_2088`, 162463/160250) is rejected before formation by §4.6 single inverted-hammer shape filtering. It is not Check-5 structure removal.

## 5. Exact changes implemented
A default-off feature flag retains the identified pattern only for higher-timeframe supply context. Tests verify legacy rejection and flagged retention with demand behavior unchanged. Existing Rule-C membership changes are included in the scoped source snapshot; they did not alter the cohort regime outcomes.

## 6. Before/after findings
Legacy: 99/99 long setups permitted, E/A UP/UP, zero A nearest supply. Flagged: 99/99 remain permitted, E/A UP/UP, A nearest supply populated in 23. Candidate visibility improved; acceptance did not.

## 7. Automated validation
Focused suite: 41 passed, 5 deprecation warnings. Compilation and diff checks passed. See test execution log.

## 8. GOLDM acceptance outcome
FAIL. All original 99 remain permitted after the narrow correction. The missing weekly source hash also prevents byte-identical replay.

## 9. MCX/NSEFO regression status
Full MCX/NSEFO validation and NSEFO golden-set comparison were not run because GOLDM acceptance failed.

## 10. Historical-data limitations
The replay is functionally anchored to available OHLC but not identical to archived weekly input. The evidence package’s stored results match its own persisted cohort but does not include original DB or exact engine files.

## 11. Outstanding technical issues
Rule-C expected resolution for coexisting supply/demand is unspecified. Pending entries were delayed 42–296 hours; their lifetime policy is unresolved.

## 12. Decisions required
Provide archived weekly file/hash, specify Rule-C behavior, decide pending-entry lifetime.

## 13. Deployment and rollback status
Not deployed. Feature flag default OFF. MCX PAPER/REAL OFF. Rollback is leave flag unset/off.

## 14. Package contents
Workbook, source snapshots, patch, tests, lifecycle evidence, 99-task paired replay, manifests, and reproducibility instructions.

## 15. Final submission status
**Partial technical fix submitted with validated diagnostic evidence; final trading-regime acceptance remains blocked.**
