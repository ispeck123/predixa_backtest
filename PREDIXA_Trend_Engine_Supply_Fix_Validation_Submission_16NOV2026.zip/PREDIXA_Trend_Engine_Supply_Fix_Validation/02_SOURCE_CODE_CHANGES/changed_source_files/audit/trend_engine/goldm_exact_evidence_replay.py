"""Compare legacy and flagged SD-engine decisions for the exact GOLDM cohort.

Only local OHLC is read.  A temporary source view is assembled with symlinks
so the production pipeline can receive the original three-frame file layout;
no database, broker, scanner, or market-data file is modified.
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile
from dataclasses import asdict
from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.config.settings import stock_data_dir_config
from scripts.setup_engine_new import process_setup_fc


def _zone(zone):
    if zone is None:
        return None
    return {"id": zone.zone_id, "distal": zone.distal, "proximal": zone.proximal}


def _result_row(task_id: int, timestamp: str, result: dict, enabled: bool) -> dict:
    context = result["trend_context"]
    return {
        "task_id": task_id,
        "evaluation_timestamp": timestamp,
        "trend_supply_fix_enabled": enabled,
        "E_regime": context.result_E.regime.value,
        "A_regime": context.result_A.regime.value,
        "X_regime": context.result_X.regime.value,
        "E_rule": context.result_E.rule_applied,
        "A_rule": context.result_A.rule_applied,
        "E_nearest_sz": json.dumps(_zone(context.result_E.nearest_sz)),
        "A_nearest_sz": json.dumps(_zone(context.result_A.nearest_sz)),
        "allow_long": context.allow_long,
        "allow_short": context.allow_short,
        "permitted_setup": context.permitted_setup,
        "long_setup_present": result["best_setup_long"] is not None,
        "long_setup": json.dumps(asdict(result["best_setup_long"]) if result["best_setup_long"] else None, default=str),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", required=True, type=Path)
    parser.add_argument("--weekly", required=True, type=Path)
    parser.add_argument("--daily", required=True, type=Path)
    parser.add_argument("--sixty", required=True, type=Path)
    parser.add_argument("--expiry", default="04122026")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite output: {args.output}")
    if not all(path.is_file() for path in (args.weekly, args.daily, args.sixty)):
        raise FileNotFoundError("weekly, daily, and sixty evidence inputs must all exist")
    cohort = pd.read_csv(args.cohort)
    if not {"task_id", "evaluation_timestamp"}.issubset(cohort.columns):
        raise ValueError("cohort requires task_id and evaluation_timestamp")

    original_dir = stock_data_dir_config.indian_commodity_data
    rows: list[dict] = []
    try:
        with tempfile.TemporaryDirectory(prefix="goldm-evidence-replay-") as tmp:
            root = Path(tmp)
            source = root / "latest_data_csv"
            source.mkdir()
            for frame, path in (("weekly", args.weekly), ("daily", args.daily), ("sixty", args.sixty)):
                (source / f"GOLDM_{args.expiry}_{frame}.csv").symlink_to(path.resolve())
            stock_data_dir_config.indian_commodity_data = str(root)
            for enabled in (False, True):
                os.environ["PREDIXA_TREND_SUPPLY_FIX_ENABLED"] = "1" if enabled else "0"
                for task in cohort[["task_id", "evaluation_timestamp"]].itertuples(index=False):
                    result = process_setup_fc(
                        "GOLDM", ["weekly", "daily", "sixty"], args.expiry,
                        pd.Timestamp(task.evaluation_timestamp).to_pydatetime(), False,
                    )
                    if not isinstance(result, dict):
                        raise RuntimeError(f"task {task.task_id} failed: {result}")
                    rows.append(_result_row(int(task.task_id), str(task.evaluation_timestamp), result, enabled))
    finally:
        stock_data_dir_config.indian_commodity_data = original_dir
        os.environ.pop("PREDIXA_TREND_SUPPLY_FIX_ENABLED", None)

    result = pd.DataFrame(rows)
    result.to_csv(args.output, index=False)
    summary = {
        "tasks": int(len(cohort)),
        "legacy_long_setups": int(result.loc[~result.trend_supply_fix_enabled, "long_setup_present"].sum()),
        "flagged_long_setups": int(result.loc[result.trend_supply_fix_enabled, "long_setup_present"].sum()),
        "flagged_E_A_regimes": {
            "/".join(key): int(value)
            for key, value in result.loc[result.trend_supply_fix_enabled].groupby(["E_regime", "A_regime"]).size().items()
        },
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
