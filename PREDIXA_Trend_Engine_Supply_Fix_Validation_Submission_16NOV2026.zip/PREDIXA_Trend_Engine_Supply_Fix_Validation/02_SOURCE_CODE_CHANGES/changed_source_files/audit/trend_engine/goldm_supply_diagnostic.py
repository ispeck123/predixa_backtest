"""Point-in-time supply-zone lifecycle diagnostic for the unified trend fix.

This is an audit utility, not a strategy implementation.  It calls the same
``ZoneDetector`` / ``ZoneQualifier`` / ``filter_buy_sell_zones_v2`` objects as
the production commodity route and writes the evidence needed before any
trend-detection behaviour is changed.

The diagnostic-only pre-§4.6 pass changes timestamps to one-hour spacings.
``ZoneDetector`` uses timestamp spacing *only* to decide whether its daily-or-
higher single-candle shape filter applies; OHLC, indexes, and every other
detection condition are unchanged.  Comparing that pass with normal detection
identifies candidates removed solely by the documented shape filter without
disabling it in production.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.models import CandleSeries, Config, TF, Zone, ZoneState
from scripts.trade_engine import (
    ZoneDetector,
    ZoneQualifier,
    load_preprocess_data,
    process_trend_zones,
)
from scripts.trend_engine import Config as TrendConfig, TrendEngine


DEFAULT_DATA_DIR = ROOT / "data" / "indian_commodity_data" / "latest_data_csv"


def _parse_timestamp(value: str) -> datetime:
    return pd.Timestamp(value).to_pydatetime()


def _zone_key(zone: Zone) -> tuple[Any, ...]:
    """Stable comparison key independent of the diagnostic timestamp view."""
    return (
        getattr(zone.ztype, "value", str(zone.ztype)),
        int(zone.base_start),
        int(zone.base_end),
        int(zone.departure_idx) if zone.departure_idx is not None else None,
        round(float(zone.distal), 8),
        round(float(zone.proximal), 8),
    )


def _zone_id(zone: Zone) -> str:
    value = getattr(zone, "zone_id", None)
    if value:
        return str(value)
    return "|".join(str(value) for value in _zone_key(zone))


def _as_value(value: Any) -> Any:
    if hasattr(value, "value"):
        return value.value
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    return value


def _base_shape(zone: Zone, cs: CandleSeries) -> tuple[str, str]:
    """Return a compact, inspectable base-shape classification and OHLC view."""
    candles = []
    for index in range(zone.base_start, zone.base_end + 1):
        candles.append({
            "index": index, "open": cs.o[index], "high": cs.h[index],
            "low": cs.l[index], "close": cs.c[index],
        })
    if zone.base_len != 1:
        return "MULTI_CANDLE_BASE", json.dumps(candles, separators=(",", ":"))
    candle = candles[0]
    span = candle["high"] - candle["low"]
    if span <= 0:
        return "ZERO_RANGE", json.dumps(candles, separators=(",", ":"))
    body = abs(candle["close"] - candle["open"]) / span
    close_position = (candle["close"] - candle["low"]) / span
    upper_wick = (candle["high"] - max(candle["open"], candle["close"])) / span
    lower_wick = (min(candle["open"], candle["close"]) - candle["low"]) / span
    if body < 0.10:
        shape = "DOJI"
    elif close_position < 0.25 and upper_wick > 0.60:
        shape = "INVERTED_HAMMER"
    elif close_position > 0.75 and lower_wick > 0.60:
        shape = "HAMMER"
    else:
        shape = "SINGLE_BASE_OTHER"
    return shape, json.dumps(candles, separators=(",", ":"))


def _series(df: pd.DataFrame, *, shape_bypass: bool = False) -> CandleSeries:
    timestamps = df["unix_timestamp"].tolist()
    if shape_bypass:
        # See module docstring.  The detector only uses ``ts`` in this path to
        # infer bar duration; preserve every price and positional index.
        timestamps = [1_700_000_000 + i * 3_600 for i in range(len(df))]
    return CandleSeries(
        o=df["open"].astype(float).tolist(),
        h=df["high"].astype(float).tolist(),
        l=df["low"].astype(float).tolist(),
        c=df["close"].astype(float).tolist(),
        ts=timestamps,
    )


def _row(zone: Zone, *, layer: str, event: str, reason: str | None,
         cmp: float, source_file: Path, cutoff: datetime, selected: bool = False,
         shape_filter_result: str | None = None, cs: CandleSeries) -> dict[str, Any]:
    zone_type = _as_value(zone.ztype)
    created_ts = getattr(zone, "created_ts", None)
    base_shape, base_candles = _base_shape(zone, cs)
    return {
        "instrument": "GOLDM",
        "layer": layer,
        "source_file": str(source_file),
        "cutoff": cutoff.isoformat(),
        "zone_id": _zone_id(zone),
        "zone_type": zone_type,
        "candidate_event": event,
        "rejection_reason": reason or "",
        "shape_filter_result": shape_filter_result or "NOT_APPLICABLE",
        "created_idx": zone.created_idx,
        "created_timestamp": _as_value(created_ts),
        "base_start": zone.base_start,
        "base_end": zone.base_end,
        "base_len": zone.base_len,
        "base_shape": base_shape,
        "base_candles": base_candles,
        "departure_idx": zone.departure_idx,
        "distal": float(zone.distal),
        "proximal": float(zone.proximal),
        "cmp": float(cmp),
        "above_cmp": bool(zone.distal > cmp),
        "below_cmp": bool(zone.distal < cmp),
        "invalidated": bool(zone.invalidated),
        "invalidation_state": _as_value(zone.state),
        "violation": _as_value(zone.violation),
        "block_reason": getattr(zone, "block_reason", None),
        "penetration_pct": float(getattr(zone, "penetration_pct", 0.0) or 0.0),
        "retest_count": int(getattr(zone, "retest_count", 0) or 0),
        "removes_structure": bool(getattr(zone, "removes_structure", False)),
        "removes_structure_type": getattr(zone, "removes_structure_type", None),
        "selected_as_nearest_sz": selected,
    }


@dataclass(frozen=True)
class LayerInput:
    label: str
    timeframe: TF
    path: Path


def _analyse_layer(item: LayerInput, cutoff: datetime) -> list[dict[str, Any]]:
    df, violation_df = load_preprocess_data(str(item.path), cutoff)
    if df.empty:
        raise RuntimeError(f"no candles at or before cutoff in {item.path}")
    cs = _series(df)
    violation_cs = _series(violation_df)
    detector = ZoneDetector(Config())
    qualifier = ZoneQualifier(Config())

    # Formed candidates as the engine sees them today.
    normal = detector.detect("GOLDM", item.timeframe, cs)
    # Diagnostic-only candidate view before the daily-or-higher §4.6 filter.
    pre_shape = detector.detect("GOLDM", item.timeframe, _series(df, shape_bypass=True))
    normal_keys = {_zone_key(zone) for zone in normal}
    rows: list[dict[str, Any]] = []
    cmp = float(cs.cmp)

    for zone in pre_shape:
        if not zone.is_sell_zone:
            continue
        if _zone_key(zone) not in normal_keys:
            rows.append(_row(
                zone, layer=item.label, event="REJECTED_BEFORE_FORMED_ZONE",
                reason="SHAPE_FILTER_4_6", cmp=cmp, source_file=item.path,
                cutoff=cutoff, shape_filter_result="REJECTED", cs=cs,
            ))

    for zone in normal:
        if not zone.is_sell_zone:
            continue
        qualifier.update_violation(violation_cs, zone)
        qualifier.update_retest(violation_cs, zone)
        # This mirrors process_trend_zones.  It records Check-5's output but
        # does not treat the result as a rejection because production does not.
        qualifier.compute_structure_removal(violation_cs, zone, None)
        if zone.invalidated or zone.state == ZoneState.RED:
            event, reason = "INVALIDATED", zone.block_reason or "INVALIDATED"
        elif zone.distal <= cmp:
            event, reason = "PROXIMITY_EXCLUDED", "NOT_OVERHEAD_OF_CMP"
        else:
            event, reason = "FORMED_SURVIVES", None
        rows.append(_row(
            zone, layer=item.label, event=event, reason=reason, cmp=cmp,
            source_file=item.path, cutoff=cutoff,
            shape_filter_result="RETAINED", cs=cs,
        ))

    # Re-run the production wrapper to obtain the exact E/A candidate list and
    # nearest selection.  The lifecycle rows above are intentionally richer;
    # this second call avoids approximating any post-qualification ordering.
    production_zones, _ = process_trend_zones(str(item.path), item.timeframe, cutoff, for_frps=False)
    selected_zone = TrendEngine(TrendConfig()).find_nearest_sz(production_zones, cmp)
    selected_key = _zone_key(selected_zone) if selected_zone is not None else None
    for row in rows:
        row_key = (
            row["zone_type"], row["base_start"], row["base_end"], row["departure_idx"],
            round(float(row["distal"]), 8), round(float(row["proximal"]), 8),
        )
        if selected_key is not None and row_key == selected_key:
            row["selected_as_nearest_sz"] = True
            if row["candidate_event"] == "FORMED_SURVIVES":
                row["candidate_event"] = "NEAREST_SZ_SELECTED"
    return rows


def run_diagnostic(
    *,
    cutoff: datetime,
    data_dir: Path,
    expiry: str,
    e_source: Path | None = None,
    a_source: Path | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run one point-in-time lifecycle audit.

    ``e_source`` and ``a_source`` make an audit reproducible when the evidence
    package preserves E/A candles in separate immutable locations.  They are
    diagnostic inputs only; production data routing remains untouched.
    """
    layers = [
        LayerInput("E", TF.E, e_source or data_dir / f"GOLDM_{expiry}_daily.csv"),
        LayerInput("A", TF.A, a_source or data_dir / f"GOLDM_{expiry}_two_forty.csv"),
    ]
    missing = [str(item.path) for item in layers if not item.path.is_file()]
    if missing:
        raise FileNotFoundError("missing required diagnostic input(s): " + ", ".join(missing))
    rows = [row for item in layers for row in _analyse_layer(item, cutoff)]
    counts = Counter((row["layer"], row["candidate_event"], row["rejection_reason"] or "NONE") for row in rows)
    summary = {
        "instrument": "GOLDM",
        "expiry_file_key": expiry,
        "cutoff": cutoff.isoformat(),
        "rows": len(rows),
        "counts": [
            {"layer": layer, "event": event, "reason": reason, "count": count}
            for (layer, event, reason), count in sorted(counts.items())
        ],
        "method": "production ZoneDetector/ZoneQualifier/filter_buy_sell_zones_v2; diagnostic-only pre-shape comparison",
    }
    return rows, summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cutoff", default="2026-03-31 23:59:59")
    parser.add_argument("--expiry", default="04122026")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--e-source", type=Path, help="Explicit E-layer OHLC CSV for an evidence audit")
    parser.add_argument("--a-source", type=Path, help="Explicit A-layer OHLC CSV for an evidence audit")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "audit" / "trend_engine" / "results" / "goldm_mar2026_supply_diagnostic")
    args = parser.parse_args()
    rows, summary = run_diagnostic(
        cutoff=_parse_timestamp(args.cutoff), data_dir=args.data_dir, expiry=args.expiry,
        e_source=args.e_source, a_source=args.a_source,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    columns = list(rows[0]) if rows else ["instrument", "layer", "candidate_event", "rejection_reason"]
    with (args.output_dir / "supply_zone_lifecycle.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader(); writer.writerows(rows)
    (args.output_dir / "supply_zone_lifecycle_summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
