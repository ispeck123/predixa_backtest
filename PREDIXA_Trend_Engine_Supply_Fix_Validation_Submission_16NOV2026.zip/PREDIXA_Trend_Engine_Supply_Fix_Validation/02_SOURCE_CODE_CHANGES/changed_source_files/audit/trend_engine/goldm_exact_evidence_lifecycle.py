"""Rebuild E/A lifecycle evidence for every persisted GOLDM anomaly task.

The input cohort is immutable evidence.  This tool only reads it and the
explicit E/A OHLC sources, then calls the shared production diagnostic.  It
does not create a replay database, submit orders, or mutate any market-data
file.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audit.trend_engine.goldm_supply_diagnostic import run_diagnostic


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", required=True, type=Path)
    parser.add_argument("--e-source", required=True, type=Path)
    parser.add_argument("--a-source", required=True, type=Path)
    parser.add_argument("--expiry", default="04122026")
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args(argv)

    cohort = pd.read_csv(args.cohort)
    required = {"task_id", "evaluation_timestamp"}
    missing = required.difference(cohort.columns)
    if missing:
        raise ValueError(f"cohort missing required columns: {sorted(missing)}")
    if not args.e_source.is_file() or not args.a_source.is_file():
        raise FileNotFoundError("both explicit E/A source files must exist")
    if args.output_dir.exists():
        raise FileExistsError(f"refusing to overwrite existing output: {args.output_dir}")
    args.output_dir.mkdir(parents=True)

    by_timestamp = cohort.groupby("evaluation_timestamp", sort=True)["task_id"].apply(list)
    records: list[dict] = []
    summaries: list[dict] = []
    for timestamp, task_ids in by_timestamp.items():
        cutoff = pd.Timestamp(timestamp).to_pydatetime()
        rows, summary = run_diagnostic(
            cutoff=cutoff, data_dir=args.e_source.parent, expiry=args.expiry,
            e_source=args.e_source, a_source=args.a_source,
        )
        for row in rows:
            row["evaluation_timestamp"] = timestamp
            row["task_ids"] = json.dumps(task_ids)
            row["affected_tasks"] = len(task_ids)
            records.append(row)
        summaries.append({"evaluation_timestamp": timestamp, "affected_tasks": len(task_ids), **summary})

    columns = list(records[0]) if records else ["evaluation_timestamp", "task_ids"]
    with (args.output_dir / "supply_zone_lifecycle_all_tasks.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(records)
    (args.output_dir / "supply_zone_lifecycle_per_timestamp.json").write_text(
        json.dumps(summaries, indent=2, default=str) + "\n", encoding="utf-8"
    )
    counts = Counter((row["layer"], row["candidate_event"], row["rejection_reason"] or "NONE") for row in records)
    summary = {
        "cohort_tasks": int(len(cohort)),
        "unique_evaluation_timestamps": int(len(by_timestamp)),
        "lifecycle_rows": int(len(records)),
        "counts": [
            {"layer": layer, "event": event, "reason": reason, "count": count}
            for (layer, event, reason), count in sorted(counts.items())
        ],
        "e_source": str(args.e_source),
        "a_source": str(args.a_source),
        "method": "production ZoneDetector/ZoneQualifier with diagnostic-only pre-4.6 comparison",
    }
    (args.output_dir / "supply_zone_lifecycle_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
