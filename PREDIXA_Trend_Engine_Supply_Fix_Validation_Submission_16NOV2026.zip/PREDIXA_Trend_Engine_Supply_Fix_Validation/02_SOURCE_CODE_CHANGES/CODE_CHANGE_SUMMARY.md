# Code change summary

Tracked diffs from available HEAD touch `scripts/models.py`, `scripts/trade_engine.py`, and `scripts/trend_engine.py`. New work-order utilities are the lifecycle diagnostic and paired replay runner; two focused regression test files cover Rule-C membership and the §4.6 supply exception. The supply correction is default-off and narrowly preserves a single inverted-hammer supply zone as trend context. Current trend-engine diff also includes the previously implemented default-off Rule-C membership logic; it did not make the 99-case cohort flip regimes.
