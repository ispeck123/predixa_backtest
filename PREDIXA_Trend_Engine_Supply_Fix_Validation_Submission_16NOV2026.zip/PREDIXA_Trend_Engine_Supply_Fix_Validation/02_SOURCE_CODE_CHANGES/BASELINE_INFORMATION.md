# Baseline information

Available repository HEAD at packaging: `278691d2307f9245982604ae721e4d8552ff46cb`; branch `prod`; HEAD date `2026-11-06T14:58:46+05:30`. This is the parent against which scoped tracked diffs were generated, not a proven pre-remediation baseline. The worktree has extensive unrelated dirty changes; they are excluded. The archive therefore does not claim a canonical historical implementation delta beyond the scoped diff against this available HEAD.
