Included evidence is limited to the GOLDM supply lifecycle and paired cohort replay. No downstream NSEFO golden-set output was found for this work-order sequence.
