# Regression status

Focused suite passed 41 tests with five existing deprecation warnings. Broader cross-market regression validation in the work order sequence is not run, gated on GOLDM acceptance.
