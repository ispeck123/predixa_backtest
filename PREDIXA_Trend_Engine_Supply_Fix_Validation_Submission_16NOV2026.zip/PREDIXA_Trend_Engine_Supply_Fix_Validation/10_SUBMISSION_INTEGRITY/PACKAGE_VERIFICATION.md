# Package verification

The archive is generated from a staged allowlist, not a repository-wide copy. The workbook, selected sources/tests, and required evidence were checked for presence. SHA-256 values cover every staged file except the manifest itself; excluding the manifest avoids recursive hashing. Verify with `sha256sum` after extraction by matching the CSV manifest. ZIP CRC and extracted hashes are checked by the build process.
