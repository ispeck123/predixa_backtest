# GOLDM acceptance

99 distinct persisted cohort task IDs are represented in both modes (198 rows). Legacy: 99 permitted longs, 99 UP/UP. Flagged: 99 permitted longs, still 99 UP/UP; A nearest supply is populated for 23. Supply candidate restoration, nearest supply selection, regime emission, and setup blocking are separate outcomes. Acceptance: FAIL.
