# Data provenance and limitations

Evidence archive SHA256: `befcefa77f1ebf178c958cb18803f2b727768f2651c284df37495efba2178c35`; package checksums verified. 8,761 archived X/60 candle records match supplied current X/60 data exactly. Supplied daily/weekly zone anchors were functionally compared; archived weekly file hash is unavailable. Therefore this paired replay is not byte-identical to original source inputs.
