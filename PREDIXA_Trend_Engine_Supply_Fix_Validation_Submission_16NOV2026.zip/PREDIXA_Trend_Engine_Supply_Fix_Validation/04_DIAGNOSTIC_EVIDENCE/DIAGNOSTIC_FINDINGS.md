# Diagnostic findings

The relevant A supply `GOLDM_A_SZ_2088` (162,463/160,250) is rejected before formation by `SHAPE_FILTER_4_6`; its base is an inverted hammer (close position 5.29%, upper wick 61.05%). It was not structure-removed, invalidated, or retest-expired at rejection. Full lifecycle counts and source caveats are in the adjacent root-cause report and CSV.
