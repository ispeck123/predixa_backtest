# GOLDM March-2026 supply lifecycle and acceptance result — 16 Nov 2026

## Objective

Evaluate the supplied 99-loss GOLDM evidence package with the supplied
backtest OHLC sources, identify the first evidence-backed supply-zone removal,
and perform the required default-off / feature-flagged controlled check.  This
is diagnostic research only.  It does not start a scanner, write an order,
change a permission, or enable MCX PAPER or REAL.

## Evidence and reproducibility

The evidence archive is
`goldm_march_2026_buy_loss_engine_evidence_a0639146_20261113.zip`.

| Check | Result |
|---|---|
| Archive SHA-256 | `befcefa77f1ebf178c958cb18803f2b727768f2651c284df37495efba2178c35` |
| ZIP CRC | PASS |
| Supplied package checksums | PASS (20/20) |
| Persisted cohort | 99 GOLDM TF2 BUY losses, all `-1.0R` |
| E/A labels in evidence | `UP` / `UP` for 99/99 |
| Exact X/60 OHLCV check against supplied backtest source | 8,761/8,761 evidence candles match exactly |
| E weekly and A daily functional zone anchors | Match the archived E/A nearest-demand-zone values at the first task |

The source-file package hashes differ from the currently supplied complete
files.  The matching candle and zone anchors make this a point-in-time
functional reproduction, not a byte-for-byte source-file identity claim.

## E/A lifecycle dump

Machine-readable lifecycle data is retained in
`supply_zone_lifecycle_all_tasks.csv` and
`supply_zone_lifecycle_per_timestamp.json`.  It covers all 99 persisted
evaluation timestamps and has 16,259 supply-candidate lifecycle rows.

| Layer | Lifecycle event | Reason | Count |
|---|---|---|---:|
| A | Invalidated | `INVALIDATED_WICK_BEYOND_DISTAL` | 12,474 |
| A | Rejected before formed zone | `SHAPE_FILTER_4_6` | 2,003 |
| E | Invalidated | `INVALIDATED_WICK_BEYOND_DISTAL` | 1,584 |
| E | Rejected before formed zone | `SHAPE_FILTER_4_6` | 198 |

The directly relevant overhead candidate is `GOLDM_A_SZ_2088`.  It occurs in
23 cohort evaluations (16–17 March) and overlaps the reported overhead-supply
area.

| Field | Evidence |
|---|---|
| Layer / type | A / SZ |
| Distal / proximal | 162,463 / 160,250 |
| Base candle | O 161,112; H 162,463; L 160,250; C 160,367 |
| Shape | Single inverted hammer |
| First lifecycle failure | `REJECTED_BEFORE_FORMED_ZONE` |
| Rejection reason | `SHAPE_FILTER_4_6` |
| Structure removal | false |
| Invalidation at rejection | false |
| Retests at rejection | 0 |

The candle has close position 5.29% of range and upper wick 61.05% of range,
so it meets the legacy single-inverted-hammer filter.  Therefore the first
confirmed reason this relevant supply disappears is §4.6, not Check-5,
invalidation, retest exhaustion, or nearest-zone selection.

## Implemented minimal correction

`PREDIXA_TREND_SUPPLY_FIX_ENABLED` is default-off.  When explicitly enabled,
the daily-or-higher §4.6 filter retains only a *supply* single inverted-hammer
candidate as supply trend context.  It does not disable doji filtering, modify
demand-zone handling, alter normal hammer filtering, or change a strategy,
target, entry, risk/reward, or execution rule.

The focused regression verifies both conditions:

1. legacy mode rejects `GOLDM_A_SZ_2088`; and
2. flagged mode retains it at 162,463 / 160,250 while demand-zone identities
   remain unchanged.

## Hard acceptance check

The controlled full W-D-60 pipeline was evaluated for all 99 original cohort
timestamps against the supplied functional candle sources.

| Mode | E/A label | A `nearest_sz` populated | Permitted long setups | Result |
|---|---|---:|---:|---|
| Legacy flag OFF | UP / UP for 99/99 | 0 | 99/99 | baseline reproduced |
| Supply flag ON | UP / UP for 99/99 | 23 | 99/99 | every long remains permitted |

Thus the feature-flagged supply restoration works, but it is **not an
acceptable candidate fix**: all 99 original cohort tasks remain permitted
longs in the functionally anchored controlled replay.  The supplied backtest
directory does not contain the archived weekly file hash, so this is not
represented as a byte-identical formal hard-gate verdict.  It is, however,
enough to prevent a PASS and to stop before NSEFO golden-set comparison,
cross-market validation, or any activation.

The full reproducibility table is `legacy_vs_flagged_replay.csv` (198 rows:
99 legacy plus 99 flagged).  It records all 99 flag-on long setups and their
unchanged UP/UP E/A labels; it is the basis for the aggregate above.

## Separate execution finding

The evidence package shows every cohort entry was delayed from its evaluation
by at least 42 hours (maximum 296 hours; 78 later than 72 hours).  That is a
separate stale pending-order/lifetime issue.  It must not be silently fixed by
or attributed to the supply detector correction.

## Status and next action

**Root cause of the missing relevant A supply: CONFIRMED.**

**Supply-only correction: IMPLEMENTED and regression-tested, default OFF.**

**GOLDM hard acceptance: NOT ACCEPTED — all 99 retained their permitted-long
status after the narrow correction; the byte-identical archived weekly input
is also still missing.**

Before changing Rule C or any order-lifetime policy, the owner/methodology
owner must identify the documented expected outcome when a valid overhead
supply coexists with the selected demand zone.  The next engineering step is
then a separately scoped, evidence-backed Rule-C or pending-order-lifetime
investigation; it must not be bundled into this supply formation fix.

MCX PAPER remains OFF.  MCX REAL remains OFF.
