# Compilation

Command: finpro `python -m py_compile` on models, trade/trend engines and three diagnostic utilities. Exit 0.

```text

```
