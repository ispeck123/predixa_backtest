# Diff check

Command: `git diff --check`; exit 0.

```text

```
