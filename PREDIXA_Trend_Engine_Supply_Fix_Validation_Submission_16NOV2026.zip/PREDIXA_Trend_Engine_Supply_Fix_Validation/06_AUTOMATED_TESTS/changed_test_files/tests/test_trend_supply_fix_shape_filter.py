from datetime import datetime
from pathlib import Path

from scripts.models import CandleSeries, Config, TF, load_preprocess_data
from scripts.trade_engine import ZoneDetector


DATA = Path("data/indian_commodity_backtest_data/fyers_continuous_from_2017/latest_data_csv/GOLDM_04122026_daily.csv")
CUTOFF = datetime.fromisoformat("2026-03-16T09:00:00")
EXPECTED_ZONE_ID = "GOLDM_A_SZ_2088"


def _series() -> CandleSeries:
    frame, _ = load_preprocess_data(str(DATA), CUTOFF)
    return CandleSeries(
        o=frame["open"].tolist(), h=frame["high"].tolist(),
        l=frame["low"].tolist(), c=frame["close"].tolist(),
        ts=frame["unix_timestamp"].tolist(),
    )


def test_flagged_supply_inverted_hammer_is_retained_for_htf_context(monkeypatch):
    """Regression for the archived GOLDM March-2026 A-layer supply candidate."""
    assert DATA.is_file(), f"missing checked-in backtest evidence: {DATA}"
    series = _series()

    monkeypatch.delenv("PREDIXA_TREND_SUPPLY_FIX_ENABLED", raising=False)
    legacy = ZoneDetector(Config()).detect("GOLDM", TF.A, series)
    assert EXPECTED_ZONE_ID not in {zone.zone_id for zone in legacy}

    monkeypatch.setenv("PREDIXA_TREND_SUPPLY_FIX_ENABLED", "1")
    corrected = ZoneDetector(Config()).detect("GOLDM", TF.A, series)
    matching = [zone for zone in corrected if zone.zone_id == EXPECTED_ZONE_ID]
    assert len(matching) == 1
    zone = matching[0]
    assert zone.is_sell_zone
    assert (zone.distal, zone.proximal) == (162463.0, 160250.0)


def test_flag_does_not_restore_demand_hammer_candidates(monkeypatch):
    """The change is supply-side only; demand-side rejection remains legacy."""
    assert DATA.is_file(), f"missing checked-in backtest evidence: {DATA}"
    series = _series()
    monkeypatch.delenv("PREDIXA_TREND_SUPPLY_FIX_ENABLED", raising=False)
    legacy = ZoneDetector(Config()).detect("GOLDM", TF.A, series)
    monkeypatch.setenv("PREDIXA_TREND_SUPPLY_FIX_ENABLED", "1")
    corrected = ZoneDetector(Config()).detect("GOLDM", TF.A, series)
    assert {zone.zone_id for zone in corrected if zone.is_buy_zone} == {
        zone.zone_id for zone in legacy if zone.is_buy_zone
    }
