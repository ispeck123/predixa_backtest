import pandas as pd

from scripts.trend_engine import Config, TF, TrendEngine, Zone, ZoneType


def zone(*, side=ZoneType.SZ, tf=TF.E, distal=120.0, proximal=110.0, penetration=0.0, retests=0):
    return Zone(
        symbol="TEST", tf=tf, ztype=side, distal=distal, proximal=proximal,
        created_idx=2, base_start=1, base_end=2, base_len=2,
        penetration_pct=penetration, retest_count=retests,
    )


def engine(enabled: bool) -> TrendEngine:
    return TrendEngine(Config(trend_supply_fix_enabled=enabled))


def test_rule_c_membership_is_legacy_noop_when_flag_is_off():
    candidate = zone(distal=1_000.0, proximal=990.0, penetration=99.0, retests=99)
    assert engine(False).rule_c_membership_reason(candidate, cmp=100.0, atr14=1.0) is None


def test_rule_c_membership_uses_ten_atr_boundary_inclusively():
    # 120 is exactly 10 * ATR above CMP and remains a member.
    assert engine(True).rule_c_membership_reason(zone(distal=120.0, proximal=115.0), cmp=100.0, atr14=2.0) is None
    assert engine(True).rule_c_membership_reason(zone(distal=125.0, proximal=120.01), cmp=100.0, atr14=2.0) == "DISTANCE_GT_10_ATR"


def test_rule_c_membership_rejects_25_percent_penetration_and_excess_retests():
    assert engine(True).rule_c_membership_reason(zone(penetration=25.0), cmp=100.0, atr14=2.0) == "PENETRATION_GTE_25_PCT"
    assert engine(True).rule_c_membership_reason(zone(retests=3), cmp=100.0, atr14=2.0) == "RETEST_LIMIT_EXCEEDED"
    assert engine(True).rule_c_membership_reason(zone(tf=TF.X, retests=1), cmp=100.0, atr14=2.0) == "RETEST_LIMIT_EXCEEDED"


def test_flagged_calculation_reselects_members_before_rule_b_or_rule_c():
    frame = pd.DataFrame({
        "open": [100.0] * 20,
        "high": [102.0] * 20,
        "low": [98.0] * 20,
        "close": [100.0] * 20,
    })
    bz = zone(side=ZoneType.BZ, distal=90.0, proximal=95.0)
    far_sz = zone(side=ZoneType.SZ, distal=151.0, proximal=141.0)
    result = engine(True).calculate_trend(
        TF.E, frame, bz, far_sz, {"BUY": [bz], "SELL": [far_sz]},
    )
    # The 25-ATR supply cannot participate when the repair flag is enabled;
    # selection consequently follows the existing Rule-B behaviour for BZ-only.
    assert result.nearest_sz is None
    assert result.rule_applied == "Rule B (Only BZ)"
    legacy = engine(False).calculate_trend(
        TF.E, frame, bz, far_sz, {"BUY": [bz], "SELL": [far_sz]},
    )
    assert legacy.nearest_sz is far_sz


def test_atr_is_calculated_from_the_layer_frame_only():
    frame = pd.DataFrame({
        "high": [101.0] * 14 + [104.0],
        "low": [99.0] * 14 + [100.0],
        "close": [100.0] * 15,
    })
    assert engine(True)._atr14_from_frame(frame, 14) > 0
