# Test execution

Command: `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_trend_supply_fix_membership.py tests/test_trend_supply_fix_shape_filter.py tests/test_mcx_e1_session_boundary.py tests/test_consumed_zone_dedup.py tests/trend_engine_audit`

Exit 0.

```text
.........................................                                [100%]
=============================== warnings summary ===============================
shared/db/db_model.py:6
  /home/ispeck/STOCK_PROJECT/STP_LATEST/shared/db/db_model.py:6: MovedIn20Warning: The ``declarative_base()`` function is now available as sqlalchemy.orm.declarative_base(). (deprecated since: 2.0) (Background on SQLAlchemy 2.0 at: https://sqlalche.me/e/b8d9)
    Base = declarative_base()

../../anaconda3/envs/finpro/lib/python3.13/site-packages/pydantic/fields.py:1093
../../anaconda3/envs/finpro/lib/python3.13/site-packages/pydantic/fields.py:1093
  /home/ispeck/anaconda3/envs/finpro/lib/python3.13/site-packages/pydantic/fields.py:1093: PydanticDeprecatedSince20: Using extra keyword arguments on `Field` is deprecated and will be removed. Use `json_schema_extra` instead. (Extra keys: 'example'). Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.11/migration/
    warn(

shared/db/fyers_req_model.py:363
  /home/ispeck/STOCK_PROJECT/STP_LATEST/shared/db/fyers_req_model.py:363: PydanticDeprecatedSince20: Pydantic V1 style `@validator` validators are deprecated. You should migrate to Pydantic V2 style `@field_validator` validators, see the migration guide for more details. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.11/migration/
    @validator("target", "stoploss", "entry", pre=True)

shared/db/fyers_req_model.py:389
  /home/ispeck/STOCK_PROJECT/STP_LATEST/shared/db/fyers_req_model.py:389: PydanticDeprecatedSince20: Pydantic V1 style `@validator` validators are deprecated. You should migrate to Pydantic V2 style `@field_validator` validators, see the migration guide for more details. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.11/migration/
    @validator("orderId", "bucket_id", pre=True)

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
41 passed, 5 warnings in 0.61s

```

Python: `Python 3.13.5` (pytest invoked through `finpro`). The run reported 41 passed, 5 deprecation warnings, no failures/skips.
