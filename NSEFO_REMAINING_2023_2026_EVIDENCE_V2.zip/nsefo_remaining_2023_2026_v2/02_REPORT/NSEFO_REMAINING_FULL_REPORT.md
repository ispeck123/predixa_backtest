# NSEFO Remaining-Universe Historical Backtest and Tuning Report

## 1. Executive summary

Run `bb0029a3fd5a4ace8243837bca6f0940` is a completed current-production NSEFO near-expiry replay for the available remainder of the configured universe. It is **BASELINE_ONLY**: no tuning manifest or candidate override runs were found. The supported decision is **NO_LOCK_INCOMPLETE_SWEEP**; no parameter lock or C7/C8 sign-off is supported.

The run contains 734,510 registered tasks, 722,211 completed tasks, 12,299 failed tasks, 722,211 scans, 241,687 signals, 250,497 eligible setup records, 216,709 entered trades, and 214,886 resolved WIN/LOSS trades.

## 2. Scope and work-order compliance

- Configured remainder: 158 symbols; available and replayed: 152 symbols.
- Missing from the available data inventory: DALBHARAT, EXIDEIND, HUDCO, SYNGENE, TATATECH, TORNTPOWER.
- Expiry: near expiry `27102026` only.
- TF1: monthly / weekly / daily.
- TF25: weekly / daily / seventy_five.
- Historical request: `2023-01-01` through `2026-10-22`.
- Persisted replay mode: two-sided (`buy_only=false`).
- Tuning decision cut: BUY-only metrics; SELL trades remain in raw evidence.

## 3. Production-code non-modification statement

No production files under `scripts/` were modified for this report. No live Config defaults, raw market data, or completed SQLite results were changed. This package was generated from the centralized database and audit-only analysis outputs.

## 4. Universe, TF mapping, and coverage

The exact per-symbol/per-TF coverage is in `04_DATA_QUALITY/source_coverage_by_symbol_tf.csv`.

```text
    symbol               start                 end  complete
       ABB 2022-01-28T05:30:00 2026-10-22T14:30:00      True
 ABCAPITAL 2021-12-31T05:30:00 2026-10-22T14:30:00      True
ADANIENSOL 2024-11-29T05:30:00 2026-10-22T14:00:00      True
ADANIGREEN 2024-11-29T05:30:00 2026-10-22T14:00:00      True
ADANIPORTS 2020-01-01T05:30:00 2026-10-22T14:15:00      True
     ALKEM 2021-02-26T05:30:00 2026-10-22T14:30:00      True
 AMBUJACEM 2020-01-01T05:30:00 2026-10-22T13:45:00      True
  ANGELONE 2024-11-29T05:30:00 2026-10-22T13:30:00      True
 APLAPOLLO 2024-11-29T05:30:00 2026-10-22T14:00:00      True
APOLLOHOSP 2020-01-01T05:30:00 2026-10-22T14:30:00      True
  ASHOKLEY 2020-01-01T05:30:00 2026-10-22T14:30:00      True
ASIANPAINT 2020-01-01T05:30:00 2026-10-22T13:45:00      True
    ASTRAL 2021-07-30T05:30:00 2026-10-22T14:15:00      True
    AUBANK 2021-02-26T05:30:00 2026-10-22T14:30:00      True
AUROPHARMA 2020-01-01T05:30:00 2026-10-22T14:15:00      True
BAJAJ-AUTO 2020-01-01T05:30:00 2026-10-22T14:30:00      True
BAJAJFINSV 2020-01-01T05:30:00 2026-10-22T14:00:00      True
BANDHANBNK 2020-02-28T05:30:00 2026-10-22T14:00:00      True
BANKBARODA 2020-01-01T05:30:00 2026-10-22T14:00:00      True
 BANKINDIA 2024-11-29T05:30:00 2026-10-22T14:00:00      True
       BEL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
BHARATFORG 2020-01-01T05:30:00 2026-10-22T13:45:00      True
    BIOCON 2020-01-01T05:30:00 2026-10-22T14:15:00      True
  BOSCHLTD 2020-01-01T05:30:00 2026-10-22T13:45:00      True
      BPCL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
 BRITANNIA 2020-01-01T05:30:00 2026-10-22T14:30:00      True
      CAMS 2024-11-29T05:30:00 2026-10-22T14:00:00      True
     CANBK 2020-01-01T05:30:00 2026-10-22T14:15:00      True
      CDSL 2024-11-29T05:30:00 2026-10-22T14:00:00      True
   CGPOWER 2024-11-29T05:30:00 2026-10-22T14:00:00      True
  CHOLAFIN 2020-01-01T05:30:00 2026-10-22T14:00:00      True
     CIPLA 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 COALINDIA 2020-01-01T05:30:00 2026-10-22T13:30:00      True
   COFORGE 2020-08-20T05:30:00 2026-10-22T14:15:00      True
    COLPAL 2020-01-01T05:30:00 2026-10-22T14:15:00      True
    CONCOR 2020-01-01T05:30:00 2026-10-22T14:30:00      True
  CROMPTON 2021-10-01T05:30:00 2026-10-22T14:15:00      True
CUMMINSIND 2020-01-01T05:30:00 2026-10-22T14:30:00      True
     DABUR 2020-01-01T05:30:00 2026-10-22T13:30:00      True
 DELHIVERY 2024-11-29T05:30:00 2026-10-22T14:00:00      True
  DIVISLAB 2020-01-01T05:30:00 2026-10-22T13:30:00      True
     DIXON 2021-08-27T05:30:00 2026-10-22T14:30:00      True
       DLF 2020-01-01T05:30:00 2026-10-22T14:30:00      True
     DMART 2024-11-29T05:30:00 2026-10-22T14:00:00      True
   DRREDDY 2020-01-01T05:30:00 2026-10-22T14:00:00      True
 EICHERMOT 2020-01-01T05:30:00 2026-10-22T14:00:00      True
      GAIL 2020-01-01T05:30:00 2026-10-22T13:45:00      True
  GLENMARK 2020-01-01T05:30:00 2026-10-22T14:00:00      True
GMRAIRPORT 2024-12-11T05:30:00 2026-10-22T14:00:00      True
  GODREJCP 2020-01-01T05:30:00 2026-10-22T13:45:00      True
GODREJPROP 2020-03-27T05:30:00 2026-10-22T13:45:00      True
    GRASIM 2020-01-01T05:30:00 2026-10-22T13:30:00      True
       HAL 2021-08-27T05:30:00 2026-10-22T14:15:00      True
   HAVELLS 2020-01-01T05:30:00 2026-10-22T14:30:00      True
   HDFCAMC 2021-01-01T05:30:00 2026-10-22T14:00:00      True
  HDFCLIFE 2020-02-28T05:30:00 2026-10-22T13:30:00      True
HEROMOTOCO 2020-01-01T05:30:00 2026-10-22T14:15:00      True
 HINDPETRO 2020-01-01T05:30:00 2026-10-22T14:00:00      True
HINDUNILVR 2020-01-01T05:30:00 2026-10-22T14:30:00      True
  HINDZINC 2025-03-28T05:30:00 2026-10-22T14:00:00      True
   ICICIGI 2020-10-30T05:30:00 2026-10-22T13:45:00      True
ICICIPRULI 2020-01-01T05:30:00 2026-10-22T13:30:00      True
      IDEA 2020-01-01T05:30:00 2026-10-22T13:45:00      True
IDFCFIRSTB 2020-01-01T05:30:00 2026-10-22T13:30:00      True
       IEX 2021-08-27T05:30:00 2026-10-22T14:15:00      True
  INDHOTEL 2021-06-25T05:30:00 2026-10-22T14:15:00      True
   INDIANB 2024-11-29T05:30:00 2026-10-22T14:00:00      True
    INDIGO 2020-01-01T05:30:00 2026-10-22T14:00:00      True
INDUSINDBK 2020-01-01T05:30:00 2026-10-22T14:30:00      True
INDUSTOWER 2020-12-18T05:30:00 2026-10-22T13:45:00      True
  INOXWIND 2025-03-28T05:30:00 2026-10-22T14:00:00      True
       IOC 2020-01-01T05:30:00 2026-10-22T14:00:00      True
     IREDA 2025-02-28T05:30:00 2026-10-22T14:00:00      True
      IRFC 2024-11-29T05:30:00 2026-10-22T14:00:00      True
JINDALSTEL 2020-01-01T05:30:00 2026-10-22T13:30:00      True
    JIOFIN 2024-11-29T05:30:00 2026-10-22T14:00:00      True
 JSWENERGY 2024-11-29T05:30:00 2026-10-22T14:00:00      True
  JSWSTEEL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
  JUBLFOOD 2020-01-01T05:30:00 2026-10-22T13:30:00      True
KALYANKJIL 2024-11-29T05:30:00 2026-10-22T14:00:00      True
       KEI 2024-11-29T05:30:00 2026-10-22T14:00:00      True
  KPITTECH 2024-11-29T05:30:00 2026-10-22T14:00:00      True
 LICHSGFIN 2020-01-01T05:30:00 2026-10-22T14:30:00      True
      LICI 2024-11-29T05:30:00 2026-10-22T14:00:00      True
     LODHA 2024-11-29T05:30:00 2026-10-22T14:00:00      True
       LTF 2024-04-23T05:30:00 2026-10-22T14:30:00      True
     LUPIN 2020-01-01T05:30:00 2026-10-22T13:30:00      True
       M&M 2020-01-01T05:30:00 2026-10-22T13:45:00      True
MANAPPURAM 2020-01-01T05:30:00 2026-10-22T13:45:00      True
    MARICO 2020-01-01T05:30:00 2026-10-22T13:30:00      True
    MARUTI 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 MAXHEALTH 2024-11-29T05:30:00 2026-10-22T14:00:00      True
       MCX 2021-08-27T05:30:00 2026-10-22T14:30:00      True
      MFSL 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 MOTHERSON 2020-01-01T05:30:00 2026-10-22T13:45:00      True
   MPHASIS 2021-02-26T05:30:00 2026-10-22T14:15:00      True
MUTHOOTFIN 2020-01-01T05:30:00 2026-10-22T13:45:00      True
NATIONALUM 2020-01-01T05:30:00 2026-10-22T14:15:00      True
    NAUKRI 2020-02-28T05:30:00 2026-10-22T13:45:00      True
      NBCC 2025-01-31T05:30:00 2026-10-22T14:00:00      True
 NESTLEIND 2020-01-01T05:30:00 2026-10-22T14:30:00      True
      NHPC 2024-11-29T05:30:00 2026-10-22T14:00:00      True
NIFTYNXT50 2024-04-24T05:30:00 2026-10-22T14:00:00      True
      NMDC 2020-01-01T05:30:00 2026-10-22T14:15:00      True
      NTPC 2020-01-01T05:30:00 2026-10-22T14:00:00      True
     NYKAA 2024-11-29T05:30:00 2026-10-22T14:00:00      True
OBEROIRLTY 2021-10-01T05:30:00 2026-10-22T14:30:00      True
      OFSS 2021-08-27T05:30:00 2026-10-22T14:30:00      True
       OIL 2024-11-29T05:30:00 2026-10-22T14:00:00      True
      ONGC 2020-01-01T05:30:00 2026-10-22T14:00:00      True
   PAGEIND 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 PATANJALI 2025-02-28T05:30:00 2026-10-22T14:00:00      True
  PETRONET 2020-01-01T05:30:00 2026-10-22T14:30:00      True
       PFC 2020-01-01T05:30:00 2026-10-22T13:30:00      True
PHOENIXLTD 2025-01-31T05:30:00 2026-10-22T14:15:00      True
PIDILITIND 2020-01-01T05:30:00 2026-10-22T13:45:00      True
     PIIND 2021-02-26T05:30:00 2026-10-22T13:30:00      True
       PNB 2020-01-01T05:30:00 2026-10-22T13:30:00      True
PNBHOUSING 2025-03-28T05:30:00 2026-10-22T14:15:00      True
 POLICYBZR 2024-11-29T05:30:00 2026-10-22T14:00:00      True
 POWERGRID 2020-01-01T05:30:00 2026-10-22T14:00:00      True
  PRESTIGE 2024-11-29T05:30:00 2026-10-22T14:00:00      True
   RBLBANK 2020-01-01T05:30:00 2026-10-22T14:15:00      True
    RECLTD 2020-01-01T05:30:00 2026-10-22T14:15:00      True
      SAIL 2020-01-01T05:30:00 2026-10-22T14:30:00      True
   SBICARD 2021-10-29T05:30:00 2026-10-22T14:30:00      True
   SBILIFE 2020-05-04T05:30:00 2026-10-22T14:15:00      True
  SHREECEM 2020-01-01T05:30:00 2026-10-22T13:30:00      True
SHRIRAMFIN 2022-12-20T05:30:00 2026-10-22T13:30:00      True
   SIEMENS 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 SOLARINDS 2025-01-31T05:30:00 2026-10-22T14:00:00      True
  SONACOMS 2024-11-29T05:30:00 2026-10-22T14:00:00      True
       SRF 2020-01-01T05:30:00 2026-10-22T14:15:00      True
 SUNPHARMA 2020-01-01T05:30:00 2026-10-22T14:00:00      True
SUPREMEIND 2024-11-29T05:30:00 2026-10-22T14:00:00      True
TATACONSUM 2020-02-25T09:15:00 2026-10-22T14:15:00      True
 TATAELXSI 2024-11-29T05:30:00 2026-10-22T14:00:00      True
 TATAPOWER 2020-01-01T05:30:00 2026-10-22T14:15:00      True
   TIINDIA 2024-11-29T05:30:00 2026-10-22T14:00:00      True
     TITAN 2020-01-01T05:30:00 2026-10-22T13:30:00      True
TORNTPHARM 2020-01-01T05:30:00 2026-10-22T14:30:00      True
     TRENT 2021-02-26T05:30:00 2026-10-22T13:30:00      True
  TVSMOTOR 2020-01-01T05:30:00 2026-10-22T13:45:00      True
ULTRACEMCO 2020-01-01T05:30:00 2026-10-22T14:30:00      True
 UNIONBANK 2024-11-29T05:30:00 2026-10-22T14:00:00      True
  UNITDSPR 2024-06-07T05:30:00 2026-10-22T14:15:00      True
       UPL 2020-01-01T05:30:00 2026-10-22T14:30:00      True
       VBL 2024-11-29T05:30:00 2026-10-22T14:00:00      True
      VEDL 2020-01-01T05:30:00 2026-10-22T14:00:00      True
    VOLTAS 2020-01-01T05:30:00 2026-10-22T13:45:00      True
   YESBANK 2024-11-29T05:30:00 2026-10-22T14:00:00      True
 ZYDUSLIFE 2022-03-07T05:30:00 2026-10-22T13:30:00      True
```

## 5. Stitched-series and contract limitations

The source inventory is classified as `STITCHED_OR_CONTINUOUS`. The near-expiry key `27102026` is a calendar-inferred export label; it does not prove exchange-verified historical contract identity or exact roll timing. Historical continuity and contract-specific economics must therefore be interpreted conservatively.

## 6. Run inventory and completion evidence

| item | count |
|---|---:|
| registered tasks | 734,510 |
| completed tasks | 722,211 |
| failed tasks | 12,299 |
| scans | 722,211 |
| signals | 241,687 |
| eligible setup records | 250,497 |
| entered trades | 216,709 |
| resolved WIN/LOSS | 214,886 |
| unresolved/non-WIN-LOSS | 1,823 |

Scan timestamps range from `2023-01-02T05:30:00` to `2026-10-22T14:30:00`. Failure details are in `04_DATA_QUALITY/failure_summary.csv`; they include warm-up insufficiency and runtime/data edge cases. Failed tasks are not silently counted as successful evidence.

## 7. Decision cut and side treatment

The persisted replay was two-sided. The raw trade export includes both BUY and SELL records, with side counts in `04_DATA_QUALITY/side_summary.csv`. Tuning metrics use the required BUY-only cut and are stored separately from the raw two-sided evidence.

## 8. Baseline/control results

The persisted override configuration is `{}`. This is the production-default control/baseline, not a tuning candidate.

BUY-only pooled 0-bps/full-cost-paper results:

```text
partition      n  win_rate  M1_give_back_rate  M2_wick_out_rate  gross_R_mean  net_R_mean_full_cost  full_cost_mean_inr
       IS  73695    0.3199             0.5952            0.1158      0.342298              0.282464           19.567289
      OOS  72098    0.2738             0.5527            0.0816      0.147413              0.078386           22.043570
   POOLED 145793    0.2971             0.5735            0.1002      0.245923              0.181543           20.791867
```

Full per-cell IS/OOS metrics and 0/2/5 bps sensitivity are in `03_METRICS/tuning_metrics.csv`.

## 9. Embed and proximity sweep results

No EMBED or PROXIMITY candidate runs exist in the database, and no complete 36-run manifest was found. Therefore there is no baseline-versus-candidate comparison.

## 10. IS/OOS methodology

The analysis generated separate IS, OOS, and pooled partitions using a deterministic midpoint reported by the analysis command (`2025-04-07 09:15:00` for this run). The partition and cell definitions are preserved in the metrics CSV. Unequal source histories mean that symbol-level composition is not uniform across partitions.

## 11. M1, M2, gross-R, and cost methodology

M1 give-back, M2 wick-out, gross R, bps-only Net-R, and statutory audit-cost outputs are retained in the metrics CSV. The cost schedule is `FYERS_DERIVATIVES_2023_2026_V1`. Quantity mode is **PAPER_QTY_10** because no reviewed contract lot-size input was supplied. Full-cost paper Net-R is not actual contract-quantity economics and is not a complete OI-4 cost-stack implementation.

## 12. Parameter comparison and pass arithmetic

The work-order arithmetic cannot be applied. The required control plus candidate runs for IS and OOS do not exist. No claim can be made about 3pp M1/M2 reductions, pooled Net-R non-regression, cell regression limits, OOS sign preservation, or tie-break selection.

## 13. Decision and C7/C8 status

**NO_LOCK_INCOMPLETE_SWEEP** — baseline retained for audit use only.

- C7: **NOT SIGNED OFF**; no completed candidate comparison.
- C8: **NOT SIGNED OFF**; no complete sweep or production-lock evidence.

## 14. Test evidence

The core audit, tuning-adapter, cost-model, and derivatives tests passed (`13 passed`). The separate live-policy test collection was unavailable in this environment because a live-session dependency was not installed; this is an environment test gate, not a failure of the historical SQLite analysis.

## 15. Limitations

Limitations preventing a production lock are: baseline-only evidence; no candidate sweep; six configured remainder symbols absent from the available data; 12,299 failed tasks; unequal symbol history; stitched/calendar-inferred contract identity; unresolved trades; paper quantity economics; no complete OI-4 cost stack; and two-sided replay versus BUY-only tuning decision cut.

## 16. Reproducibility

Use `05_REPRODUCIBILITY/commands_executed.txt`. The analysis uses the existing SQLite database only and does not rerun production replay tasks. The database path and run ID are recorded in `06_RAW_EVIDENCE/README.md`.
