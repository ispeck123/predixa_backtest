SQLite source: `audit/nsefo_futures_backtest/storage/nsefo_remaining_available_2023_2026.sqlite`
Run ID: `bb0029a3fd5a4ace8243837bca6f0940`
The database is referenced, not copied into the ZIP.
