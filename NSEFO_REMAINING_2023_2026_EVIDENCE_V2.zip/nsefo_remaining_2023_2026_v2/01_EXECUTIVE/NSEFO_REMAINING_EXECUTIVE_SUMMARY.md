# NSEFO Remaining-Universe Executive Summary

**Decision: NO_LOCK_INCOMPLETE_SWEEP**

Run `bb0029a3fd5a4ace8243837bca6f0940` completed as a baseline-only near-expiry replay.

- Tasks/completed/failed: 734,510 / 722,211 / 12,299
- Scans/signals/eligible setups: 722,211 / 241,687 / 250,497
- Entered/resolved trades: 216,709 / 214,886
- Available symbols: 152 of configured remainder 158
- Missing symbols: DALBHARAT, EXIDEIND, HUDCO, SYNGENE, TATATECH, TORNTPOWER
- Expiry: `27102026`; TFs: 1 and 25
- Replay: two-sided; tuning analysis: BUY-only
- Quantity mode: `PAPER_QTY_10`
- Core tests: `13 passed`
- Production files modified: **NONE**

No candidate comparison, tuning lock, C7 sign-off, or C8 sign-off is supported.
