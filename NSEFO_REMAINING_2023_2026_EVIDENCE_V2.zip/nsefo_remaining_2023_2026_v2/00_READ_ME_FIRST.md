# NSEFO Remaining-Universe Evidence Package

This versioned package covers run `bb0029a3fd5a4ace8243837bca6f0940`. It is baseline-only and was generated from centralized SQLite results without replaying tasks. No production lock is recommended.
