# NSEFO TF2 60-minute evaluation

Latest completed full run containing TF2: `6737d85be9b94e0682d71adc646b692d` (`nsefo_provisional_expiry_aware_full_20261111`, completed 2026-11-11T14:51:01.433341+00:00). This was a combined TF2+TF4 execution. This package isolates TF2 by persisted `strategy_tf=2`; it is not a separate TF2-only replay.

- Period: 2024-10-01 to 2026-09-30
- Stack: W-D-60; 60-minute execute candles
- Workers: 30
- Research mode: `PROVISIONAL_EXPIRY_AWARE_NEAR_SLOT_ASSUMPTION`; gate bypass `True`
- Database integrity: `ok`; duplicate trade setups: 0

| Metric | TF2 result |
|---|---:|
| Tasks completed / failed | 57,145 / 2,884 of 60,029 |
| Signals | 17,093 |
| Trades | 4,369 (4,369 resolved; 0 unresolved) |
| Wins / losses / TIME_EXIT | 812 / 3,011 / 546 |
| Gross realized return | -209.742754R |
| Win rate | 18.5855% |
| Profit factor | 0.931968 |
| Sequential drawdown | -625.783166R |

The run uses FYERS continuous prices with an assumed historical NEAR-slot attribution. The pinned NSE expiry map is pending owner verification. Gross R is not net monetary P&L and does not include costs/slippage. The unfiltered TF2 baseline is included as context; it is not a controlled paired comparison. See detailed ledgers, failure counts, run config, and expiry evidence in the package.
