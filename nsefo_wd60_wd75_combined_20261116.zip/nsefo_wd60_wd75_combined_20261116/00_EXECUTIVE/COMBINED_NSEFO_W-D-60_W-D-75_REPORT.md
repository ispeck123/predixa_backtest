# Combined NSEFO W-D-60 and W-D-75 backtest report

## Scope
This submission combines the latest completed full expiry-aware evidence for TF2 `W-D-60` (60-minute candles) and TF25 `W-D-75` (75-minute candles). They are separate runs and are reported separately, not pooled into a single portfolio result. The TF2 evidence is isolated from a combined TF2+TF4 run by persisted `strategy_tf=2`; it is not a TF2-only execution.

| Measure | TF2 W-D-60 | TF25 W-D-75 |
|---|---:|---:|
| Run ID | 6737d85be9b94e0682d71adc646b692d | 81a868318d35408285309b1c1f9a7167 |
| Status | COMPLETED | COMPLETED |
| Period | 2024-10-01 to 2026-09-30 | 2024-10-01 to 2026-09-30 |
| Tasks completed / failed | 57,145 / 2,884 | 229,464 / 3,360 |
| Signals | 17,093 | 57,773 |
| Trades | 4,369 | 16,151 |
| Wins / losses / TIME_EXIT | 812 / 3,011 / 546 | 3,043 / 11,263 / 1,833 |
| Gross realized R | -209.742754 | -530.729181 |
| Win rate | 18.5855% | 18.8549% |
| Profit factor | 0.931968 | 0.953930 |
| Sequential drawdown | -625.783166R | -1,058.261580R |

## Findings
TF2 generated a negative gross realized result (-209.74R; PF 0.932). TF25 generated -530.73R gross realized (PF 0.954). These are independent stack outcomes; do not sum them into a combined portfolio curve. Both have task failures recorded in their included error summaries.

Both use the provisional expiry-aware NEAR-slot assumption on FYERS continuous data. The same NSEFO map SHA-256 is pinned; owner verification remains pending. Results are gross R, not net currency P&L, and omit costs/slippage. Runs were executed on different dates and their source views differ, so performance differences cannot be attributed solely to timeframe.

TF25 sample validation passed (1,425/1,425 tasks, zero sample errors, SQLite integrity `ok`, no sample cutoff or force-exit-date violations). The full TF25 validator encountered a trade entry with no same-day expiry-map observation (`ABCAPITAL`, 2025-02-01); full-run expiry compliance is therefore unresolved and is explicitly disclosed.
