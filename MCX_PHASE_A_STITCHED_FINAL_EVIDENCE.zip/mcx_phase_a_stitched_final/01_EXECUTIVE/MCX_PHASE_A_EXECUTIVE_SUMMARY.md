# MCX Phase-A Stitched-Series Backtest Executive Summary

## Scope

- Instruments: GOLDM, SILVER, SILVERM, CRUDEOILM, NATGASMINI.
- Period requested: 2025-09-01 to 2026-09-30.
- Production decision path: `process_setup_fc(..., is_future=False)`.
- Production files modified: **NONE**.
- Price source: approved stitched MCX series; contract labels are calendar-inferred rather than exchange-verified historical contract IDs.

## Replay completion

| status    |   count |
|:----------|--------:|
| COMPLETED |   31705 |
| FAILED    |    1285 |

|   scans |   signals |   eligible |
|--------:|----------:|-----------:|
|   31705 |      7415 |       7415 |

## Resolved outcomes

| outcome    |   trades |
|:-----------|---------:|
| LOSS       |     3541 |
| UNRESOLVED |       76 |
| WIN        |     1389 |

| side   |   trades |   wins |   losses |   win_pct |   avg_r |
|:-------|---------:|-------:|---------:|----------:|--------:|
| BUY    |     2586 |    966 |     1620 |    37.355 |  0.6324 |
| SELL   |     2344 |    423 |     1921 |    18.046 | -0.2618 |

## Evidence boundary

The package reports current-production decisions and historical OHLC path resolution. It does not establish net profitability after costs/slippage or exchange-verified expired-contract attribution. The 1,285 failed tasks are preserved in data-quality evidence: most were early-history production warm-up rejections, while 67 were source-boundary indexing failures concentrated in the supplied SILVER history. No completed observations were discarded.
