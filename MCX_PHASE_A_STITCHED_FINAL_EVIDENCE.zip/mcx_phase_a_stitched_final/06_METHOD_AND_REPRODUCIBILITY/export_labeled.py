"""Export resolved Phase-A trades with ordered path and exit counterfactuals.

The evaluator is audit-only.  Baseline fields are read from the production-path
replay; the breakeven and trailing fields are labelled counterfactuals and do
not alter a stored baseline outcome.
"""
from __future__ import annotations

import argparse
import sqlite3
from functools import lru_cache
from pathlib import Path

import pandas as pd

from .calendar_contracts import mcx_contract_live, nsefo_contract_live


@lru_cache(maxsize=128)
def _source_bars(root_text: str, source_symbol: str, frame: str) -> pd.DataFrame:
    underlying, expiry = source_symbol.rsplit("@", 1)
    path = Path(root_text) / f"{underlying}_{expiry}_{frame}.csv"
    df = pd.read_csv(path)
    col = "tradeDate" if "tradeDate" in df else "timestamp"
    df["timestamp"] = pd.to_datetime(df[col], dayfirst=True, errors="coerce")
    return df.dropna(subset=["timestamp"]).sort_values("timestamp", kind="stable").reset_index(drop=True)


def _future_bars(root: Path, source_symbol: str, frame: str, entry_timestamp: str) -> pd.DataFrame:
    df = _source_bars(str(root), source_symbol, frame)
    return df[df.timestamp > pd.Timestamp(entry_timestamp)].reset_index(drop=True)


def evaluate_path(side: str, entry: float, stop: float, target: float, bars: pd.DataFrame) -> tuple[dict, list[dict]]:
    """Evaluate baseline, +0.5R next-bar BE and a next-bar 0.5R trailing stop.

    All stop changes become effective on the following completed OHLC bar. This
    avoids inventing an intrabar ordering that the OHLC source cannot prove.
    """
    risk=abs(entry-stop); sign=1 if side == "BUY" else -1
    base_stop=stop; be_stop=stop; trail_stop=stop; be_armed=False; trail_armed=False
    result={"first_positive_bar":None,"first_negative_bar":None,"favorable_before_adverse":None,
            "baseline_path_outcome":None,"be05_outcome":None,"be05_r":None,"trail05_outcome":None,"trail05_r":None,
            "max_favorable_excursion":None,"max_adverse_excursion":None,"max_favorable_pct_of_target":None}
    path=[]; mfe=float("-inf");mae=float("inf")
    previous_ts=None
    for i,b in bars.iterrows():
        hi,lo=float(b.high),float(b.low)
        fav=(hi-entry) if sign==1 else (entry-lo); adv=(lo-entry) if sign==1 else (entry-hi)
        mfe=max(mfe,fav);mae=min(mae,adv)
        if fav>0 and result["first_positive_bar"] is None: result["first_positive_bar"]=int(i)
        if adv<0 and result["first_negative_bar"] is None: result["first_negative_bar"]=int(i)
        # Production-compatible target-first baseline convention.
        target_hit=(hi>=target) if sign==1 else (lo<=target)
        stop_hit=(lo<=base_stop) if sign==1 else (hi>=base_stop)
        if result["baseline_path_outcome"] is None and (target_hit or stop_hit): result["baseline_path_outcome"]="WIN" if target_hit else "LOSS"
        be_target=target_hit; be_hit=(lo<=be_stop) if sign==1 else (hi>=be_stop)
        if result["be05_outcome"] is None and (be_target or be_hit):
            price=target if be_target else be_stop; result["be05_outcome"]="WIN" if be_target else ("BREAKEVEN" if abs(price-entry)<1e-9 else "LOSS");result["be05_r"]=(price-entry)*sign/risk
        tr_target=target_hit; tr_hit=(lo<=trail_stop) if sign==1 else (hi>=trail_stop)
        if result["trail05_outcome"] is None and (tr_target or tr_hit):
            price=target if tr_target else trail_stop;result["trail05_outcome"]="WIN" if tr_target else ("BREAKEVEN" if abs(price-entry)<1e-9 else "LOSS");result["trail05_r"]=(price-entry)*sign/risk
        overnight=bool(previous_ts is not None and b.timestamp.date() != previous_ts.date())
        path.append({"bar_index":int(i),"timestamp":b.timestamp.isoformat(),"high":hi,"low":lo,"favorable_r":fav/risk,"adverse_r":adv/risk,"be_stop_active":be_stop,"trail_stop_active":trail_stop,"overnight_session_boundary_before":int(overnight)})
        previous_ts=b.timestamp
        # State updates apply only after this bar has closed.
        if fav >= .5*risk: be_armed=True;trail_armed=True
        if be_armed: be_stop=entry
        if trail_armed:
            candidate=(hi-.5*risk) if sign==1 else (lo+.5*risk)
            trail_stop=max(trail_stop,candidate) if sign==1 else min(trail_stop,candidate)
        if result["baseline_path_outcome"] and result["be05_outcome"] and result["trail05_outcome"]: break
    result["favorable_before_adverse"]=(None if result["first_positive_bar"] is None or result["first_negative_bar"] is None else int(result["first_positive_bar"] < result["first_negative_bar"]))
    if mfe != float("-inf"):
        result["max_favorable_excursion"]=mfe;result["max_adverse_excursion"]=mae;result["max_favorable_pct_of_target"]=100*mfe/abs(target-entry)
    return result,path


def export_run(storage: Path, run_id: str, root: Path, segment: str, output: Path) -> None:
    output.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(storage) as db:
        trades=pd.read_sql_query("""SELECT t.trade_id,t.symbol source_symbol,t.strategy_tf,t.side,t.scan_timestamp,t.setup_timestamp,t.entry_timestamp,t.exit_timestamp,t.entry_price,t.stop_price,t.target_price,t.exit_price,t.outcome,t.gross_r,t.gross_return_pct,t.exit_reason,t.target_hit,t.stop_hit,t.bars_held,r.E_regime e_regime,r.A_regime a_regime,r.X_regime x_regime,r.E_rule_applied,r.A_rule_applied,r.X_rule_applied,s.final_bias,s.permitted_setup,s.allow_long,s.allow_short,p.outcome_direction
          FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id JOIN regime_snapshots r ON r.scan_id=s.scan_id LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id WHERE s.run_id=? AND t.outcome IN ('WIN','LOSS') ORDER BY t.trade_id""",db,params=[run_id])
        tf_names={row[0]:row[1] for row in db.execute("SELECT DISTINCT strategy_tf,strategy_tf_name FROM scan_tasks WHERE run_id=?",(run_id,))}
    out=[];paths=[]
    infer=nsefo_contract_live if segment.upper()=="NSEFO" else mcx_contract_live
    for row in trades.itertuples(index=False):
        underlying=row.source_symbol.rsplit("@",1)[0];contract_live,roll=infer(underlying,row.scan_timestamp)
        try:
            bars=_future_bars(root,row.source_symbol,tf_names[row.strategy_tf],row.entry_timestamp)
            metrics,bar_path=evaluate_path(row.side,float(row.entry_price),float(row.stop_price),float(row.target_price),bars)
        except Exception as exc:
            metrics={"path_evaluation_error":f"{type(exc).__name__}: {exc}"};bar_path=[]
        signature=" | ".join(str(x or "") for x in (row.E_rule_applied,row.A_rule_applied,row.X_rule_applied))
        e1_boundaries=sum(x.get("overnight_session_boundary_before",0) for x in bar_path)
        d=row._asdict();d.update(metrics);d.update({"stock_name":underlying,"instrument_class":"index" if underlying in {"NIFTY","BANKNIFTY","FINNIFTY"} else "stock" if segment.upper()=="NSEFO" else "commodity","contract_live":contract_live,"contract_live_source":"CALENDAR_INFERRED_FROM_STITCHED_SERIES","roll_boundary_flag":int(roll),"e1_session_boundary_count":e1_boundaries if segment.upper()=="MCX" else 0,"strategy_tf_name":tf_names[row.strategy_tf],"zone_signature":signature,"rrr":abs(float(row.target_price)-float(row.entry_price))/abs(float(row.entry_price)-float(row.stop_price))})
        out.append(d)
        paths.extend({"trade_id":row.trade_id,**x} for x in bar_path)
    trade_columns=["trade_id","stock_name","instrument_class","contract_live","contract_live_source","roll_boundary_flag","e1_session_boundary_count","strategy_tf","strategy_tf_name","side","setup_timestamp","entry_price","stop_price","target_price","exit_price","outcome","outcome_direction","gross_r","e_regime","a_regime","x_regime","zone_signature","rrr","first_positive_bar","first_negative_bar","favorable_before_adverse","max_favorable_excursion","max_adverse_excursion","max_favorable_pct_of_target","be05_outcome","be05_r","trail05_outcome","trail05_r"]
    pd.DataFrame(out,columns=trade_columns if not out else None).to_csv(output/f"{segment.lower()}_fut_regime_tf_backtest_labeled.csv",index=False)
    pd.DataFrame(paths,columns=["trade_id","bar_index","timestamp","high","low","favorable_r","adverse_r","be_stop_active","trail_stop_active","overnight_session_boundary_before"]).to_csv(output/f"{segment.lower()}_trade_bar_path.csv",index=False)
    print(f"resolved trades exported: {len(out):,}; path rows: {len(paths):,}; output={output}")


def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument("--storage",required=True,type=Path);p.add_argument("--run",required=True);p.add_argument("--root",required=True,type=Path);p.add_argument("--segment",choices=("NSEFO","MCX"),required=True);p.add_argument("--output",required=True,type=Path);a=p.parse_args(argv);export_run(a.storage,a.run,a.root,a.segment,a.output)

if __name__=="__main__": main()
