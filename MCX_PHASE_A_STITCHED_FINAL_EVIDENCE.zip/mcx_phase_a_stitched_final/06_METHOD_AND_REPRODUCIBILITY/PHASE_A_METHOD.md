# MCX Phase-A Stitched-Series Method

Scope is deliberately limited to `GOLDM`, `SILVER`, `SILVERM`, `CRUDEOILM`, and
`NATGASMINI`. This runner invokes the unchanged production
`process_setup_fc(..., is_future=False)` path in isolated worker processes.

The source is stitched. `contract_live` is an inferred contract-period label,
not verified historic contract OHLC attribution. The 23:30→09:00 IST E1 gap is
persisted/flagged for analysis; the unchanged production zone API does not
accept a hard session-boundary marker, so the baseline does not claim a zone
reset at that seam.

```bash
PYTHONPATH=. python -m audit.mcx_futures_backtest.preflight --strict-contract-history
PYTHONPATH=. python -m audit.mcx_futures_backtest.run_phase_a run \
  --run-name mcx_phase_a --symbols phase-a --tfs 1,2,3,4 \
  --start 2025-09-01 --end 2026-09-30 --workers 4 \
  --compute-reference-oracle --storage audit/mcx_futures_backtest/storage/phase_a.sqlite
```
