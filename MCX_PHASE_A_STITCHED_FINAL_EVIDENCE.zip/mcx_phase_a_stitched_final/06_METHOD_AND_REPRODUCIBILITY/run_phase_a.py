"""Phase-A MCX replay, intentionally separate from the NSEFO runner.

It calls the current ``process_setup_fc`` with ``is_future=False`` against the
commodity data root.  The wrapper exists only in a worker process; no
production module is edited.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from audit.derivatives_backtest_common.contract_inventory import parse_contract_filename
from audit.mcx_futures_backtest.preflight import MCX_FRAMES, MCX_ROOT, MCX_STACKS, PRIORITY
from audit.nsefo_futures_backtest.run_phase_a import Config, Coordinator


def _symbols(value: str) -> tuple[str,...]:
    if value == "phase-a": return tuple(sorted(PRIORITY & {parse_contract_filename(p,MCX_FRAMES).symbol for p in MCX_ROOT.glob('*.csv') if parse_contract_filename(p,MCX_FRAMES)}))
    p=Path(value)
    if p.exists(): return tuple(x.strip().upper() for x in p.read_text().splitlines() if x.strip() and not x.startswith('#'))
    return tuple(x.strip().upper() for x in value.split(',') if x.strip())


def _sources(symbol: str, stack: tuple[str,...]) -> list[str]:
    found={}
    for p in MCX_ROOT.glob(f"{symbol}_*.csv"):
        x=parse_contract_filename(p,MCX_FRAMES)
        if x: found.setdefault(x.expiry,set()).add(x.timeframe)
    return sorted([e for e,v in found.items() if set(stack).issubset(v)],key=lambda x:pd.to_datetime(x,format='%d%m%Y'))


def _source(symbol: str, stack: tuple[str,...], end: str) -> str|None:
    xs=_sources(symbol,stack)
    if not xs:return None
    target=pd.Timestamp(end); cover=[]
    for expiry in xs:
        d=pd.read_csv(MCX_ROOT/f"{symbol}_{expiry}_{stack[-1]}.csv",usecols=['tradeDate']).tradeDate
        last=pd.to_datetime(d.iloc[-1],dayfirst=True,errors='coerce')
        if pd.notna(last) and last>=target:cover.append(expiry)
    return min(cover or xs,key=lambda x:abs(pd.to_datetime(x,format='%d%m%Y')-target))


def generate_tasks(cfg: Config):
    for symbol in cfg.symbols:
        for tf in cfg.tfs:
            stack=MCX_STACKS[tf];expiry=_source(symbol,stack,cfg.end)
            if not expiry:continue
            d=pd.read_csv(MCX_ROOT/f"{symbol}_{expiry}_{stack[-1]}.csv",usecols=['tradeDate'])
            ts=pd.to_datetime(d.tradeDate,dayfirst=True,errors='coerce').dropna().drop_duplicates()
            for i,x in enumerate(ts[(ts>=pd.Timestamp(cfg.start))&(ts<=pd.Timestamp(cfg.end)+pd.Timedelta(days=1)-pd.Timedelta(nanoseconds=1))]):
                if i%cfg.sample_every:continue
                yield {'symbol':f'{symbol}@{expiry}','strategy_tf':tf,'strategy_tf_name':stack[-1],'evaluation_timestamp':x.isoformat()}


def execute_task(task:dict,*args,**kwargs):
    import audit.futures_trend_backtest.run_futures_backtest as legacy
    import scripts.setup_engine_new as production
    original=production.process_setup_fc
    def commodity_process(tick,time_list,exp_num,last_d_time,is_future):
        return original(tick,time_list,exp_num,last_d_time,False)
    legacy.DATA=MCX_ROOT;legacy.STACKS=dict(MCX_STACKS);legacy._bars.cache_clear();production.process_setup_fc=commodity_process
    try:return legacy.execute_task(task,*args,**kwargs)
    finally:production.process_setup_fc=original


class MCXCoordinator(Coordinator):
    def create(self):
        tasks=list(generate_tasks(self.cfg));tasks=tasks[:self.cfg.limit_tasks] if self.cfg.limit_tasks else tasks
        rid=self.store.create_run(self.cfg,len(tasks));self.store.register_tasks(rid,tasks);return rid


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='cmd',required=True)
    def common(x):
        x.add_argument('--run-name',default='mcx_phase_a_stitched');x.add_argument('--symbols',default='phase-a');x.add_argument('--tfs',default='1,2,3,4');x.add_argument('--start',default='2025-09-01');x.add_argument('--end',default='2026-09-30');x.add_argument('--executor',choices=('process',),default='process');x.add_argument('--workers',default='4');x.add_argument('--storage',default='audit/mcx_futures_backtest/storage/phase_a.sqlite');x.add_argument('--limit-tasks',type=int);x.add_argument('--sample-every',type=int,default=1);x.add_argument('--compute-reference-oracle',action='store_true')
    for x in ('dry-run','run'):common(sub.add_parser(x))
    for x in ('status','resume'):
        q=sub.add_parser(x);q.add_argument('run_id');q.add_argument('--storage',default='audit/mcx_futures_backtest/storage/phase_a.sqlite')
    a=p.parse_args(argv)
    if a.cmd in ('status','resume'):
        from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
        store=SQLiteBacktestStorage(a.storage);row=store.get_run(a.run_id)
        if row is None:raise SystemExit('unknown run_id')
        c=MCXCoordinator(Config(**json.loads(row['config_json'])),execute_task);print(json.dumps(c.status(a.run_id) if a.cmd=='status' else c.run(a.run_id),indent=2,default=str));return
    tfs=tuple(int(x) for x in a.tfs.split(','));invalid=set(tfs)-set(MCX_STACKS)
    if invalid:raise SystemExit(f'unsupported MCX TF IDs: {sorted(invalid)}')
    cfg=Config(a.run_name,_symbols(a.symbols),tfs,a.start,a.end,a.executor,a.workers,storage_path=a.storage,limit_tasks=a.limit_tasks,sample_every=a.sample_every,compute_reference_oracle=a.compute_reference_oracle,variant_name='PHASE_A_MCX_STITCHED_CALENDAR_INFERRED')
    tasks=list(generate_tasks(cfg));tasks=tasks[:cfg.limit_tasks] if cfg.limit_tasks else tasks
    if a.cmd=='dry-run':print(json.dumps({'symbols':list(cfg.symbols),'tfs':list(tfs),'canonical_sources_per_symbol_tf':1,'canonical_tasks':len(tasks),'session_boundary':'23:30->09:00 IST flagged at export'},indent=2));return
    c=MCXCoordinator(cfg,execute_task);rid=c.create();print(f'run_id={rid}');print(json.dumps(c.run(rid),indent=2,default=str))

if __name__=='__main__':main()
