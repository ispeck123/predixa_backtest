"""Create the management report for the approved MCX stitched-series baseline."""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

import pandas as pd


def table(frame: pd.DataFrame, limit: int | None = None) -> str:
    if frame.empty:
        return "No rows."
    if limit is not None:
        frame = frame.head(limit)
    return frame.to_markdown(index=False)


def query(connection: sqlite3.Connection, sql: str, run_id: str) -> pd.DataFrame:
    return pd.read_sql_query(sql, connection, params=[run_id])


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--run", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)

    with sqlite3.connect(args.storage) as connection:
        run = query(connection, "select * from backtest_runs where run_id=?", args.run)
        if run.empty:
            raise SystemExit(f"Unknown run: {args.run}")
        meta = run.iloc[0]
        task_status = query(connection, "select status, count(*) as tasks from scan_tasks where run_id=? group by status order by status", args.run)
        failures = query(connection, """
            select coalesce(e.exception_message, 'no recorded exception') as reason, count(*) as tasks
            from scan_tasks t left join errors e on e.error_id=t.error_id
            where t.run_id=? and t.status='FAILED'
            group by reason order by tasks desc
        """, args.run)
        population = query(connection, """
            select count(*) as scans, sum(signal_generated) as signals,
                   sum(entry_candidate) as eligible_entries
            from scan_results where run_id=?
        """, args.run)
        outcomes = query(connection, """
            select t.outcome, count(*) as trades
            from simulated_trades t join scan_results s on s.scan_id=t.scan_id
            where s.run_id=? group by t.outcome order by t.outcome
        """, args.run)
        side = query(connection, """
            select t.side, count(*) as trades, sum(t.outcome='WIN') as wins,
              sum(t.outcome='LOSS') as losses,
              round(100.0*sum(t.outcome='WIN')/count(*),3) as win_pct,
              round(avg(t.gross_r),4) as avg_gross_r,
              round(100.0*avg(case when p.outcome_direction='AGAINST_TRADE_DIRECTION' then 1.0 else 0.0 end),3) as against_pct
            from simulated_trades t
            join scan_results s on s.scan_id=t.scan_id
            left join trade_path_metrics p on p.trade_id=t.trade_id
            where s.run_id=? and t.outcome in ('WIN','LOSS')
            group by t.side order by t.side
        """, args.run)
        ea = query(connection, """
            select r.e_regime as E, r.a_regime as A, t.side, count(*) as trades,
              sum(t.outcome='WIN') as wins, sum(t.outcome='LOSS') as losses,
              round(100.0*sum(t.outcome='WIN')/count(*),3) as win_pct,
              round(avg(t.gross_r),4) as avg_gross_r
            from simulated_trades t join scan_results s on s.scan_id=t.scan_id
            join regime_snapshots r on r.scan_id=s.scan_id
            where s.run_id=? and t.outcome in ('WIN','LOSS')
            group by r.e_regime,r.a_regime,t.side
            order by E,A,t.side
        """, args.run)
        tf = query(connection, """
            select s.strategy_tf as strategy_tf, count(*) as trades,
              sum(t.outcome='WIN') as wins, sum(t.outcome='LOSS') as losses,
              round(100.0*sum(t.outcome='WIN')/count(*),3) as win_pct,
              round(avg(t.gross_r),4) as avg_gross_r
            from simulated_trades t join scan_results s on s.scan_id=t.scan_id
            where s.run_id=? and t.outcome in ('WIN','LOSS')
            group by s.strategy_tf order by s.strategy_tf
        """, args.run)
        symbol = query(connection, """
            select s.symbol, count(*) as trades, sum(t.outcome='WIN') as wins,
              sum(t.outcome='LOSS') as losses,
              round(100.0*sum(t.outcome='WIN')/count(*),3) as win_pct,
              round(avg(t.gross_r),4) as avg_gross_r
            from simulated_trades t join scan_results s on s.scan_id=t.scan_id
            where s.run_id=? and t.outcome in ('WIN','LOSS')
            group by s.symbol order by s.symbol
        """, args.run)

    completed = int(task_status.loc[task_status.status == "COMPLETED", "tasks"].sum())
    total = int(task_status.tasks.sum())
    resolved = int(outcomes.loc[outcomes.outcome.isin(["WIN", "LOSS"]), "trades"].sum())
    total_wins = int(side.wins.sum())
    win_pct = 100 * total_wins / resolved if resolved else 0.0
    lines = [
        "# MCX Phase-A Stitched-Series Backtest — Final Report",
        "",
        "## Executive summary",
        "",
        f"This report documents the completed current-production MCX replay `{args.run}`. It uses the approved stitched/continuous OHLC source, not individual expired-contract histories. Production files modified: **NONE**.",
        "",
        f"- Scope: GOLDM, SILVER, SILVERM, CRUDEOILM and NATGASMINI; strategy TF IDs 1–4.",
        f"- Requested replay period: {meta['historical_start']} to {meta['historical_end']}.",
        f"- Completed scans: {completed:,}/{total:,} ({100*completed/total:.3f}%).",
        f"- Signals: {int(population.iloc[0].signals):,}; entered trades: {int(outcomes.trades.sum()):,}; resolved WIN/LOSS trades: {resolved:,}.",
        f"- Resolved baseline outcome: {total_wins:,} wins ({win_pct:.3f}%), with average gross R calculated by the existing audit resolver.",
        "",
        "## Interpretation boundary",
        "",
        "The tables measure behaviour of the current production setup/trend pipeline against supplied stitched OHLC paths. They are not a claim of exchange-verified individual-contract attribution, net live profitability, or an instruction to alter production trend logic. `contract_live` labels in the evidence are calendar-inferred from the stitched series and are descriptive only. The unchanged production zone API has no contract-roll or session-boundary reset input; boundary flags must not be interpreted as hard zone resets.",
        "",
        "## Run coverage",
        "",
        table(task_status), "", table(population), "", table(outcomes),
        "",
        "## Data-quality and completion disclosure",
        "",
        f"{total-completed:,} tasks reached terminal failure and are retained rather than excluded silently. The dominant failures are early-history production warm-up rejections; the remaining source-boundary indexing failures are recorded in the supplied data-quality CSV.",
        "", table(failures),
        "",
        "## Actual baseline outcomes by side",
        "",
        table(side),
        "",
        "## Trend-engine E/A context versus realized outcome",
        "",
        "E/A is the current production regime snapshot at the scan that generated the entered trade. Outcome is resolved only afterwards from future OHLC bars.",
        "", table(ea),
        "",
        "## Strategy timeframe results",
        "",
        table(tf),
        "",
        "## Instrument results",
        "",
        table(symbol),
        "",
        "## Available forensic evidence",
        "",
        "The accompanying labelled trade and bar-path CSVs retain scan timestamp, setup timestamp, entry/exit, E/A/X regimes, rule/diagnosis, permission fields, zone context where exposed, and actual path metrics. The analysis directory provides Rule-B/Rule-C, roll-boundary, instrument-class and regime-timeframe summaries without rerunning production calls.",
        "",
        "## Final classification",
        "",
        "**Completed stitched-series MCX Phase-A baseline.** The evidence is suitable for management review of current-production decisions and realized OHLC-path outcomes under the supplied data. Individual expired-contract continuity and hard session/roll zone-boundary behaviour remain outside what this source can verify.",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
