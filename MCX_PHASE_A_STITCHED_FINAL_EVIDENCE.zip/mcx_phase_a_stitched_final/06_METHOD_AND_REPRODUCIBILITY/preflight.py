"""MCX Phase-A source readiness report, including the E1 session-gap requirement."""
from __future__ import annotations

import argparse
from pathlib import Path

from audit.derivatives_backtest_common.contract_inventory import contract_summary, inventory_contract_data

MCX_ROOT = Path("data/indian_commodity_data/latest_data_csv")
MCX_FRAMES = ("monthly", "weekly", "daily", "seventy_five", "two_forty", "one_twenty", "sixty", "fifteen")
MCX_STACKS = {
    1: ("monthly", "weekly", "daily"),
    2: ("weekly", "daily", "two_forty"),
    3: ("daily", "two_forty", "one_twenty"),
    4: ("daily", "two_forty", "sixty"),
}
PRIORITY = {"GOLD", "GOLDM", "SILVER", "SILVERM", "CRUDEOIL", "CRUDEOILM", "NATURALGAS", "NATGASMINI"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate MCX Phase-A source data before clean replay.")
    parser.add_argument("--root", type=Path, default=MCX_ROOT)
    parser.add_argument("--output", type=Path, default=Path("audit/mcx_futures_backtest/results"))
    parser.add_argument("--strict-contract-history", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    inv = inventory_contract_data(args.root, MCX_FRAMES, MCX_STACKS, "MCX")
    inv["phase_a_priority"] = inv.symbol.isin(PRIORITY)
    summary = contract_summary(inv)
    summary["phase_a_priority"] = summary.symbol.isin(PRIORITY)
    inv.to_csv(args.output / "mcx_source_file_inventory.csv", index=False)
    summary.to_csv(args.output / "mcx_contract_inventory.csv", index=False)
    print(f"MCX source files: {len(inv):,}; contract keys: {len(summary):,}; symbols: {summary.symbol.nunique():,}")
    print(f"Source mode counts: {inv.source_mode.value_counts(dropna=False).to_dict()}")
    print("Session policy required for a later replay: 23:30 -> 09:00 IST is a hard E1 boundary.")
    if args.strict_contract_history and (inv.source_mode == "STITCHED_OR_CONTINUOUS").any():
        print("STRICT FAILURE: supplied files predate their stated contract expiry window; historical contract-live attribution is not evidenced.")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
