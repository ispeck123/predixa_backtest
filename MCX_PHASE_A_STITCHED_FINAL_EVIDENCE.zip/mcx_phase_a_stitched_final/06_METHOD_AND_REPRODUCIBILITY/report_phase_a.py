"""Render a conservative report from completed Phase-A exports and summaries."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd

def _table(path: Path) -> str:
    if not path.exists() or path.stat().st_size == 0:return "No resolved-trade rows."
    d=pd.read_csv(path);return "No rows." if d.empty else d.to_markdown(index=False)

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--segment',required=True);p.add_argument('--labelled',required=True,type=Path);p.add_argument('--analysis',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args(argv)
    d=pd.read_csv(a.labelled);resolved=len(d);period='unavailable' if d.empty else f"{d.setup_timestamp.min()} to {d.setup_timestamp.max()}"
    limitations=("The supplied source is stitched/continuous. `contract_live` is calendar-inferred and does not prove historical contract identity. "
                 "The unchanged production zone API has no roll/session-boundary input; boundary flags are recorded for analysis but do not constitute a zone reset. "
                 "Trailing and breakeven results are audit-only counterfactuals: stop updates activate on the following completed OHLC bar.")
    lines=[f"# {a.segment.upper()} Phase-A Futures Backtest Report","",f"- Resolved trades: {resolved:,}",f"- Trade period: {period}","- Production path: `scripts.setup_engine_new.process_setup_fc`.","- Baseline trading logic modified: **none**.","","## Data provenance and limitations","",limitations,"","## Regime × timeframe × side","",_table(a.analysis/'regime_tf_summary.csv'),"","## Instrument-class × side","",_table(a.analysis/'instrument_class_summary.csv'),"","## Rule context","",_table(a.analysis/'rule_summary.csv'),"","## Roll-boundary flags","",_table(a.analysis/'roll_boundary_summary.csv'),"","## Exit counterfactual interpretation","","`be05_*`: move stop to breakeven after a completed bar reaches +0.5R. `trail05_*`: then trail at 0.5R from the completed-bar high/low. These do not overwrite baseline outcomes."]
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text('\n'.join(lines),encoding='utf-8');print(a.output)

if __name__=='__main__':main()
