"""Analysis of a completed labelled Phase-A export; never reruns production."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd

def summary(df, by):
    g=df.groupby(by,dropna=False)
    return g.agg(trades=('trade_id','size'),wins=('outcome',lambda x:(x=='WIN').sum()),losses=('outcome',lambda x:(x=='LOSS').sum()),win_pct=('outcome',lambda x:round(100*(x=='WIN').mean(),3)),avg_r=('gross_r','mean'),baseline_against_pct=('outcome_direction',lambda x:round(100*(x=='AGAINST_TRADE_DIRECTION').mean(),3)),be05_win_pct=('be05_outcome',lambda x:round(100*(x=='WIN').mean(),3)),trail05_win_pct=('trail05_outcome',lambda x:round(100*(x=='WIN').mean(),3))).reset_index()

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args(argv);a.output.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(a.input)
    jobs={'regime_tf_summary.csv':['instrument_class','e_regime','a_regime','strategy_tf','side'],'instrument_class_summary.csv':['instrument_class','side'],'rule_summary.csv':['e_regime','a_regime','zone_signature','side'],'roll_boundary_summary.csv':['roll_boundary_flag','side'],'contract_live_summary.csv':['contract_live','side']}
    for name,cols in jobs.items(): summary(d,cols).to_csv(a.output/name,index=False)
    print(f'analysis complete: {len(d):,} resolved trades -> {a.output}')

if __name__=='__main__':main()
