# MCX Phase-A Evidence Package

Start with `01_EXECUTIVE/MCX_PHASE_A_EXECUTIVE_SUMMARY.md`, then the full report and result CSVs. The SQLite database contains scan, regime, zone, setup, trade, path-metric and error evidence. Raw OHLC source files are not duplicated; their repository path and method are recorded in metadata. Production trading code was not changed.
