# MCX Phase-A Stitched-Series Backtest — Final Report

## Executive summary

This report documents the completed current-production MCX replay `d6307703511b4d7b95434cd35712ab86`. It uses the approved stitched/continuous OHLC source, not individual expired-contract histories. Production files modified: **NONE**.

- Scope: GOLDM, SILVER, SILVERM, CRUDEOILM and NATGASMINI; strategy TF IDs 1–4.
- Requested replay period: 2025-09-01 to 2026-09-30.
- Completed scans: 31,705/32,990 (96.105%).
- Signals: 7,415; entered trades: 5,006; resolved WIN/LOSS trades: 4,930.
- Resolved baseline outcome: 1,389 wins (28.174%), with average gross R calculated by the existing audit resolver.

## Interpretation boundary

The tables measure behaviour of the current production setup/trend pipeline against supplied stitched OHLC paths. They are not a claim of exchange-verified individual-contract attribution, net live profitability, or an instruction to alter production trend logic. `contract_live` labels in the evidence are calendar-inferred from the stitched series and are descriptive only. The unchanged production zone API has no contract-roll or session-boundary reset input; boundary flags must not be interpreted as hard zone resets.

## Run coverage

| status    |   tasks |
|:----------|--------:|
| COMPLETED |   31705 |
| FAILED    |    1285 |

|   scans |   signals |   eligible_entries |
|--------:|----------:|-------------------:|
|   31705 |      7415 |               7415 |

| outcome    |   trades |
|:-----------|---------:|
| LOSS       |     3541 |
| UNRESOLVED |       76 |
| WIN        |     1389 |

## Data-quality and completion disclosure

1,285 tasks reached terminal failure and are retained rather than excluded silently. The dominant failures are early-history production warm-up rejections; the remaining source-boundary indexing failures are recorded in the supplied data-quality CSV.

| reason                                     |   tasks |
|:-------------------------------------------|--------:|
| E-TF has 2 bars, minimum 7 required        |     232 |
| E-TF has 3 bars, minimum 7 required        |     223 |
| E-TF has 5 bars, minimum 7 required        |     209 |
| E-TF has 4 bars, minimum 7 required        |     209 |
| E-TF has 6 bars, minimum 7 required        |     191 |
| E-TF has 1 bars, minimum 7 required        |     154 |
| single positional indexer is out-of-bounds |      67 |

## Actual baseline outcomes by side

| side   |   trades |   wins |   losses |   win_pct |   avg_gross_r |   against_pct |
|:-------|---------:|-------:|---------:|----------:|--------------:|--------------:|
| BUY    |     2586 |    966 |     1620 |    37.355 |        0.6324 |        62.645 |
| SELL   |     2344 |    423 |     1921 |    18.046 |       -0.2618 |        81.954 |

## Trend-engine E/A context versus realized outcome

E/A is the current production regime snapshot at the scan that generated the entered trade. Outcome is resolved only afterwards from future OHLC bars.

| E   | A   | side   |   trades |   wins |   losses |   win_pct |   avg_gross_r |
|:----|:----|:-------|---------:|-------:|---------:|----------:|--------------:|
| DN  | DN  | SELL   |      839 |    119 |      720 |    14.184 |       -0.4543 |
| DN  | SW  | SELL   |      366 |    104 |      262 |    28.415 |        0.1461 |
| SW  | DN  | SELL   |      533 |     63 |      470 |    11.82  |       -0.4929 |
| SW  | SW  | BUY    |      412 |    222 |      190 |    53.883 |        1.3797 |
| SW  | SW  | SELL   |      225 |     61 |      164 |    27.111 |        0.1575 |
| SW  | UP  | BUY    |      518 |    160 |      358 |    30.888 |        0.4886 |
| UP  | SW  | BUY    |      949 |    373 |      576 |    39.305 |        0.6479 |
| UP  | SW  | SELL   |      381 |     76 |      305 |    19.948 |       -0.1543 |
| UP  | UP  | BUY    |      707 |    211 |      496 |    29.844 |        0.2815 |

## Strategy timeframe results

|   strategy_tf |   trades |   wins |   losses |   win_pct |   avg_gross_r |
|--------------:|---------:|-------:|---------:|----------:|--------------:|
|             1 |       72 |      0 |       72 |     0     |       -1      |
|             2 |      586 |    110 |      476 |    18.771 |       -0.2556 |
|             3 |     1164 |    319 |      845 |    27.405 |        0.1133 |
|             4 |     3108 |    960 |     2148 |    30.888 |        0.3576 |

## Instrument results

| symbol              |   trades |   wins |   losses |   win_pct |   avg_gross_r |
|:--------------------|---------:|-------:|---------:|----------:|--------------:|
| CRUDEOILM@19102026  |      995 |    294 |      701 |    29.548 |        0.4558 |
| GOLDM@05102026      |     1088 |    416 |      672 |    38.235 |        0.6181 |
| NATGASMINI@27102026 |     1301 |    363 |      938 |    27.902 |        0.1638 |
| SILVER@30092026     |      222 |     85 |      137 |    38.288 |        0.3778 |
| SILVERM@30112026    |     1324 |    231 |     1093 |    17.447 |       -0.3032 |

## Available forensic evidence

The accompanying labelled trade and bar-path CSVs retain scan timestamp, setup timestamp, entry/exit, E/A/X regimes, rule/diagnosis, permission fields, zone context where exposed, and actual path metrics. The analysis directory provides Rule-B/Rule-C, roll-boundary, instrument-class and regime-timeframe summaries without rerunning production calls.

## Final classification

**Completed stitched-series MCX Phase-A baseline.** The evidence is suitable for management review of current-production decisions and realized OHLC-path outcomes under the supplied data. Individual expired-contract continuity and hard session/roll zone-boundary behaviour remain outside what this source can verify.
