Run audit scripts from repository root. Phase-3 every-week replay was not completed; do not treat the included every-20-week Phase-2 sample as dense evidence.
