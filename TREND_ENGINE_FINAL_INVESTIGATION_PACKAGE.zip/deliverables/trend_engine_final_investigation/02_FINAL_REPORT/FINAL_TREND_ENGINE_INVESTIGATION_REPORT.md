# Trend Engine Independent Investigation

## Phase 1 + Phase 2 + Phase 3 consolidated findings

Production files modified: **none**.

Phase 1 established the active decision path and independently assessed ICICI
Lombard. Phase 2 completed a 52-symbol, 881-observation, strictly-as-of
cross-universe sample. It found E/A/X bullish classification asymmetry of
+40.4pp/+32.0pp/+49.6pp respectively, with positive symbol-cluster bootstrap
intervals. Rule B Only-BZ produced 31/0, 17/0, and 39/0 bullish/bearish severe
contradictions at E/A/X in that sample.

Phase 3 was intended to replay every completed weekly bar and targeted daily
windows. That full replay was not completed under the command execution limit:
production zone regeneration took approximately 4–5 seconds per sampled
checkpoint and the existing 20-week checkpoint runner was required to persist
work within the limit. Consequently, this package contains **no dense Phase-3
claim**, no bar-level latency estimate, and no dense episode-duration estimate.

The confirmed discrepancy is a documented-but-inactive control: HTF veto and
quadrant enforcement conditions are commented out in the active source. The
observed classification asymmetry is distinct from an implementation failure:
the exercised code followed its active zone-dominance rules, which can disagree
with the independent confirmed-pivot reference. No profitability conclusion is
made.

See the Phase 2 report for full statistics, the source-code findings for line
references, and limitations in the technical appendix.
