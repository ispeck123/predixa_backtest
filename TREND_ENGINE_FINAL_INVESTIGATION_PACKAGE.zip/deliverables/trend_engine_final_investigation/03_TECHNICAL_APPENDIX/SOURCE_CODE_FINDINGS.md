# Source-code findings (production unchanged)

- `scripts/trend_engine.py:932-956`, `TrendEngine.find_nearest_bz/sz`: selects non-invalidated zones by distal/CMP relation and proximal ordering; no age, state, retest, or penetration eligibility filter.
- `scripts/trend_engine.py:1052-1153`, `calculate_trend`: Rule B returns UP for only-BZ and DN for only-SZ, subject only to `htf_regime` safeguards.
- `scripts/trend_engine.py:1165-1243`: Cascading Window uses closes from a nearest zone's `created_idx` through current bar.
- `scripts/trend_engine.py:1276-1467`: Rule C Scenario 1/2/3 determines zone-side dominance; Scenario 3 has two opposing-zone violations.
- `scripts/trend_engine.py:1537-1693`, `MultiTimeframeTrendCalculator.calculate_full_context`: E then A then X; final permissions/Bias come from E/A matrix call.
- `scripts/trend_engine.py:1785-1906`, `ExecutionDecisionEngine`, `BUY_MATRIX`, `SELL_MATRIX`, `get_permissions`: matrix key is `(eval_regime, analyze_regime)`; quadrant enforcement block is commented out.
- `scripts/trend_engine.py:1913-1977`, `HTFVetoEngine.check_veto`: intended conditions are commented; active method returns no veto.
- `shared/config/settings.py:43-51`: cash `TIME_FRAMES_2` is weekly/daily/sixty.

These are confirmed implementation facts. They do not, alone, establish financial correctness or an implementation defect.
