# Technical Audit Appendix

The independent oracle uses 3-left/3-right confirmed pivots: the last two highs
and lows must form HH+HL for UP or LH+LL for DN; otherwise SW. It imports no
zone results. Each production call is supplied a timestamp T and source loaders
filter data to T. Conditional asymmetry is `P(engine=UP|ref=DN) -
P(engine=DN|ref=UP)`. Wilson intervals are used for rates; Phase 2 used 1,000
deterministic symbol-cluster bootstrap resamples, seed 20260916.

Phase 2 used all 52 requested symbols, 881 observations, every twentieth
weekly timestamp. The direct production zone recalculation cost prevented a
complete every-week Phase-3 replay in this execution environment. No future
state was cached into earlier observations; resumed rows were keyed by
symbol/timestamp. See Phase 1 and Phase 2 runners/tests in the package.
