# Read me first

This is an investigation-only package. Production trend-engine files were not
modified. Read in order: `01_EXECUTIVE`, `02_FINAL_REPORT`, then
`03_TECHNICAL_APPENDIX`; raw Phase 1/2 evidence is included for verification.

Phase 2 is the completed 52-symbol cross-sectional sample. Phase 3 dense
replay was not completed and is explicitly represented as unavailable rather
than substituted with Phase 2 data. Reproduce using the included audit scripts
from repository root; source market-data paths and configured mapping appear in
the reports.
