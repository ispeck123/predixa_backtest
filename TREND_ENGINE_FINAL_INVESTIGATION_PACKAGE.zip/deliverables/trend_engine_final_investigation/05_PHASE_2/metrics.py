from __future__ import annotations
import math, numpy as np, pandas as pd

def wilson(k,n,z=1.95996398454):
 if not n:return (float('nan'),float('nan'))
 p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
 return c-h,c+h
def conditional(df, tf):
 ref={'E':'reference_weekly','A':'reference_daily','X':'reference_sixty'}.get(tf,f'reference_{tf}')
 e,r=df[f'{tf}_regime'],df[ref]; dn=r.eq('DN'); up=r.eq('UP')
 a=int((e.eq('UP')&dn).sum()); b=int((e.eq('DN')&up).sum()); na=int(dn.sum()); nb=int(up.sum())
 pa=a/na if na else float('nan'); pb=b/nb if nb else float('nan')
 return dict(up_ref_dn_n=a,ref_dn_n=na,up_given_ref_dn=pa,up_ci_low=wilson(a,na)[0],up_ci_high=wilson(a,na)[1],dn_ref_up_n=b,ref_up_n=nb,dn_given_ref_up=pb,dn_ci_low=wilson(b,nb)[0],dn_ci_high=wilson(b,nb)[1],asymmetry=pa-pb,asymmetry_ratio=pa/pb if pb and not math.isnan(pb) else float('nan'))
def episodes(df, tf):
 out=[]
 for s,g in df.sort_values('timestamp').groupby('symbol'):
  ref={'E':'reference_weekly','A':'reference_daily','X':'reference_sixty'}.get(tf,f'reference_{tf}')
  kind=np.where((g[f'{tf}_regime'].eq('UP')&g[ref].eq('DN')),'BULLISH_CONTRADICTION',np.where((g[f'{tf}_regime'].eq('DN')&g[ref].eq('UP')),'BEARISH_CONTRADICTION',''))
  start=None
  for pos,k in enumerate(kind):
   if k and start is None:start=pos
   if start is not None and (not k or pos==len(kind)-1):
    end=pos if k else pos-1; q=g.iloc[start:end+1]; out.append({'symbol':s,'timeframe':tf,'kind':kind[start],'start':q.timestamp.iloc[0],'end':q.timestamp.iloc[-1],'observations':len(q),'calendar_days':(pd.Timestamp(q.timestamp.iloc[-1])-pd.Timestamp(q.timestamp.iloc[0])).days,'engine_regime':q[f'{tf}_regime'].iloc[0],'reference_regime':q[ref].iloc[0],'start_cmp':q.X_cmp.iloc[0],'end_cmp':q.X_cmp.iloc[-1],'move_pct':q.X_cmp.iloc[-1]/q.X_cmp.iloc[0]-1,'rule_at_start':q[f'{tf}_rule_applied'].iloc[0],'dominant_rule':q[f'{tf}_rule_applied'].mode().iat[0]});start=None
 return pd.DataFrame(out)
def bootstrap_symbols(df, tf, draws=1000, seed=20260916):
 rng=np.random.default_rng(seed); groups=[g for _,g in df.groupby('symbol')]; vals=[]
 for _ in range(draws):
  sample=pd.concat([groups[i] for i in rng.integers(0,len(groups),len(groups))])
  vals.append(conditional(sample,tf)['asymmetry'])
 return {'timeframe':tf,'draws':draws,'asymmetry_bootstrap_low':float(np.nanquantile(vals,.025)),'asymmetry_bootstrap_high':float(np.nanquantile(vals,.975)),'asymmetry_bootstrap_median':float(np.nanmedian(vals))}
