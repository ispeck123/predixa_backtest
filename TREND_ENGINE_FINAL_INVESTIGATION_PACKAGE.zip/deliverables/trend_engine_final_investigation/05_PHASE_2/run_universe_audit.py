"""Restartable weekly as-of production replay; audit-only."""
from __future__ import annotations
import argparse, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
import pandas as pd
from scripts.trend_engine import MultiTimeframeTrendCalculator
from audit.trend_engine.price_action_oracle import label_as_of, diagnostics
from audit.trend_engine.phase2.universe_config import SYMBOLS,TIMEFRAMES
from audit.trend_engine.phase2.metrics import conditional,episodes,bootstrap_symbols
DATA=ROOT/'data/indian_stock_data/latest_data_csv'; OUT=Path(__file__).parent/'results'
def load(s,t):
 d=pd.read_csv(DATA/f'{s}_{t}.csv'); col='tradeDate' if 'tradeDate' in d else 'timestamp';d['_ts']=pd.to_datetime(d[col],dayfirst=True);return d.sort_values('_ts')
def quality(s,fs):
 rows=[]
 for tf,d in fs.items():
  bad=~d[['open','high','low','close']].notna().all(axis=1)|(d.high<d.low)|(d.close>d.high)|(d.close<d.low)|(d.open>d.high)|(d.open<d.low)
  rows.append({'symbol':s,'timeframe':tf,'rows':len(d),'start':d._ts.min(),'end':d._ts.max(),'duplicates':d._ts.duplicated().sum(),'non_monotonic':int(not d._ts.is_monotonic_increasing),'bad_ohlc':int(bad.sum())})
 return rows
def z(out,prefix,z):
 if z:
  for f in ['zone_id','proximal','distal','age_bars','retest_count','state','penetration_pct','created_idx'] :out[f'{prefix}_{f}']=z.get(f)
def run_symbol(s, existing, weekly_stride=1):
 missing=[t for t in TIMEFRAMES if not (DATA/f'{s}_{t}.csv').exists()]
 if missing:return [],{'symbol':s,'reason':'missing files','missing_timeframes':','.join(missing)},[]
 try:fs={t:load(s,t) for t in TIMEFRAMES}
 except Exception as e:return [],{'symbol':s,'reason':f'parse error: {e}','missing_timeframes':''},[]
 qs=quality(s,fs); weekly=fs['weekly']; rows=[]
 # Every weekly source timestamp is considered. Warmup is applied per actual clipped frame.
 for _,wr in weekly.iloc[::weekly_stride].iterrows():
  t=wr._ts
  cuts={tf:d[d._ts<=t] for tf,d in fs.items()}
  if len(cuts['weekly'])<20 or len(cuts['daily'])<40 or len(cuts['sixty'])<100:continue
  key=t.isoformat()
  if (s,key) in existing:continue
  try:
   m=MultiTimeframeTrendCalculator();m._set_symbol_and_timeframe(TIMEFRAMES,s,t.to_pydatetime());c=m.to_api(m.calculate_full_context())
  except Exception as e: return rows,{'symbol':s,'reason':f'engine error at {key}: {e}','missing_timeframes':''},qs
  x={'symbol':s,'timestamp':key,'E_timeframe':'weekly','A_timeframe':'daily','X_timeframe':'sixty','E_cmp':float(cuts['weekly'].close.iloc[-1]),'A_cmp':float(cuts['daily'].close.iloc[-1]),'X_cmp':float(cuts['sixty'].close.iloc[-1])}
  for L,tf in [('E','weekly'),('A','daily'),('X','sixty')]:
   r=c['result_'+L];x[f'{L}_regime']=c['regime_'+L];x[f'{L}_rule_applied']=r['rule_applied'];x[f'{L}_diagnosis']=r['diagnosis'];x[f'{L}_quadrant']=c['quadrant_'+L];x[f'reference_{tf}']=label_as_of(cuts[tf]);z(x,L+'_bz',r['nearest_bz']);z(x,L+'_sz',r['nearest_sz'])
  d=diagnostics(cuts['daily']);x.update(d);x.update({k:c[k] for k in ['bias','allow_long','allow_short','permitted_setup','trade_type_long','trade_type_short','htf_veto_longs','htf_veto_shorts','htf_veto_reason']})
  for L,tf in [('E','weekly'),('A','daily'),('X','sixty')]:
   x[f'{L}_engine_up_ref_dn'] = x[f'{L}_regime'] == 'UP' and x[f'reference_{tf}'] == 'DN'
   x[f'{L}_engine_dn_ref_up'] = x[f'{L}_regime'] == 'DN' and x[f'reference_{tf}'] == 'UP'
  x['bullish_bias_while_E_ref_DN']='Bullish' in x['bias'] and x['reference_weekly']=='DN';x['bullish_bias_while_A_ref_DN']='Bullish' in x['bias'] and x['reference_daily']=='DN';x['bearish_bias_while_E_ref_UP']='Bearish' in x['bias'] and x['reference_weekly']=='UP';x['bearish_bias_while_A_ref_UP']='Bearish' in x['bias'] and x['reference_daily']=='UP';rows.append(x)
 return rows,None,qs
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--max-symbols',type=int,default=52);ap.add_argument('--start',type=int,default=0);ap.add_argument('--weekly-stride',type=int,default=1);a=ap.parse_args();OUT.mkdir(parents=True,exist_ok=True); p=OUT/'universe_observations.csv'; old=pd.read_csv(p) if p.exists() else pd.DataFrame(); existing=set(zip(old.symbol,old.timestamp)) if not old.empty else set();skips=[];q=[]
 for i,s in enumerate(SYMBOLS[a.start:a.start+a.max_symbols],a.start+1):
  start=time.time();rows,skip,qq=run_symbol(s,existing,a.weekly_stride);q+=qq
  if rows:pd.concat([old,pd.DataFrame(rows)],ignore_index=True).to_csv(p,index=False);old=pd.read_csv(p)
  if skip:skips.append(skip)
  print(f'[{i}/52] {s}: {len(rows)} new rows, {time.time()-start:.1f}s',flush=True)
 pd.DataFrame(q).to_csv(OUT/'data_quality_report.csv',index=False);pd.DataFrame(skips).to_csv(OUT/'skipped_symbols.csv',index=False)
 if old.empty:return
 summ=[]
 for s,g in old.groupby('symbol'):
  x={'symbol':s,'observations':len(g)}
  for L,tf in [('E','weekly'),('A','daily'),('X','sixty')]:x.update({f'{L}_{k}':v for k,v in conditional(g,L).items()});x[f'{L}_exact_agreement']=(g[f'{L}_regime']==g[f'reference_{tf}']).mean()
  summ.append(x)
 pd.DataFrame(summ).sort_values('symbol').to_csv(OUT/'symbol_summary.csv',index=False);pd.concat([episodes(old,L) for L in 'EAX']).to_csv(OUT/'disagreement_episodes.csv',index=False)
 pd.DataFrame([{'timeframe':L,**conditional(old,L)} for L in 'EAX']).to_csv(OUT/'timeframe_summary.csv',index=False)
 pd.DataFrame([bootstrap_symbols(old,L) for L in 'EAX']).to_csv(OUT/'bootstrap_summary.csv',index=False)
 rules=[]
 for L,tf in [('E','weekly'),('A','daily'),('X','sixty')]:
  for rule,g in old.groupby(f'{L}_rule_applied'):
   rules.append({'timeframe':L,'rule_applied':rule,'activations':len(g),'up_ref_dn':int(((g[f'{L}_regime']=='UP')&(g[f'reference_{tf}']=='DN')).sum()),'dn_ref_up':int(((g[f'{L}_regime']=='DN')&(g[f'reference_{tf}']=='UP')).sum()),'symbols_affected':g.symbol.nunique()})
 pd.DataFrame(rules).to_csv(OUT/'rule_summary.csv',index=False)
 old.assign(year=pd.to_datetime(old.timestamp).dt.year).groupby('year').size().rename('observations').reset_index().to_csv(OUT/'yearly_summary.csv',index=False)
 pd.DataFrame([{'metric':'final_bullish_combined_dn','count':int(((old.bias.str.contains('Bullish'))&(old.reference_weekly.eq('DN'))&(old.reference_daily.eq('DN'))).sum())},{'metric':'final_bearish_combined_up','count':int(((old.bias.str.contains('Bearish'))&(old.reference_weekly.eq('UP'))&(old.reference_daily.eq('UP'))).sum())},{'metric':'bias_bullish_x_dn','count':int((old.bias.str.contains('Bullish')&old.X_regime.eq('DN')).sum())},{'metric':'bias_bearish_x_up','count':int((old.bias.str.contains('Bearish')&old.X_regime.eq('UP')).sum())}]).to_csv(OUT/'final_bias_summary.csv',index=False)
if __name__=='__main__':main()
