# Trend-engine audit tooling

`run_audit.py` calls `MultiTimeframeTrendCalculator.calculate_full_context()` as
of each selected timestamp; it does not patch, mock, or alter production zone
generation.  The default scope is the reproducible `icici_lombard_gic`
weekly/daily/sixty-minute mapping and one evaluation approximately every 40
daily bars.  Run from repository root:

```bash
python audit/trend_engine/run_audit.py
pytest -q tests/trend_engine_audit/test_conformance.py
```

`price_action_oracle.py` is independent: it labels confirmed HH+HL as UP and
LH+LL as DN using three bars left/right.  The right bars are only pivot
confirmation, and are already present as of each replay cutoff.

Results are generated from repository data and may be rerun.  No audit file is
loaded by the production application.
