"""Walk-forward audit runner.  Production code is called unchanged as-of each T."""
from __future__ import annotations
import csv, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import pandas as pd
from scripts.trend_engine import MultiTimeframeTrendCalculator
from audit.trend_engine.price_action_oracle import label_as_of, diagnostics

DATA=ROOT/'data/indian_stock_data/latest_data_csv'; OUT=Path(__file__).parent/'results'
# The dedicated reproduced symbol is kept intentionally narrow for a complete
# as-of replay within an interactive audit run.  Pass additional symbols by
# editing this audit-only list and rerunning; no production behavior changes.
SYMBOLS=['icici_lombard_gic']; TFS=['weekly','daily','sixty']
def read(symbol,tf):
 d=pd.read_csv(DATA/f'{symbol}_{tf}.csv'); c='tradeDate' if 'tradeDate' in d else 'timestamp'; d['_ts']=pd.to_datetime(d[c],dayfirst=True); return d.sort_values('_ts')
def safe_zone(z, t, n):
 if not z:return {}
 return {f'{t}_{n}_id':z.get('zone_id'),f'{t}_{n}_proximal':z.get('proximal'),f'{t}_{n}_distal':z.get('distal'),f'{t}_{n}_state':z.get('state'),f'{t}_{n}_age':z.get('age_bars'),f'{t}_{n}_retests':z.get('retest_count')}
def main():
 OUT.mkdir(parents=True,exist_ok=True); rows=[]
 for symbol in SYMBOLS:
  frames={tf:read(symbol,tf) for tf in TFS}
  # Monthly evaluations avoid a full-data single-shot and keep runtime reproducible.
  candidates=frames['daily'].iloc[200::40]
  for _,r in candidates.iterrows():
   t=r._ts
   if any((f._ts<=t).sum()<minimum for f,minimum in zip(frames.values(),[20,40,100])):continue
   m=MultiTimeframeTrendCalculator(); m._set_symbol_and_timeframe(TFS,symbol,t.to_pydatetime())
   try: ctx=m.to_api(m.calculate_full_context())
   except Exception as exc: print('SKIP',symbol,t,repr(exc),file=sys.stderr); continue
   cuts={tf:f[f._ts<=t] for tf,f in frames.items()}; d=diagnostics(cuts['daily'])
   x={'timestamp':t.isoformat(),'symbol':symbol,'E_timeframe':'weekly','A_timeframe':'daily','X_timeframe':'sixty','cmp':float(cuts['sixty'].close.iloc[-1]),**d}
   for key,tf in [('E','weekly'),('A','daily'),('X','sixty')]:
    result=ctx['result_'+key]; x[f'{key}_regime']=ctx['regime_'+key]; x[f'{key}_rule_applied']=result['rule_applied']; x[f'{key}_diagnosis']=result['diagnosis']; x[f'{key}_quadrant']=ctx['quadrant_'+key]; x[f'{key}_structure']=label_as_of(cuts[tf]); x.update(safe_zone(result['nearest_bz'],key,'bz'));x.update(safe_zone(result['nearest_sz'],key,'sz'))
   x.update({k:ctx[k] for k in ['bias','allow_long','allow_short','permitted_setup','trade_type_long','trade_type_short','htf_veto_longs','htf_veto_shorts','htf_veto_reason']}); rows.append(x)
 pd.DataFrame(rows).to_csv(OUT/'observations.csv',index=False)
 df=pd.DataFrame(rows)
 if df.empty:return
 episodes=[]
 for (s,tf),g in pd.concat([df.assign(tf=k,eng=df[f'{k}_regime'],ref=df[f'{k}_structure']) for k in 'EAX']).groupby(['symbol','tf']):
  g=g.sort_values('timestamp'); bad=(g.eng.eq('UP')&g.ref.eq('DN'))|(g.eng.eq('DN')&g.ref.eq('UP')); start=None
  for i,(idx,row) in enumerate(g.iterrows()):
   if bad.loc[idx] and start is None:start=i
   if start is not None and (not bad.loc[idx] or i==len(g)-1):
    end=i if bad.loc[idx] else i-1; q=g.iloc[start:end+1]; episodes.append({'symbol':s,'timeframe':tf,'start':q.timestamp.iloc[0],'end':q.timestamp.iloc[-1],'bars':len(q),'engine_regime':q.eng.iloc[0],'structure_regime':q.ref.iloc[0],'rule_applied':q[f'{tf}_rule_applied'].mode().iat[0],'move_pct':q.cmp.iloc[-1]/q.cmp.iloc[0]-1});start=None
 pd.DataFrame(episodes).to_csv(OUT/'disagreement_episodes.csv',index=False)
 summary=[]
 for tf in 'EAX':
  for eng in ['UP','SW','DN']:
   for ref in ['UP','SW','DN']: summary.append({'timeframe':tf,'engine':eng,'reference':ref,'count':int(((df[f'{tf}_regime']==eng)&(df[f'{tf}_structure']==ref)).sum())})
 pd.DataFrame(summary).to_csv(OUT/'confusion_matrix.csv',index=False)
 df.groupby(['E_rule_applied']).size().rename('observations').reset_index().to_csv(OUT/'rule_summary.csv',index=False)
 cases=df[((df.E_regime=='UP')&(df.E_structure=='DN'))|((df.E_regime=='DN')&(df.E_structure=='UP'))].head(10).to_dict('records'); (OUT/'case_studies.json').write_text(json.dumps(cases,default=str,indent=2))
 print(f'wrote {len(df)} observations')
if __name__=='__main__':main()
