"""Independent, audit-only confirmed-pivot market-structure oracle.

It deliberately imports no trend-engine zones or classifications.  A pivot at i
is usable only after RIGHT bars have printed; thus label_as_of never consumes
unconfirmed pivots.
"""
from __future__ import annotations
import pandas as pd

UP, SW, DN = "UP", "SW", "DN"

def confirmed_pivots(df: pd.DataFrame, left: int = 3, right: int = 3):
    """Return confirmed high/low pivots available at df's final bar."""
    highs, lows = df.high.to_list(), df.low.to_list()
    out = []
    # i+right <= final index is the only future information used: confirmation.
    for i in range(left, len(df) - right):
        if highs[i] >= max(highs[i-left:i+right+1]): out.append((i, "H", highs[i]))
        if lows[i] <= min(lows[i-left:i+right+1]): out.append((i, "L", lows[i]))
    return out

def label_as_of(df: pd.DataFrame, left: int = 3, right: int = 3) -> str:
    """UP=last two same-type pivots are HH+HL; DN=LL+LH; else SW."""
    pivots = confirmed_pivots(df, left, right)
    hs = [p for p in pivots if p[1] == "H"][-2:]
    ls = [p for p in pivots if p[1] == "L"][-2:]
    if len(hs) < 2 or len(ls) < 2: return SW
    hh, hl = hs[-1][2] > hs[-2][2], ls[-1][2] > ls[-2][2]
    lh, ll = hs[-1][2] < hs[-2][2], ls[-1][2] < ls[-2][2]
    return UP if hh and hl else DN if lh and ll else SW

def diagnostics(df: pd.DataFrame, n: int = 20) -> dict:
    close = df.close.astype(float)
    ema = close.ewm(span=20, adjust=False).mean()
    pivots = confirmed_pivots(df)
    hi = next((x[2] for x in reversed(pivots) if x[1] == "H"), None)
    lo = next((x[2] for x in reversed(pivots) if x[1] == "L"), None)
    return {"ema20": float(ema.iloc[-1]), "ema20_slope": float(ema.iloc[-1]-ema.iloc[-min(6,len(ema))]),
            "return_n": float(close.iloc[-1]/close.iloc[-min(n,len(close))]-1),
            "range_direction": float(df.high.iloc[-1]-df.low.iloc[-min(n,len(df))]),
            "recent_swing_high": hi, "recent_swing_low": lo,
            "drawdown_from_swing_high": None if not hi else float(close.iloc[-1]/hi-1),
            "rally_from_swing_low": None if not lo else float(close.iloc[-1]/lo-1)}
