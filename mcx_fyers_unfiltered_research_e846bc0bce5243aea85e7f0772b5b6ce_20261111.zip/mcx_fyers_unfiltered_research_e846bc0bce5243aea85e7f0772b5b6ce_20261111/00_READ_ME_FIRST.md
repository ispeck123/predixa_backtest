Read `01_EXECUTIVE/MCX_EXECUTIVE_SUMMARY.md` first. The full SQLite evidence is not duplicated in this ZIP; its immutable path and SHA-256 are in `05_REPRODUCIBILITY/source_database.txt`.
