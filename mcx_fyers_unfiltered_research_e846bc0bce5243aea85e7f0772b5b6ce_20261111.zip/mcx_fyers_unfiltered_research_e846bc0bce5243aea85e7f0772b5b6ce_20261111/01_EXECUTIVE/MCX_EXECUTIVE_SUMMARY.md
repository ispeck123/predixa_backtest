# MCX FYERS Research Submission

Run `e846bc0bce5243aea85e7f0772b5b6ce` completed with `136,653` completed tasks and `957` bounded-retry exclusions. SQLite integrity is `ok`.

Resolved performance: **37,482** trades, **24.09%** win rate, **-754.05R** gross realized R, and **0.9735** R profit factor.

## Scope and limitations

This is `UNFILTERED_RESEARCH_BASELINE` evidence. It uses the research-only gate bypass and does **not** claim historical expiry attribution, expiry-minus-five entry cutoff, expiry-minus-three TIME_EXIT, or verified MCX E1 compliance. `gross_r` is normalized realized R, not cash P&L. Contract multipliers, lot-size history, brokerage, exchange charges, slippage, and net cash P&L are not persisted by this runner and are not fabricated in this submission. The sequential drawdown is an informational ordering of resolved trade R by exit time, not a portfolio-equity calculation for overlapping positions.
