# Detailed findings

## Execution integrity

- Terminal run status: `COMPLETED`.
- No duplicate trade scans: `0`.
- Entries after replay end: `0`.
- Exits after replay end: `0`.
- Resolver gross-R reconciliation is documented by the source run and final sample evidence.

## Failure handling

The failures are retained in the SQLite `errors` table and exported in `03_METRICS`. They are not hidden or treated as wins/losses. Repeated error events reflect the configured bounded retries.

## Data handling

Input manifest and any supplied quality-view evidence are in `04_DATA_QUALITY`. Original FYERS source data was not edited. NSEFO's derived research source view retains whole valid source files and excludes entire malformed source-frame configurations, avoiding a simulated path across a deleted candle.

## Scope and limitations

This is `UNFILTERED_RESEARCH_BASELINE` evidence. It uses the research-only gate bypass and does **not** claim historical expiry attribution, expiry-minus-five entry cutoff, expiry-minus-three TIME_EXIT, or verified MCX E1 compliance. `gross_r` is normalized realized R, not cash P&L. Contract multipliers, lot-size history, brokerage, exchange charges, slippage, and net cash P&L are not persisted by this runner and are not fabricated in this submission. The sequential drawdown is an informational ordering of resolved trade R by exit time, not a portfolio-equity calculation for overlapping positions.
