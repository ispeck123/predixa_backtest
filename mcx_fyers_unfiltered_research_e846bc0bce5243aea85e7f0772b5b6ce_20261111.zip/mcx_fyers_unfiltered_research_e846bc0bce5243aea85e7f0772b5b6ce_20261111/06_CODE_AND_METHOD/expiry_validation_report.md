# Historical expiry and contract-slot validation

## Result

**NOT READY FOR EXPIRY-SENSITIVE REPLAY.** The completed MCX and NSEFO replays used current-expiry-labelled FYERS continuous containers. No selected container stores a historical contract-slot or dated-contract identifier per candle.

## Evidence

- Both current data updaters request FYERS history with `cont_flag=1`.
- The completed replay runners select a single current-expiry-labelled CSV per symbol/timeframe and describe it as stitched/continuous research.
- Filename expiry labels are retained in the coverage CSV solely as current source identifiers; they are not historical exchange expiries.
- Official NSE documentation defines the exchange bhavcopy expiry and contract-master issue/maturity fields; MCX and NSE official retrieval endpoints are listed in the source manifest.

## Required to resolve

1. Official historical contract records for each exchange/symbol/date, staged with checksums and `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER` status.
2. Provider documentation or immutable historical metadata proving whether each continuous container represents NEAR, NEXT, FAR, or another slot at every timestamp.
3. Owner approval to promote exact, non-overlapping slot intervals to `OFFICIAL_VERIFIED`.

Until all three exist, the lookup must return `MISSING_EVIDENCE`; expiry-minus-five entry rejection and expiry-minus-three TIME_EXIT must not be applied by assumption.

## Data protection

This package read SQLite databases using `mode=ro` and read existing OHLC CSVs only. No OHLC file, SQLite file, production gate, live setting, or completed replay was modified.
