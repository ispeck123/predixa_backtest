"""Create a read-only integrity manifest for the FYERS continuous OHLC inputs.

This is deliberately an audit utility, not a loader or normalizer: it never
changes an OHLC file.  It resolves the exact containers selected by the
existing research runners, fingerprints them, and records any coverage or
data-quality issue before a new replay is considered.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

import pandas as pd

from audit.mcx_futures_backtest import run_stitched_grid as mcx_runner
from audit.nsefo_futures_backtest import run_phase_a as nsefo_runner
from audit.nsefo_futures_backtest.preflight import NSEFO_STACKS


REQUIRED_COLUMNS = ("open", "high", "low", "close", "qty", "tradeDate")
FRAME_MINUTES = {
    "five": 5, "fifteen": 15, "twenty_five": 25, "sixty": 60,
    "seventy_five": 75, "one_twenty": 120, "one_twenty_five": 125,
    "two_forty": 240,
}


@dataclass(frozen=True)
class RequiredSource:
    exchange: str
    symbol: str
    strategy_tf: int
    contract_slot: str
    source_expiry_label: str
    timeframe: str
    path: Path
    requested_start: str
    requested_end: str


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _nsefo_config(storage: Path, run_id: str) -> dict:
    uri = f"file:{storage.resolve()}?mode=ro"
    with sqlite3.connect(uri, uri=True) as db:
        row = db.execute("SELECT config_json FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone()
    if row is None:
        raise ValueError(f"locked NSEFO baseline run is absent: {run_id}")
    return json.loads(row[0])


def nsefo_sources(storage: Path, run_id: str) -> tuple[list[RequiredSource], list[dict]]:
    cfg = _nsefo_config(storage, run_id)
    found: list[RequiredSource] = []
    missing: list[dict] = []
    for symbol in cfg["symbols"]:
        for tf in cfg["tfs"]:
            stack = NSEFO_STACKS[int(tf)]
            label = nsefo_runner._canonical_source(symbol, stack, cfg["end"])
            if label is None:
                missing.append({"exchange": "NSEFO", "symbol": symbol, "strategy_tf": tf,
                                "reason": f"no current source with complete stack {','.join(stack)}"})
                continue
            for timeframe in stack:
                found.append(RequiredSource("NSEFO", symbol, int(tf), "CURRENT_CONTINUOUS_CONTAINER", label,
                                            timeframe, nsefo_runner.NSEFO_ROOT / f"{symbol}_{label}_{timeframe}.csv",
                                            cfg["start"], cfg["end"]))
    return found, missing


def mcx_sources() -> tuple[list[RequiredSource], list[dict]]:
    symbols = ("GOLDM", "CRUDEOILM", "SILVERM", "NATGASMINI")
    tfs = (2, 4, 3)
    start, end = "2023-03-14", "2026-11-02"
    found: list[RequiredSource] = []
    missing: list[dict] = []
    for symbol in symbols:
        for tf in tfs:
            stack = mcx_runner.STACKS[tf]
            label = mcx_runner._source(symbol, stack, end)
            if label is None:
                missing.append({"exchange": "MCX", "symbol": symbol, "strategy_tf": tf,
                                "reason": f"no current source with complete stack {','.join(stack)}"})
                continue
            for timeframe in stack:
                found.append(RequiredSource("MCX", symbol, tf, "CURRENT_CONTINUOUS_CONTAINER", label,
                                            timeframe, mcx_runner.MCX_ROOT / f"{symbol}_{label}_{timeframe}.csv",
                                            start, end))
    return found, missing


def _stamp(value: object) -> pd.Timestamp:
    return pd.to_datetime(value, dayfirst=True, errors="coerce")


def inspect(source: RequiredSource) -> dict:
    before = source.path.stat()
    record = {
        "exchange": source.exchange, "symbol": source.symbol, "strategy_tf": source.strategy_tf,
        "contract_slot": source.contract_slot, "source_expiry_label": source.source_expiry_label,
        "timeframe": source.timeframe, "source_file": str(source.path),
        "requested_start": source.requested_start, "requested_end": source.requested_end,
        "file_size": before.st_size, "mtime_ns": before.st_mtime_ns, "sha256": "",
        "row_count": 0, "first_timestamp": "", "last_timestamp": "", "missing_columns": "",
        "invalid_timestamp_count": 0, "duplicate_timestamp_count": 0, "out_of_order_count": 0,
        "invalid_ohlc_count": 0, "negative_price_count": 0, "negative_quantity_count": 0,
        "intra_session_gap_count": 0, "coverage_start_ok": False, "coverage_end_ok": False,
        "snapshot_stable": False, "validation_status": "FAIL",
        "issues": "",
    }
    issues: list[str] = []
    try:
        frame = pd.read_csv(source.path)
        record["row_count"] = len(frame)
        missing = sorted(set(REQUIRED_COLUMNS) - set(frame.columns))
        if missing:
            record["missing_columns"] = ";".join(missing)
            issues.append("missing_required_columns")
        else:
            timestamps = _stamp(frame["tradeDate"])
            record["invalid_timestamp_count"] = int(timestamps.isna().sum())
            valid_ts = timestamps.dropna()
            record["duplicate_timestamp_count"] = int(valid_ts.duplicated().sum())
            record["out_of_order_count"] = int((valid_ts.diff().dropna() < pd.Timedelta(0)).sum())
            if not valid_ts.empty:
                record["first_timestamp"] = valid_ts.min().isoformat()
                record["last_timestamp"] = valid_ts.max().isoformat()
                # Source bars have mixed timestamp conventions: intraday bars
                # are local-session timestamps while daily/weekly/monthly bars
                # may be emitted as a date (and pandas may represent that as
                # UTC midnight).  Replay eligibility is specified by trading
                # date, so compare calendar dates rather than time-of-day.
                start = pd.Timestamp(source.requested_start).date()
                end = pd.Timestamp(source.requested_end).date()
                record["coverage_start_ok"] = bool(valid_ts.min().date() <= start)
                record["coverage_end_ok"] = bool(valid_ts.max().date() >= end)
                minutes = FRAME_MINUTES.get(source.timeframe)
                if minutes:
                    same_day = valid_ts.dt.date.eq(valid_ts.shift().dt.date)
                    record["intra_session_gap_count"] = int(((valid_ts.diff() > pd.Timedelta(minutes=minutes * 3)) & same_day).sum())
            numeric = frame[["open", "high", "low", "close", "qty"]].apply(pd.to_numeric, errors="coerce")
            record["negative_price_count"] = int((numeric[["open", "high", "low", "close"]] < 0).any(axis=1).sum())
            record["negative_quantity_count"] = int((numeric["qty"] < 0).sum())
            record["invalid_ohlc_count"] = int(((numeric["high"] < numeric[["open", "close", "low"]].max(axis=1)) |
                                                (numeric["low"] > numeric[["open", "close", "high"]].min(axis=1)) |
                                                numeric[["open", "high", "low", "close"]].isna().any(axis=1)).sum())
            if record["invalid_timestamp_count"]: issues.append("invalid_timestamp")
            if record["duplicate_timestamp_count"]: issues.append("duplicate_timestamp")
            if record["out_of_order_count"]: issues.append("out_of_order")
            if record["invalid_ohlc_count"]: issues.append("invalid_ohlc")
            if record["negative_price_count"]: issues.append("negative_price")
            if record["negative_quantity_count"]: issues.append("negative_quantity")
            if not record["coverage_start_ok"]: issues.append("does_not_cover_requested_start")
            if not record["coverage_end_ok"]: issues.append("does_not_cover_requested_end")
    except Exception as exc:  # Preserve the failure in the audit artifact.
        issues.append(f"read_error:{type(exc).__name__}:{exc}")
    after = source.path.stat()
    record["snapshot_stable"] = (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
    if not record["snapshot_stable"]:
        issues.append("file_changed_while_validating")
    if not issues:
        record["sha256"] = _sha256(source.path)
        # Hashing is intentionally followed by another stat so a race cannot
        # produce an apparently immutable manifest for a changing source.
        final = source.path.stat()
        record["snapshot_stable"] = record["snapshot_stable"] and (after.st_size, after.st_mtime_ns, after.st_ino) == (final.st_size, final.st_mtime_ns, final.st_ino)
        if not record["snapshot_stable"]:
            issues.append("file_changed_during_hash")
    record["issues"] = ";".join(issues)
    record["validation_status"] = "PASS" if not issues else "FAIL"
    return record


def _write_csv(path: Path, rows: Iterable[dict]) -> None:
    rows = list(rows)
    columns = list(rows[0]) if rows else []
    with path.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="new audit directory; must not already exist")
    parser.add_argument("--nsefo-storage", type=Path, required=True)
    parser.add_argument("--nsefo-run", required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=False)
    nsefo, missing_nsefo = nsefo_sources(args.nsefo_storage, args.nsefo_run)
    mcx, missing_mcx = mcx_sources()
    requirements = nsefo + mcx
    # A physical CSV can support two strategy stacks. Validate it once, then
    # retain all stack references in the manifest for traceability.
    by_path: dict[Path, RequiredSource] = {}
    for item in requirements:
        by_path.setdefault(item.path, item)
    inspected = {path: inspect(item) for path, item in by_path.items()}
    rows = []
    for item in requirements:
        row = dict(inspected[item.path])
        row.update({"strategy_tf": item.strategy_tf, "contract_slot": item.contract_slot,
                    "source_expiry_label": item.source_expiry_label})
        rows.append(row)
    _write_csv(args.output / "fyers_input_manifest.csv", rows)
    missing = missing_nsefo + missing_mcx
    with (args.output / "missing_source_cells.json").open("x", encoding="utf-8") as handle:
        json.dump(missing, handle, indent=2); handle.write("\n")
    counts = Counter(row["validation_status"] for row in rows)
    summary = {
        "created_at_utc": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "manifest_rows": len(rows), "physical_files_checked": len(by_path),
        "status_counts": dict(counts), "missing_source_cells": len(missing),
        "overall_status": "PASS" if counts.get("FAIL", 0) == 0 and not missing else "BLOCKED",
        "data_semantics": "FYERS continuous/stiched containers; current filename expiry labels are not historical contract attribution",
    }
    with (args.output / "summary.json").open("x", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2); handle.write("\n")
    report = "# FYERS Input Snapshot Validation\n\n" + "\n".join(f"- {key}: {value}" for key, value in summary.items()) + "\n"
    (args.output / "VALIDATION_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if summary["overall_status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
