"""Build a read-only evidence package for a completed FYERS research replay."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import zipfile
from pathlib import Path

import pandas as pd

from audit.derivatives_backtest_common.fixed_trade_export import export_fixed_trade_schema


ROOT = Path.cwd()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def copy_if_present(source: Path, target: Path) -> None:
    if source.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def save_frame(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def sample_summary(path: Path) -> dict:
    if not path.is_file():
        return {"present": False}
    with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True) as db:
        run = db.execute("SELECT run_id,status,task_count,completed_count,failed_count,variant_name FROM backtest_runs LIMIT 1").fetchone()
        return {
            "present": True, "sqlite": str(path), "integrity": db.execute("PRAGMA integrity_check").fetchone()[0],
            "run": dict(zip(("run_id", "status", "task_count", "completed_count", "failed_count", "variant_name"), run)),
            "signals": db.execute("SELECT count(*) FROM scan_results WHERE signal_generated=1").fetchone()[0],
            "trades": db.execute("SELECT count(*) FROM simulated_trades").fetchone()[0],
            "errors": db.execute("SELECT count(*) FROM errors").fetchone()[0],
        }


def build(args: argparse.Namespace) -> dict:
    storage = args.storage.resolve()
    output = args.output.resolve()
    archive = args.archive.resolve()
    if output.exists() or archive.exists():
        raise FileExistsError("refusing to overwrite an existing package directory or archive")
    output.mkdir(parents=True)
    dirs = {name: output / name for name in ("01_EXECUTIVE", "02_FULL_REPORT", "03_METRICS", "04_DATA_QUALITY", "05_REPRODUCIBILITY", "06_CODE_AND_METHOD", "07_TRADE_EXPORT", "08_SAMPLE_VALIDATION", "09_LOGS")}
    for directory in dirs.values(): directory.mkdir()
    with sqlite3.connect(f"file:{storage}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        run = db.execute("SELECT * FROM backtest_runs WHERE run_id=?", (args.run,)).fetchone()
        if run is None:
            raise ValueError(f"run not found: {args.run}")
        if run["status"] != "COMPLETED":
            raise ValueError(f"refusing submission for non-terminal run status: {run['status']}")
        config = json.loads(run["config_json"])
        tasks = pd.read_sql_query("SELECT status,count(*) AS count FROM scan_tasks WHERE run_id=? GROUP BY status ORDER BY status", db, params=(args.run,))
        failures = pd.read_sql_query("""SELECT exception_type,exception_message,symbol,timeframe,
                                      count(*) AS error_events, count(DISTINCT task_id) AS tasks
                                      FROM errors WHERE run_id=?
                                      GROUP BY exception_type,exception_message,symbol,timeframe
                                      ORDER BY tasks DESC,error_events DESC""", db, params=(args.run,))
        failure_type = pd.read_sql_query("""SELECT exception_type,exception_message,count(*) AS error_events,
                                          count(DISTINCT task_id) AS tasks
                                          FROM errors WHERE run_id=? GROUP BY exception_type,exception_message
                                          ORDER BY tasks DESC""", db, params=(args.run,))
        scans = pd.read_sql_query("""SELECT strategy_tf,count(*) AS scans,sum(signal_generated) AS signals,
                                   sum(entry_candidate) AS entry_candidates,sum(gate_denied) AS gate_denied
                                   FROM scan_results WHERE run_id=? GROUP BY strategy_tf ORDER BY strategy_tf""", db, params=(args.run,))
        trades = pd.read_sql_query("""SELECT t.*, task.evaluation_timestamp, s.gate_reason
                                    FROM simulated_trades t
                                    JOIN scan_results s ON s.scan_id=t.scan_id
                                    JOIN scan_tasks task ON task.task_id=s.task_id
                                    WHERE s.run_id=? ORDER BY t.trade_id""", db, params=(args.run,))
        source_coverage = pd.read_sql_query("""SELECT strategy_tf,symbol,min(evaluation_timestamp) AS first_timestamp,
                                             max(evaluation_timestamp) AS last_timestamp,count(*) AS tasks
                                             FROM scan_tasks WHERE run_id=? GROUP BY strategy_tf,symbol
                                             ORDER BY strategy_tf,symbol""", db, params=(args.run,))
        gate = pd.read_sql_query("SELECT coalesce(gate_reason,'NULL') AS gate_reason,count(*) AS scans FROM scan_results WHERE run_id=? GROUP BY gate_reason ORDER BY scans DESC", db, params=(args.run,))
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    for col in ("scan_timestamp", "entry_timestamp", "exit_timestamp"):
        trades[col] = pd.to_datetime(trades[col], errors="coerce")
    resolved = trades[trades.exit_price.notna()].copy()
    wins, losses = int((resolved.outcome == "WIN").sum()), int((resolved.outcome == "LOSS").sum())
    positive = float(resolved.loc[resolved.gross_r > 0, "gross_r"].sum())
    negative = float(resolved.loc[resolved.gross_r < 0, "gross_r"].sum())
    ordered = resolved.sort_values("exit_timestamp")
    equity = ordered.gross_r.cumsum()
    drawdown = equity - equity.cummax()
    metrics = pd.DataFrame([{
        "segment": args.segment, "research_mode": config.get("research_mode"), "run_id": args.run,
        "task_count": int(run["task_count"]), "completed_tasks": int(run["completed_count"]), "failed_tasks": int(run["failed_count"]),
        "trades": len(trades), "resolved_trades": len(resolved), "unresolved_trades": int(trades.exit_price.isna().sum()),
        "wins": wins, "losses": losses, "win_rate_pct": 100 * wins / len(resolved) if len(resolved) else None,
        "gross_r_sum": float(resolved.gross_r.sum()), "avg_gross_r": float(resolved.gross_r.mean()) if len(resolved) else None,
        "profit_factor_r": positive / abs(negative) if negative else None,
        "sequential_realized_r_drawdown": float(drawdown.min()) if len(drawdown) else None,
        "sqlite_integrity": integrity, "post_window_entries": int((trades.entry_timestamp > pd.Timestamp(run["historical_end"]) + pd.Timedelta(days=1)).sum()),
        "post_window_exits": int((trades.exit_timestamp > pd.Timestamp(run["historical_end"]) + pd.Timedelta(days=1)).sum()),
        "duplicate_trade_scans": int((trades.groupby("scan_id").size() > 1).sum()),
    }])
    by_tf = resolved.groupby("strategy_tf").agg(trades=("trade_id", "size"), wins=("outcome", lambda x: (x == "WIN").sum()), gross_r=("gross_r", "sum"), avg_gross_r=("gross_r", "mean")).reset_index()
    by_symbol = resolved.groupby("symbol").agg(trades=("trade_id", "size"), wins=("outcome", lambda x: (x == "WIN").sum()), gross_r=("gross_r", "sum"), avg_gross_r=("gross_r", "mean")).reset_index().sort_values("gross_r", ascending=False)
    outcomes = trades.groupby(["strategy_tf", "outcome"]).size().rename("trades").reset_index()
    for name, frame in {"task_status.csv": tasks, "failure_summary.csv": failure_type, "failure_by_symbol_tf.csv": failures, "scan_population_by_tf.csv": scans, "gate_summary.csv": gate, "outcome_distribution.csv": outcomes, "performance_summary.csv": metrics, "performance_by_tf.csv": by_tf, "performance_by_symbol.csv": by_symbol, "source_coverage_by_symbol_tf.csv": source_coverage}.items():
        save_frame(dirs["03_METRICS"] / name, frame)
    save_frame(dirs["07_TRADE_EXPORT"] / "trade_ledger.csv", trades)
    fixed = export_fixed_trade_schema(storage, args.run, args.segment, dirs["07_TRADE_EXPORT"] / f"{args.segment.lower()}_fixed_buy_setup_export.csv")
    sample = sample_summary(args.sample_storage) if args.sample_storage else {"present": False}
    (dirs["08_SAMPLE_VALIDATION"] / "sample_validation.json").write_text(json.dumps(sample, indent=2, default=str) + "\n")
    if args.sample_storage:
        copy_if_present(args.sample_storage, dirs["08_SAMPLE_VALIDATION"] / args.sample_storage.name)
    save_frame(dirs["04_DATA_QUALITY"] / "input_manifest.csv", pd.read_csv(args.input_manifest).query("exchange == @args.segment"))
    for item in args.quality_files:
        copy_if_present(item, dirs["04_DATA_QUALITY"] / item.name)
    db_hash = sha256(storage)
    (dirs["05_REPRODUCIBILITY"] / "run_config.json").write_text(json.dumps(config, indent=2, sort_keys=True) + "\n")
    (dirs["05_REPRODUCIBILITY"] / "source_database.txt").write_text(f"path={storage}\nsha256={db_hash}\nintegrity_check={integrity}\nrun_id={args.run}\n")
    (dirs["05_REPRODUCIBILITY"] / "commands_executed.txt").write_text(args.command + "\n")
    for source in args.code_files:
        copy_if_present(source, dirs["06_CODE_AND_METHOD"] / source.name)
    for source in args.reference_files:
        copy_if_present(source, dirs["06_CODE_AND_METHOD"] / source.name)
    copy_if_present(args.log, dirs["09_LOGS"] / args.log.name)
    limitations = """
## Scope and limitations

This is `UNFILTERED_RESEARCH_BASELINE` evidence. It uses the research-only gate bypass and does **not** claim historical expiry attribution, expiry-minus-five entry cutoff, expiry-minus-three TIME_EXIT, or verified MCX E1 compliance. `gross_r` is normalized realized R, not cash P&L. Contract multipliers, lot-size history, brokerage, exchange charges, slippage, and net cash P&L are not persisted by this runner and are not fabricated in this submission. The sequential drawdown is an informational ordering of resolved trade R by exit time, not a portfolio-equity calculation for overlapping positions.
""".strip()
    executive = f"""# {args.segment} FYERS Research Submission

Run `{args.run}` completed with `{run['completed_count']:,}` completed tasks and `{run['failed_count']:,}` bounded-retry exclusions. SQLite integrity is `{integrity}`.

Resolved performance: **{len(resolved):,}** trades, **{100*wins/max(1,len(resolved)):.2f}%** win rate, **{float(resolved.gross_r.sum()):,.2f}R** gross realized R, and **{positive/abs(negative) if negative else 0:.4f}** R profit factor.

{limitations}
"""
    detailed = f"""# Detailed findings

## Execution integrity

- Terminal run status: `{run['status']}`.
- No duplicate trade scans: `{int((trades.groupby('scan_id').size() > 1).sum())}`.
- Entries after replay end: `{int((trades.entry_timestamp > pd.Timestamp(run['historical_end']) + pd.Timedelta(days=1)).sum())}`.
- Exits after replay end: `{int((trades.exit_timestamp > pd.Timestamp(run['historical_end']) + pd.Timedelta(days=1)).sum())}`.
- Resolver gross-R reconciliation is documented by the source run and final sample evidence.

## Failure handling

The failures are retained in the SQLite `errors` table and exported in `03_METRICS`. They are not hidden or treated as wins/losses. Repeated error events reflect the configured bounded retries.

## Data handling

Input manifest and any supplied quality-view evidence are in `04_DATA_QUALITY`. Original FYERS source data was not edited. NSEFO's derived research source view retains whole valid source files and excludes entire malformed source-frame configurations, avoiding a simulated path across a deleted candle.

{limitations}
"""
    (output / "00_READ_ME_FIRST.md").write_text(f"Read `01_EXECUTIVE/{args.segment}_EXECUTIVE_SUMMARY.md` first. The full SQLite evidence is not duplicated in this ZIP; its immutable path and SHA-256 are in `05_REPRODUCIBILITY/source_database.txt`.\n")
    (dirs["01_EXECUTIVE"] / f"{args.segment}_EXECUTIVE_SUMMARY.md").write_text(executive)
    (dirs["02_FULL_REPORT"] / f"{args.segment}_DETAILED_FINDINGS.md").write_text(detailed)
    checksums = []
    for file in sorted(path for path in output.rglob("*") if path.is_file()):
        checksums.append(f"{sha256(file)}  {file.relative_to(output)}")
    (dirs["05_REPRODUCIBILITY"] / "SHA256SUMS.txt").write_text("\n".join(checksums) + "\n")
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as package:
        for file in sorted(path for path in output.rglob("*") if path.is_file()):
            package.write(file, f"{output.name}/{file.relative_to(output)}")
    return {"package": str(output), "archive": str(archive), "archive_sha256": sha256(archive), "fixed_export": fixed, "database_sha256": db_hash}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--segment", required=True, choices=("MCX", "NSEFO")); p.add_argument("--storage", required=True, type=Path); p.add_argument("--run", required=True)
    p.add_argument("--output", required=True, type=Path); p.add_argument("--archive", required=True, type=Path); p.add_argument("--input-manifest", required=True, type=Path); p.add_argument("--log", required=True, type=Path)
    p.add_argument("--sample-storage", type=Path); p.add_argument("--quality-files", type=Path, nargs="*", default=[]); p.add_argument("--code-files", type=Path, nargs="*", default=[]); p.add_argument("--reference-files", type=Path, nargs="*", default=[]); p.add_argument("--command", required=True)
    args = p.parse_args(argv); print(json.dumps(build(args), indent=2)); return 0


if __name__ == "__main__":
    raise SystemExit(main())
