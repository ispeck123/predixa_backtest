"""Build an immutable research view containing only whole validated FYERS CSVs.

Files with an invalid OHLC envelope are excluded as complete source-frame
configurations.  This avoids editing source data or permitting a simulated
position to jump over a removed bad candle.  Late-starting, otherwise valid
histories are retained and their actual coverage remains in the input
manifest.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import shutil
from pathlib import Path

import pandas as pd


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write(path: Path, rows: list[dict]) -> None:
    columns = list(rows[0]) if rows else ["exchange", "source_file", "reason"]
    with path.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader(); writer.writerows(rows)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path, help="new derived-view directory")
    args = p.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=False)
    frame = pd.read_csv(args.manifest)
    included: list[dict] = []
    excluded: list[dict] = []
    for source_name, rows in frame.groupby("source_file", sort=True):
        first = rows.iloc[0]
        source = Path(source_name)
        issues = set(";".join(rows["issues"].fillna("")).split(";"))
        if "invalid_ohlc" in issues:
            excluded.append({"exchange": first.exchange, "source_file": str(source), "reason": "invalid_ohlc_source_frame_excluded", "references": len(rows)})
            continue
        if not source.is_file():
            excluded.append({"exchange": first.exchange, "source_file": str(source), "reason": "source_missing_at_view_build", "references": len(rows)})
            continue
        target = args.output / str(first.exchange) / "latest_data_csv" / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        src_hash, dst_hash = digest(source), digest(target)
        if src_hash != dst_hash:
            raise RuntimeError(f"copy hash mismatch: {source}")
        included.append({"exchange": first.exchange, "source_file": str(source), "derived_file": str(target), "sha256": src_hash,
                         "references": len(rows), "coverage_issue_retained": "does_not_cover_requested_start" in issues})
    write(args.output / "included_sources.csv", included)
    write(args.output / "excluded_source_configurations.csv", excluded)
    (args.output / "README.md").write_text(
        "# Derived valid-source research view\n\n"
        "This directory is a copy-only research view. Original FYERS CSVs were not changed. "
        "Any physical source frame with an invalid OHLC envelope was excluded in full; "
        "late-starting but structurally valid histories were retained.\n",
        encoding="utf-8",
    )
    print({"included_files": len(included), "excluded_files": len(excluded), "output": str(args.output)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
