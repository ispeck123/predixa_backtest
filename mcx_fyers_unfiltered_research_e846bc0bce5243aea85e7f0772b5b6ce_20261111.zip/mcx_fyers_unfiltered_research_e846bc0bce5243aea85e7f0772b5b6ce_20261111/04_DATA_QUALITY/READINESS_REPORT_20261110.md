# FYERS expiry-aware replay readiness — 10 November 2026

## Decision

**BLOCKED — do not start a sample or full official replay yet.**  This is a
fail-closed research decision.  No OHLC CSV, existing SQLite database,
baseline run, live/paper gate, or production trading configuration was
changed.

## Fresh FYERS source snapshot

The manifest at
`research/backtest_validation/input_manifest/fyers_snapshot_20261110T163000Z/`
was built from a stable, read-only pass over the exact containers selected by
the current research runners.  It contains CSV paths, size, timestamps,
coverage, quality checks and SHA-256 values for every passing physical file.

| Exchange | Stack references | Physical files | Passing references | Failing references |
| --- | ---: | ---: | ---: | ---: |
| MCX | 36 | 20 | 36 | 0 |
| NSEFO | 903 | 605 | 539 | 364 |

The current downloader was not active while the snapshot was made.  The
snapshot rechecked each file's inode, size and modification time before and
after parsing and hashing, so no file that changed during validation is being
treated as immutable.

The FYERS updater code requests continuous history (`cont_flag="1"`).  The
current dated filenames are therefore current container labels for continuous
or stitched histories; they are **not** historical contract identity or expiry
evidence.

## Input blockers

### NSEFO

1. The locked 152-symbol TF2/TF4 replay is missing the TF4 stack for
   `BAJAJ-AUTO`, `M&M`, and `NIFTYNXT50`.  Each lacks the required
   `one_twenty_five` source frame.
2. Forty-two locked symbols do not begin on or before the required
   `2024-10-01` start date.  The affected source references are recorded with
   `does_not_cover_requested_start` in `fyers_input_manifest.csv`.
3. One hundred fifty-three physical source CSVs contain at least one invalid
   OHLC envelope (`high < open/close/low`, `low > open/close/high`, or missing
   price).  They were not repaired, filtered, or rewritten.  Every affected
   source and count is in the manifest.

These are source-data completion/correction requirements.  A fresh provider
download or authoritative provider correction is required; manual candle edits
and interpolation are expressly excluded.

### MCX

All 36 selected stack references pass current CSV integrity and requested-date
coverage.  This alone does not make an expiry-aware replay permissible.

## Historical expiry and slot-attribution gate

* `research/expiry_history/nsefo_official_20241001_20260930/` contains
  218,806 same-day official NSE futures observations for all 152 locked
  symbols: 72,936 NEAR, 72,936 NEXT and 72,934 FAR records across 494
  confirmed source dates.  Every row is deliberately
  `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER`; none is `OFFICIAL_VERIFIED`.
  The source manifest records 28 dates as `MISSING_EVIDENCE`, rather than
  inventing records.
* `research/expiry_history/MCX_historical_expiry_map.csv` contains only its
  schema header.  No historical MCX official expiry records have been
  recovered for GOLDM, CRUDEOILM, SILVERM, or NATGASMINI.
* The current stitched runners select a single current continuous container
  for each symbol/strategy stack and do not resolve a historical
  Near/Next/Far slot per timestamp.  The existing lookup is fail-closed and
  intentionally refuses non-`OFFICIAL_VERIFIED` records.

Therefore the locked `expiry - 5` entry cutoff, `expiry - 3` TIME_EXIT, and
MCX E1 cannot yet be applied truthfully to a historical contract.  A raw
stitched smoke run would not validate those rules and is not an authorized
substitute for the expiry-aware sample.

## Preservation and verification

The completed unfiltered baselines remain comparison-only and passed SQLite
integrity checks:

* `audit/mcx_futures_backtest/storage/mcx_stitched_grid_research_bypass_full_20261108.sqlite`
* `audit/nsefo_futures_backtest/storage/nsefo_tf2_tf4_research_bypass_full_20261108.sqlite`

Focused expiry/parser tests passed: `5 passed`.  These tests confirm the
fail-closed lookup and official NSE parser behaviour; they do not promote any
expiry record to verified status.

## Required next evidence before execution

1. Complete/correct the three missing NSEFO TF4 frames, all 42 incomplete
   historical ranges, and the 153 malformed provider source files by a fresh
   authoritative download.  Then regenerate a new immutable manifest.
2. Obtain the MCX historical expiry calendar from official MCX records for the
   four locked symbols, with source hashes and the required historical window.
3. Complete the owner verification procedure for the official NSE map and the
   MCX map.  Do not change statuses merely to pass a runner gate.
4. Establish and document timestamp-level slot attribution between the FYERS
   continuous containers and the historical official Near/Next/Far records.
5. Only after items 1--4 pass, integrate the research-only expiry layer and
   run isolated expiry-aware samples.  Full MCX and NSEFO runs may then start
   independently when their own sample gates pass.
