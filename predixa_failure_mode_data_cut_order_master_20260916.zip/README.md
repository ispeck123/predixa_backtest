# PREDIXA failure-mode data cut — order master scope

This cut includes every completed (`success` or `failed`) row in `outputs/cash_order_master_engine_rerun_20260901_141530/all_orders_engine_enriched.csv`. It contains 22 completed orders. Phase 2/Phase 1 forensic records are joined by Order ID where available; unmatched orders are retained with empty bar paths and `BAR_PATH_UNAVAILABLE`.

The order master is authoritative for order identity, symbol, direction, entry, target, stop, timestamps, outcome, and entry tertile. No conclusions are changed. `entry_zone_width_pct` remains null because proximal/distal zone boundaries are not present in the order-master or joined forensic record.

A sequence flag is left null when the required stop/bar sequence cannot be established from the available OHLC path. This avoids treating missing evidence as a clean loss.
