# MCX TF5 / W-D-60 submission package

Run ID: `5705025a58b64afbb127a82b12a3ca9e`. The replay completed 2026-11-17. This archive contains the detailed evaluation report, all read-only run exports, standalone SQLite backup, full execution log, expiry map, source OHLC containers, sample-run validation, code snapshot, and SHA-256 manifests.

## Interpretation
The completed run is provisional research, not a validated final performance result. The strict expiry validator stopped on a SILVERM Sunday timestamp (2026-02-01) with no matching bhavcopy session; seven persisted trades used that Sunday candle. Fourteen other trades remain unresolved. The expiry map is a bhavcopy mirror pending official validation. The report documents all limitations and does not hide failed tasks.

## Integrity
The bundled full-run SQLite backup passes `PRAGMA integrity_check`. Original SQLite and OHLC source files were opened read-only and were not modified. `package_manifest.json` hashes the package contents (excluding itself); the ZIP checksum is provided alongside the archive.
