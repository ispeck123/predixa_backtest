from audit.derivatives_backtest_common.continuous_segment_filters import MCX_STACKS as FILTER_STACKS
from audit.mcx_futures_backtest.preflight import MCX_STACKS as PREFLIGHT_STACKS
from audit.mcx_futures_backtest.run_phase_a import MCX_STACKS as PHASE_A_STACKS
from audit.mcx_futures_backtest.run_stitched_grid import STACK_NAMES, STACKS
from shared.config.settings import stock_logic_config


def test_commodity_tf5_is_w_d_60_across_audit_stack_maps():
    expected = tuple(stock_logic_config.COMMODITY_TIME_FRAME_5)
    assert expected == ("weekly", "daily", "sixty")
    assert STACKS[5] == expected
    assert STACK_NAMES[5] == "W-D-60"
    assert PREFLIGHT_STACKS[5] == expected
    assert PHASE_A_STACKS[5] == expected
    assert FILTER_STACKS[5] == expected
