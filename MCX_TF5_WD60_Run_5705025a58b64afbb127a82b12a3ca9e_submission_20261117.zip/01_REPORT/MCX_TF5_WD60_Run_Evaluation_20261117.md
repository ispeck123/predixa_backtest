# MCX TF5 / W-D-60 Full Run Evaluation

**Prepared:** 2026-11-17  
**Run ID:** `5705025a58b64afbb127a82b12a3ca9e`  
**Run status:** Completed; all registered tasks are terminal, including failed tasks.

> **Evaluation conclusion:** The replay completed and the SQLite database is structurally sound, but this is not a fully validated final performance result. Seven SILVERM trades executed on Sunday 2026-02-01 using Sunday candles in the input series. The strict expiry validator fails because the bhavcopy map has no Sunday observation. The map is a bhavcopy mirror pending official validation and owner approval. Treat these results as provisional research only.

## Run configuration

- Replay period: 2023-03-14 through 2026-11-02.
- Instruments: GOLDM, CRUDEOILM, SILVERM, NATGASMINI.
- Strategy timeframe: TF5, **weekly / daily / 60-minute (W-D-60)**.
- Process executor with 24 workers; BUY-only.
- Research gate bypass enabled for this audit runner only.
- Research mode: `PROVISIONAL_EXPIRY_AWARE_NEAR_SLOT_ASSUMPTION`.
- Slot attribution assumption: the current FYERS continuous container is treated as the observed NEAR slot; historical contract identity is attached from the separate daily bhavcopy mirror.
- Expiry map state: `MIRROR_OF_MCX_BHAVCOPY_PENDING_OFFICIAL_VALIDATION`.
- Expiry map SHA-256: `bfeae0e24ff381c2bf1fa9e5a0f39e00085ddfc5eb5f2246e597d5506203f0d2`.
- Run metadata records code revision `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`, branch `prod`, seed `20261111`.

## Execution and coverage

- Tasks registered: 54,200; completed: 53,408; failed: 792.
- Failed task containers: CRUDEOILM 321; NATGASMINI 471; GOLDM and SILVERM 0.
- Input coordinator excluded 100 evaluation timestamps without same-day expiry-map observations; 54,200 tasks were registered.
- Signals: 18,679; setup records: 18,679.
- SQLite `PRAGMA integrity_check`: `ok`.
- The error table contains retry-attempt records, so its row count exceeds the 792 final failed-task count. The main groups are insufficient E-TF warm-up (1–6 bars where 7 are required) and `single positional indexer is out-of-bounds` (180 error attempts).

## Setup disposition

| Disposition | Count |
|---|---:|
| Allowed | 3,207 |
| E1 gap | 3,098 |
| Entry window closed | 12,135 |
| RR below 2.1 | 239 |

These are setup dispositions from the run records. The entry cutoff is expiry minus five observed sessions; the forced exit is expiry minus three observed sessions.

## Trade outcomes and gross R

- Persisted trade rows: 3,206; 2,729 resolved WIN/LOSS trades; 463 `TIME_EXIT`; 14 `UNRESOLVED`.
- WIN: 264; LOSS: 2,465; resolved WIN/LOSS win rate: **9.67%**.
- Gross realized result, excluding unresolved rows and costs: **-1,181.332 R**.
- Mean gross R across trades with realized R: -0.3701 R.
- Gross-R profit factor: 0.528.
- Event-ordered cumulative-R drawdown diagnostic: 1,181.33 R. This is not a capital or portfolio drawdown: it assumes equal risk per trade and sequences overlapping multi-symbol trades by exit timestamp.
- No currency P&L, historical lot-size scaling, brokerage, exchange costs, or slippage adjustment is asserted.

### Per-instrument summary

| Instrument container | Trades | Wins | Losses | TIME_EXIT | Unresolved | Win rate (W/L only) | Gross R* |
|---|---:|---:|---:|---:|---:|---:|---:|
| CRUDEOILM@19112026 | 785 | 84 | 681 | 20 | 0 | 10.98% | -405.908 |
| GOLDM@04122026 | 455 | 12 | 239 | 204 | 0 | 4.78% | 149.467 |
| NATGASMINI@24112026 | 892 | 101 | 721 | 70 | 0 | 12.29% | -477.024 |
| SILVERM@30112026 | 1,009 | 67 | 824 | 169 | 14 | 7.52% | -447.867 |

*Gross R excludes unresolved trades and transaction costs. The `@...` suffix is the filename/container label, not proof that all historical bars belong to that single expiry.

TIME_EXIT outcomes: 463 trades, +580.342 R total, mean +1.253 R. The 14 unresolved trades contribute no realized R and remain separately counted.

## Expiry and E1 audit

The runner’s strict full-run validator was executed and **did not pass**. It stopped at:

```text
KeyError: no MCX NEAR expiry observation for SILVERM on 2026-02-01
```

A separate read-only audit continued record-by-record and found:

- Setup timestamps missing a map observation: 0.
- Trade entry timestamps missing a map observation: 7, all SILVERM on Sunday 2026-02-01.
- Mapped eligible setup / trade entry-cutoff violations: 0.
- Mapped TIME_EXIT date mismatches: 0.
- Duplicate setup-to-trade groups: 0.
- Non-TIME_EXIT trades crossing the MCX E1 seam: 0.
- Mandatory `TIME_EXIT` trades crossing the E1 seam and retained by the runner’s forced-exit exception: 463.
- Provisional terminal NEAR segments beyond the replay end: 4 (one per required symbol); the map has observed sessions after the replay end sufficient for this window’s control dates, but the contracts themselves are not observed through their later expiry dates.

The seven unmapped Sunday trades prevent an overall expiry-compliance pass. The fact that mapped rows show no cutoff or forced-exit date mismatch does not resolve those unmapped executions.

## Source-data finding

The exact selected SILVERM 60-minute source file is:

```text
data/indian_commodity_data/latest_data_csv/SILVERM_30112026_sixty.csv
```

It contains 60-minute rows timestamped Sunday 2026-02-01 from 09:00 through 23:00 IST. Repeated flat prices occur after 10:00. The completed ledger contains seven SILVERM trades entered and exited at 09:00 on that Sunday; all seven are LOSS, totaling -7.0 R. No MCX bhavcopy NEAR observation exists for that Sunday.

The weekly, daily, and 60-minute input files were inspected read-only. Their hashes, row/date coverage, weekend counts, and weekend candle rows are in `source_file_manifest.csv` and `weekend_source_candles.csv`. No source OHLC values were changed.

## Sample and validation results

- TF5 sample run: `11e0ca07345a4c62bf8f34eeccc51e1f`.
- 100 sample tasks completed (25 per instrument), yielding 50 signals and 25 trades. The 25 trades were all losses.
- The sample validator passed: SQLite integrity `ok`; zero cutoff violations, zero discretionary E1 crossing trades, zero duplicate trades, and no task errors.
- The sample had no TIME_EXIT events and does not detect the full-run Sunday execution defect.
- Full-run validator: **failed / not fully evaluable** on the missing Sunday SILVERM expiry observation.

## Artifacts

- SQLite database: `research/fyers_backtest_execution_20261117/MCX_full/mcx_tf5_wd60_expiry_aware_full_20261117.sqlite`
- Run log: `logs/mcx_tf5_wd60_full_20261117.log`
- Input exclusion ledger: `research/fyers_backtest_execution_20261117/MCX_full/mcx_tf5_wd60_expiry_aware_full_20261117.sqlite.input_exclusions.json`
- Expiry map: `research/expiry_history/mcx_bhavcopy_mirror_provisional_extended_20261111/MCX_historical_expiry_map_provisional.csv`
- Evaluation outputs in this directory: `evaluation_summary.json`, `validation_checks.json`, `trade_export.csv`, `setup_export.csv`, `failed_tasks.csv`, `error_records.csv`, `setup_disposition.csv`, `symbol_performance.csv`, `monthly_gross_r.csv`, `source_file_manifest.csv`, and `weekend_source_candles.csv`.

## Final assessment

The run is technically complete and its database is intact. It produced 3,206 trade records and a provisional gross result of -1,181.332 R. This is **not a validated final performance conclusion**: seven SILVERM entries used Sunday data and cannot be matched to the expiry map; 14 other trades remain unresolved; task failures and the unverified mirror calendar remain disclosed. Keep this run as a completed provisional research artifact. Do not promote it as expiry-certified strategy performance. A reliable final screen requires an approved handling policy for non-session candles and a rerun with the source/session issue addressed.
