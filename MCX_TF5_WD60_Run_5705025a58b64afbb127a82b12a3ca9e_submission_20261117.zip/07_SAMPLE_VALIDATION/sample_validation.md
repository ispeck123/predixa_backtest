# MCX provisional expiry-aware sample validation

- Run: `11e0ca07345a4c62bf8f34eeccc51e1f`
- Status: `COMPLETED`
- Pass: `True`
- SQLite integrity: `ok`
- Entry-cutoff violations: 0
- E1-crossing discretionary trades: 0
- TIME_EXIT trades: 0
- TIME_EXIT records retained despite an overnight seam: 0
- Known warm-up errors only: `True`

This is provisional research: the FYERS continuous container is explicitly treated as the observed MCX NEAR slot; the bhavcopy mirror remains pending official validation.
