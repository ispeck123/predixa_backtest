"""Export resolved CASH replay trades in the live tracking-cell schema.

This utility is deliberately read-only: it never invokes ``process_setup`` or
the trend engine.  E/A regimes are the values captured by the production
pipeline at the historical scan/setup timestamp and stored in
``regime_snapshots`` during the baseline run.

The original pilot schema retained the selected setup's ``zone_id`` and a
contemporaneous zone snapshot, but not the literal ``zone_signature`` string.
For those historical rows this exporter reconstructs the documented live
format ``SYMBOL:X:proximal:distal`` from that *persisted* selected-zone
snapshot.  It exposes source/status columns so consumers do not confuse this
with a raw string emitted by a later replay version.
"""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

import pandas as pd


REQUIRED_COLUMNS = [
    "stock", "time_frame", "strategy_tf", "e_regime", "a_regime", "side",
    "entry", "stop", "target", "result", "gross_r", "zone_signature",
]


def _format_bound(value: object) -> str:
    """Match the production signature's two-decimal zone-bound rounding."""
    return str(round(float(value), 2))


def _zone_signature(row: pd.Series) -> tuple[str | None, str]:
    """Return a traceable live-format signature from persisted X-zone state."""
    if pd.notna(row.get("raw_zone_signature")) and str(row["raw_zone_signature"]).strip():
        return str(row["raw_zone_signature"]), "EMITTED_BY_PIPELINE_AT_SETUP_TIME"
    if pd.isna(row.get("selected_zone_id")):
        return None, "UNAVAILABLE_NO_SELECTED_SETUP_ZONE_ID"
    if pd.isna(row.get("zone_proximal")) or pd.isna(row.get("zone_distal")):
        return None, "UNAVAILABLE_NO_MATCHING_PERSISTED_X_ZONE"
    return (
        f"{row['stock']}:X:{_format_bound(row['zone_proximal'])}:{_format_bound(row['zone_distal'])}",
        "RECONSTRUCTED_FROM_PERSISTED_SELECTED_X_ZONE",
    )


def _accepted_backfill(backfill_storage: Path | None) -> dict[int, str]:
    """Read only validated, pinned-pipeline backfill emissions."""
    if backfill_storage is None:
        return {}
    with sqlite3.connect(backfill_storage) as connection:
        rows = connection.execute("SELECT trade_id,signature FROM backfill_tasks WHERE status='MATCHED' AND signature IS NOT NULL").fetchall()
    return {int(trade_id): str(signature) for trade_id, signature in rows}


def export_cash_tracking_cells(storage: Path, run_id: str, output: Path,
                                backfill_storage: Path | None = None) -> pd.DataFrame:
    """Emit one WIN/LOSS trade row with current live-compatible tracking keys."""
    with sqlite3.connect(storage) as connection:
        setup_columns = {row[1] for row in connection.execute("PRAGMA table_info(setup_results)")}
    raw_signature = "su.zone_signature AS raw_zone_signature" if "zone_signature" in setup_columns else "NULL AS raw_zone_signature"
    sql = f"""
    SELECT
        t.trade_id,
        t.symbol AS stock,
        t.strategy_tf AS strategy_tf,
        st.strategy_tf_name AS time_frame,
        t.scan_timestamp,
        t.setup_timestamp,
        t.entry_timestamp,
        t.exit_timestamp,
        t.side,
        t.entry_price AS entry,
        t.stop_price AS stop,
        t.target_price AS target,
        t.outcome,
        t.gross_r,
        r.E_regime AS e_regime,
        r.A_regime AS a_regime,
        r.X_regime AS x_regime,
        su.zone_id AS selected_zone_id,
        {raw_signature},
        z.proximal AS zone_proximal,
        z.distal AS zone_distal
    FROM simulated_trades t
    JOIN scan_results s ON s.scan_id = t.scan_id
    JOIN scan_tasks st ON st.task_id = s.task_id
    JOIN regime_snapshots r ON r.scan_id = s.scan_id
    LEFT JOIN setup_results su ON su.setup_id = t.setup_id
    LEFT JOIN zone_snapshots z
      ON z.scan_id = t.scan_id
     AND z.timeframe = 'X'
     AND z.zone_id = su.zone_id
    WHERE s.run_id = ?
      AND t.outcome IN ('WIN', 'LOSS')
    ORDER BY t.trade_id
    """
    with sqlite3.connect(storage) as connection:
        frame = pd.read_sql_query(sql, connection, params=[run_id])

    accepted_backfill = _accepted_backfill(backfill_storage)
    if frame.empty:
        result = frame.copy()
        result["result"] = pd.Series(dtype="string")
        result["zone_signature"] = pd.Series(dtype="string")
        result["zone_signature_source"] = pd.Series(dtype="string")
    else:
        # The requested SUCCESS/FAIL labels are a presentation mapping only;
        # original production-compatible WIN/LOSS is retained for audit trace.
        result = frame.copy()
        result["result"] = result["outcome"].map({"WIN": "SUCCESS", "LOSS": "FAIL"})
        signatures = result.apply(_zone_signature, axis=1, result_type="expand")
        result["zone_signature"] = signatures[0]
        result["zone_signature_source"] = signatures[1]
        if accepted_backfill:
            backfilled = result["trade_id"].map(accepted_backfill)
            replace = backfilled.notna()
            result.loc[replace, "zone_signature"] = backfilled[replace]
            result.loc[replace, "zone_signature_source"] = "EMITTED_BY_PINNED_PIPELINE_BACKFILL"

    result["segment"] = "CASH"
    ordered = REQUIRED_COLUMNS + [
        "trade_id", "outcome", "x_regime", "scan_timestamp", "setup_timestamp",
        "entry_timestamp", "exit_timestamp", "selected_zone_id", "zone_proximal",
        "zone_distal", "raw_zone_signature", "zone_signature_source", "segment",
    ]
    # Preserve every requested primary field even for an empty run.
    for column in ordered:
        if column not in result:
            result[column] = pd.Series(dtype="object")
    result = result[ordered]
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--run", required=True, help="Completed CASH replay run ID")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--signature-backfill", type=Path,
                        help="Optional pinned-version backfill SQLite evidence database")
    args = parser.parse_args(argv)
    frame = export_cash_tracking_cells(args.storage, args.run, args.output, args.signature_backfill)
    sources = frame["zone_signature_source"].value_counts(dropna=False).to_dict()
    print(f"exported {len(frame):,} resolved CASH trades to {args.output}")
    print(f"zone_signature_source={sources}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
