"""Resumable, pinned-version CASH setup-signature backfill.

This is audit infrastructure, not a new backtest.  It replays only the
original resolved-trade scan timestamps using an isolated Git worktree pinned
to the baseline run's commit.  A signature is accepted only when the returned
pipeline context matches the stored trade's E/A regimes, selected setup zone,
and proposed entry/stop/target within a small numeric tolerance.
"""
from __future__ import annotations

import argparse
import contextlib
import concurrent.futures
import json
import logging
import os
import sqlite3
import subprocess
import sys
import time
import traceback
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

import pandas as pd


TF_STACKS = {
    1: ["monthly", "weekly", "daily"],
    2: ["weekly", "daily", "sixty"],
    5: ["weekly", "daily", "one_twenty_five"],
    6: ["daily", "one_twenty_five", "twenty_five"],
    25: ["weekly", "daily", "seventy_five"],
}
SCHEMA = """
CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS backfill_tasks (
 trade_id INTEGER PRIMARY KEY, source_run_id TEXT NOT NULL, symbol TEXT NOT NULL,
 strategy_tf INTEGER NOT NULL, scan_timestamp TEXT NOT NULL,
 expected_e_regime TEXT, expected_a_regime TEXT, expected_zone_id TEXT,
 expected_entry REAL, expected_stop REAL, expected_target REAL,
 status TEXT NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0,
 signature TEXT, pipeline_zone_id TEXT, pipeline_e_regime TEXT, pipeline_a_regime TEXT,
 pipeline_entry REAL, pipeline_stop REAL, pipeline_target REAL,
 validation_detail TEXT, error_type TEXT, error_message TEXT, updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_backfill_status ON backfill_tasks(status, trade_id);
"""


def _value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if hasattr(value, "value"):
        return value.value
    return value


def _get(obj: Any, name: str) -> Any:
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def _numeric_match(left: Any, right: Any, tolerance: float = 1e-8) -> bool:
    try:
        return abs(float(left) - float(right)) <= tolerance
    except (TypeError, ValueError):
        return False


def _worker(task: dict[str, Any], worktree: str) -> dict[str, Any]:
    """Invoke the exact baseline checkout's production pipeline as of T."""
    try:
        os.chdir(worktree)
        logging.disable(logging.CRITICAL)
        if worktree not in sys.path:
            sys.path.insert(0, worktree)
        # Worker processes are fresh.  Defensive removal prevents a parent
        # import from accidentally selecting the active checkout instead.
        for module in list(sys.modules):
            if module == "scripts" or module.startswith("scripts.") or module == "shared" or module.startswith("shared."):
                del sys.modules[module]
        from scripts.setup_engine_new import process_setup

        # Historical production code is verbose.  Its stdout is not evidence
        # and would corrupt the coordinator's progress output.
        with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            result = process_setup(task["symbol"], TF_STACKS[int(task["strategy_tf"])], pd.Timestamp(task["scan_timestamp"]).to_pydatetime())
        if isinstance(result, str):
            raise RuntimeError(result)
        proposal = result.get("best_setup_long")
        context = result.get("trend_context")
        if proposal is None or context is None:
            return {"trade_id": task["trade_id"], "status": "NO_PIPELINE_SETUP", "detail": "best_setup_long or trend_context absent"}
        raw_signature = _value(_get(proposal, "zone_signature"))
        if raw_signature and len(str(raw_signature).split(":")) >= 4:
            # ``format_result`` is what changes the engine-internal TEST
            # prefix to the stock name in the live export.  Retain that exact
            # stable-signature convention without changing any zone bounds.
            signature = f"{task['symbol']}:" + ":".join(str(raw_signature).split(":")[-3:])
        else:
            signature = raw_signature
        observed = {
            "signature": signature,
            "zone_id": _value(_get(proposal, "zone_id")),
            "e_regime": _value(_get(context, "regime_E")),
            "a_regime": _value(_get(context, "regime_A")),
            "entry": _value(_get(proposal, "entry_price")),
            "stop": _value(_get(proposal, "stop_price")),
            "target": _value(_get(proposal, "target_price")),
        }
        checks = {
            "e_regime": observed["e_regime"] == task["expected_e_regime"],
            "a_regime": observed["a_regime"] == task["expected_a_regime"],
            "zone_id": str(observed["zone_id"]) == str(task["expected_zone_id"]),
            "entry": _numeric_match(observed["entry"], task["expected_entry"]),
            "stop": _numeric_match(observed["stop"], task["expected_stop"]),
            "target": _numeric_match(observed["target"], task["expected_target"]),
            "signature": bool(observed["signature"] and str(observed["signature"]).strip()),
        }
        # Source OHLC files are live/stitched and may be revised after a run.
        # For a signature backfill, its identity is established by the same
        # E/A context and selected setup zone ID.  Price comparisons remain in
        # the evidence but are intentionally not used to replace the selected
        # zone with a different one.
        identity_keys = ("e_regime", "a_regime", "zone_id", "signature")
        status = "MATCHED" if all(checks[key] for key in identity_keys) else "MISMATCH"
        return {"trade_id": task["trade_id"], "status": status, "detail": json.dumps({"checks": checks}, sort_keys=True), **observed}
    except Exception as exc:  # Error is evidence; never conceal failed replay.
        return {"trade_id": task["trade_id"], "status": "ERROR", "detail": traceback.format_exc(), "error_type": type(exc).__name__, "error_message": str(exc)}


def _commit(worktree: Path) -> str:
    return subprocess.check_output(["git", "-C", str(worktree), "rev-parse", "HEAD"], text=True).strip()


def _prepare(base_storage: Path, run_id: str, backfill_storage: Path, worktree: Path,
             missing_only: bool) -> sqlite3.Connection:
    with sqlite3.connect(base_storage) as source:
        run = source.execute("SELECT git_commit FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError(f"Unknown baseline run ID: {run_id}")
        baseline_commit = run[0]
        if _commit(worktree) != baseline_commit:
            raise ValueError(f"Worktree commit {_commit(worktree)} does not match baseline commit {baseline_commit}")
        filter_missing = """AND NOT EXISTS (
            SELECT 1 FROM zone_snapshots z
            WHERE z.scan_id=t.scan_id AND z.timeframe='X' AND z.zone_id=su.zone_id
        )""" if missing_only else ""
        tasks = pd.read_sql_query(f"""
            SELECT t.trade_id, s.run_id source_run_id, t.symbol, t.strategy_tf, t.scan_timestamp,
                   r.E_regime expected_e_regime, r.A_regime expected_a_regime, su.zone_id expected_zone_id,
                   t.entry_price expected_entry, t.stop_price expected_stop, t.target_price expected_target
            FROM simulated_trades t
            JOIN scan_results s ON s.scan_id=t.scan_id
            JOIN regime_snapshots r ON r.scan_id=s.scan_id
            JOIN setup_results su ON su.setup_id=t.setup_id
            WHERE s.run_id=? AND t.outcome IN ('WIN','LOSS') {filter_missing}
            ORDER BY t.trade_id
        """, source, params=[run_id])
    connection = sqlite3.connect(backfill_storage, timeout=60)
    connection.executescript(SCHEMA)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("INSERT OR REPLACE INTO metadata VALUES (?,?)", ("baseline_commit", baseline_commit))
    connection.execute("INSERT OR REPLACE INTO metadata VALUES (?,?)", ("baseline_run_id", run_id))
    connection.executemany("""INSERT OR IGNORE INTO backfill_tasks
        (trade_id,source_run_id,symbol,strategy_tf,scan_timestamp,expected_e_regime,expected_a_regime,expected_zone_id,expected_entry,expected_stop,expected_target)
        VALUES (:trade_id,:source_run_id,:symbol,:strategy_tf,:scan_timestamp,:expected_e_regime,:expected_a_regime,:expected_zone_id,:expected_entry,:expected_stop,:expected_target)""", tasks.to_dict("records"))
    connection.commit()
    return connection


def _counts(connection: sqlite3.Connection) -> dict[str, int]:
    rows = connection.execute("SELECT status,count(*) FROM backfill_tasks GROUP BY status").fetchall()
    out = {name: count for name, count in rows}
    out["TOTAL"] = sum(out.values())
    return out


def _claim(connection: sqlite3.Connection, limit: int) -> list[dict[str, Any]]:
    rows = connection.execute("SELECT * FROM backfill_tasks WHERE status IN ('PENDING','RETRY') ORDER BY trade_id LIMIT ?", (limit,)).fetchall()
    if not rows:
        return []
    ids = [row[0] for row in rows]
    connection.executemany("UPDATE backfill_tasks SET status='RUNNING',attempts=attempts+1 WHERE trade_id=?", [(key,) for key in ids])
    connection.commit()
    return [dict(zip([description[0] for description in connection.execute("SELECT * FROM backfill_tasks LIMIT 0").description], row)) for row in rows]


def _save(connection: sqlite3.Connection, result: dict[str, Any]) -> None:
    connection.execute("""UPDATE backfill_tasks SET status=?,signature=?,pipeline_zone_id=?,pipeline_e_regime=?,pipeline_a_regime=?,pipeline_entry=?,pipeline_stop=?,pipeline_target=?,validation_detail=?,error_type=?,error_message=?,updated_at=datetime('now') WHERE trade_id=?""",
                       (result["status"], result.get("signature"), result.get("zone_id"), result.get("e_regime"), result.get("a_regime"), result.get("entry"), result.get("stop"), result.get("target"), result.get("detail"), result.get("error_type"), result.get("error_message"), result["trade_id"]))


def run(args: argparse.Namespace) -> int:
    args.worktree = args.worktree.resolve()
    database = _prepare(args.base_storage, args.run, args.backfill_storage, args.worktree,
                        args.missing_only)
    database.execute("UPDATE backfill_tasks SET status='PENDING' WHERE status='RUNNING'")
    database.commit()
    initial = _counts(database)
    print(f"Backfill universe: {initial['TOTAL']:,} resolved CASH trades; existing={initial}", flush=True)
    started = time.monotonic(); completed = 0; last = started
    remaining_limit = args.limit
    try:
        with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
            while True:
                if remaining_limit is not None and remaining_limit <= 0:
                    break
                batch_size = args.workers * 2 if remaining_limit is None else min(args.workers * 2, remaining_limit)
                pending = _claim(database, batch_size)
                if not pending:
                    break
                futures = [pool.submit(_worker, task, str(args.worktree)) for task in pending]
                for future in concurrent.futures.as_completed(futures):
                    _save(database, future.result())
                    completed += 1
                database.commit()
                if remaining_limit is not None:
                    remaining_limit -= len(pending)
                now = time.monotonic()
                if now - last >= args.progress_seconds:
                    c = _counts(database); rate = completed / max(now - started, .001)
                    print(f"Backfill: {c.get('MATCHED',0)+c.get('MISMATCH',0)+c.get('ERROR',0)+c.get('NO_PIPELINE_SETUP',0):,}/{c['TOTAL']:,}; matched={c.get('MATCHED',0):,}; mismatch={c.get('MISMATCH',0):,}; errors={c.get('ERROR',0):,}; rate={rate:.2f}/s", flush=True)
                    last = now
    except KeyboardInterrupt:
        database.execute("UPDATE backfill_tasks SET status='PENDING' WHERE status='RUNNING'")
        database.commit()
        print("Interrupted safely. Resume with the same command.", file=sys.stderr, flush=True)
        return 130
    finally:
        print(json.dumps(_counts(database), indent=2), flush=True)
        database.close()
    return 0


def status(args: argparse.Namespace) -> int:
    with sqlite3.connect(args.backfill_storage) as database:
        print(json.dumps(_counts(database), indent=2))
        for key, value in database.execute("SELECT key,value FROM metadata ORDER BY key"):
            print(f"{key}={value}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--backfill-storage", type=Path, required=True)
    run_parser = sub.add_parser("run", parents=[common])
    run_parser.add_argument("--base-storage", type=Path, required=True)
    run_parser.add_argument("--run", required=True)
    run_parser.add_argument("--worktree", type=Path, required=True)
    run_parser.add_argument("--workers", type=int, default=4)
    run_parser.add_argument("--progress-seconds", type=float, default=15)
    run_parser.add_argument("--limit", type=int,
                            help="Process at most N unfinished rows; use only for smoke validation")
    run_parser.add_argument("--missing-only", action="store_true", default=True,
                            help="Backfill only trades without a persisted selected X-zone snapshot (default)")
    run_parser.add_argument("--all-resolved", dest="missing_only", action="store_false",
                            help="Re-emit signatures for every resolved trade; slower and normally unnecessary")
    status_parser = sub.add_parser("status", parents=[common])
    args = parser.parse_args(argv)
    return run(args) if args.command == "run" else status(args)


if __name__ == "__main__":
    raise SystemExit(main())
