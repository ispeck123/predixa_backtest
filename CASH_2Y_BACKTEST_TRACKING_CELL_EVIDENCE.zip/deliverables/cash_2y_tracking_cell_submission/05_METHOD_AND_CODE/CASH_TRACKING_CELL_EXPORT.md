# Cash backtest tracking-cell export

This is the CASH-only export requested for live-vs-backtest tracking cells.
It does not apply to NSEFO or MCX.

## Source and timing

`export_cash_tracking_cells.py` reads an already completed CASH replay SQLite
database. It does not invoke `process_setup()`, calculate zones, or recalculate
trend. For each resolved simulated trade, `e_regime` and `a_regime` are copied
from `regime_snapshots`, which was written from the current production
pipeline's `TrendContext` at the same historical scan/setup timestamp captured
on the trade row.

## Command

```bash
python -m audit.fresh_trend_backtest.export_cash_tracking_cells \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run d6e50e96d56642d6864700a2bedfcdda \
  --output audit/fresh_trend_backtest/results/current_engine_2y_analysis/cash_regime_tf_backtest_labeled.csv
```

## Primary tracking fields

| Export field | Meaning |
|---|---|
| `stock` | Cash symbol used by the replay. |
| `strategy_tf` | Canonical integer strategy key; use this for comparison with live cells. |
| `time_frame` | Human-readable execute-frame label, supplied alongside the integer key. |
| `e_regime`, `a_regime` | Pipeline-emitted E/A TrendContext at scan/setup time. |
| `side`, `entry`, `stop`, `target` | Frozen simulated BUY setup values. |
| `result` | `SUCCESS` for a baseline `WIN`; `FAIL` for a baseline `LOSS`. |
| `gross_r` | Resolved baseline R-multiple. |
| `zone_signature` | Selected setup-zone signature where evidence permits it. |

`outcome` is retained as the original `WIN`/`LOSS` evidence field. Other
columns (`scan_timestamp`, `setup_timestamp`, `entry_timestamp`, `trade_id`,
and X regime) provide traceability.

## Zone-signature evidence status

The completed two-year database predates literal signature persistence. Where
the selected X-zone snapshot was persisted, the export reconstructs the same
documented live format: `SYMBOL:X:proximal:distal`, rounded to two decimals.
Its `zone_signature_source` is
`RECONSTRUCTED_FROM_PERSISTED_SELECTED_X_ZONE`.

If that selected zone snapshot was not retained, `zone_signature` is empty and
`zone_signature_source` is `UNAVAILABLE_NO_MATCHING_PERSISTED_X_ZONE`. This is
intentional: no zone is invented or recomputed after the historical decision.
Future audit replays persist the literal pipeline-emitted setup signature with
source `EMITTED_BY_PIPELINE_AT_SETUP_TIME`.
