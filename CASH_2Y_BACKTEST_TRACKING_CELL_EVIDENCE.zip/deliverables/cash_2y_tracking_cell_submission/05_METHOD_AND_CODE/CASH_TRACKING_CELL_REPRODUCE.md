# Reproduce the CASH tracking-cell export

From the repository root:

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.export_cash_tracking_cells \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run d6e50e96d56642d6864700a2bedfcdda \
  --signature-backfill audit/fresh_trend_backtest/storage/cash_zone_signature_backfill_614_v2.sqlite \
  --output audit/fresh_trend_backtest/results/current_engine_2y_analysis/cash_regime_tf_backtest_labeled_final.csv
```

Validate the audit tooling:

```bash
python -m pytest tests/fresh_trend_backtest -q
```

Check zone-signature backfill status:

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.backfill_cash_zone_signatures status \
  --backfill-storage audit/fresh_trend_backtest/storage/cash_zone_signature_backfill_614_v2.sqlite
```

The backfill is complete only when all 14,627 rows have status `MATCHED` and
there are no pending, mismatch, or error rows.
