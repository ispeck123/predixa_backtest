"""Read-only export of every eligible CASH BUY setup from a completed run."""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

import pandas as pd


def export_eligible_setups(storage: Path, run_id: str, output: Path) -> pd.DataFrame:
    sql = """
    SELECT su.setup_id,s.scan_id,s.symbol AS stock,s.strategy_tf,st.strategy_tf_name AS time_frame,
           s.evaluation_timestamp AS scan_timestamp,su.setup_timestamp,su.direction,su.pattern,
           su.zone_id AS selected_zone_id,su.proposed_entry,su.proposed_stop,su.proposed_target,
           su.rr,su.setup_score,su.setup_rank,su.permission_state,
           s.final_bias,s.allow_long,s.allow_short,s.permitted_setup,s.trade_type_long,s.htf_veto_longs,s.htf_veto_shorts,
           r.E_regime AS e_regime,r.A_regime AS a_regime,r.X_regime AS x_regime,
           r.E_rule_applied,r.A_rule_applied,r.X_rule_applied,r.E_diagnosis,r.A_diagnosis,r.X_diagnosis,
           z.proximal AS selected_zone_proximal,z.distal AS selected_zone_distal,
           t.trade_id,t.entry_timestamp,t.exit_timestamp,t.entry_price,t.stop_price,t.target_price,t.exit_price,
           t.outcome,t.exit_reason,t.target_hit,t.stop_hit,t.bars_held,t.gross_r,t.gross_return_pct,
           p.outcome_direction,p.max_favorable_excursion,p.max_adverse_excursion,p.max_favorable_pct_of_target,
           p.bars_to_mfe,p.bars_to_mae,p.bars_to_exit
    FROM setup_results su
    JOIN scan_results s ON s.scan_id=su.scan_id
    JOIN scan_tasks st ON st.task_id=s.task_id
    JOIN regime_snapshots r ON r.scan_id=s.scan_id
    LEFT JOIN zone_snapshots z ON z.scan_id=s.scan_id AND z.timeframe='X' AND z.zone_id=su.zone_id
    LEFT JOIN simulated_trades t ON t.setup_id=su.setup_id
    LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id
    WHERE s.run_id=? AND su.eligible=1 AND su.direction='BUY'
    ORDER BY su.setup_id
    """
    with sqlite3.connect(storage) as db:
        frame = pd.read_sql_query(sql, db, params=[run_id])
    frame["setup_lifecycle"] = "NOT_ENTERED"
    frame.loc[frame.trade_id.notna(), "setup_lifecycle"] = "ENTERED_UNRESOLVED"
    frame.loc[frame.outcome.eq("WIN"), "setup_lifecycle"] = "RESOLVED_SUCCESS"
    frame.loc[frame.outcome.eq("LOSS"), "setup_lifecycle"] = "RESOLVED_FAIL"
    frame["result"] = frame.outcome.map({"WIN": "SUCCESS", "LOSS": "FAIL"})
    has_zone = frame.selected_zone_proximal.notna() & frame.selected_zone_distal.notna()
    frame["zone_signature"] = None
    frame.loc[has_zone, "zone_signature"] = frame.loc[has_zone].apply(
        lambda x: f"{x.stock}:X:{round(float(x.selected_zone_proximal),2)}:{round(float(x.selected_zone_distal),2)}", axis=1)
    frame["zone_signature_source"] = "UNAVAILABLE_NO_MATCHING_PERSISTED_X_ZONE"
    frame.loc[has_zone, "zone_signature_source"] = "RECONSTRUCTED_FROM_PERSISTED_SELECTED_X_ZONE"
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    return frame


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--run", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    frame = export_eligible_setups(args.storage, args.run, args.output)
    print(f"exported {len(frame):,} eligible CASH BUY setups to {args.output}")
    print(frame.setup_lifecycle.value_counts().to_dict())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
