# Fresh Trend Engine Baseline Report

## Scope

- Run ID: `d6e50e96d56642d6864700a2bedfcdda`
- Status: COMPLETED
- Engine variant: CURRENT_PRODUCTION
- Period: 2024-09-17 to 2026-09-16
- Executor / workers: process / 4

## Task completion

| status    |   count |
|:----------|--------:|
| COMPLETED |  385994 |

## Scan and trade population

|   scans |   signals |   eligible |
|--------:|----------:|-----------:|
|  385994 |     58829 |      58829 |

|   trades |   wins |   losses |   win_pct |
|---------:|-------:|---------:|----------:|
|    48438 |  14039 |    33776 |    28.983 |

## E/A outcome results

| E   | A   |   trades |   wins |   losses |   win_pct |   against_pct |
|:----|:----|---------:|-------:|---------:|----------:|--------------:|
| SW  | SW  |     5009 |   1968 |     3024 |    39.289 |        60.371 |
| SW  | UP  |     8333 |   2389 |     5865 |    28.669 |        70.383 |
| UP  | SW  |    13352 |   3417 |     9830 |    25.592 |        73.622 |
| UP  | UP  |    21744 |   6265 |    15057 |    28.813 |        69.247 |

## UP/UP by execution regime

| E   | A   | X   |     n |   wins |   losses |   win_pct |   against_pct |
|:----|:----|:----|------:|-------:|---------:|----------:|--------------:|
| UP  | UP  | SW  |  7207 |   1970 |     5088 |    27.335 |        70.598 |
| UP  | UP  | UP  | 14537 |   4295 |     9969 |    29.545 |        68.577 |

## Mixed higher-timeframe states

| E   | A   |     n |   wins |   win_pct |
|:----|:----|------:|-------:|----------:|
| SW  | UP  |  8333 |   2389 |    28.669 |
| UP  | SW  | 13352 |   3417 |    25.592 |

## Timeframe results

|   strategy_tf | E   | A   |     n |   wins |   win_pct |
|--------------:|:----|:----|------:|-------:|----------:|
|             1 | SW  | SW  |   193 |     19 |     9.845 |
|             1 | SW  | UP  |   186 |     44 |    23.656 |
|             1 | UP  | SW  |   591 |     78 |    13.198 |
|             1 | UP  | UP  |  1089 |    197 |    18.09  |
|             2 | SW  | SW  |  2959 |   1217 |    41.129 |
|             2 | SW  | UP  |  4627 |   1461 |    31.576 |
|             2 | UP  | SW  |  7216 |   2085 |    28.894 |
|             2 | UP  | UP  | 11347 |   3604 |    31.762 |
|             5 | SW  | SW  |   246 |     68 |    27.642 |
|             5 | SW  | UP  |   478 |     64 |    13.389 |
|             5 | UP  | SW  |   629 |    185 |    29.412 |
|             5 | UP  | UP  |  1308 |    360 |    27.523 |
|             6 | SW  | SW  |   254 |    109 |    42.913 |
|             6 | SW  | UP  |   255 |     80 |    31.373 |
|             6 | UP  | SW  |  1000 |    250 |    25     |
|             6 | UP  | UP  |  1015 |    214 |    21.084 |
|            25 | SW  | SW  |  1357 |    555 |    40.899 |
|            25 | SW  | UP  |  2787 |    740 |    26.552 |
|            25 | UP  | SW  |  3916 |    819 |    20.914 |
|            25 | UP  | UP  |  6985 |   1890 |    27.058 |

## Yearly results

|   year |     n |   wins |   win_pct |
|-------:|------:|-------:|----------:|
|   2024 |  9526 |   2630 |    27.609 |
|   2025 | 23722 |   7652 |    32.257 |
|   2026 | 15190 |   3757 |    24.733 |

## Symbol results

| symbol                    |    n |   wins |   win_pct |
|:--------------------------|-----:|-------:|----------:|
| abb_india                 |  730 |    206 |    28.219 |
| adani_ports               |  341 |     54 |    15.836 |
| apollo_hospitals          |  616 |    209 |    33.929 |
| bajaj_auto                |  360 |     49 |    13.611 |
| bajaj_finance             | 1030 |    218 |    21.165 |
| bank_of_baroda            | 1466 |    426 |    29.059 |
| bharat_electronics        | 1154 |    318 |    27.556 |
| bharti_airtel             | 1471 |    266 |    18.083 |
| britannia_industries      |  581 |    207 |    35.628 |
| cg_power_inds             |  811 |    126 |    15.536 |
| cholamandalam_investment  | 1007 |    185 |    18.371 |
| divis_laboratories        | 1165 |    207 |    17.768 |
| dlf                       | 1027 |    222 |    21.616 |
| eicher_motors             |  836 |    205 |    24.522 |
| eternal                   |  744 |    188 |    25.269 |
| godrej_consumer           | 1036 |    348 |    33.591 |
| grasim_industries         |  523 |     97 |    18.547 |
| hcl_technologies          |  768 |    122 |    15.885 |
| hdfcbank                  | 1655 |    546 |    32.991 |
| hero_motocorp             | 1067 |    327 |    30.647 |
| hindalco_industries       |  694 |    246 |    35.447 |
| hindunilvr                |  579 |    248 |    42.832 |
| hindustan_aeronautics     |  736 |    257 |    34.918 |
| icici_lombard_gic         |  921 |    247 |    26.819 |
| icicibank                 | 1143 |    409 |    35.783 |
| indian_hotels             |  714 |    119 |    16.667 |
| indigo                    |  890 |    425 |    47.753 |
| info_edge                 | 1262 |    646 |    51.189 |
| infy                      | 1801 |    439 |    24.375 |
| jindal_steel_power        |  660 |    239 |    36.212 |
| jsw_steel                 |  932 |    249 |    26.717 |
| larsen_toubro             |  783 |    224 |    28.608 |
| ltimindtree               |  512 |    177 |    34.57  |
| mahindra_mahindra         | 1854 |    419 |    22.6   |
| maruti_suzuki             |  991 |    272 |    27.447 |
| ntpc                      |  442 |    237 |    53.62  |
| pidilite_industries       | 1259 |    715 |    56.791 |
| power_finance_corporation | 1202 |     99 |     8.236 |
| reliance                  | 1248 |    578 |    46.314 |
| shree_cement              | 1118 |    223 |    19.946 |
| shriram_finance           |  842 |    239 |    28.385 |
| siemens                   |  652 |    190 |    29.141 |
| sun_pharma                |  523 |    101 |    19.312 |
| tata_steel                |  873 |    501 |    57.388 |
| tatamotors                | 1371 |    244 |    17.797 |
| titan                     |  646 |    257 |    39.783 |
| torrent_pharmaceuticals   |  718 |    308 |    42.897 |
| trent                     |  767 |    103 |    13.429 |
| tvs_motor                 | 1118 |    465 |    41.592 |
| ultratech_cement          | 1212 |    264 |    21.782 |
| varun_beverages           |  849 |    202 |    23.793 |
| vedanta                   |  738 |    171 |    23.171 |

## Interpretation boundary

This report describes fresh replay outcomes generated by the current production pipeline. It does not modify, tune, or recommend a Trend Engine change. The independent oracle and rule/zone analysis are available only if the run was executed with the relevant optional evidence fields enabled.