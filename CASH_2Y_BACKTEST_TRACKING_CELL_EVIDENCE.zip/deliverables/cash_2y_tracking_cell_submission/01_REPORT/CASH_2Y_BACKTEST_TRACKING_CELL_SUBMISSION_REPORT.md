# CASH 2-Year Backtest — Regime/TF Tracking-Cell Export

## Submission purpose

This report accompanies the final CASH historical-replay trade export for
live-versus-backtest tracking by the cell:

`(stock, e_regime, a_regime, strategy_tf)`.

The export is a read-only extraction from the completed current-production
CASH baseline. It does not use historical orders as input and it does not
rerun the baseline strategy, trade resolution, or outcome calculation.

## Evidence sources

| Item | Value |
|---|---|
| Baseline run ID | `d6e50e96d56642d6864700a2bedfcdda` |
| Baseline SQLite | `audit/fresh_trend_backtest/storage/backtest_2y.sqlite` |
| Baseline engine commit | `6140a07046b72ced7377edcf4ae1c9d59e228010` |
| Zone-signature backfill SQLite | `audit/fresh_trend_backtest/storage/cash_zone_signature_backfill_614_v2.sqlite` |
| Final export | `audit/fresh_trend_backtest/results/current_engine_2y_analysis/cash_regime_tf_backtest_labeled_final.csv` |
| SHA-256 | `47f9b9279db78ef2eac0bf0aec68ac17d79daa2f7a8b3a14202f88b85684c53d` |

## Coverage

| Measure | Result |
|---|---:|
| Resolved CASH BUY trades | 47,815 |
| Symbols | 52 |
| Scan-time coverage | 2024-09-17 05:30 to 2026-09-11 15:25 |
| Latest recorded exit | 2026-09-16 15:25 |
| `SUCCESS` rows | 14,039 |
| `FAIL` rows | 33,776 |

## Complete eligible-setup population

The accompanying file `cash_eligible_setups_with_outcomes.csv` contains every
engine-approved CASH BUY setup, not only trades that later resolved. It is the
complete relevant setup population for this baseline.

| Lifecycle | Setups | Meaning |
|---|---:|---|
| `RESOLVED_SUCCESS` | 14,039 | Entry triggered and the baseline target resolved first. |
| `RESOLVED_FAIL` | 33,776 | Entry triggered and the baseline stop resolved first. |
| `ENTERED_UNRESOLVED` | 623 | Entry triggered but no terminal TP/SL outcome before source-data end. |
| `NOT_ENTERED` | 10,391 | Production-approved setup whose entry condition did not trigger. |
| **Total eligible BUY setups** | **58,829** | Complete engine-approved CASH setup population. |

Every eligible-setup row contains the pipeline-captured E/A/X context,
strategy TF, scan/setup timestamp, setup zone ID, proposed entry/stop/target,
permission/bias fields, and trade/outcome fields where an entry occurred.

## Required field validation

Every required submission field is populated for all 47,815 rows.

| Field | Missing | Notes |
|---|---:|---|
| `stock` | 0 | CASH replay symbol. |
| `strategy_tf` | 0 | Canonical integer key used for live-cell reconciliation. |
| `time_frame` | 0 | Readable execute-frame label. |
| `e_regime` | 0 | Production pipeline `TrendContext.regime_E` captured at scan/setup time. |
| `a_regime` | 0 | Production pipeline `TrendContext.regime_A` captured at scan/setup time. |
| `side` | 0 | All rows are BUY, consistent with the CASH scope. |
| `entry`, `stop`, `target` | 0 | Frozen baseline trade values. |
| `result` | 0 | `SUCCESS` or `FAIL`. |
| `gross_r` | 0 | Baseline resolved R-multiple. |
| `zone_signature` | 0 | See signature provenance below. |

Additional checks: zero duplicate `trade_id` values; no unsupported regime
values; every row has positive BUY risk (`entry > stop`) and target above entry.

## Regime provenance

`e_regime` and `a_regime` are not retrospectively classified. They are copied
from the `regime_snapshots` captured when the current production pipeline
evaluated the historical scan/setup timestamp. The zone-signature backfill
re-ran the pinned baseline engine only to recover a missing setup signature;
it did not overwrite E/A values or trade outcomes.

## Zone-signature provenance

No final row has an unavailable signature.

| Source | Trades | Meaning |
|---|---:|---|
| `RECONSTRUCTED_FROM_PERSISTED_SELECTED_X_ZONE` | 33,188 | The baseline database retained the selected X-zone ID and contemporaneous bounds; the live signature format `SYMBOL:X:proximal:distal` was reconstructed from that stored decision state. |
| `EMITTED_BY_PINNED_PIPELINE_BACKFILL` | 14,627 | The setup zone signature was re-emitted by `process_setup()` from an isolated worktree pinned to the baseline commit. Its engine-internal prefix is normalized to the CASH stock name using the same stable live-export signature convention; no zone bounds are altered. Every backfill row matched the stored E/A regimes and selected setup-zone ID. |

The backfill is auditable in its own SQLite database. Its final status is
14,627 `MATCHED`, zero mismatches, and zero errors.

The no-missing-signature statement applies to the resolved-trade submission
file. The eligible-setup file also includes unentered/unresolved opportunities;
some of those have no persisted selected X-zone bounds, and their signature
status remains explicit rather than inferred. This does not affect the
complete resolved-trade tracking-cell dataset.

## Strategy-TF mapping

| `strategy_tf` | `time_frame` | Trades |
|---:|---|---:|
| 1 | `daily` | 1,985 |
| 2 | `sixty` | 25,909 |
| 5 | `one_twenty_five` | 2,598 |
| 6 | `twenty_five` | 2,497 |
| 25 | `seventy_five` | 14,826 |

Use `strategy_tf` as the matching key with live completed-order exports. The
label is provided to make the export reviewable, not as a substitute key.

## E/A tracking-cell population

| E regime | A regime | Trades | SUCCESS | FAIL |
|---|---|---:|---:|---:|
| SW | SW | 4,992 | 1,968 | 3,024 |
| SW | UP | 8,254 | 2,389 | 5,865 |
| UP | SW | 13,247 | 3,417 | 9,830 |
| UP | UP | 21,322 | 6,265 | 15,057 |

These are population counts only. They do not independently establish live
execution tracking error, trading profitability, or a trend-engine defect.

## Column definitions

| Column | Definition |
|---|---|
| `result` | Presentation mapping: baseline `WIN` → `SUCCESS`; baseline `LOSS` → `FAIL`. The original `outcome` remains in the file. |
| `gross_r` | Resolved baseline R-multiple, calculated from frozen entry/stop and resolved exit. |
| `scan_timestamp` / `setup_timestamp` | Historical production decision timestamp at which the stored E/A context applies. |
| `entry_timestamp` / `exit_timestamp` | Simulated subsequent execution and resolution timestamps. |
| `zone_signature_source` | Audit provenance for the accompanying zone signature. |

## Reproduction

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.export_cash_tracking_cells \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run d6e50e96d56642d6864700a2bedfcdda \
  --signature-backfill audit/fresh_trend_backtest/storage/cash_zone_signature_backfill_614_v2.sqlite \
  --output audit/fresh_trend_backtest/results/current_engine_2y_analysis/cash_regime_tf_backtest_labeled_final.csv
```

Production trading code was not modified to create this export or backfill.
