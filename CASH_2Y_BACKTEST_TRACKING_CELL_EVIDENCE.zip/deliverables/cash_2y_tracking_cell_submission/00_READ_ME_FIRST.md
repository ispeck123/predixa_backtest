# CASH 2-Year Backtest Tracking-Cell Evidence Package

## Purpose

This package supports like-for-like reconciliation between live completed CASH
orders and the completed two-year historical CASH replay using the common
cell key:

`(stock, e_regime, a_regime, strategy_tf)`.

Start with `01_REPORT/CASH_2Y_BACKTEST_TRACKING_CELL_SUBMISSION_REPORT.md`,
then use `02_FINAL_EXPORT/cash_regime_tf_backtest_labeled_final.csv` for
cell-level analysis.

## Package contents

- `01_REPORT/` — final tracking-cell report and the original two-year
  baseline report.
- `02_FINAL_EXPORT/` — complete 47,815-row resolved-trade submission dataset,
  the complete 58,829-row eligible-setup population with lifecycle outcomes,
  and machine-readable validation evidence.
- `03_BASELINE_SUMMARIES/` — baseline E/A, symbol, timeframe, year, reference,
  and loss summaries used for supporting analysis.
- `04_ZONE_SIGNATURE_BACKFILL/` — the durable 14,627-row pinned-engine
  backfill evidence database and its run log.
- `05_METHOD_AND_CODE/` — export/backfill source and operating documentation.
- `06_REPRODUCIBILITY/` — commands, test evidence, run metadata and checksums.

## Key submission facts

- Segment: CASH only. NSEFO and MCX are not included.
- Baseline run: `d6e50e96d56642d6864700a2bedfcdda`.
- Baseline commit: `6140a07046b72ced7377edcf4ae1c9d59e228010`.
- Resolved BUY trades: 47,815 across 52 symbols.
- Eligible BUY setups: 58,829, including unentered and unresolved lifecycle
  states so the complete engine-approved opportunity population is available.
- Required fields, including `e_regime`, `a_regime`, `strategy_tf`,
  `time_frame`, `gross_r`, and `zone_signature`, have zero missing values.

## Evidence boundary

The full baseline SQLite evidence database is 754 MB and is not duplicated in
this package. The final export contains all submission rows, the package
contains the complete zone-signature backfill evidence database, and the
report identifies the baseline database path/run/checksum context for internal
retrieval. No source market-data files are included.

## Production-code statement

No production trading files were modified. The signature backfill ran in an
isolated worktree pinned to the baseline commit and only wrote audit evidence.
