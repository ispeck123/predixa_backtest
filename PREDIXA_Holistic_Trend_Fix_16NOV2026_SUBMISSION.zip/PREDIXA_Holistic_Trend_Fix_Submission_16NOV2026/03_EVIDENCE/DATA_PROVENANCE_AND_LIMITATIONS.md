# Data provenance and limitations

The 99-task evaluation cohort is derived by deduplicating `task_id` and `evaluation_timestamp` from the prior comparison evidence. It contains 99 unique task/timestamp pairs and is included for reproduction.

The replay used the three local GOLDM files listed with hashes in `FINAL_VALIDATION_REPORT.md`. The 60-minute file had previously been reported as functionally matching the supplied X/60 evidence (8,761/8,761 candles). The weekly source hash for the archived historical replay was unavailable. The locally available weekly file used for this execution is hashed now, but this newly computed hash does not prove that it is the archived historical input.

The replay outputs are decisions/zone summaries, not a new trade P&L backtest. The earlier lifecycle files are preserved as-is. No OHLC dataset is bundled.
