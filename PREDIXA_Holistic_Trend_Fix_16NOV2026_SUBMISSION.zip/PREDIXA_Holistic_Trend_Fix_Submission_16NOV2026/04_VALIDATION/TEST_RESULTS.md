# Test and static validation results

- Focused pytest command: see `test_results/focused_pytest_output.txt`.
- Result: 49 passed, 0 failed, 0 skipped, 5 warnings, exit code 0.
- Warning categories: SQLAlchemy `declarative_base` deprecation; Pydantic `Field` extra-keyword deprecation; Pydantic v1 `@validator` deprecations.
- `py_compile scripts/trend_engine.py tests/test_trend_violation_formation_scope.py`: PASS.
- `git diff --check`: PASS.
- Environment: `finpro`, Python 3.13 (from executable path and pytest warning paths).
- No full repository regression suite was run for this focused scan-scope task.
