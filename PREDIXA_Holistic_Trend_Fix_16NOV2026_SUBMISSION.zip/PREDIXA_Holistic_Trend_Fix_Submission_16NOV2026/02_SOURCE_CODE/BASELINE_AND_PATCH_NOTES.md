# Baseline and patch notes

- Repository HEAD at packaging: `278691d2307f9245982604ae721e4d8552ff46cb`
- Branch: `prod`
- `scripts/trend_engine.py` was already modified in the worktree before this scan-scope task, carrying the earlier default-off supply exception and Rule-C membership implementation.
- The focused patch reconstructs the file contents inspected immediately before this task by reversing only the edits made here. It is intended to apply after those pre-existing worktree changes are present; it is not represented as a complete patch from Git HEAD.
- The full source snapshot is included at `02_SOURCE_CODE/scripts/trend_engine.py`.
- No unrelated working-tree changes are included.
