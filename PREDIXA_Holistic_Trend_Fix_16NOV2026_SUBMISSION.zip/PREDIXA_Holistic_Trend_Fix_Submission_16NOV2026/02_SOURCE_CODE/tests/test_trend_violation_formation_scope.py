import pandas as pd

from scripts.trend_engine import (
    CandleSeries,
    Config,
    TF,
    TrendEngine,
    TrendRegime,
    TrendViolationChecker,
    Zone,
    ZoneType,
)


def _zone(side: ZoneType, *, created_idx: int, distal: float, proximal: float) -> Zone:
    return Zone(
        symbol="TEST",
        tf=TF.A,
        ztype=side,
        distal=distal,
        proximal=proximal,
        created_idx=created_idx,
        base_start=max(0, created_idx - 1),
        base_end=created_idx,
        base_len=2,
    )


def test_close_violation_scans_from_the_tested_zone_only_when_flagged():
    checker_off = TrendViolationChecker(Config(trend_supply_fix_enabled=False))
    checker_on = TrendViolationChecker(Config(trend_supply_fix_enabled=True))
    cs = CandleSeries(
        o=[110, 110, 95, 95],
        h=[111, 111, 96, 96],
        l=[109, 109, 94, 94],
        c=[110, 110, 95, 95],
    )
    bz = _zone(ZoneType.BZ, created_idx=0, distal=80, proximal=90)
    sz = _zone(ZoneType.SZ, created_idx=2, distal=100, proximal=105)

    assert checker_off.has_bz_violated_sz(cs, bz, sz)
    assert not checker_on.has_bz_violated_sz(cs, bz, sz)
    assert not checker_on.wick_violation_bz_over_sz(cs, bz, sz)

    # A later close beyond the tested supply distal still counts.
    cs.c[-1] = 101
    cs.h[-1] = 102
    assert checker_on.has_bz_violated_sz(cs, bz, sz)
    assert checker_on.wick_violation_bz_over_sz(cs, bz, sz)


def test_opposite_close_and_wick_scans_start_at_tested_demand_formation():
    checker_off = TrendViolationChecker(Config(trend_supply_fix_enabled=False))
    checker_on = TrendViolationChecker(Config(trend_supply_fix_enabled=True))
    cs = CandleSeries(
        o=[90, 90, 105, 105],
        h=[91, 91, 106, 106],
        l=[89, 89, 104, 104],
        c=[90, 90, 105, 105],
    )
    sz = _zone(ZoneType.SZ, created_idx=0, distal=120, proximal=110)
    bz = _zone(ZoneType.BZ, created_idx=2, distal=100, proximal=105)

    assert checker_off.has_sz_violated_bz(cs, sz, bz)
    assert not checker_on.has_sz_violated_bz(cs, sz, bz)
    assert not checker_on.wick_violation_sz_under_bz(cs, sz, bz)

    cs.c[-1] = 99
    cs.l[-1] = 98
    assert checker_on.has_sz_violated_bz(cs, sz, bz)
    assert checker_on.wick_violation_sz_under_bz(cs, sz, bz)


def test_cascade_does_not_count_preformation_closes_as_supply_violations():
    # The two high closes occur before either supply zone exists. Legacy reach
    # counted both supplies as violated; corrected per-zone reach counts none.
    closes = [130.0] * 10 + [100.0, 96.0, 95.0, 95.0, 95.0]
    frame = pd.DataFrame({
        "open": closes,
        "high": [value + 1 for value in closes],
        "low": [value - 1 for value in closes],
        "close": closes,
    })
    bz = _zone(ZoneType.BZ, created_idx=9, distal=80.0, proximal=90.0)
    sz1 = _zone(ZoneType.SZ, created_idx=11, distal=110.0, proximal=105.0)
    sz2 = _zone(ZoneType.SZ, created_idx=12, distal=115.0, proximal=112.0)
    zones = {"BUY": [bz], "SELL": [sz1, sz2]}

    legacy = TrendEngine(Config(trend_supply_fix_enabled=False)).calculate_trend(
        TF.A, frame, bz, sz1, zones, all_zones_for_cascade=[bz, sz1, sz2]
    )
    corrected = TrendEngine(Config(trend_supply_fix_enabled=True)).calculate_trend(
        TF.A, frame, bz, sz1, zones, all_zones_for_cascade=[bz, sz1, sz2]
    )

    assert legacy.regime == TrendRegime.UP
    assert legacy.rule_applied == "Cascading Window (Demand Dominance)"
    assert corrected.regime != TrendRegime.UP

