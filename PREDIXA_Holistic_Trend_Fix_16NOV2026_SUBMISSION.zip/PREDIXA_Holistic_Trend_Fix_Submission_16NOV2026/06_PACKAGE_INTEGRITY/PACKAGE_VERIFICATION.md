# Package verification

The archive contains 29 files. `SHA256_MANIFEST.csv` lists the 28 other packaged files; it excludes itself to avoid a recursive checksum. Archive validation performed CRC checking, duplicate-member and path-traversal checks, full extraction to a temporary directory, manifest hash comparison, and CSV/JSON parsing.

The ZIP archive checksum is reported separately in the handoff response.
