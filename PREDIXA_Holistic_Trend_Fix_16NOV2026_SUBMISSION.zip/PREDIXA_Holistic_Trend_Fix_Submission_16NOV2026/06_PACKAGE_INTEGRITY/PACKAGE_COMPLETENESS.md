# Package completeness

Included: original work-order workbook; current shared trend-engine source snapshot; task-scoped scan-scope patch; new tests plus existing supply-fix tests; prior root-cause report and lifecycle artifacts; previous comparison evidence; newly executed 99-task legacy/flagged replay; raw focused pytest output; methodology/provenance and validation reports.

Not included: raw OHLC input files, provider credentials, databases, production configuration secrets, full repository, or unrelated dirty working-tree files.

Integrity verification is recorded after ZIP creation in `06_PACKAGE_INTEGRITY/PACKAGE_VERIFICATION.md`. `SHA256_MANIFEST.csv` lists every other packaged file; it excludes itself to avoid a recursive checksum.
