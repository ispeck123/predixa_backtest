# Reproduction guide

Run from repository root in the existing `finpro` environment. This replay reads local OHLC and writes only to the chosen output path. It does not activate a scanner or use broker/database order paths. Ensure the output does not already exist; the replay utility refuses overwrite.

```bash
python audit/trend_engine/goldm_exact_evidence_replay.py \
  --cohort <path-to-replay_cohort_task_ids_and_timestamps.csv> \
  --weekly <verified-GOLDM-weekly.csv> \
  --daily <verified-GOLDM-daily.csv> \
  --sixty <verified-GOLDM-sixty.csv> \
  --output <new-output.csv>
```

The script executes each cohort timestamp with flag OFF and ON and records 198 rows for 99 tasks. For exact archived reproduction, supply the precise weekly artifact whose original hash was missing from the prior run. The local inputs used for this package and their hashes are documented in `FINAL_VALIDATION_REPORT.md`; those inputs are not included in the archive.

Focused tests: execute the command shown in `04_VALIDATION/TEST_RESULTS.md`.
