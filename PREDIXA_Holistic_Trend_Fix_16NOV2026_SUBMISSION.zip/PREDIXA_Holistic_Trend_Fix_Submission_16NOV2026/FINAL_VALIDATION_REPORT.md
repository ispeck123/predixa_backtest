# PREDIXA Holistic Trend Fix — Implementation and Validation

## Objective and scope

Implement the supplied 16-Nov-2026 scan-scope correction in the existing shared trend engine. No new strategy, production gate, scanner, or trading permission was introduced.

## Implementation

With `trend_supply_fix_enabled` enabled, the two close-based Rule-C violation methods and two wick diagnostic methods now scan from the formation index of the zone being tested. The cascading-window counts evaluate each supply/demand zone from its own `created_idx`; nearest-zone intact checks use that zone's own formation index. The legacy branch retains the former formulas. `TrendViolationChecker` receives the same Config object so it can observe the existing feature flag.

The flag default remains disabled: with the environment variable unset, `Config().trend_supply_fix_enabled` is `False`. No production config was changed.

## Automated validation

Command, executed with `/home/ispeck/anaconda3/envs/finpro/bin/python`:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_trend_violation_formation_scope.py \
  tests/test_trend_supply_fix_membership.py \
  tests/test_trend_supply_fix_shape_filter.py \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_consumed_zone_dedup.py \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/trend_engine_audit
```

Result: **49 passed, 5 warnings, exit 0**. Warnings are existing SQLAlchemy/Pydantic deprecations. Python compilation passed for the affected module and new test. `git diff --check` passed. Raw pytest output is included.

## GOLDM cohort replay

The existing 99-task cohort was reconstructed from unique `(task_id, evaluation_timestamp)` values in the prior legacy/flagged comparison file and run through the existing functional replay script in both flag states. The replay completed with exit 0 and emitted 198 rows (99 tasks per mode). The locally selected inputs were:

- Weekly: `data/indian_commodity_data/latest_data_csv/GOLDM_04122026_weekly.csv` — SHA-256 `b4fbd9b83ab18b1852b0e0c3a0aadb73f1dd2fbc6f9513cff14645bdea87b134`.
- Daily: `data/indian_commodity_backtest_data/fyers_continuous_from_2017/latest_data_csv/GOLDM_04122026_daily.csv` — SHA-256 `a99788238256a01682d3c5cf65d47eb3c04c38a45f43da7e8937ffb5f62389a8`.
- 60-minute: `data/indian_commodity_backtest_data/fyers_continuous_from_2017/latest_data_csv/GOLDM_04122026_sixty.csv` — SHA-256 `5a86b0dcc21e3c874686fd7a9fb6045fca00e376610f6b1050e223013a511ede`.

Flag OFF: 99/99 E/A UP/UP, no E/A nearest supply, and 99/99 long setups. All legacy output columns match the previous recorded comparison exactly.

Flag ON: E remains UP in 99/99. A is SW in 23 and UP in 76. `GOLDM_A_SZ_2088` is selected as A nearest supply in 23 tasks; E nearest supply remains absent in all tasks. **All 99/99 still have `allow_long=True` and a long setup present.** The work-order claim that the scan-scope change alone yields SW/DN and blocks all 99 longs is therefore **not verified and the acceptance gate remains FAIL**.

The earlier report already disclosed missing archived weekly-file hash provenance. This replay used the locally available weekly file above; it is functional evidence and is not a byte-identical reproduction of the historical run.

## Acceptance and safety

- Scan-scope implementation: PASS (code and focused regression tests).
- Legacy output compatibility: PASS for compared replay output columns on this run.
- GOLDM hard acceptance (all 99 long setups blocked): FAIL.
- Production activation: BLOCKED; flag remains OFF by default.
- MCX PAPER and REAL: remain OFF. No scanner, broker, database, or order path was activated.

## Required next review

Investigate why E remains UP and why A resolves to SW after the corrected scan. Do not promote the flag or claim the 99-task acceptance until a validated replay produces the required classification and blocks the cohort. Obtain the exact archived weekly source and hash for byte-identical verification.
