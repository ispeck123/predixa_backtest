# PREDIXA evaluator-emitted failure-mode cut

This cut includes every completed order-master row. Each row was re-evaluated against the execution-timeframe OHLC using the same evaluator decision logic with opt-in capture of the fill-to-exit path and up to 20 post-stop bars. Setup context was re-emitted by rerunning the scan at the recorded setup timestamp.

`recorded_*` fields are the order-master outcome; `fresh_evaluator_*` fields show the result of the re-run. Differences are flagged and require review because current OHLC may differ from the historical evaluation snapshot.
