# MCX Phase-A Tuning Executive Summary

- Run: `f59cf6dbc3794c27ac8b595d80969bd1`
- Status: `COMPLETED`
- Tasks: 31,120; completed: 29,057; failed: 2,063
- Scans/signals/eligible setups/entered/resolved trades: 29,057 / 10,345 / 10,539 / 8,104 / 8,098
- Tuning runs: baseline/default only; no complete sweep.
- Lock decision: **no lock recommendation—insufficient completed tuning sweep evidence.**
- Data caveat: stitched/continuous MCX source with calendar-inferred contract labels.
- Production files modified: **NONE**.
