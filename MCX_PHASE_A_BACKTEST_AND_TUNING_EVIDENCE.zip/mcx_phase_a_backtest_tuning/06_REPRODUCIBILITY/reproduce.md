# Reproduce

Run from the repository root. The source CSV directory is not copied into the package.

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.analyze_tuning --storage audit/mcx_futures_backtest/storage/mcx_phase_a_full_available.sqlite --run f59cf6dbc3794c27ac8b595d80969bd1 --output audit/mcx_futures_backtest/results/f59cf6dbc3794c27ac8b595d80969bd1 --round-trip-bps 0,2,5
```

The package is audit-only and does not call `process_setup_fc`.
