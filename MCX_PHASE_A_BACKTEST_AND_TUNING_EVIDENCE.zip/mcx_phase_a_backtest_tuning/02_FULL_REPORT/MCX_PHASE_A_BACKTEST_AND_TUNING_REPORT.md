# MCX Phase-A Backtest and Tuning Report

## 1. Executive summary

Run `f59cf6dbc3794c27ac8b595d80969bd1` is a completed current-production MCX Phase-A replay, but it is not a clean full-data run: `29,057` of `31,120` tasks completed and `2,063` failed. The failures are retained in the evidence and are not silently discarded.

This database contains one baseline/default run. No persisted audit-only override fields were found and no complete parameter sweep exists. Therefore: **no lock recommendation—insufficient completed tuning sweep evidence.**

## 2. Scope and data coverage

- Symbols: CRUDEOILM, GOLDM, NATGASMINI, SILVER, SILVERM
- Strategy TFs: 1, 2, 3, 4
- Period: 2025-10-13 through 2026-10-15
- Source: `data/indian_commodity_data/latest_data_csv` (192 CSV files)
- Reference oracle: `True`
- Production path: `scripts.setup_engine_new.process_setup_fc(..., is_future=False)`

## 3. Strategy-TF mapping

TF1 = monthly / weekly / daily; TF2 = weekly / daily / two_forty; TF3 = daily / two_forty / one_twenty; TF4 = daily / two_forty / sixty.

## 4. Replay and data limitations

The replay is as-of and uses the centralized SQLite evidence. The source is stitched/continuous. Contract-live labels are calendar-inferred and do not establish exchange-verified historical contract identity. The production zone API does not accept a hard roll/session reset. The run contains failed warm-up/source-boundary tasks, including minimum E-TF/X-TF history errors. Rule B and Rule C Scenario 3 are not separately persisted in the schema.

## 5. Counts

| item | count |
|---|---:|
| tasks | 31,120 |
| completed tasks | 29,057 |
| failed tasks | 2,063 |
| scans | 29,057 |
| signals | 10,345 |
| signal/setup observations | 10,345 |
| eligible setup rows | 10,539 |
| entered trade rows | 8,104 |
| resolved trades (WIN/LOSS) | 8,098 |
| unresolved/unfilled trades | 6 |

## 6. Baseline results

See `mcx_ea_summary.csv`, `mcx_eax_summary.csv`, `mcx_symbol_summary.csv`, `mcx_timeframe_summary.csv`, `mcx_yearly_summary.csv`, and `mcx_rule_summary.csv`.

## 7. Tuning evidence

Persisted overrides: `{}`. This is a baseline/default run, not a candidate override run. `mcx_tuning_metrics.csv` contains IS, OOS, pooled, cell-level, and 0/2/5 bps-only sensitivity rows. These are not a complete brokerage/slippage/OI-4 cost stack.

Protocol decision: **no lock recommendation—insufficient completed tuning sweep evidence.**

## 8. Conclusion

Baseline evidence is retained for audit review. No candidate is supported, because no baseline-versus-candidate IS/OOS comparison exists and the run has failed tasks. Production strategy, Config defaults, zone logic, entry/exit logic, and market data were not modified.
