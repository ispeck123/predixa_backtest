# Executive submission summary

## Scope

This package implements and evidences the 08-Nov-2026 PREDIXA work order: revert the live NSEFO TF2/TF4 permits, preserve the MCX hold, add one audit-only research bypass, and standardise deterministic BUY-setup exports.

## Live policy verification

| Path | Verified result |
|---|---|
| NSEFO TF2 UP/UP live/paper | `DENY`, multiplier 0.0 |
| NSEFO TF4 SW/SW live/paper | `DENY`, multiplier 0.0 |
| NSEFO TF25 SW/SW live/paper | `CORE`, multiplier 1.0 |
| MCX live/paper | `DENY`, multiplier 0.0 |
| NSEFO research bypass | `RESEARCH_BYPASS`, multiplier 1.0 |
| MCX research bypass | `RESEARCH_BYPASS`, multiplier 1.0 |

## Evidence status

- Focused regression tests: return code `0`. See `05_TEST_EVIDENCE/focused_pytest.txt`.
- NSEFO repaired-gate run `92f13c51fae94bdcbb0e7e376328ad92`: 186,233 signals, 166,273 entered trades, 164,760 resolved trades, SQLite integrity `ok`.
- MCX run `db087a5edb264683a5e932ccda11d631` was still in progress at package snapshot: 115,261 completed tasks, 794 failed tasks, 37,000 signals, and 0 gate denials. The active MCX SQLite database was not copied or changed.

## Submission boundary

The prior NSEFO evidence is included for transparency. It does not promote TF2/TF4 to live policy. The next NSEFO re-screen must use the persisted `research_gate_bypass=true` configuration. MCX research output may be exported only after its running replay reaches a terminal completed state.
