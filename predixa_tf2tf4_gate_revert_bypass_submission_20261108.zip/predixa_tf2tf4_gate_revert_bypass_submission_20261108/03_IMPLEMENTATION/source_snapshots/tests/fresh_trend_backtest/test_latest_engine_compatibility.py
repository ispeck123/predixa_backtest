"""Regression coverage for audit adapters of the current live gate boundary."""
from __future__ import annotations

from audit.fresh_trend_backtest.production_gate import evaluate_gate
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.fresh_trend_backtest.config import ReplayConfig


def test_cash_adapter_uses_live_gate_policy_not_a_copied_table():
    denied = evaluate_gate("NSE_CASH", 1, "SW", "SW")
    permitted = evaluate_gate("NSE_CASH", 2, "SW", "SW")
    assert denied.denied and denied.tier == "DENY"
    assert not permitted.denied and permitted.tier == "CORE"


def test_live_nsefo_tf2_tf4_and_mcx_remain_held():
    nsefo = evaluate_gate("NSEFO", 2, "UP", "UP")
    mcx = evaluate_gate("MCX", 4, "SW", "SW")
    assert (nsefo.tier, nsefo.size_multiplier) == ("DENY", 0.0)
    assert (mcx.tier, mcx.size_multiplier) == ("DENY", 0.0)


def test_research_bypass_admits_nsefo_and_mcx_without_changing_live_gate():
    for exchange, tf, e_regime, a_regime in (("NSEFO", 2, "UP", "UP"), ("MCX", 4, "SW", "SW")):
        live = evaluate_gate(exchange, tf, e_regime, a_regime)
        research = evaluate_gate(exchange, tf, e_regime, a_regime, research_gate_bypass=True)
        assert (live.tier, live.size_multiplier) == ("DENY", 0.0)
        assert (research.tier, research.size_multiplier) == ("RESEARCH_BYPASS", 1.0)
        assert "research-only" in research.reason


def test_gate_fields_persist_in_normalized_scan_and_setup_tables(tmp_path):
    storage = SQLiteBacktestStorage(tmp_path / "audit.sqlite")
    cfg = ReplayConfig(run_name="gate-persistence", symbols=("infy",), tfs=(2,), start="2026-01-01", end="2026-01-01")
    run = storage.create_run(cfg)
    storage.register_tasks(run, [{"symbol":"infy", "strategy_tf":2, "strategy_tf_name":"sixty", "evaluation_timestamp":"2026-01-01T10:00:00"}])
    task = storage.claim_tasks(run, 1)[0]
    event = {"task": task, "duration_ms": 1.0, "worker_id": "test", "max_retries": 0,
        "result": {"scan": {"task_id":task["task_id"], "run_id":run, "symbol":"infy", "strategy_tf":2,
            "evaluation_timestamp":task["evaluation_timestamp"], "cmp":100.0, "signal_generated":1,
            "setup_generated":1, "entry_candidate":0, "rejection_reason":"gate", "final_bias":"Neutral",
            "allow_long":1, "allow_short":0, "permitted_setup":None, "trade_type_long":None,
            "trade_type_short":None, "dbr_required":0, "rbd_required":0, "htf_veto_longs":0,
            "htf_veto_shorts":0, "htf_veto_reason":None, "production_runtime_ms":1.0,
            "gate_tier":"DENY", "gate_size_multiplier":0.0, "gate_reason":"test gate", "gate_denied":1,
            "raw_json":None}, "regime":{"E_regime":"SW", "A_regime":"SW", "X_regime":"SW"},
            "zones":[], "setups":[{"symbol":"infy", "strategy_tf":2, "direction":"BUY",
              "setup_timestamp":task["evaluation_timestamp"], "eligible":0, "blocked_reason":"test gate",
              "permission_state":"BLOCKED", "gate_tier":"DENY", "gate_size_multiplier":0.0,
              "gate_reason":"test gate"}]}}
    storage.save_events([event])
    assert tuple(storage.conn.execute("SELECT gate_tier,gate_denied FROM scan_results").fetchone()) == ("DENY", 1)
    assert tuple(storage.conn.execute("SELECT gate_tier,gate_size_multiplier FROM setup_results").fetchone()) == ("DENY", 0.0)
