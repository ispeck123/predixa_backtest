"""Phase-A NSEFO replay on one canonical stitched source per underlying/TF.

This replaces the old three-expiry loop.  It calls the unchanged production
``process_setup_fc`` implementation through the existing audit worker, while
recording a calendar-inferred contract label separately at export time.
"""
from __future__ import annotations

import argparse
import concurrent.futures as futures
import json
import os
import signal
import time
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path

import pandas as pd

from audit.derivatives_backtest_common.contract_inventory import parse_contract_filename
from audit.fresh_trend_backtest.result_writer import ResultWriter
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.nsefo_futures_backtest.preflight import (
    NSEFO_ACTIVE_EXPIRIES,
    NSEFO_ALLOWED_SYMBOLS,
    NSEFO_FRAMES,
    NSEFO_ROOT,
    NSEFO_STACKS,
)


@dataclass(frozen=True)
class Config:
    run_name: str; symbols: tuple[str, ...]; tfs: tuple[int, ...]; start: str; end: str
    executor: str = "process"; workers: int | str = "4"; max_retries: int = 2
    storage_path: str = "audit/nsefo_futures_backtest/storage/phase_a.sqlite"
    write_batch_size: int = 100; flush_seconds: float = 2; progress_seconds: float = 10
    limit_tasks: int | None = None; sample_every: int = 1; compute_reference_oracle: bool = False
    random_seed: int = 20260930; variant_name: str = "PHASE_A_STITCHED_CALENDAR_INFERRED"
    engine_overrides: dict | None = None
    buy_only: bool = False
    research_gate_bypass: bool = False
    def canonical(self): return asdict(self)
    @property
    def config_hash(self): return sha256(json.dumps(self.canonical(), sort_keys=True, default=str).encode()).hexdigest()
    @property
    def storage(self): return Path(self.storage_path)
    def resolved_workers(self): return max(1, min(4, (os.cpu_count() or 2)//2)) if self.workers == "auto" else max(1, int(self.workers))


def _symbols(value: str) -> tuple[str, ...]:
    if value == "all":
        found=set()
        for p in NSEFO_ROOT.glob("*.csv"):
            item=parse_contract_filename(p, NSEFO_FRAMES)
            if item: found.add(item.symbol)
        return tuple(sorted(found & NSEFO_ALLOWED_SYMBOLS))
    p=Path(value)
    symbols = tuple(x.strip().upper() for x in p.read_text().splitlines() if x.strip() and not x.startswith("#")) if p.exists() else tuple(x.strip().upper() for x in value.split(",") if x.strip())
    invalid = set(symbols) - NSEFO_ALLOWED_SYMBOLS
    if invalid: raise SystemExit(f"symbols not in NSEFO allowlist: {', '.join(sorted(invalid))}")
    return symbols


def _eligible_sources(symbol: str, stack: tuple[str,...]) -> list[str]:
    frames: dict[str,set[str]]={}
    for p in NSEFO_ROOT.glob(f"{symbol}_*.csv"):
        item=parse_contract_filename(p, NSEFO_FRAMES)
        if item: frames.setdefault(item.expiry,set()).add(item.timeframe)
    active = set(NSEFO_ACTIVE_EXPIRIES.get(symbol, ()))
    return sorted([e for e, available in frames.items() if e in active and set(stack).issubset(available)], key=lambda x: pd.to_datetime(x, format="%d%m%Y"))


def _canonical_source(symbol: str, stack: tuple[str,...], end: str) -> str | None:
    eligible=_eligible_sources(symbol,stack)
    if not eligible: return None
    target=pd.Timestamp(end)
    # A stitched source is still a physical CSV with an end date.  Prefer one
    # that actually covers the requested endpoint before applying a stable
    # nearest-expiry tie-breaker.
    covering=[]
    for expiry in eligible:
        path=NSEFO_ROOT/f"{symbol}_{expiry}_{stack[-1]}.csv"
        dates=pd.read_csv(path,usecols=["tradeDate"]).tradeDate
        last=pd.to_datetime(dates.iloc[-1],dayfirst=True,errors="coerce")
        if pd.notna(last) and last >= target: covering.append(expiry)
    pool=covering or eligible
    return min(pool,key=lambda x: abs(pd.to_datetime(x,format="%d%m%Y")-target))


def _timestamps(symbol: str, source: str, x_frame: str, start: str, end: str):
    path=NSEFO_ROOT/f"{symbol}_{source}_{x_frame}.csv"
    df=pd.read_csv(path,usecols=["tradeDate"])
    ts=pd.to_datetime(df.tradeDate,dayfirst=True,errors="coerce").dropna().drop_duplicates()
    return [x.isoformat() for x in ts[(ts>=pd.Timestamp(start)) & (ts<=pd.Timestamp(end)+pd.Timedelta(days=1)-pd.Timedelta(nanoseconds=1))]]


def generate_tasks(cfg: Config):
    for symbol in cfg.symbols:
        for tf in cfg.tfs:
            stack=NSEFO_STACKS[tf]; source=_canonical_source(symbol,stack,cfg.end)
            if source is None: continue
            # Phase A deliberately permits one—and only one—canonical stitched
            # source per underlying/TF.  This is the guard against the old
            # three-expiry duplicate replay.
            for i, ts in enumerate(_timestamps(symbol,source,stack[-1],cfg.start,cfg.end)):
                if i % cfg.sample_every: continue
                yield {"symbol":f"{symbol}@{source}","strategy_tf":tf,"strategy_tf_name":stack[-1],"evaluation_timestamp":ts,
                       # Tuning uses the explicit --buy-only decision cut.
                       # Existing Phase-A replay retains its prior two-sided mode.
                       "market_segment":"NSEFO","is_future":True,"buy_only":cfg.buy_only}


def execute_task(task: dict, *args, **kwargs):
    # Imported in each worker.  The old runner remains intact; its worker is
    # reused only as an adapter to the unchanged production entry point.
    import audit.futures_trend_backtest.run_futures_backtest as legacy
    legacy.DATA=NSEFO_ROOT; legacy.STACKS=dict(NSEFO_STACKS)
    return legacy.execute_task(task, *args, **kwargs)


class Coordinator:
    def __init__(self,cfg,worker=execute_task): self.cfg=cfg; self.store=SQLiteBacktestStorage(cfg.storage); self.worker=worker
    def create(self):
        tasks=list(generate_tasks(self.cfg)); tasks=tasks[:self.cfg.limit_tasks] if self.cfg.limit_tasks else tasks
        rid=self.store.create_run(self.cfg,len(tasks)); self.store.register_tasks(rid,tasks); return rid
    def run(self,rid):
        self.store.reclaim_stale(rid); self.store.set_run_status(rid,"RUNNING"); kind="process" if self.cfg.executor=="auto" else self.cfg.executor; pool_cls=futures.ProcessPoolExecutor if kind=="process" else futures.ThreadPoolExecutor; workers=self.cfg.resolved_workers(); self.store.set_execution(rid,kind,workers); writer=ResultWriter(self.store,self.cfg.write_batch_size,self.cfg.flush_seconds); writer.start(); active={}; last=time.monotonic(); stopping=False
        def stop(*_): nonlocal stopping; stopping=True
        old=(signal.signal(signal.SIGINT,stop),signal.signal(signal.SIGTERM,stop))
        try:
            with pool_cls(max_workers=workers) as pool:
                while not stopping:
                    writer.raise_if_failed()
                    capacity=max(0,workers*2-len(active))
                    for task in self.store.claim_tasks(rid,capacity):
                        # scan_tasks intentionally stores only the normalized
                        # cross-market task identity.  Reattach run-level
                        # execution semantics at dispatch; otherwise the
                        # persisted buy_only flag is lost before the legacy
                        # worker evaluates BUY/SELL candidates.
                        task = {**task, "market_segment": "NSEFO", "is_future": True,
                                "buy_only": self.cfg.buy_only,
                                "research_gate_bypass": self.cfg.research_gate_bypass}
                        active[pool.submit(self.worker,task,False,self.cfg.max_retries,kind=="process",self.cfg.compute_reference_oracle,self.cfg.engine_overrides)]=task
                    if not active:
                        c=self.store.task_counts(rid)
                        if not (c.get("PENDING",0) or c.get("RETRY",0)): break
                        continue
                    done,_=futures.wait(active,timeout=.25,return_when=futures.FIRST_COMPLETED)
                    for f in done:
                        task=active.pop(f)
                        try: writer.submit(f.result())
                        except BaseException as ex: writer.submit({"task":task,"error":{"type":type(ex).__name__,"message":str(ex),"traceback":"future retrieval failure"},"duration_ms":None,"worker_id":"coordinator","max_retries":self.cfg.max_retries})
                    if time.monotonic()-last>=self.cfg.progress_seconds:
                        c=self.store.task_counts(rid); print(f"Run {rid}: {c.get('COMPLETED',0):,}/{c.get('TOTAL',0):,} ({100*c.get('COMPLETED',0)/max(1,c.get('TOTAL',1)):.1f}%), active={len(active)}, writer_queue={writer.queue.qsize()}, executor={kind}/{workers}",flush=True);last=time.monotonic()
        finally:
            writer.close();self.store.finalise_counts(rid);c=self.store.task_counts(rid);self.store.set_run_status(rid,"COMPLETED" if c.get("COMPLETED",0)+c.get("FAILED",0)==c.get("TOTAL",0) else "PAUSED");signal.signal(signal.SIGINT,old[0]);signal.signal(signal.SIGTERM,old[1])
        return self.status(rid)
    def status(self,rid):
        r=dict(self.store.get_run(rid));c=self.store.task_counts(rid);sig=self.store.conn.execute("SELECT count(*) FROM scan_results WHERE run_id=? AND signal_generated=1",(rid,)).fetchone()[0];tr=self.store.conn.execute("SELECT count(*) FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?",(rid,)).fetchone()[0];return {"run":r,"task_counts":c,"signals":sig,"entered_trades":tr}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="cmd",required=True)
    def common(x):
        x.add_argument("--run-name",default="nsefo_phase_a_stitched");x.add_argument("--symbols",default="all");x.add_argument("--tfs",default="1,2,3,4,5,25");x.add_argument("--start",default="2024-09-30");x.add_argument("--end",default="2026-09-30");x.add_argument("--executor",choices=("process","thread","auto"),default="process");x.add_argument("--workers",default="4");x.add_argument("--storage",default="audit/nsefo_futures_backtest/storage/phase_a.sqlite");x.add_argument("--limit-tasks",type=int);x.add_argument("--sample-every",type=int,default=1);x.add_argument("--compute-reference-oracle",action="store_true");x.add_argument("--engine-overrides-json",default="{}");x.add_argument("--buy-only",action="store_true");x.add_argument("--research-gate-bypass",action="store_true",help="audit-only: admit all gate cells without changing live/paper policy");x.add_argument("--random-seed",type=int,default=20260930)
    for name in ("dry-run","run"): common(sub.add_parser(name))
    for name in ("status","resume"):
        x=sub.add_parser(name);x.add_argument("run_id");x.add_argument("--storage",default="audit/nsefo_futures_backtest/storage/phase_a.sqlite")
    a=p.parse_args(argv)
    if a.cmd in ("status","resume"):
        store=SQLiteBacktestStorage(a.storage);row=store.get_run(a.run_id)
        if row is None: raise SystemExit("unknown run_id")
        c=Coordinator(Config(**json.loads(row["config_json"])))
        print(json.dumps(c.status(a.run_id) if a.cmd=="status" else c.run(a.run_id),indent=2,default=str));return
    tfs=tuple(int(x) for x in a.tfs.split(","));invalid=set(tfs)-set(NSEFO_STACKS)
    if invalid: raise SystemExit(f"unsupported TF IDs: {sorted(invalid)}")
    cfg=Config(a.run_name,_symbols(a.symbols),tfs,a.start,a.end,a.executor,a.workers,storage_path=a.storage,limit_tasks=a.limit_tasks,sample_every=a.sample_every,compute_reference_oracle=a.compute_reference_oracle,engine_overrides=json.loads(a.engine_overrides_json),buy_only=a.buy_only,research_gate_bypass=a.research_gate_bypass,random_seed=a.random_seed)
    tasks=list(generate_tasks(cfg));tasks=tasks[:cfg.limit_tasks] if cfg.limit_tasks else tasks
    if a.cmd=="dry-run": print(json.dumps({"symbols":len(cfg.symbols),"tfs":list(tfs),"canonical_sources_per_symbol_tf":1,"canonical_tasks":len(tasks),"buy_only":cfg.buy_only,"research_gate_bypass":cfg.research_gate_bypass,"random_seed":cfg.random_seed,"contract_live":"calendar-inferred at export; source is stitched"},indent=2));return
    c=Coordinator(cfg);rid=c.create();print(f"run_id={rid}");print(json.dumps(c.run(rid),indent=2,default=str))

if __name__=="__main__": main()
