# Latest Production Engine Compatibility

## Scope

This note records the audit-only compatibility update made after the current
production code introduced `scripts.tf_regime_gate_by_exchange.gate` at the
formatter/scanner permission boundary.  No production source file is changed
by the replay platform.

## Effective replay behaviour

| Segment | Production entry point | Audit treatment of current gate | Direction / policy |
|---|---|---|---|
| Cash | `process_setup(...)` | Calls the live `gate("NSE_CASH", tf, E, A)` through `production_gate.py`. A zero multiplier keeps the raw setup as a blocked audit record but makes it ineligible for entry. | BUY-only, cash RR threshold 2.0. |
| NSEFO | `process_setup_fc(..., is_future=True)` | Calls the live `gate("NSEFO", tf, E, A)` unless the persisted audit-only `research_gate_bypass` run flag is true. | Live/paper remains validated-only (`SW/SW/25`); a research run may measure TF screening cells. |
| MCX | `process_setup_fc(..., is_future=False)` | Calls the live `gate("MCX", tf, E, A)` unless the persisted audit-only `research_gate_bypass` run flag is true. | Live/paper remains held; a research run may measure BUY candidates. RR threshold 2.1. |

The gate itself is **not copied into audit code**. The adapter imports and
calls the production implementation unless the run's explicit research flag
is set. The bypass is not present in production scanners, paper scanners, the
sizing bridge, or the live gate implementation.

## Evidence semantics

`scan_results.signal_generated` means the raw current setup pipeline found a
candidate. `entry_candidate=1` and `setup_results.eligible=1` require the
current gate and segment policy to permit it. Therefore a gate-denied setup is
not simulated as an entry, but remains visible with `blocked_reason`,
`gate_tier`, `gate_size_multiplier`, and `gate_reason` for diagnosis.

## Database additions

New runs persist these fields in `scan_results` and `setup_results`:

- `gate_tier`
- `gate_size_multiplier`
- `gate_reason`
- `gate_denied` (scan level)

`SQLiteBacktestStorage` applies additive migrations to an existing audit DB;
it neither rewrites historical rows nor changes production databases.

## Validation

Run:

```bash
PYTHONPATH=. pytest -q \
  tests/fresh_trend_backtest \
  tests/derivatives_backtest \
  tests/test_tf_regime_gate_by_exchange.py \
  tests/test_mcx_golive_policy.py
```

Then use each market runner's `dry-run` and a new `--limit-tasks 10` pilot
database before initiating a multi-month run. Existing completed runs should
be retained as evidence of the code revision recorded in their manifests;
they should not be relabelled as current-gate runs.
