"""MCX stitched-series research replay for the approved three-stack grid.

This runner is deliberately separate from the strict within-contract Stage-1
runner. It uses one canonical stitched source per instrument/stack and keeps
the output labelled as stitched-series research. It is BUY-only and uses the
offline MCX gate bypass; live MCX order gates remain unchanged.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.nsefo_futures_backtest.run_phase_a import Config, Coordinator
from audit.mcx_futures_backtest.preflight import MCX_ROOT, PRIORITY


# Exact image specification.
STACKS = {
    2: ("weekly", "daily", "sixty"),       # W-D-60
    4: ("daily", "two_forty", "sixty"),   # D-240-60
    3: ("daily", "two_forty", "one_twenty"),  # D-240-120
}
STACK_NAMES = {2: "W-D-60", 4: "D-240-60", 3: "D-240-120"}
DEFAULT_SYMBOLS = ("GOLDM", "CRUDEOILM", "SILVERM", "NATGASMINI")


@dataclass(frozen=True)
class StitchedConfig(Config):
    buy_only: bool = True
    research_gate_bypass: bool = True
    sample_per_cell: int | None = None


def _symbols(value: str) -> tuple[str, ...]:
    if value == "all":
        return DEFAULT_SYMBOLS
    path = Path(value)
    values = tuple(
        x.strip().upper()
        for x in path.read_text().splitlines()
        if x.strip() and not x.lstrip().startswith("#")
    ) if path.exists() else tuple(x.strip().upper() for x in value.split(",") if x.strip())
    invalid = set(values) - set(DEFAULT_SYMBOLS)
    if invalid:
        raise SystemExit(f"symbols not in MCX stitched-grid universe: {', '.join(sorted(invalid))}")
    return values


def _sources(symbol: str, stack: tuple[str, ...]) -> list[str]:
    found: dict[str, set[str]] = {}
    for path in MCX_ROOT.glob(f"{symbol}_*.csv"):
        name = path.name
        if not name.startswith(f"{symbol}_") or not name.endswith(".csv"):
            continue
        remainder = name[len(symbol) + 1 : -4]
        if "_" not in remainder:
            continue
        expiry, frame = remainder.split("_", 1)
        if len(expiry) == 8 and expiry.isdigit():
            found.setdefault(expiry, set()).add(frame)
    return sorted(
        [expiry for expiry, frames in found.items() if set(stack).issubset(frames)],
        key=lambda x: pd.to_datetime(x, format="%d%m%Y"),
    )


def _source(symbol: str, stack: tuple[str, ...], end: str) -> str | None:
    candidates = _sources(symbol, stack)
    if not candidates:
        return None
    target = pd.Timestamp(end)
    covering = []
    for expiry in candidates:
        path = MCX_ROOT / f"{symbol}_{expiry}_{stack[-1]}.csv"
        dates = pd.read_csv(path, usecols=["tradeDate"]).tradeDate
        last = pd.to_datetime(dates, dayfirst=True, errors="coerce").max()
        if pd.notna(last) and last >= target:
            covering.append(expiry)
    pool = covering or candidates
    return min(pool, key=lambda x: abs(pd.to_datetime(x, format="%d%m%Y") - target))


def _timestamps(symbol: str, expiry: str, execute_frame: str, start: str, end: str) -> list[str]:
    path = MCX_ROOT / f"{symbol}_{expiry}_{execute_frame}.csv"
    frame = pd.read_csv(path, usecols=["tradeDate"])
    timestamps = pd.to_datetime(frame.tradeDate, dayfirst=True, errors="coerce").dropna().drop_duplicates()
    high = pd.Timestamp(end) + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1)
    return [x.isoformat() for x in timestamps[(timestamps >= pd.Timestamp(start)) & (timestamps <= high)]]


def generate_tasks(cfg: StitchedConfig):
    for symbol in cfg.symbols:
        for tf in cfg.tfs:
            stack = STACKS[int(tf)]
            expiry = _source(symbol, stack, cfg.end)
            if expiry is None:
                continue
            emitted = 0
            for timestamp in _timestamps(symbol, expiry, stack[-1], cfg.start, cfg.end):
                if cfg.sample_per_cell is not None and emitted >= int(cfg.sample_per_cell):
                    break
                emitted += 1
                yield {
                    "symbol": f"{symbol}@{expiry}",
                    "underlying": symbol,
                    "contract_expiry": expiry,
                    "strategy_tf": int(tf),
                    "strategy_tf_name": STACK_NAMES[int(tf)],
                    "evaluation_timestamp": timestamp,
                    "market_segment": "MCX",
                    "is_future": False,
                    "buy_only": True,
                    "research_gate_bypass": cfg.research_gate_bypass,
                }


def execute_task(task: dict, *args, **kwargs):
    """Adapt the existing audit worker to the MCX stitched source."""
    import audit.futures_trend_backtest.run_futures_backtest as legacy
    import scripts.setup_engine_new as production

    legacy.DATA = MCX_ROOT
    legacy.STACKS = dict(STACKS)
    legacy._bars.cache_clear()
    original = production.process_setup_fc

    def commodity_process(tick, time_list, exp_num, last_d_time, is_future):
        return original(tick, time_list, exp_num, last_d_time, False)

    production.process_setup_fc = commodity_process
    task = {**task, "market_segment": "MCX", "is_future": False, "buy_only": True,
            "research_gate_bypass": bool(task.get("research_gate_bypass", True))}
    try:
        return legacy.execute_task(task, *args, **kwargs)
    finally:
        production.process_setup_fc = original


class StitchedCoordinator(Coordinator):
    def create(self):
        tasks = list(generate_tasks(self.cfg))
        if self.cfg.limit_tasks:
            tasks = tasks[: self.cfg.limit_tasks]
        run_id = self.store.create_run(self.cfg, len(tasks))
        self.store.register_tasks(run_id, tasks)
        return run_id


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--run-name", default="mcx_stitched_grid_research")
        p.add_argument("--symbols", default="all")
        p.add_argument("--tfs", default="2,4,3", help="2=W-D-60, 4=D-240-60, 3=D-240-120")
        p.add_argument("--start", default="2023-03-14")
        p.add_argument("--end", default="2026-11-02")
        p.add_argument("--executor", choices=("process",), default="process")
        p.add_argument("--workers", default="24")
        p.add_argument("--storage", default="audit/mcx_futures_backtest/storage/mcx_stitched_grid.sqlite")
        p.add_argument("--limit-tasks", type=int)
        p.add_argument("--sample-per-cell", type=int)
        p.add_argument("--compute-reference-oracle", action="store_true")
        p.add_argument("--engine-overrides-json", default="{}")
        p.add_argument("--research-gate-bypass", action=argparse.BooleanOptionalAction, default=True,
                       help="audit-only; live/paper MCX remains held")
        p.add_argument("--random-seed", type=int, default=20260930)

    common(sub.add_parser("dry-run"))
    common(sub.add_parser("run"))
    for name in ("status", "resume"):
        p = sub.add_parser(name)
        p.add_argument("run_id")
        p.add_argument("--storage", default="audit/mcx_futures_backtest/storage/mcx_stitched_grid.sqlite")

    args = parser.parse_args(argv)
    if args.cmd in ("status", "resume"):
        store = SQLiteBacktestStorage(args.storage)
        row = store.get_run(args.run_id)
        if row is None:
            raise SystemExit(f"unknown run_id: {args.run_id}")
        cfg = StitchedConfig(**json.loads(row["config_json"]))
        coordinator = StitchedCoordinator(cfg, execute_task)
        print(json.dumps(coordinator.status(args.run_id) if args.cmd == "status" else coordinator.run(args.run_id), indent=2, default=str))
        return

    tfs = tuple(int(x.strip()) for x in args.tfs.split(",") if x.strip())
    invalid = set(tfs) - set(STACKS)
    if invalid:
        raise SystemExit(f"unsupported stitched-grid TF IDs: {sorted(invalid)}")
    cfg = StitchedConfig(
        run_name=args.run_name,
        symbols=_symbols(args.symbols),
        tfs=tfs,
        start=args.start,
        end=args.end,
        executor=args.executor,
        workers=args.workers,
        storage_path=args.storage,
        limit_tasks=args.limit_tasks,
        compute_reference_oracle=args.compute_reference_oracle,
        engine_overrides=json.loads(args.engine_overrides_json),
        buy_only=True,
        research_gate_bypass=args.research_gate_bypass,
        sample_per_cell=args.sample_per_cell,
        variant_name="MCX_STITCHED_GRID_BUY_ONLY_RESEARCH",
        random_seed=args.random_seed,
    )
    tasks = list(generate_tasks(cfg))
    if args.cmd == "dry-run":
        print(json.dumps({
            "symbols": list(cfg.symbols),
            "stacks": {STACK_NAMES[tf]: list(STACKS[tf]) for tf in tfs},
            "start": cfg.start,
            "end": cfg.end,
            "tasks": len(tasks),
            "buy_only": True,
            "research_gate_bypass": cfg.research_gate_bypass,
            "random_seed": cfg.random_seed,
            "source_mode": "STITCHED_SERIES_RESEARCH",
        }, indent=2))
        return
    coordinator = StitchedCoordinator(cfg, execute_task)
    run_id = coordinator.create()
    print(f"run_id={run_id}", flush=True)
    print(json.dumps(coordinator.run(run_id), indent=2, default=str))


if __name__ == "__main__":
    main()
