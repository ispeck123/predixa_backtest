# Prior NSEFO evidence

The previously generated repaired-gate NSEFO submission package was extracted here unchanged from:

`/home/ispeck/PROJECTS_DEV/STP_LATEST/fin_backend_final_latest/deliverables/nsefo_tf2_tf4_run_92f13c51fae94bdcbb0e7e376328ad92.zip`

Its original archive checksum is retained as `original_submission_zip.sha256`.

Interpretation: this historical run demonstrated that signals/trades are generated once a gate admits them. It was created while TF2/TF4 had been temporarily opened in the live gate; it is therefore not a live-policy validation. The restored live policy and new research-only bypass are documented in this parent package.
