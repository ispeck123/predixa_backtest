# PREDIXA gate-revert and research-bypass evidence package

Read in this order:

1. `01_EXECUTIVE/EXECUTIVE_SUMMARY.md`
2. `02_WORK_ORDER/` — supplied Excel work order
3. `03_IMPLEMENTATION/implementation_diff.patch` and source snapshots
4. `04_FINDINGS/` — live gate verification plus NSEFO/MCX read-only snapshots
5. `05_TEST_EVIDENCE/` — focused regression tests
6. `07_PRIOR_NSEFO_EVIDENCE/` — extracted earlier NSEFO submission evidence

The package contains no copied active SQLite database. Database paths, read-only snapshots, integrity results, and checksums are retained instead.
