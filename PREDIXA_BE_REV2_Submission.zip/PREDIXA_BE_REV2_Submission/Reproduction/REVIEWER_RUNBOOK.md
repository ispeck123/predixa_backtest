# Reviewer runbook

## Prepare two offline trees

Use a clean copy of the original repository to create both scratch trees from the pinned revision. Store the extracted package outside these trees.

```bash
BASELINE=7ac0a972d3e89e7beeb1743391e2cfbedbdcd046
BUNDLE=/absolute/path/to/PREDIXA_BE_REV2_Submission
ORIGINAL=/absolute/path/to/predixa-backend
SCRATCH=$(mktemp -d)
mkdir "$SCRATCH/baseline" "$SCRATCH/corrected"
git -C "$ORIGINAL" archive "$BASELINE" | tar -x -C "$SCRATCH/baseline"
git -C "$ORIGINAL" archive "$BASELINE" | tar -x -C "$SCRATCH/corrected"
git -C "$SCRATCH/corrected" apply --check "$BUNDLE/Source/REV2_SOURCE.patch"
git -C "$SCRATCH/corrected" apply "$BUNDLE/Source/REV2_SOURCE.patch"
for tree in baseline corrected; do
  mkdir -p "$SCRATCH/$tree/data"
  cp -a "$BUNDLE/Inputs/Replay_Fixtures/data/." "$SCRATCH/$tree/data/"
done
PREDIXA_PYTHON=/absolute/path/to/finpro/bin/python \
  bash "$BUNDLE/Reproduction/run_core_checks.sh" \
  "$SCRATCH/baseline" "$SCRATCH/corrected" "$SCRATCH/core-checks"
```

Expected output includes seven byte matches, 60 focused passes on the verified environment, and the scoped E result of 2,970 OOS trades and +0.358R net mean. The runner reads the bundled OHLC snapshots and CASH ledger. It does not start any scanner or broker operation.

## Reproduce flag-enabled evidence

Use the commands and variant settings in [REPRODUCE.md](../Evidence/04_edge_repro/REPRODUCE.md). Run `replay_cash_sample.py` from the patched checkout, pass a fresh output path and use only the named flag or B+D for strict-stop comparison. The official edge checker uses 0.2% round-trip cost and the 2025-11-01 split for these CASH comparisons. For G use the included ledger as the input to `apply_gate_to_ledger.py`. The bundled raw evidence contains the original output files and SQLite stores.

## Reproduce the MySQL migration check

Use the tested server version and the disposable socket path expected by `Evidence/05_testing/check_candidate_migration.py`. Run from the patched tree so its migration paths resolve. Ensure the directory and its server are exclusively owned by the test run before using these commands.

```bash
mkdir -m 700 /tmp/predixa-rev2-mysql
mysqld --no-defaults --initialize-insecure --datadir=/tmp/predixa-rev2-mysql
mysqld --no-defaults --datadir=/tmp/predixa-rev2-mysql \
  --socket=/tmp/predixa-rev2-mysql/test.sock \
  --pid-file=/tmp/predixa-rev2-mysql/test.pid --skip-networking --mysqlx=OFF
```

With the server running in its own terminal, invoke from the corrected tree using the tested Python environment. After verification, shut down the disposable server.

```bash
python "$BUNDLE/Evidence/05_testing/check_candidate_migration.py"
mysqladmin --no-defaults --protocol=SOCKET \
  --socket=/tmp/predixa-rev2-mysql/test.sock -u root shutdown
```

## Broad regression evidence

The original before-and-after commands used pytest on `tests` with `--continue-on-collection-errors` and four explicit excludes.

```bash
python -m pytest -q --continue-on-collection-errors tests \
  --ignore=tests/test_websocket.py --ignore=tests/scanner_test.py \
  --ignore=tests/engine_test.py --ignore=tests/test_order_by_cmp.py
```

Compare failing test IDs in the baseline and corrected logs. The observed runs used isolated scratch trees and dummy loopback settings. The package runner omits this broader command because full environment and unrelated data prerequisites are repository-specific.
