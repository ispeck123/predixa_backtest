#!/usr/bin/env bash
# Use clean scratch checkouts at the documented revision.
set -euo pipefail

if [[ $# != 3 ]]; then
    printf 'Usage: %s BASELINE_CHECKOUT PATCHED_CHECKOUT NEW_OUTPUT_DIRECTORY\n' "$0" >&2
    exit 2
fi
bundle=$(cd "$(dirname -- "$0")/.." && pwd)
baseline=$(cd "$1" && pwd)
patched=$(cd "$2" && pwd)
if [[ "$baseline" == "$patched" ]]; then
    printf 'Use separate baseline and patched checkouts.\n' >&2
    exit 2
fi
for checkout in "$baseline" "$patched"; do
    if [[ -e "$checkout/.env" ]]; then
        printf 'The offline runner requires a scratch checkout without a root .env.\n' >&2
        exit 2
    fi
done
mkdir -- "$3"
output=$(cd "$3" && pwd)
python_executable=${PREDIXA_PYTHON:-python}
export PYTHONPATH=. PYTHONHASHSEED=2718 DB_HOST=127.0.0.1
export DB_USER=rev2_offline DB_PASSWORD=rev2_offline DB_SCHEMA=rev2_offline

capture() {
    local checkout=$1 label=$2
    cd "$checkout"
    "$python_executable" "$bundle/Evidence/01_baseline/capture_outputs.py" "$output/$label" > "$output/$label-cash-capture.log" 2>&1
    "$python_executable" "$bundle/Evidence/01_baseline/capture_derivative_outputs.py" "$output/$label" > "$output/$label-derivative-capture.log" 2>&1
    "$python_executable" "$bundle/Evidence/04_edge_repro/replay_cash_sample.py" "$output/$label-replay" '{}' > "$output/$label-replay.log" 2>&1
}
capture "$baseline" baseline
capture "$patched" corrected
for artifact in gate.json setup.json trades.json MCX.json NSEFO.json; do
    cmp "$output/baseline/$artifact" "$output/corrected/$artifact"
    cmp "$bundle/Evidence/01_baseline/frozen-seeded/$artifact" "$output/corrected/$artifact"
    printf 'Matched %s\n' "$artifact"
done
for artifact in frozen_tasks.json trades.csv; do
    cmp "$output/baseline-replay/$artifact" "$output/corrected-replay/$artifact"
    cmp "$bundle/Evidence/04_edge_repro/supporting_raw_outputs/baseline/$artifact" "$output/corrected-replay/$artifact"
    printf 'Matched native CASH %s\n' "$artifact"
done
cd "$patched"
"$python_executable" -m pytest -q tests/test_predixa_be_rev2.py \
    tests/test_tf_regime_gate_by_exchange.py tests/test_consumed_zone_dedup.py \
    tests/fresh_trend_backtest | tee "$output/focused-pytest.txt"
"$python_executable" scripts/edge_repro_check.py \
    "$bundle/Inputs/Ledger/cash_regime_tf_backtest_labeled_final.csv" \
    --segment NSE_CASH --rt 0.002 --split 2025-11-01 --cell UP/SW/2 | tee "$output/E_scoped.txt"
