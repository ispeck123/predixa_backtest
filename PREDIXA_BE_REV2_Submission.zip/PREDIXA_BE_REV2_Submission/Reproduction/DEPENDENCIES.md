# Dependency requirements

## Core verification

- Git, Bash, and standard Unix commands including sha256sum. The patch requires the PREDIXA backend source at commit `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`.
- Anaconda Python 3.13.5 on Linux x86-64 was used for the focused and broad test runs. The tested package versions are in [requirements-focused.txt](requirements-focused.txt) and [verified-environment-packages.txt](verified-environment-packages.txt). Use the repository-compatible environment with those package versions. The focused list records selected direct requirements and is not a solver lock. Some versions in the tested Anaconda environment may require an earlier build channel or platform-specific artifacts, so a fresh pip-only installation was not verified.
- Python's sqlite3 module for replay persistence. No separate SQLite server is required.
- MySQL 8.4.0 and PyMySQL 1.1.1 for A3 verification. The isolated server uses a private Unix socket with TCP and MySQL X disabled.
- openpyxl 3.1.5 was used to read the workbook in the audit environment. Microsoft Excel or another compatible reader can be used for review.

The broker client library is needed by imports in scanner tests. The focused checks need no credentials or active connection. The runner sets a dummy loopback database configuration and refuses checkouts containing a root .env file. The regression evidence reflects the original finpro environment, not a fresh dependency installation.

## Included files and external prerequisites

The workbook, historical CASH trade ledger and hash-pinned OHLC snapshots ship under Inputs. The OHLC files reproduce the small native CASH and derivative snapshot checks. The archive does not contain the owner-supplied real corporate-action example, an approved historical cell ranking export, the authoritative collection window, or the owner’s exact NSEFO acceptance dataset. Those remain release dependencies.

For the broader legacy suite consult the complete environment inventory and the baseline and corrected pytest logs. Optional lakehouse, connector, and legacy data dependencies are exercised by that wider suite. The broad run is historical evidence and is not part of the package verification runner.
