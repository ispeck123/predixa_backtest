"""Optional evidence derived from the candles consumed by the existing resolver."""
from math import isfinite

import pandas as pd

from scripts.mfe_mae_helper import completed_excursions
from scripts.trade_engine import atr


def trade_observability(trade, setup, score, signature, bars, atr_period):
    fill = pd.Timestamp(trade["entry_timestamp"])
    end = pd.Timestamp(trade["exit_timestamp"]) if trade["exit_timestamp"] else None
    path = bars.iloc[:0]
    if end is not None:
        path = bars.loc[bars.timestamp.between(fill, end)]
        if (path.empty or path.timestamp.iloc[0] != fill or path.timestamp.iloc[-1] != end
                or not path.timestamp.is_monotonic_increasing or path.timestamp.duplicated().any()):
            path = path.iloc[:0]
    metrics = completed_excursions(
        float(trade["entry_price"]), float(trade["stop_price"]), trade["side"],
        path.high.tolist(), path.low.tolist(), trade["outcome"],
    )
    # The fill bar's close and extremes were unknown at the entry touch.
    # Use only the ATR observable at the preceding completed candle.
    prior = bars.loc[bars.timestamp < fill]
    atr_at_entry = None
    if len(prior) and "close" in prior:
        value = atr(prior.high.tolist(), prior.low.tolist(), prior.close.tolist(), atr_period)[-1]
        if value is not None and isfinite(value) and value > 0:
            atr_at_entry = value
    return dict(
        metrics, setup_score=score, zone_v38_score=score, setup_rank=setup["setup_rank"],
        atr_at_entry=atr_at_entry, zone_signature=setup["zone_signature"],
        region_signature=signature, strategy_tf=trade["strategy_tf"],
    )


def export_observability(storage, run_id, output):
    """Export an opt-in sidecar keyed by the same trade ID as the legacy export."""
    import sqlite3
    from contextlib import closing
    from pathlib import Path

    database = Path(storage).resolve().as_uri() + "?mode=ro"
    with closing(sqlite3.connect(database, uri=True)) as connection:
        frame = pd.read_sql_query(
            """SELECT o.*, t.symbol, t.side, t.entry_timestamp, t.exit_timestamp, t.gross_r
               FROM trade_observability o
               JOIN simulated_trades t USING (trade_id)
               JOIN scan_results s USING (scan_id)
               WHERE s.run_id = ? ORDER BY o.trade_id""",
            connection, params=(run_id,),
        )
    frame.to_csv(output, index=False)
    return len(frame)
