"""Known split/bonus discontinuities in unadjusted CASH candles."""
from calendar import monthrange
from datetime import date, datetime, timedelta, timezone


def cash_ex_dates(symbol, events):
    return frozenset(date.fromisoformat(ex_date) for instrument, ex_date, kind in events
                     if instrument.casefold() == symbol.casefold() and kind.upper() in {"SPLIT", "BONUS"})


def exchange_session_dates(timestamps):
    # models.py encodes naive exchange-local wall times as integer Unix values.
    return [datetime.fromtimestamp(ts, tz=timezone.utc).date() for ts in timestamps]


def crosses_ex_date(prior, current, ex_dates, candle_frame):
    if candle_frame == "weekly":
        # The aggregate can include a discontinuity anywhere in its week.
        end = current + timedelta(days=6 - current.weekday())
        return any(prior <= day <= end for day in ex_dates)
    if candle_frame == "monthly":
        end = current.replace(day=monthrange(current.year, current.month)[1])
        return any(prior <= day <= end for day in ex_dates)
    return any(prior < day <= current for day in ex_dates)
