-- MySQL 8+. Apply only on an isolated database until release approval.
CREATE TABLE IF NOT EXISTS cross_tf_candidates (
  candidate_key CHAR(64) PRIMARY KEY,
  region_signature VARCHAR(160) NOT NULL,
  exchange VARCHAR(24) NOT NULL,
  instrument VARCHAR(100) NOT NULL,
  strategy_tf INT NOT NULL,
  zone_side VARCHAR(8) NOT NULL,
  arbitration_group CHAR(64) NOT NULL,
  window_start DATETIME(6) NOT NULL,
  window_end DATETIME(6) NOT NULL,
  chosen BOOLEAN NOT NULL,
  decision_reason VARCHAR(96) NOT NULL,
  selected_candidate_key CHAR(64),
  evidence_version VARCHAR(96),
  decided_at DATETIME(6) NOT NULL,
  winner_group CHAR(64) GENERATED ALWAYS AS (CASE WHEN chosen THEN arbitration_group END) STORED,
  UNIQUE KEY uq_cross_tf_winner (winner_group),
  KEY ix_cross_tf_region_lookup (exchange, instrument, zone_side, window_start),
  CHECK (window_end > window_start)
) ENGINE=InnoDB;
