-- Archive candidate audit records before running this downgrade.
DROP TABLE IF EXISTS cross_tf_candidates;
