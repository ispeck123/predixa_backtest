"""
MFE/MAE computation for B-W-EMBED tuning (task T2). PURE MECHANICAL — no chart eyeballing.

MFE (Max Favorable Excursion) = furthest price moved TOWARD target before the trade closed, in R.
MAE (Max Adverse Excursion)   = furthest price moved TOWARD/PAST stop before the trade closed, in R.

R = |entry - stop|.  A trade "gave back" if it was a loser with MFE >= 1.0 (ran +1R then reversed).
A trade "wicked out" if it was a winner with MAE > 1.0 (breached the stop level, survived, then hit target).

INPUTS you already have per backtest trade:
  entry, stop  : the entry and stoploss prices
  side         : 'BUY' or 'SELL'
  bars         : the exec-TF OHLC bars BETWEEN fill and completion (inclusive), each with .high/.low
                 — the SAME bars the backtest already replays to decide win/loss.

This is meant to be called inside the existing fill->completion replay loop; it adds two running
values, nothing more. No extra data load, no manual step.
"""

def mfe_mae_in_R(entry, stop, side, bar_highs, bar_lows):
    """Return (mfe_R, mae_R). bar_highs/bar_lows are the highs/lows of bars from fill to completion."""
    risk = abs(entry - stop)
    if risk <= 0 or not bar_highs:
        return 0.0, 0.0
    hi = max(bar_highs)
    lo = min(bar_lows)
    if side == 'BUY':
        mfe = (hi - entry) / risk     # favorable = up
        mae = (entry - lo) / risk     # adverse   = down toward stop
    else:  # SELL
        mfe = (entry - lo) / risk     # favorable = down
        mae = (hi - entry) / risk     # adverse   = up toward stop
    return round(mfe, 3), round(mae, 3)


def classify_trade(win, mfe_R, mae_R):
    """Return the two B-W-EMBED metrics flags for this trade."""
    give_back = (not win) and (mfe_R >= 1.0)   # loser that first ran >=1R toward target
    wick_out  = win and (mae_R > 1.0)          # winner that breached the stop before target
    return give_back, wick_out


# ── Aggregate over a trade list to produce the M1/M2 the tuning protocol needs ──
def summarize(trades):
    """
    trades: iterable of dicts with keys entry, stop, side ('BUY'/'SELL'), win (bool),
            bar_highs (list), bar_lows (list).
    Returns dict with n, win_rate, M1_give_back_rate (of losers), M2_wick_out_rate (of winners).
    """
    n = 0; wins = 0; losers = 0; give_backs = 0; wick_outs = 0
    for t in trades:
        mfe, mae = mfe_mae_in_R(t['entry'], t['stop'], t['side'], t['bar_highs'], t['bar_lows'])
        gb, wo = classify_trade(t['win'], mfe, mae)
        n += 1
        if t['win']:
            wins += 1
            if wo: wick_outs += 1
        else:
            losers += 1
            if gb: give_backs += 1
    return {
        'n': n,
        'win_rate': round(wins / n, 4) if n else 0.0,
        'M1_give_back_rate': round(give_backs / losers, 4) if losers else 0.0,   # of losers
        'M2_wick_out_rate':  round(wick_outs / wins, 4) if wins else 0.0,        # of winners
    }


def completed_excursions(entry, stop, side, highs, lows, outcome):
    """OHLC excursions on inclusive execution bars, indexed from fill at zero.

    The resolver treats the completion bar as atomic and resolves target first.
    OHLC cannot order both extremes within that bar. Metrics measure the
    observed bar path, including its wicks, rather than infer tick ordering.
    """
    from math import isfinite

    if outcome not in {"WIN", "LOSS", "TIME_EXIT"}:
        return {"metric_quality": "INCOMPLETE_TRADE"}
    if not all(isfinite(price) for price in (entry, stop)) or entry == stop or side not in {"BUY", "SELL"}:
        return {"metric_quality": "INVALID_INITIAL_RISK"}
    if (not len(highs) or len(highs) != len(lows)
            or any(not isfinite(h) or not isfinite(l) or h < l for h, l in zip(highs, lows))):
        return {"metric_quality": "MISSING_OR_INVALID_CANDLES"}
    mfe, mae = mfe_mae_in_R(entry, stop, side, highs, lows)
    high_idx = max(range(len(highs)), key=highs.__getitem__)
    low_idx = min(range(len(lows)), key=lows.__getitem__)
    risk = abs(entry - stop)
    if side == "BUY":
        favorable, adverse = highs[high_idx] - entry, entry - lows[low_idx]
        bars_to_mfe, bars_to_mae = high_idx, low_idx
    else:
        favorable, adverse = entry - lows[low_idx], highs[high_idx] - entry
        bars_to_mfe, bars_to_mae = low_idx, high_idx
    give_back, wick_out = classify_trade(outcome == "WIN", favorable / risk, adverse / risk)
    return dict(
        metric_quality="OK", mfe_R=max(0.0, mfe), mae_R=max(0.0, mae),
        bars_to_mfe=bars_to_mfe if favorable > 0 else 0,
        bars_to_mae=bars_to_mae if adverse > 0 else 0,
        give_back=give_back if outcome != "TIME_EXIT" else None,
        wick_out=wick_out if outcome != "TIME_EXIT" else None,
    )
