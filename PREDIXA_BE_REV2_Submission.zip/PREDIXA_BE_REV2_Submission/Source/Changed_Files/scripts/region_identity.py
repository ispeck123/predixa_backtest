"""Cross-timeframe price identity and guarded geometry matching."""
from decimal import Decimal, ROUND_HALF_UP


def _price(value):
    price = Decimal(str(value))
    if not price.is_finite():
        raise ValueError("region boundaries must be finite")
    return price


def region_signature(symbol, proximal, distal):
    prices = (_price(p).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
              for p in (proximal, distal))
    return f"{symbol.upper()}:" + ":".join(format(p, "f") for p in prices)


def equivalent_regions(left, right, *, price_tolerance, minimum_overlap):
    """Compare raw endpoints within a caller-supplied tolerance and overlap.

    Inputs contain exchange, instrument (including expiry when applicable),
    side, proximal and distal. Overlap is intersection / union.
    """
    tolerance = _price(price_tolerance)
    overlap = _price(minimum_overlap)
    if tolerance < 0 or not 0 < overlap <= 1:
        raise ValueError("invalid region comparison parameters")
    if tuple(left[k] for k in ("exchange", "instrument", "side")) != tuple(
        right[k] for k in ("exchange", "instrument", "side")
    ):
        return False
    p1, d1 = (_price(left[k]) for k in ("proximal", "distal"))
    p2, d2 = (_price(right[k]) for k in ("proximal", "distal"))
    if abs(p1 - p2) > tolerance or abs(d1 - d2) > tolerance:
        return False
    lo1, hi1 = sorted((p1, d1))
    lo2, hi2 = sorted((p2, d2))
    intersection = min(hi1, hi2) - max(lo1, lo2)
    union = max(hi1, hi2) - min(lo1, lo2)
    return intersection > 0 and intersection >= overlap * union
