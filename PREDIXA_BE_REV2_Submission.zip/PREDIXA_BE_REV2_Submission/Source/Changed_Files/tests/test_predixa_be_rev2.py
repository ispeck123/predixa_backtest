from dataclasses import asdict
from datetime import date
from types import SimpleNamespace

import pandas as pd
import pytest

from audit.fresh_trend_backtest.observability import trade_observability
from audit.fresh_trend_backtest.production_gate import evaluate_gate
from scripts.additional_engine_class import HardGateChecker, RiskTargetCalculator, ZoneNestingTier
from scripts.corporate_action_gaps import cash_ex_dates, crosses_ex_date
from scripts.mfe_mae_helper import completed_excursions
from scripts.models import Config, Quadrant, TF, TradeType, TrendRegime, Zone, ZoneType
from scripts.region_identity import equivalent_regions, region_signature
from scripts.tf_regime_gate_by_exchange import gate


def test_region_identity_and_genuine_equivalence():
    first = dict(exchange="NSE_CASH", instrument="INFY", side="BUY", proximal="100.005", distal=99)
    second = {**first, "proximal": "100.006", "distal": "99.01"}

    def match(other):
        return equivalent_regions(first, other, price_tolerance="0.01", minimum_overlap="0.95")

    assert region_signature("infy", "100.005", 99) == "INFY:100.01:99.00"
    assert match(second)
    assert not match({**second, "distal": "99.01001"})
    assert not match({**second, "side": "SELL"})
    assert not match({**second, "exchange": "NSEFO"})
    assert not match({**second, "proximal": "100.010", "distal": "100.006"})
    assert not equivalent_regions(
        first, {**first, "proximal": 100.50, "distal": 99.50},
        price_tolerance="0.50", minimum_overlap="0.95",
    )


@pytest.mark.parametrize("quadrant", [Quadrant.Q1, Quadrant.Q2, Quadrant.Q3])
@pytest.mark.parametrize("side", [ZoneType.BZ, ZoneType.SZ])
@pytest.mark.parametrize("enabled", [False, True])
def test_q2_only(quadrant, side, enabled):
    zone = Zone("infy", TF.X, side, 94, 100, 2, 0, 1, 2, removes_structure=True)
    ctx = SimpleNamespace(
        regime_E=TrendRegime.SW,
        trade_type_long=TradeType.RANGE_EXTREME,
        trade_type_short=TradeType.RANGE_EXTREME,
    )
    checker = HardGateChecker(Config(range_midcurve_hard_block=enabled))
    ok, reason = checker.check_gates_pre_rr(zone, ctx, TF.X, 101, quadrant=quadrant)
    if enabled and side == ZoneType.BZ and quadrant == Quadrant.Q2:
        assert (ok, reason) == (False, "G7_Q2_MIDCURVE_RED_RANGE")
        assert "G7_Q2_MIDCURVE" in zone.gate_warnings
    else:
        assert ok
        if side == ZoneType.BZ and quadrant != Quadrant.Q1:
            assert "G7_NOT_Q1" in zone.gate_warnings


def test_existing_strict_stop_fallback(monkeypatch):
    from scripts.trend_engine import Config as TrendConfig

    zone = Zone("infy", TF.X, ZoneType.BZ, 96, 100, 2, 0, 1, 2)
    zone.nesting_tier = ZoneNestingTier.TIER_3
    for enabled in (False, True):
        config = TrendConfig(**{"embed_strict_stop": enabled})
        assert asdict(config)["embed_strict_stop"] is enabled
        calculator = RiskTargetCalculator(config)
        monkeypatch.setattr(calculator, "_compute_entry", lambda *_: (100, []))
        monkeypatch.setattr(calculator, "_get_sl_reference_levels", lambda *_: [90, 96])
        monkeypatch.setattr(calculator, "_compute_stop", lambda ref, *_: ref)
        monkeypatch.setattr(calculator, "_compute_target", lambda *_: (112, "STRUCTURAL", 112))
        result = calculator.calculate(zone, 102, [], 1, htf_zones=[])
        assert result.valid is (not enabled)
        assert result.stop == (90 if enabled else 96)


@pytest.mark.parametrize("side,stop,highs,lows", [
    ("BUY", 90, [106, 112, 112], [99, 95, 89]),
    ("SELL", 110, [101, 105, 111], [94, 88, 88]),
])
@pytest.mark.parametrize("outcome", ["WIN", "LOSS"])
def test_completed_excursion_path_and_first_ties(side, stop, highs, lows, outcome):
    fields = completed_excursions(100, stop, side, highs, lows, outcome)
    assert fields["metric_quality"] == "OK"
    assert (fields["mfe_R"], fields["mae_R"]) == (1.2, 1.1)
    assert (fields["bars_to_mfe"], fields["bars_to_mae"]) == (1, 2)
    assert fields["wick_out"] is (outcome == "WIN")
    assert fields["give_back"] is (outcome == "LOSS")


def test_missing_risk_or_bars():
    assert completed_excursions(100, 100, "BUY", [100], [99], "WIN") == {
        "metric_quality": "INVALID_INITIAL_RISK"}
    assert completed_excursions(100, 90, "BUY", [], [], "WIN") == {
        "metric_quality": "MISSING_OR_INVALID_CANDLES"}
    assert completed_excursions(100, 90, "BUY", [], [], "UNRESOLVED") == {
        "metric_quality": "INCOMPLETE_TRADE"}


def test_no_post_exit_excursions_and_no_fill_bar_atr():
    bars = pd.DataFrame(
        {"timestamp": pd.date_range("2026-01-01", periods=4),
         "high": [102, 104, 125, 500], "low": [98, 96, 89, 1], "close": [100, 101, 120, 250]},
    )
    trade = dict(entry_timestamp="2026-01-02", exit_timestamp="2026-01-03", side="BUY",
                 entry_price=100, stop_price=90, outcome="WIN", strategy_tf=2)
    fields = trade_observability(trade, dict(setup_rank=1, zone_signature="legacy"), 77,
                                 "INFY:100.00:90.00", bars, 14)
    assert (fields["mfe_R"], fields["mae_R"], fields["atr_at_entry"]) == (2.5, 1.1, 4)
    assert fields["setup_score"] == fields["zone_v38_score"] == 77


def test_split_and_bonus_session_dates():
    events = (("fixture", "2026-01-26", "SPLIT"), ("fixture", "2026-02-05", "BONUS"),
              ("fixture", "2026-02-03", "DIVIDEND"))
    ex_dates = cash_ex_dates("FIXTURE", events)
    assert ex_dates == {date(2026, 1, 26), date(2026, 2, 5)}
    assert crosses_ex_date(date(2026, 1, 23), date(2026, 1, 27), ex_dates, "sixty")
    assert crosses_ex_date(date(2026, 1, 26), date(2026, 2, 2), ex_dates, "weekly")
    assert not crosses_ex_date(date(2026, 1, 27), date(2026, 1, 28), ex_dates, "daily")
    assert not cash_ex_dates("adjusted_fixture", events)


def test_realized_r_policy_exhaustive():
    cfg = Config(realized_r_cell_whitelist_enabled=True)
    expected = {"NSE_CASH": {(2, "SW", "SW"), (6, "SW", "SW"), (25, "SW", "SW"),
                             (6, "SW", "UP"), (5, "UP", "SW")},
                "NSEFO": {(25, "SW", "SW")}, "MCX": set(), "UNKNOWN": set()}
    for segment, allowed in expected.items():
        for tf in (1, 2, 3, 4, 5, 6, 25):
            for e in ("SW", "UP", "DN"):
                for a in ("SW", "UP", "DN"):
                    args = (segment, tf, e, a)
                    assert bool(gate(*args, config=cfg)[1]) is ((tf, e, a) in allowed)
                    assert evaluate_gate(*args, config=cfg, research_gate_bypass=True).denied is (
                        (tf, e, a) not in allowed)
    assert gate("NSE_CASH", 6, "SW", "UP", config=cfg)[:2] == ("MARGINAL", 0.5)
    assert gate("NSE_CASH", 2, "UP", "SW")[:2] == ("MARGINAL", 0.5)
    assert "pending" in gate("NSE_CASH", 2, "UP", "SW", config=cfg)[2]


def test_flagged_insertion_holds_before_provider_or_database(monkeypatch):
    from shared.db import db_utils
    from scripts import models

    def forbidden(*args, **kwargs):
        pytest.fail("denied candidate touched database or market data")

    monkeypatch.setattr(db_utils.dbc, "get_session", forbidden)
    monkeypatch.setattr(db_utils, "check_upper_lower_circuit_range", forbidden)
    monkeypatch.setattr(models, "Config", lambda: Config(cross_tf_region_dedup_enabled=True))
    assert db_utils.insert_trade_signals({}, 1, 8, 2) == (False, None)
    monkeypatch.setattr(models, "Config", lambda: Config(realized_r_cell_whitelist_enabled=True))
    pending = {"e_regime": "UP", "a_regime": "SW", "STOCK_NAME": "infy"}
    assert db_utils.insert_trade_signals(pending, 1, 8, 2) == (False, None)


def test_whitelist_sizer_uses_same_policy(monkeypatch):
    from scripts import models
    from scripts.position_sizing import PositionSizer, Setup, default_config_10L

    monkeypatch.setattr(models, "Config", lambda: Config(realized_r_cell_whitelist_enabled=True))
    portfolio, segments = default_config_10L()
    sizer = PositionSizer(portfolio, segments)
    pending = Setup(symbol="infy", segment="NSE_CASH", entry=100, stop=90, target=120,
                    zone_score=100, rr=2, sector="", e_regime="UP", a_regime="SW", time_frame="2")
    assert sizer.size(pending) is None
    from dataclasses import replace
    pending = replace(pending, e_regime="SW")
    assert sizer.size(pending) is not None


@pytest.mark.parametrize("event", ["SPLIT", "BONUS"])
def test_gap_module_preserves_unrelated_real_gap(event):
    from scripts.models import CandleSeries, VolatilityRegime
    from scripts.trade_engine import GapModule

    times = pd.to_datetime(["2026-01-23", "2026-01-27", "2026-01-28"])
    cs = CandleSeries(
        o=[100, 56, 109], h=[102, 57, 126], l=[99, 50, 108], c=[101, 51, 125],
        ts=[t.value // 10**9 for t in times],
    )
    module = GapModule()
    levels = [
        Zone("fixture", TF.X, ZoneType.BZ, 95, 99, 0, 0, 0, 1),
        Zone("fixture", TF.X, ZoneType.SZ, 72, 65, 0, 0, 0, 1),
    ]
    legacy = module.detect("fixture", TF.X, cs, VolatilityRegime.NORMAL, levels)
    assert [(zone.ztype, zone.created_idx) for zone in legacy] == [(ZoneType.GSZ, 1), (ZoneType.GDZ, 2)]
    ex_dates = cash_ex_dates("fixture", (("fixture", "2026-01-26", event),))
    guarded = module.detect("fixture", TF.X, cs, VolatilityRegime.NORMAL, levels,
                            gap_ex_dates=ex_dates, candle_frame="daily")
    assert guarded == legacy[1:]
    assert module.detect("fixture", TF.X, cs, VolatilityRegime.NORMAL, levels,
                         gap_ex_dates=ex_dates, candle_frame="daily") == guarded


def test_sidecar_writer_and_export_preserve_legacy_trade(tmp_path, monkeypatch):
    from audit.fresh_trend_backtest import worker
    from audit.fresh_trend_backtest.config import ReplayConfig
    from audit.fresh_trend_backtest.observability import export_observability
    from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage

    ts = pd.date_range("2026-02-01", periods=3)
    bars = pd.DataFrame(dict(timestamp=ts, high=[102, 104, 121], low=[98, 96, 99], close=[101, 99, 120]))
    monkeypatch.setattr(worker, "_x_bars", lambda *_: bars)
    setup = dict(entry_price=100, stop_price=90, target_price=120, rr_ratio=2,
                 zone_score_v38=8, zone_signature="legacy", region_signature="FIXTURE:100.00:90.00")
    raw = dict(best_setup_long=setup, price_cmp=103, trend_context=SimpleNamespace(
        regime_E="SW", regime_A="SW", regime_X="SW", allow_long=True))
    database = tmp_path / "fixture.sqlite"
    storage = SQLiteBacktestStorage(database)
    cfg = ReplayConfig(run_name="fixture", symbols=("fixture",), tfs=(2,),
                       start="2026-02-01", end="2026-02-01")
    snapshots = []
    for state in (False, True):
        run = storage.create_run(cfg)
        storage.register_tasks(run, [dict(symbol="fixture", strategy_tf=2, strategy_tf_name="sixty",
                                          evaluation_timestamp=ts[0].isoformat())])
        task = storage.claim_tasks(run, 1)[0]
        payload = worker._context_payload(task, raw, 0, config=Config(trade_observability_wiring_enabled=state))
        storage.save_events([dict(task=task, result=payload)])
        trade = storage.conn.execute(
            "SELECT entry_price,stop_price,exit_price,gross_r,outcome FROM simulated_trades ORDER BY trade_id DESC"
        ).fetchone()
        snapshots.append(tuple(trade))
        assert export_observability(database, run, tmp_path / "sidecar.csv") == int(state)
    assert snapshots == [(100, 90, 120, 2, "WIN")] * 2
    fields = storage.conn.execute(
        "SELECT setup_score, atr_at_entry, bars_to_mfe, region_signature FROM trade_observability"
    ).fetchone()
    assert tuple(fields) == (8, 4, 1, "FIXTURE:100.00:90.00")
    storage.close()
