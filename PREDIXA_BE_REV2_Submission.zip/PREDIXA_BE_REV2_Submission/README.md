# PREDIXA Backend Revision 2 Submission

**Review disposition: PARTIAL IMPLEMENTATION — ACTION REQUIRED**

Start with the [detailed implementation report](Report/PREDIXA_BE_REV2_Detailed_Implementation_Report.docx). The [Markdown source](Report/PREDIXA_BE_REV2_Detailed_Implementation_Report.md) is also included for easy comparison and review.

| Folder | Contents |
|---|---|
| `Report/` | Standalone technical report with findings, control behavior, tests, and release criteria |
| `Source/` | Apply-checked patch and review copies of all changed and added files, including tests and MySQL upgrade and rollback scripts |
| `Inputs/` | Authoritative workbook, frozen OHLC fixtures, historical CASH trade ledger, and hashes |
| `Evidence/` | Baseline outputs, workstream reports, raw pytest and MySQL logs, native replay databases, trade changes and SHA-256 comparisons |
| `Reproduction/` | Tested environment inventory, requirements, clean-checkout instructions and verification runner |
| `Verification/` | Independent packaging verification results |

Revision baseline `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`. The source patch is intended for the PREDIXA repository at this revision. This archive contains a source overlay and the supplied replay fixtures. It requires the baseline repository and an isolated Python environment. The broad legacy test run used additional repository dependencies and fixtures described in the report.

To verify every artifact after extracting the archive, run `sha256sum -c SHA256SUMS.txt` from this folder. No production credentials, deployment environment files, or live trading state are included.
