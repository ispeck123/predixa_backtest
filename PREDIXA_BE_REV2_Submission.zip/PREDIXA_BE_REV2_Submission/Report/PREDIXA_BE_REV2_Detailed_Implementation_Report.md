---
title: "PREDIXA Backend Revision 2"
subtitle: "Implementation, verification evidence and release disposition"
date: "18 November 2026 work order"
---

# 1. Submission decision

**PARTIAL IMPLEMENTATION — ACTION REQUIRED**

The revision 2 source changes are available as an isolated feature worktree and as an apply-checked patch against baseline revision `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`. The submission is ready for engineering review. Production activation remains blocked.

The strongest verified results are seven byte-identical flag-OFF artifacts, a paired replay with all seven completed trades retaining their economics while gaining observability fields, and an isolated MySQL migration test. The main incomplete engineering work is A2/A3 runtime arbitration. Strict stop failed its bounded diagnostic. Rows C, E, F and G still need the evidence described below.

| Item | Recorded value |
|---|---|
| Specification | `PREDIXA_BE_WorkOrder_rev2_18NOV2026.xlsx`, `BE_WORK_ORDER` |
| Baseline branch | `prod` |
| Baseline revision | `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046` |
| Working branch | `predixa/be-rev2` |
| Source delivery | Patch, 16 modified and six new source or test files, including two SQL scripts |
| Configuration | Five new Boolean controls default to False. Existing strict stop remains False. E introduced no flag or legacy policy edit. |
| Operational safety | No production DB migration, live scanner, broker operation, permission change, order execution, or deployment occurred. |

# 2. Architecture and change boundaries

The CASH and derivative scanners use `process_setup` and `process_setup_fc` to run the shared supply and demand pipeline. The pipeline derives trend context, detects gaps, qualifies Execute zones, computes risk, runs the hard gates, and selects the setup. The formatter exposes strategy timeframe and E/A regimes. A common exchange gate supplies both eligibility and sizing decisions. Signal and automated order insertion have separate persistence boundaries. Existing per-timeframe scheduling can deliver geometrically equivalent candidates seconds apart.

The backtest workers use that production setup path and then resolve fills and completion from as-of historical data. A central SQLite writer persists scans, setups and trades. B adds an optional trade-keyed evidence table and sidecar CSV. The existing primary trade ledger retains its columns and, in the paired sample, its exact bytes. MySQL uses standalone upgrade and rollback SQL for A3. No existing production business table was altered by the migration test.

| Control | Default | Review scope |
|---|---|---|
| `cross_tf_region_dedup_enabled` | False | Emit region identity. Hold the guarded insertion paths pending a closed-window arbiter. |
| `trade_observability_wiring_enabled` | False | Record excursion and setup metadata. Uses A1 identity without enabling A2. |
| `range_midcurve_hard_block` | False | Hard-block RANGE_EXTREME Execute-Q2 BUY setups. |
| `embed_strict_stop` | False | Existing structural stop behavior. B provides measurement for evaluation. |
| `corp_action_gap_guard_enabled` | False | Consume explicit split/bonus metadata for unadjusted CASH input. |
| `realized_r_cell_whitelist_enabled` | False | Apply the revised emission schedule. Hold UP/SW/2 pending reconciliation of E. |

# 3. Work-order traceability

| Row | Engineering | Acceptance | Evidence and limitation |
|---|---|---|---|
| A1 | Implemented | Not verified end to end | Rounding, scope and geometry verified. CASH replay economics unchanged. Duplicate-order collapse requires A2. |
| A2 | Partially implemented | Blocked by dependency | Guarded insertion fails closed. Winner selection and durable collection remain incomplete. |
| A3 | Partially implemented | Blocked by dependency | Tested schema exists. Scanner audit writes and transaction integration remain incomplete. |
| B1 | Implemented | Pass on scoped replay | Seven complete CASH records have excursions and bar order. Wider population remains outside the sample. |
| B2 | Implemented | Pass on scoped replay | Seven complete CASH records have score, entry ATR, rank, signatures and timeframe. |
| C | Implemented | Not verified on required NSEFO cell | Bounded CASH replay removed all four Execute-Q2 trades. |
| D | Existing behavior verified | Fail on scoped replay | Three sampled winners removed. Give-back and wick-out counts did not improve. |
| E | Investigated | Not verified against workbook evidence | Scoped checker reproduces a positive CASH result. Source discrepancy requires owner reconciliation. |
| F | Implemented | Blocked by dependency | Synthetic split and bonus tests passed. Real event and before/after R unavailable. |
| G | Implemented | Not verified end to end | Exact whitelist matrix tested. CASH fixed-ledger comparison completed. Cross-exchange chronological emission remains open. |

## A. Region identity, order arbitration and audit storage

A1 keeps the legacy zone signature and adds a timeframe-independent signature generated from the trading symbol and proximal/distal price. Decimal half-up rounding to 0.01 makes the representation deterministic. Region compatibility uses raw endpoints, exact exchange and instrument scope, side, endpoint tolerance, positive overlap and an intersection-over-union floor. Tolerance and overlap values in unit tests are fixtures. Production matching parameters still require approval.

A2 holds guarded insertion when enabled. The current first-arrival scanning interface cannot choose a higher-ranked candidate arriving later without a collection and finalization boundary. A dated, pre-decision evidence version and an approved window must be supplied before implementing the successful winner path. Independent regions are also held by the current A-enabled guard. No realized R from the evaluated trade is used for selection.

A3 adds the `cross_tf_candidates` table. Per-candidate keys support retries and a generated winner-group key enforces uniqueness at the database level. The isolated race produced one committed winner row and one duplicate-key rejection. This demonstrates a storage primitive. It does not demonstrate grouping across nearby buckets, successful winner selection, scanner restart recovery, or order and audit transaction consistency.

## B. Completion metrics and trade writer

The recorder derives normalized favorable and adverse excursion from actual initial risk. It uses the inclusive fill-to-exit candle range selected by the existing resolver, indexes from the fill at zero and takes the first equal extremum. The existing execution model uses target-first resolution when both levels are touched in the same OHLC bar. The observations include that bar and cannot infer intrabar ordering. Missing or invalid candles and unfinished trades receive a quality status.

The writer captures the actual computed zone score, rank, strategy stack identifier and signatures. Entry ATR uses the last completed candle observable before the fill bar. The seven records in the CASH diagnostic populate every requested observation field. A dedicated SQLite table and optional CSV preserve the existing ledger columns. Unit tests also exercise BUY and SELL direction, zero risk, missing bars, ties and post-exit exclusion. The replay sample contains only BUY trades.

## C. Execute Q2 RANGE_EXTREME BUY gate

The enabled gate rejects a Q2 BUY with `G7_Q2_MIDCURVE_RED_RANGE` and records `G7_Q2_MIDCURVE`. The disabled path preserves `G7_NOT_Q1`. A parameterized matrix covers both sides and all three quadrants. In the bounded CASH replay, three losing Q2 trades and one winning Q2 trade were removed. The remaining trades retained their existing outcomes. This experiment did not reproduce the workbook’s NSEFO SW/SW/25 reference.

## D. Embedded strict stop

Both Config classes already exposed `embed_strict_stop=False`. The relevant calculator uses it to skip the tight Execute distal when the structurally wider nested stop cannot pass the reward-to-risk requirement. The focused TIER_3 test exercised the existing fallback. No stop algorithm change or ATR floor was introduced.

With B active in both sides of the comparison, enabling D left the counts at two losing trades with MFE at least 1R and zero winning trades with MAE above 1R. It removed all three winning trades in the small CASH sample. Net R fell by 7.103R, including an OOS subset decrease of 5.028R. This fails the scoped no-regression criterion and supports leaving strict stop disabled pending a representative replay.

## E. CASH UP/SW/2

The existing CASH ledger reproduced +0.358R net mean across 2,970 OOS trades at 0.2% round-trip cost and the documented 2025-11-01 split. Win rate was 32.8%, and IS net mean was +0.076R. The checker did not publish a confidence interval. The sample and metric did not reproduce the workbook’s weaker summary. A denial and sizing reduction were conditional on failed fresh reproduction, so both legacy settings were retained. Under G the cell remains pending resolution.

## F. Split and bonus gap guard

The guard uses exchange-local session dates and explicit metadata for unadjusted CASH candles. It filters the first comparison that crosses an ex-date, including a market closure, and handles weekly/monthly aggregates that include the event. The source OHLC is preserved. The primary gap detector and the separate Execute re-detection both receive the same guard data. Synthetic holiday-adjacent split and bonus tests removed the false GSZ while preserving a later GDZ. The owner’s real fixture, its price-adjustment provenance and a downstream R comparison remain outstanding.

## G. Realized-R emission whitelist

| Segment | Enabled policy |
|---|---|
| CASH core | SW/SW/2, SW/SW/6, SW/SW/25 |
| CASH marginal | SW/UP/6, UP/SW/5 |
| CASH pending | UP/SW/2 held |
| NSEFO | SW/SW/25 only |
| MCX | No eligible cells |

Tests enumerate the policy across relevant stack IDs and regimes, exercise allocator denial and verify that a denied candidate stops before database or market-data access. The policy is reused in the formatter, historical adapter, allocator and guarded persistence paths. The fixed CASH export retained exactly the five permitted cells. Holding UP/SW/2 removed 2,970 OOS trades and 1,062.862R net in that ledger. This is the effect of reapplying eligibility to completed trades. It does not capture portfolio weighting, capital contention or chronological regeneration. Complete NSEFO and MCX emission replays remain unverified.

# 4. Replay results

The bounded native sample uses 16 CASH scan tasks, across four timeframes and four historical dates. The source OHLC, resolution rules and costs are held fixed across variants. Each run uses the pinned baseline or its revision 2 patch. The selected dates provide diagnostic coverage. The sample is not a preregistered acceptance corpus. The market-data input hashes and raw variant outputs are included. The official checker uses completed BUY trades and setup-time IS/OOS separation at 2025-11-01 with 0.2% round-trip friction.

| Comparison | Trades before to after | Net R before | Net R after | Net R delta |
|---|---:|---:|---:|---:|
| A1 native CASH | 7 to 7 | +2.603 | +2.603 | 0.000 |
| B1/B2 native CASH | 7 to 7 | +2.603 | +2.603 | 0.000 |
| C native CASH | 7 to 3 | +2.603 | +3.902 | +1.299 |
| D native CASH | 7 to 4 | +2.603 | −4.500 | −7.103 |
| G native CASH | 7 to 7 | +2.603 | +2.603 | 0.000 |
| G fixed CASH ledger, OOS | 4,988 to 2,018 | +3,058.519 | +1,995.657 | −1,062.862 |

The E result is mean R per trade. The table reports summed net R. The native sample OOS subsets are provided separately alongside gross R and changed trade identities. Missing OOS coverage in scoped cells fails closed. A2, A3 and F have no paired realized-R result.

# 5. Compatibility and database verification

Seven seeded artifacts matched by SHA-256. They cover 189 gate decisions, eight CASH snapshots, a derivative snapshot for each of NSEFO and MCX, a fill fixture, the native CASH ledger, and its frozen task list. The first unseeded setup captures differed due to string rendering of an existing Python set. Independent runs with `PYTHONHASHSEED=2718` matched without rewriting business fields. This is a scoped parity result. Production-wide order sequencing, the full API surface and all export variants remain unverified.

The MySQL 8.4 migration test used a private Unix socket with TCP disabled. Upgrade, rerun, downgrade, existing-row preservation, rollback, retry rejection and concurrent unique-winner enforcement passed. Both the server and its data directory were isolated from production. SQLite adds schema metadata for the evidence table. Existing trade fields and the sampled primary CSV were preserved.

# 6. Automated tests and reproduction

| Test execution | Passed | Failed | Warnings |
|---|---:|---:|---:|
| Final focused suite | 60 | 0 | 5 |
| Baseline broad offline suite | 556 | 12 | 27 |
| Corrected broad offline suite | 583 | 12 | 27 |

The 12 failing test identifiers match across the broad before-and-after runs. Four manual or infrastructure-bound modules were excluded from both runs and are named in the evidence. The focused suite exercises geometry, whitelist, allocator, insertion holds, Q2 conditions, TIER_3 fallback, excursion chronology, corporate-action filtering, replay writing and export. SQL isolation and concurrency evidence are separate from pytest totals. The package checks also reapply the patch to a fresh copy of the pinned source and rerun the focused checks and deterministic comparisons from bundled fixtures.

Reproduction requires the baseline PREDIXA source, Linux with Bash/Git, the verified Python environment and optional MySQL 8.4 for migration testing. The package includes selected direct requirement pins, the full observed package/version inventory, raw logs and exact commands. A new pip-only environment installation was not verified.

# 7. Release criteria and next approvals

1. Supply the approved collection window and versioned historical cell scores with explicit availability dates. Complete an authoritative, transactional scanner/order arbitration path and verify chosen/suppressed decisions under concurrency, rollback, retries and restart.
2. Reproduce C and D on the agreed SW/SW datasets, with the exact NSEFO evaluation for C. D requires improvement in both requested excursion counts and preservation of validated economics.
3. Reconcile the revised CASH UP/SW/2 claim with the reproduced ledger. Record owner disposition before altering its independent denial/weight policy or permitting it under G.
4. Supply a real CASH split or bonus event, the adjustment status of its source and replay data. Establish zero false gaps and report realized R.
5. Complete native cross-exchange whitelist verification and broader flag-OFF contracts. Address the baseline failures relevant to release.
6. Obtain owner approval for migration and activation separately. Preserve the audit evidence before any downgrade.

All new flags and the existing strict-stop control remain OFF. No live operation or production deployment took place.
