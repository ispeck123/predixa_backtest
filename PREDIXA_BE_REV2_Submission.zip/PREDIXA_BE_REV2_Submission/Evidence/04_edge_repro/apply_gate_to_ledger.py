"""Apply each permission schedule to the same existing CASH export."""
import csv
import sys
from pathlib import Path

from scripts.models import Config
from scripts.tf_regime_gate_by_exchange import gate

source, output = map(Path, sys.argv[1:])
output.mkdir(parents=True, exist_ok=True)
with source.open(newline="") as handle:
    reader = csv.DictReader(handle)
    rows = list(reader)
    fields = reader.fieldnames
for label, enabled in (("legacy", False), ("realized_r", True)):
    config = Config(realized_r_cell_whitelist_enabled=enabled)
    with (output / f"{label}.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fields)
        writer.writeheader()
        for row in rows:
            _, weight, _ = gate("NSE_CASH", int(row["strategy_tf"]), row["e_regime"],
                                row["a_regime"], row["stock"], config=config)
            if weight:
                writer.writerow(row)
