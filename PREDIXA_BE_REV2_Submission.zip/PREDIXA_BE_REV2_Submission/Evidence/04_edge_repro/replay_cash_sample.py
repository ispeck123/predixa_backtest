"""Bounded native CASH replay for engineering checks, not release OOS evidence."""
import contextlib
import io
import json
import logging
import sys
from pathlib import Path

import pandas as pd

from audit.fresh_trend_backtest.config import ReplayConfig
from audit.fresh_trend_backtest.export_cash_tracking_cells import export_cash_tracking_cells
from audit.fresh_trend_backtest.replay import TF_STACKS, completed_scan_timestamps
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.fresh_trend_backtest.worker import execute_task

output = Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=True)
overrides = json.loads(sys.argv[2])
logging.disable(logging.CRITICAL)
tfs = (2, 5, 6, 25)
tasks = []
for day in ("2024-11-11", "2025-10-30", "2025-11-12", "2025-11-13"):
    start = pd.Timestamp(day)
    for tf in tfs:
        times = completed_scan_timestamps("infy", tf, start, start + pd.Timedelta(hours=23))
        if times:
            tasks.append(dict(symbol="infy", strategy_tf=tf, strategy_tf_name=TF_STACKS[tf][-1],
                              evaluation_timestamp=times[0].isoformat()))
with contextlib.redirect_stdout(io.StringIO()):
    storage = SQLiteBacktestStorage(output / "replay.sqlite")
    run = storage.create_run(ReplayConfig(run_name="revision2-diagnostic", symbols=("infy",),
                                         tfs=tfs, start="2024-11-11", end="2025-11-13"),
                             run_id="revision2-diagnostic")
    storage.register_tasks(run, tasks)
    scans = storage.claim_tasks(run, len(tasks))
    events = [execute_task(task, engine_overrides=overrides) for task in scans]
    for event in events:
        if "error" in event:
            raise RuntimeError(event["error"])
    storage.save_events(events)
    storage.close()
export_cash_tracking_cells(output / "replay.sqlite", run, output / "trades.csv")
(output / "frozen_tasks.json").write_text(json.dumps(tasks, indent=2) + "\n")
if overrides.get("trade_observability_wiring_enabled"):
    from audit.fresh_trend_backtest.observability import export_observability

    export_observability(output / "replay.sqlite", run, output / "observability.csv")
