"""Summarize the bounded native replay and the CASH ledger policy replay."""
from collections import defaultdict
import csv
from hashlib import sha256
from pathlib import Path

from scripts.edge_repro_check import load

root = Path(__file__).resolve().parent
raw = root / "supporting_raw_outputs"
split = "2025-11-01"
cost = 0.002


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def read_totals(path):
    groups = defaultdict(lambda: [0, 0., 0.])
    for row in load(path, None, split=split):
        key = (*row["cell"][1:4], "OOS" if row["d"] >= split else "IS")
        for label in (key, ("ALL", "ALL", "ALL", key[3]), ("ALL", "ALL", "ALL", "ALL")):
            values = groups[label]
            values[0] += 1
            values[1] += row["g"]
            values[2] += row["g"] - cost * row["e"] / abs(row["e"] - row["s"])
    return groups


def key(row):
    return row["stock"], row["strategy_tf"], row["side"], row["setup_timestamp"]


def comparison(before, after):
    first = {key(row): row for row in rows(before)}
    second = {key(row): row for row in rows(after)}
    for trade in sorted(first.keys() | second.keys()):
        left, right = first.get(trade), second.get(trade)
        if left and right:
            metrics = ("entry", "stop", "target", "entry_timestamp", "exit_timestamp",
                       "outcome", "gross_r")
            status = "UNCHANGED" if all(left[m] == right[m] for m in metrics) else "CHANGED"
        else:
            status = "REMOVED" if left else "ADDED"
        yield (*trade, status, (left or {}).get("trade_id"), (right or {}).get("trade_id"),
               (left or {}).get("gross_r"), (right or {}).get("gross_r"))


base = raw / "baseline/trades.csv"
pairs = {
    row: (base, raw / f"{variant}/trades.csv") for row, variant in
    {"A1": "A", "B1": "B", "B2": "B", "C": "C", "D": "D", "G sample": "G"}.items()
}
pairs["G ledger"] = raw / "G_ledger/legacy.csv", raw / "G_ledger/realized_r.csv"
with (root / "BEFORE_AFTER_TRADES.csv").open("w", newline="") as d, (
    root / "CELL_REALIZED_R_COMPARISON.csv"
).open("w", newline="") as c, (root / "EDGE_REPRO_SUMMARY.csv").open("w", newline="") as s:
    details, cells, summary = map(csv.writer, (d, c, s))
    details.writerow(("row", "symbol", "strategy_tf", "side", "setup_timestamp", "change",
                      "before_trade_id", "after_trade_id", "before_gross_r", "after_gross_r"))
    columns = ("n_before", "n_after", "gross_r_before", "gross_r_after", "gross_r_delta",
               "net_r_before", "net_r_after", "net_r_delta")
    cells.writerow(("row", "E", "A", "tf", "partition", *columns))
    summary.writerow(("row", "partition", *columns, "before_sha256", "after_sha256"))
    for row, (before, after) in pairs.items():
        first, second = read_totals(before), read_totals(after)
        details.writerows((row, *record) for record in comparison(before, after))
        digest = [sha256(path.read_bytes()).hexdigest() for path in (before, after)]
        for cell in sorted(first.keys() | second.keys(), key=str):
            a, b = first[cell], second[cell]
            record = (a[0], b[0], a[1], b[1], b[1]-a[1], a[2], b[2], b[2]-a[2])
            cells.writerow((row, *cell, *record))
            if cell[:3] == ("ALL",) * 3:
                summary.writerow((row, cell[3], *record, *digest))
    for row in ("A2", "A3", "E", "F"):
        summary.writerow((row, "NO_PAIRED_REPLAY"))
