"""Capture deterministic derivative setup artifacts from continuous local fixtures."""
import contextlib
from datetime import datetime
import io
import json
from pathlib import Path
import sys

from audit.fresh_trend_backtest.replay import serialise
from scripts.setup_engine_new import process_setup_fc

specs = (
    ("NSEFO", "INFY", "27102026", True, ["weekly", "daily", "seventy_five"]),
    ("MCX", "CRUDEOILM", "18122026", False, ["weekly", "daily", "sixty"]),
)
output = Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=True)
for segment, symbol, expiry, future, frames in specs:
    with contextlib.redirect_stdout(io.StringIO()):
        result = process_setup_fc(symbol, frames, expiry, datetime(2026, 10, 20, 15), future)
    if not isinstance(result, dict) or result.get("trend_context") is None:
        raise RuntimeError(f"{segment} invalid capture: {result}")
    (output / f"{segment}.json").write_text(
        json.dumps(serialise(result), separators=(",", ":"), default=str) + "\n")
