"""Capture deterministic portions of offline production and fill paths."""
import contextlib
import io
import itertools
import json
import sys
from pathlib import Path

import pandas as pd

from audit.fresh_trend_backtest.replay import resolve_buy, run_current_setup, serialise
from scripts.tf_regime_gate_by_exchange import gate

output = Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=True)
gates = [[values, gate(*values)] for values in itertools.product(
    ("NSE_CASH", "NSEFO", "MCX"), (1, 2, 3, 4, 5, 6, 25),
    ("UP", "SW", "DN"), ("UP", "SW", "DN")
)]
setups = []
with contextlib.redirect_stdout(io.StringIO()):
    for tf in (2, 5, 6, 25):
        for date in ("2025-11-19 15:00", "2026-08-26 15:00"):
            setups.append([tf, date, serialise(run_current_setup("infy", tf, pd.Timestamp(date)))])
bars = pd.DataFrame([
    ["2026-01-01 09:15", 110, 95],
    ["2026-01-01 10:15", 106, 99],
    ["2026-01-01 11:15", 121, 89],
], columns=["timestamp", "high", "low"])
bars["timestamp"] = pd.to_datetime(bars["timestamp"])
trades = [resolve_buy(dict(scan_timestamp="2026-01-01 09:15", entry=100, stop=90, target=target), bars)
          for target in (120, 130)]
for name, payload in (("gate", gates), ("setup", setups), ("trades", trades)):
    (output / f"{name}.json").write_text(json.dumps(payload, separators=(",", ":"), default=str) + "\n")
