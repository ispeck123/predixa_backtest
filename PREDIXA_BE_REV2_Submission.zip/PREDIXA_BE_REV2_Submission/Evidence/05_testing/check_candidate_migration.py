"""Run only against the isolated, TCP-disabled revision 2 test server."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
import pymysql

SOCKET = "/tmp/predixa-rev2-mysql/test.sock"
UP = Path("scripts/db_migrations/20261118_cross_tf_candidates.sql").read_text()
DOWN = Path("scripts/db_migrations/rollback/20261118_cross_tf_candidates.sql").read_text()
INSERT = """INSERT INTO cross_tf_candidates
(candidate_key, region_signature, exchange, instrument, strategy_tf, zone_side,
 arbitration_group, window_start, window_end, chosen, decision_reason,
 selected_candidate_key, evidence_version, decided_at)
VALUES (%s, 'FIXTURE:100.00:99.00', 'NSE_CASH', 'FIXTURE', %s, 'BUY',
 %s, '2026-01-01 00:00:00', '2026-01-01 00:01:00', %s, 'fixture', NULL,
 'synthetic-test-version', '2026-01-01 00:01:00')"""


def connect(database=None):
    return pymysql.connect(user="root", unix_socket=SOCKET, database=database)


with connect() as connection, connection.cursor() as cur:
    cur.execute("CREATE DATABASE IF NOT EXISTS rev2_isolated_test")
with connect("rev2_isolated_test") as connection, connection.cursor() as cur:
    cur.execute("CREATE TABLE IF NOT EXISTS legacy_probe (id INT PRIMARY KEY, value INT)")
    cur.execute("INSERT IGNORE INTO legacy_probe VALUES (1, 37)")
    connection.commit()
    cur.execute(DOWN)
    cur.execute(UP)
    cur.execute(UP)
    cur.execute("SELECT * FROM legacy_probe")
    assert cur.fetchall() == ((1, 37),)
    cur.execute(INSERT, ("rollback", 2, "rollback-group", True))
    connection.rollback()
    cur.execute("SELECT COUNT(*) FROM cross_tf_candidates")
    assert cur.fetchone() == (0,)

    start = Barrier(2)
    def insert_winner(tf):
        with connect("rev2_isolated_test") as worker, worker.cursor() as query:
            start.wait(timeout=5)
            try:
                query.execute(INSERT, (str(tf), tf, "race-group", True))
            except pymysql.IntegrityError as error:
                assert error.args[0] == 1062
                worker.rollback()
                return False
            worker.commit()
            return True
    with ThreadPoolExecutor(2) as pool:
        assert sorted(pool.map(insert_winner, (2, 5))) == [False, True]
    connection.rollback()
    cur.execute("SELECT COUNT(*) FROM cross_tf_candidates WHERE chosen = TRUE")
    assert cur.fetchone() == (1,)
    cur.execute(INSERT, ("suppressed", 5, "race-group", False))
    try:
        cur.execute(INSERT, ("suppressed", 5, "race-group", False))
        raise AssertionError("candidate key accepted a duplicate")
    except pymysql.IntegrityError as error:
        assert error.args[0] == 1062
    connection.commit()
    cur.execute(DOWN)
    cur.execute(DOWN)
    cur.execute("SELECT * FROM legacy_probe")
    assert cur.fetchall() == ((1, 37),)
print("MySQL 8.4 upgrade, rerun, downgrade, legacy data, rollback, retry and concurrent unique winner checks passed")
