# Package verification

- The supplied patch applied cleanly to a freshly exported copy of the pinned Git revision.
- Independent core checks in the patched scratch copy passed all 60 focused tests. The seven flag-OFF artifacts matched both fresh baseline outputs and the archived evidence.
- The official scoped E run reproduced 2,970 OOS trades, 32.8% OOS wins, and +0.358R OOS net mean from the bundled input ledger.
- Every bundled source file matches the file obtained by applying the patch. Input hashes identify the exact supplied workbook, historical ledger and replay fixtures.
- The archive contains historical reports and logs for the broad regression and isolated MySQL checks. The package verification run focused on the patch, core tests, deterministic replay and scoped E, and did not repeat the full suite or start MySQL.
