Start with 01_EXECUTIVE. Source SQLite is not copied; its immutable path and SHA-256 are recorded in 06_REPRODUCIBILITY.
