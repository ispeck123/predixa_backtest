"""NSEFO provisional-expiry-aware replay on the existing FYERS containers.

This audit-only runner keeps the locked strategy implementation and existing
continuous OHLC inputs unchanged.  For research it treats each continuous
container as the observed NSEFO NEAR slot at the evaluation date, attaches the
separately staged same-day bhavcopy observation, and enforces the locked
session-relative expiry controls.  Owner approval remains pending; results
must not be represented as official verified contract-attributed performance.
"""
from __future__ import annotations

import argparse
import concurrent.futures as futures
import json
import signal
import time
from dataclasses import dataclass, replace
from pathlib import Path

from audit.derivatives_backtest_common.expiry_session_controls import ExpirySessionControlMap, sha256
from audit.fresh_trend_backtest.result_writer import ResultWriter
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.nsefo_futures_backtest.run_phase_a import (
    Config, NSEFO_STACKS, _symbols, _symbols_from_baseline, execute_task,
    generate_tasks,
)


PROVISIONAL_STATUS = "OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER"
MODE = "PROVISIONAL_EXPIRY_AWARE_NEAR_SLOT_ASSUMPTION"


@dataclass(frozen=True)
class ProvisionalConfig(Config):
    expiry_map_path: str = ""
    expiry_map_sha256: str = ""
    contract_slot_assumption: str = "FYERS_CONTINUOUS_CONTAINER_TREATED_AS_OBSERVED_NEAR_SLOT"
    expiry_map_verification_status: str = PROVISIONAL_STATUS


class ProvisionalCoordinator:
    """Single SQLite writer, process workers, and map controls per task."""

    def __init__(self, cfg: ProvisionalConfig):
        self.cfg = cfg
        self.store = SQLiteBacktestStorage(cfg.storage)
        self.expiries = ExpirySessionControlMap.load(
            Path(cfg.expiry_map_path), "NSEFO", cfg.symbols, {PROVISIONAL_STATUS},
        )
        if self.expiries.digest != cfg.expiry_map_sha256:
            raise ValueError("provisional expiry map checksum differs from pinned config")

    def _tasks(self) -> list[dict]:
        included, excluded = [], []
        for task in generate_tasks(self.cfg):
            symbol = str(task["symbol"]).rsplit("@", 1)[0]
            if self.expiries.has_observation(symbol, task["evaluation_timestamp"]):
                included.append(task)
            else:
                excluded.append({"symbol": symbol, "strategy_tf": task["strategy_tf"], "evaluation_timestamp": task["evaluation_timestamp"], "reason": "no_same_day_expiry_observation"})
        if self.cfg.limit_tasks:
            included = included[:self.cfg.limit_tasks]
        sidecar = self.cfg.storage.with_suffix(self.cfg.storage.suffix + ".input_exclusions.json")
        if sidecar.exists():
            raise FileExistsError(f"refusing to overwrite exclusion ledger: {sidecar}")
        sidecar.write_text(json.dumps({"included_tasks": len(included), "excluded_tasks": len(excluded), "rows": excluded}, indent=2) + "\n", encoding="utf-8")
        return included

    def create(self):
        self.expiries.assert_controls_complete(self.cfg.end)
        tasks = self._tasks()
        run_id = self.store.create_run(self.cfg, len(tasks))
        self.store.register_tasks(run_id, tasks)
        return run_id

    def _dispatch(self, task: dict) -> dict:
        underlying = str(task["symbol"]).rsplit("@", 1)[0]
        return {
            **task,
            "market_segment": "NSEFO", "is_future": True,
            "buy_only": self.cfg.buy_only,
            "research_gate_bypass": self.cfg.research_gate_bypass,
            "research_mode": self.cfg.research_mode,
            "research_data_root": self.cfg.research_data_root,
            "resolution_end": self.cfg.end,
            "expiry_control": self.expiries.control(underlying, task["evaluation_timestamp"], exclude_e1_gap=False,
                                                     replay_end=self.cfg.end),
        }

    def run(self, run_id: str):
        self.store.reclaim_stale(run_id)
        self.store.set_run_status(run_id, "RUNNING")
        workers = self.cfg.resolved_workers()
        self.store.set_execution(run_id, "process", workers)
        writer = ResultWriter(self.store, self.cfg.write_batch_size, self.cfg.flush_seconds)
        writer.start()
        active = {}
        last = time.monotonic()
        stopping = False

        def stop(*_):
            nonlocal stopping
            stopping = True

        old = (signal.signal(signal.SIGINT, stop), signal.signal(signal.SIGTERM, stop))
        try:
            with futures.ProcessPoolExecutor(max_workers=workers) as pool:
                while not stopping:
                    writer.raise_if_failed()
                    capacity = max(0, workers * 2 - len(active))
                    for claimed in self.store.claim_tasks(run_id, capacity):
                        try:
                            task = self._dispatch(claimed)
                        except Exception as exc:
                            writer.submit({"task": claimed, "error": {"type": type(exc).__name__, "message": str(exc), "traceback": "expiry-control dispatch"}, "duration_ms": None, "worker_id": "coordinator", "max_retries": self.cfg.max_retries})
                            continue
                        active[pool.submit(execute_task, task, False, self.cfg.max_retries, True, self.cfg.compute_reference_oracle, self.cfg.engine_overrides)] = task
                    if not active:
                        counts = self.store.task_counts(run_id)
                        if not (counts.get("PENDING", 0) or counts.get("RETRY", 0)):
                            break
                        continue
                    done, _ = futures.wait(active, timeout=0.25, return_when=futures.FIRST_COMPLETED)
                    for future in done:
                        task = active.pop(future)
                        try:
                            writer.submit(future.result())
                        except BaseException as exc:
                            writer.submit({"task": task, "error": {"type": type(exc).__name__, "message": str(exc), "traceback": "future retrieval failure"}, "duration_ms": None, "worker_id": "coordinator", "max_retries": self.cfg.max_retries})
                    if time.monotonic() - last >= self.cfg.progress_seconds:
                        counts = self.store.task_counts(run_id)
                        print(f"Run {run_id}: {counts.get('COMPLETED', 0):,}/{counts.get('TOTAL', 0):,} ({100 * counts.get('COMPLETED', 0) / max(1, counts.get('TOTAL', 1)):.1f}%), active={len(active)}, writer_queue={writer.queue.qsize()}, executor=process/{workers}", flush=True)
                        last = time.monotonic()
                if not stopping:
                    for future in active:
                        writer.submit(future.result())
        finally:
            writer.close()
            self.store.finalise_counts(run_id)
            counts = self.store.task_counts(run_id)
            terminal = counts.get("COMPLETED", 0) + counts.get("FAILED", 0)
            self.store.set_run_status(run_id, "COMPLETED" if terminal == counts.get("TOTAL", 0) else "PAUSED")
            signal.signal(signal.SIGINT, old[0])
            signal.signal(signal.SIGTERM, old[1])
        return self.status(run_id)

    def status(self, run_id: str):
        run = dict(self.store.get_run(run_id))
        counts = self.store.task_counts(run_id)
        signals = self.store.conn.execute("SELECT count(*) FROM scan_results WHERE run_id=? AND signal_generated=1", (run_id,)).fetchone()[0]
        trades = self.store.conn.execute("SELECT count(*) FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?", (run_id,)).fetchone()[0]
        return {"run": run, "task_counts": counts, "signals": signals, "entered_trades": trades}


def _config(args, symbols: tuple[str, ...]) -> ProvisionalConfig:
    map_path = Path(args.expiry_map).resolve()
    return ProvisionalConfig(
        args.run_name, symbols, tuple(int(x) for x in args.tfs.split(",") if x.strip()), args.start, args.end,
        "process", args.workers, storage_path=args.storage, limit_tasks=args.limit_tasks,
        sample_every=args.sample_every, compute_reference_oracle=args.compute_reference_oracle,
        variant_name="PHASE_A_STITCHED_" + MODE, engine_overrides=json.loads(args.engine_overrides_json),
        buy_only=True, research_gate_bypass=args.research_gate_bypass, research_mode=MODE,
        research_data_root=str(args.research_data_root) if args.research_data_root else None,
        random_seed=args.random_seed, expiry_map_path=str(map_path), expiry_map_sha256=sha256(map_path),
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    def common(item):
        item.add_argument("--run-name", default="nsefo_provisional_expiry_aware")
        item.add_argument("--symbols", default="all")
        item.add_argument("--symbols-from-storage", type=Path)
        item.add_argument("--symbols-from-run")
        item.add_argument("--tfs", default="2,4")
        item.add_argument("--start", default="2024-10-01")
        item.add_argument("--end", default="2026-09-30")
        item.add_argument("--workers", default="24")
        item.add_argument("--storage", required=True)
        item.add_argument("--expiry-map", required=True)
        item.add_argument("--research-data-root", type=Path, required=True)
        item.add_argument("--limit-tasks", type=int)
        item.add_argument("--sample-every", type=int, default=1)
        item.add_argument("--compute-reference-oracle", action="store_true")
        item.add_argument("--engine-overrides-json", default="{}")
        item.add_argument("--research-gate-bypass", action=argparse.BooleanOptionalAction, default=True)
        item.add_argument("--random-seed", type=int, default=20260930)

    common(sub.add_parser("dry-run")); common(sub.add_parser("run"))
    for name in ("status", "resume"):
        item = sub.add_parser(name); item.add_argument("run_id"); item.add_argument("--storage", required=True)
        item.add_argument("--workers", help="execution-only resume override; persisted config remains immutable")
    args = parser.parse_args(argv)
    if args.cmd in {"status", "resume"}:
        store = SQLiteBacktestStorage(args.storage)
        row = store.get_run(args.run_id)
        if row is None:
            raise SystemExit(f"unknown run_id: {args.run_id}")
        cfg = ProvisionalConfig(**json.loads(row["config_json"]))
        if args.workers:
            cfg = replace(cfg, workers=args.workers)
        coordinator = ProvisionalCoordinator(cfg)
        print(json.dumps(coordinator.status(args.run_id) if args.cmd == "status" else coordinator.run(args.run_id), indent=2, default=str))
        return
    if bool(args.symbols_from_storage) != bool(args.symbols_from_run):
        parser.error("--symbols-from-storage and --symbols-from-run must be supplied together")
    tfs = tuple(int(x) for x in args.tfs.split(",") if x.strip())
    invalid = set(tfs) - set(NSEFO_STACKS)
    if invalid:
        raise SystemExit(f"unsupported TF IDs: {sorted(invalid)}")
    symbols = _symbols_from_baseline(args.symbols_from_storage, args.symbols_from_run) if args.symbols_from_storage else _symbols(args.symbols)
    cfg = _config(args, symbols)
    expiries = ExpirySessionControlMap.load(Path(cfg.expiry_map_path), "NSEFO", cfg.symbols, {PROVISIONAL_STATUS})
    tasks = list(generate_tasks(cfg))
    if cfg.limit_tasks:
        tasks = tasks[:cfg.limit_tasks]
    if args.cmd == "dry-run":
        print(json.dumps({"symbols": len(cfg.symbols), "tfs": list(cfg.tfs), "tasks": len(tasks), "map_path": cfg.expiry_map_path, "map_sha256": cfg.expiry_map_sha256, "map_near_observations": len(expiries.rows), "unresolved_terminal_segments": expiries.unresolved_terminal_segments(), "research_mode": MODE, "slot_assumption": cfg.contract_slot_assumption, "rules": {"entry_cutoff": "expiry minus 5 observed trading sessions; no new entry on or after cutoff", "time_exit": "first executable bar on expiry minus 3 observed trading sessions", "mcx_e1": "not applicable"}}, indent=2))
        return
    coordinator = ProvisionalCoordinator(cfg)
    run_id = coordinator.create()
    print(f"run_id={run_id}", flush=True)
    print(json.dumps(coordinator.run(run_id), indent=2, default=str))


if __name__ == "__main__":
    main()
