"""Fresh historical futures replay using the current ``process_setup_fc`` path.

This runner deliberately uses its own namespace and SQLite file.  It does not
modify, import as input, or overwrite the cash replay evidence.  A task is one
underlying/expiry/strategy-timeframe/completed X-bar timestamp.  The database's
``symbol`` value is the explicit contract key ``UNDERLYING@DDMMYYYY`` so the
existing normalized audit schema can keep contracts independent.
"""
from __future__ import annotations

import argparse
import concurrent.futures as futures
import contextlib
import io
import json
import logging
import os
import signal
import time
import traceback
from dataclasses import asdict, dataclass
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
from typing import Any

import pandas as pd

from audit.fresh_trend_backtest.result_writer import ResultWriter
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.fresh_trend_backtest.worker import _enum, _value, _zone
from audit.fresh_trend_backtest.production_gate import evaluate_gate

DATA = Path("data/indian_stocks_future_data/latest_data_csv")

from audit.nsefo_futures_backtest.preflight import NSEFO_ACTIVE_EXPIRIES, NSEFO_ALLOWED_SYMBOLS


def future_stacks() -> dict[int, tuple[str, ...]]:
    """Read the production mapping; never infer a cash timeframe mapping."""
    from shared.config.settings import stock_logic_config
    out = {}
    for tf in (1, 2, 5, 25):
        value = getattr(stock_logic_config, f"FUTURE_TIME_FRAME_{tf}", None)
        if not value:
            raise RuntimeError(f"production FUTURE_TIME_FRAME_{tf} is not configured")
        out[tf] = tuple(value)
    return out


STACKS = future_stacks()


@dataclass(frozen=True)
class FuturesConfig:
    run_name: str
    symbols: tuple[str, ...]
    tfs: tuple[int, ...]
    start: str
    end: str
    expiries: int = 3
    expiry_policy: str = "nearest_on_or_after_end"
    executor: str = "process"
    workers: int | str = "4"
    max_retries: int = 2
    storage_path: str = "audit/futures_trend_backtest/storage/futures_backtest.sqlite"
    write_batch_size: int = 100
    flush_seconds: float = 2.0
    progress_seconds: float = 10.0
    limit_tasks: int | None = None
    sample_every: int = 1
    compute_reference_oracle: bool = False
    store_raw_json: bool = False
    raw_json_sample_rate: float = 0.0
    random_seed: int = 20260929
    variant_name: str = "CURRENT_PRODUCTION_FUTURES"
    engine_overrides: dict | None = None
    research_gate_bypass: bool = False

    def canonical(self): return asdict(self)
    @property
    def config_hash(self):
        return sha256(json.dumps(self.canonical(), sort_keys=True, default=str).encode()).hexdigest()
    @property
    def storage(self): return Path(self.storage_path)
    def resolved_workers(self):
        if self.workers != "auto": return max(1, int(self.workers))
        return max(1, min(4, (os.cpu_count() or 2) // 2))


def _parse_symbols(value: str) -> tuple[str, ...]:
    if value == "all":
        return tuple(sorted({p.name.rsplit("_", 2)[0].upper() for p in DATA.glob("*_daily.csv")} & NSEFO_ALLOWED_SYMBOLS))
    p = Path(value)
    symbols = tuple(x.strip().upper() for x in p.read_text().splitlines() if x.strip() and not x.lstrip().startswith("#")) if p.exists() else tuple(x.strip().upper() for x in value.split(",") if x.strip())
    invalid = set(symbols) - NSEFO_ALLOWED_SYMBOLS
    if invalid: raise SystemExit(f"symbols not in NSEFO allowlist: {', '.join(sorted(invalid))}")
    return symbols


def _contract_files(symbol: str) -> dict[str, set[str]]:
    """Return actual on-disk frames by expiry, case-insensitively."""
    found: dict[str, set[str]] = {}
    wanted = symbol.upper() + "_"
    for path in DATA.glob("*_*.csv"):
        name = path.name
        if not name.upper().startswith(wanted): continue
        try:
            _, expiry, frame = name.rsplit("_", 2)
            frame = frame[:-4]
            if len(expiry) == 8 and expiry.isdigit(): found.setdefault(expiry, set()).add(frame)
        except ValueError:
            continue
    return found


def select_expiries(symbol: str, end: str, count: int, needed: set[str]) -> list[str]:
    available = _contract_files(symbol)
    parse_expiry = lambda value: pd.to_datetime(value, format="%d%m%Y")
    active = set(NSEFO_ACTIVE_EXPIRIES.get(symbol, ()))
    eligible = sorted((e for e, frames in available.items() if e in active and needed.issubset(frames)), key=parse_expiry)
    end_day = pd.Timestamp.now().normalize() if end == "auto" else pd.Timestamp(end).normalize()
    forward = [e for e in eligible if parse_expiry(e) >= end_day]
    # A historical end can be after all supplied contracts.  Keep this explicit
    # deterministic fallback rather than silently omitting a symbol.
    return (forward if len(forward) >= count else eligible)[0:count]


def _read(symbol: str, expiry: str, frame: str) -> pd.DataFrame:
    choices = list(DATA.glob(f"{symbol}_{expiry}_{frame}.csv")) + list(DATA.glob(f"{symbol.lower()}_{expiry}_{frame}.csv"))
    if not choices:
        choices = [p for p in DATA.glob(f"*_{expiry}_{frame}.csv") if p.name.rsplit("_", 2)[0].upper() == symbol.upper()]
    if not choices: raise FileNotFoundError(f"missing {symbol}_{expiry}_{frame}.csv")
    df = pd.read_csv(choices[0]); col = "tradeDate" if "tradeDate" in df.columns else "timestamp"
    df["timestamp"] = pd.to_datetime(df[col], dayfirst=True, errors="coerce")
    return df.dropna(subset=["timestamp"]).sort_values("timestamp", kind="stable").reset_index(drop=True)


@lru_cache(maxsize=96)
def _bars(symbol: str, expiry: str, frame: str) -> pd.DataFrame:
    return _read(symbol, expiry, frame)


def _timestamps(symbol: str, expiry: str, tf: int, start: str, end: str) -> list[pd.Timestamp]:
    x = _bars(symbol, expiry, STACKS[tf][-1])
    lo = pd.Timestamp("1900-01-01") if start == "auto" else pd.Timestamp(start)
    hi = pd.Timestamp.now() if end == "auto" else pd.Timestamp(end) + (pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1) if len(end) == 10 else pd.Timedelta(0))
    x = x[(x.timestamp >= lo) & (x.timestamp <= hi)].drop_duplicates("timestamp")
    # The futures production scanner runs each configured execute-frame bar.
    return [pd.Timestamp(x) for x in x.timestamp]


def generate_tasks(cfg: FuturesConfig):
    missing = []
    for underlying in cfg.symbols:
        for tf in cfg.tfs:
            stack = STACKS[tf]
            expiries = select_expiries(underlying, cfg.end, cfg.expiries, set(stack))
            if not expiries:
                missing.append({"symbol": underlying, "tf": tf, "reason": "no expiry has all required E/A/X files"})
            for expiry in expiries:
                for n, ts in enumerate(_timestamps(underlying, expiry, tf, cfg.start, cfg.end)):
                    if n % cfg.sample_every: continue
                    yield {"symbol": f"{underlying}@{expiry}", "underlying": underlying, "contract_expiry": expiry,
                           "strategy_tf": tf, "strategy_tf_name": STACKS[tf][-1], "evaluation_timestamp": ts.isoformat()}
    if missing:
        Path("audit/futures_trend_backtest/results").mkdir(parents=True, exist_ok=True)
        pd.DataFrame(missing).to_csv("audit/futures_trend_backtest/results/skipped_contracts.csv", index=False)


def _crosses_mcx_e1(entry: object, exit_: object) -> bool:
    """Return whether a holding period crosses the locked 23:30->09:00 seam.

    This belongs to the research adapter only.  It deliberately does not alter
    the production order resolver or live MCX policy.
    """
    if entry is None or exit_ is None:
        return False
    start, end = pd.Timestamp(entry), pd.Timestamp(exit_)
    if end <= start:
        return False
    seam = start.normalize() + pd.Timedelta(hours=23, minutes=30)
    if start >= seam:
        seam += pd.Timedelta(days=1)
    return seam < end


def _resolve(side: str, candidate: dict, bars: pd.DataFrame, resolution_end: object | None = None,
             expiry_control: dict | None = None) -> dict:
    """Mirror active FC resolver ordering: target wins an OHLC ambiguous bar."""
    scan = pd.Timestamp(candidate["scan_timestamp"]); entry, stop, target = (float(candidate[k]) for k in ("entry", "stop", "target"))
    future = bars[bars.timestamp > scan]
    # A task may use later bars to resolve an order created at its scan time,
    # but never bars beyond the configured replay window.  Without this bound
    # a short sample could report entries months after its declared end date.
    # This is audit-runner control flow only; production order logic is not
    # changed.
    if resolution_end is not None:
        cutoff = pd.Timestamp(resolution_end)
        if isinstance(resolution_end, str) and len(resolution_end) == 10:
            cutoff += pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1)
        future = future[future.timestamp <= cutoff]
    future = future.reset_index(drop=True); entered = None; mfe = float("-inf"); mae = float("inf"); imfe = imae = None
    entry_cutoff = pd.Timestamp(expiry_control["entry_cutoff_date"]).normalize() if expiry_control and expiry_control.get("entry_cutoff_date") else None
    force_exit = pd.Timestamp(expiry_control["force_exit_date"]).normalize() if expiry_control and expiry_control.get("force_exit_date") else None
    exclude_e1 = bool(expiry_control and expiry_control.get("exclude_e1_gap"))
    for idx, bar in future.iterrows():
        lo, hi = float(bar.low), float(bar.high)
        if entered is None:
            if entry_cutoff is not None and pd.Timestamp(bar.timestamp).normalize() >= entry_cutoff:
                return {"entry_timestamp": None, "exit_timestamp": None, "exit_price": None,
                  "outcome": "UNFILLED", "exit_reason": "entry_window_closed", "target_hit": 0, "stop_hit": 0,
                  "bars_held": None, "max_favorable_excursion": None, "max_adverse_excursion": None,
                  "max_favorable_pct_of_target": None, "bars_to_mfe": None, "bars_to_mae": None,
                  "outcome_direction": None, "blocked_reason": "entry_window_closed"}
            if not lo <= entry <= hi: continue
            entered = bar.timestamp
        fav, adverse = ((hi - entry), (lo - entry)) if side == "BUY" else ((entry - lo), (entry - hi))
        if fav >= mfe: mfe, imfe = fav, idx
        if adverse <= mae: mae, imae = adverse, idx
        # The locked expiry-minus-three rule is a deterministic square-off at
        # the first executable bar of that session.  It takes precedence over
        # intrabar target/stop simulation on that same bar.
        if force_exit is not None and pd.Timestamp(bar.timestamp).normalize() >= force_exit:
            if exclude_e1 and _crosses_mcx_e1(entered, bar.timestamp):
                return {"entry_timestamp": None, "exit_timestamp": None, "exit_price": None,
                  "outcome": "UNFILLED", "exit_reason": "e1_gap", "target_hit": 0, "stop_hit": 0,
                  "bars_held": None, "max_favorable_excursion": None, "max_adverse_excursion": None,
                  "max_favorable_pct_of_target": None, "bars_to_mfe": None, "bars_to_mae": None,
                  "outcome_direction": None, "blocked_reason": "e1_gap"}
            return {"entry_timestamp": entered.isoformat(), "exit_timestamp": bar.timestamp.isoformat(), "exit_price": float(bar.close),
              "outcome": "TIME_EXIT", "exit_reason": "expiry_minus_3_time_exit", "target_hit": 0, "stop_hit": 0,
              "bars_held": idx, "max_favorable_excursion": mfe, "max_adverse_excursion": mae,
              "max_favorable_pct_of_target": 100*mfe/abs(target-entry), "bars_to_mfe": imfe, "bars_to_mae": imae,
              "outcome_direction": "TIME_EXIT"}
        target_hit = hi >= target if side == "BUY" else lo <= target
        stop_hit = lo <= stop if side == "BUY" else hi >= stop
        if target_hit or stop_hit:
            win = bool(target_hit)  # documented production target-first order
            exit_price = target if win else stop
            if exclude_e1 and _crosses_mcx_e1(entered, bar.timestamp):
                return {"entry_timestamp": None, "exit_timestamp": None, "exit_price": None,
                  "outcome": "UNFILLED", "exit_reason": "e1_gap", "target_hit": 0, "stop_hit": 0,
                  "bars_held": None, "max_favorable_excursion": None, "max_adverse_excursion": None,
                  "max_favorable_pct_of_target": None, "bars_to_mfe": None, "bars_to_mae": None,
                  "outcome_direction": None, "blocked_reason": "e1_gap"}
            return {"entry_timestamp": entered.isoformat(), "exit_timestamp": bar.timestamp.isoformat(), "exit_price": exit_price,
              "outcome": "WIN" if win else "LOSS", "exit_reason": "Target hit" if win else "Stoploss hit", "target_hit": int(target_hit), "stop_hit": int(stop_hit),
              "bars_held": idx, "max_favorable_excursion": mfe, "max_adverse_excursion": mae, "max_favorable_pct_of_target": 100*mfe/abs(target-entry),
              "bars_to_mfe": imfe, "bars_to_mae": imae, "outcome_direction": "PERMITTED_DIRECTION" if win else "AGAINST_TRADE_DIRECTION"}
    return {"entry_timestamp": entered.isoformat() if entered is not None else None, "exit_timestamp": None, "exit_price": None,
            "outcome": "UNRESOLVED" if entered is not None else "UNFILLED", "exit_reason": "end_of_source_history", "target_hit": 0, "stop_hit": 0,
            "bars_held": None, "max_favorable_excursion": None, "max_adverse_excursion": None, "max_favorable_pct_of_target": None,
            "bars_to_mfe": None, "bars_to_mae": None, "outcome_direction": None}


def _reference(underlying: str, expiry: str, tf: int, ts: str) -> dict:
    from audit.trend_engine.price_action_oracle import diagnostics, label_as_of
    cutoff = pd.Timestamp(ts); out = {}
    for label, frame in zip(("E", "A", "X"), STACKS[tf]):
        d = _bars(underlying, expiry, frame); clipped = d[d.timestamp <= cutoff]
        if clipped.empty: continue
        diag = diagnostics(clipped); out[f"reference_{label}"] = label_as_of(clipped)
        out[f"{label}_ema20"] = diag["ema20"]; out[f"{label}_ema_slope"] = diag["ema20_slope"]; out[f"return_20_{label}"] = diag["return_n"]
        if label == "X": out["last_confirmed_swing_high"] = diag["recent_swing_high"]; out["last_confirmed_swing_low"] = diag["recent_swing_low"]
    return out


@contextlib.contextmanager
def _research_input_root(task: dict, is_future: bool):
    """Temporarily point one isolated worker at a derived research view.

    The setting object is restored before the worker returns.  No source file,
    settings file, live process, or production configuration is changed.
    """
    root = task.get("research_data_root")
    if not root:
        yield
        return
    from shared.config.settings import stock_data_dir_config
    field = "indian_stock_future_data_dir" if is_future else "indian_commodity_data"
    previous = getattr(stock_data_dir_config, field)
    setattr(stock_data_dir_config, field, str(Path(root)))
    try:
        yield
    finally:
        setattr(stock_data_dir_config, field, previous)


def execute_task(task: dict, store_raw_json=False, max_retries=2, capture_output=True, compute_reference_oracle=False, engine_overrides=None) -> dict:
    started = time.perf_counter()
    try:
        from scripts.setup_engine_new import process_setup_fc
        # SQLite deliberately retains the contract key in the normalised symbol
        # column.  Claimed tasks therefore reconstruct worker-only fields here.
        underlying, expiry = str(task["symbol"]).rsplit("@", 1)
        task = {**task, "underlying": underlying, "contract_expiry": expiry}
        t = pd.Timestamp(task["evaluation_timestamp"])
        # NSEFO and MCX Phase-A adapters use this common audit worker.  These
        # task fields are audit metadata only; the production callable remains
        # the current ``process_setup_fc`` entry point.
        exchange = str(task.get("market_segment", "NSEFO"))
        is_future = bool(task.get("is_future", True))
        buy_only = bool(task.get("buy_only", False))
        call = lambda: process_setup_fc(task["underlying"], list(STACKS[task["strategy_tf"]]), task["contract_expiry"], t.to_pydatetime(), is_future)
        from audit.fresh_trend_backtest.tuning import production_config_overrides
        if capture_output:
            # The production logger has preconfigured stream handlers. Suppress
            # it only in the isolated worker so a long process run retains the
            # coordinator progress line; this does not mutate production code.
            previous_disable = logging.root.manager.disable
            logging.disable(logging.CRITICAL)
            try:
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    with _research_input_root(task, is_future):
                        with production_config_overrides(engine_overrides): raw = call()
            finally:
                logging.disable(previous_disable)
        else:
            with _research_input_root(task, is_future):
                with production_config_overrides(engine_overrides): raw = call()
        if isinstance(raw, str): raise RuntimeError(raw)
        ctx = raw.get("trend_context")
        if ctx is None: raise RuntimeError(raw.get("data_insufficient_reason", "production result lacks trend_context"))
        cmp = raw.get("price_cmp"); long = raw.get("best_setup_long"); short = raw.get("best_setup_short")
        def serial(x):
            from audit.fresh_trend_backtest.replay import serialise
            return serialise(x)
        # This is an offline audit replay. The explicit switch is scoped to
        # the audit adapter and never changes production gate() behaviour.
        decision = evaluate_gate(
            exchange,
            int(task["strategy_tf"]),
            _value(ctx, "regime_E"),
            _value(ctx, "regime_A"),
            research_gate_bypass=bool(task.get("research_gate_bypass", False)),
        )
        candidates = [("BUY", long, bool(_value(ctx, "allow_long", False)))]
        if not buy_only:
            candidates.append(("SELL", short, bool(_value(ctx, "allow_short", False))))
        generated = any(x is not None for _, x, _ in candidates); setups = []
        for side, obj, allowed in candidates:
            if obj is None: continue
            s = serial(obj); rr = float(s.get("rr_ratio") or 0)
            blocked = None
            mcx_disposition = None
            if decision.denied:
                blocked = decision.reason
            elif not allowed:
                blocked = f"{side.lower()}_permission_blocked"
            elif rr < 2.1:
                blocked = "rr_below_2.1"
            elif task.get("expiry_control", {}).get("entry_cutoff_date") and pd.Timestamp(task["evaluation_timestamp"]).normalize() >= pd.Timestamp(task["expiry_control"]["entry_cutoff_date"]).normalize():
                blocked = "entry_window_closed"
            elif exchange == "MCX" and bool(task.get("research_gate_bypass", False)):
                # The live MCX proving policy delegates to the live gate and
                # would therefore classify every candidate as EXCLUDED.  This
                # audit path already made the explicit research-only bypass
                # above, so do not call the live policy a second time.
                mcx_disposition = "BACKTEST_PERMIT"
            eligible = blocked is None
            setup = {"symbol": task["symbol"], "strategy_tf": task["strategy_tf"], "direction": side, "setup_timestamp": task["evaluation_timestamp"], "pattern": s.get("pattern"), "zone_id": str(s.get("zone_id")) if s.get("zone_id") is not None else None,
              "zone_signature": s.get("zone_signature"), "proposed_entry": s.get("entry_price"), "proposed_stop": s.get("stop_price"), "proposed_target": s.get("target_price"), "rr": rr, "setup_score": s.get("score"), "setup_rank": 1, "eligible": int(eligible), "blocked_reason": blocked, "permission_state": "ALLOWED" if eligible else "BLOCKED", "gate_tier": decision.tier, "gate_size_multiplier": decision.size_multiplier, "gate_reason": decision.reason}
            if eligible:
                candidate = {"scan_timestamp": task["evaluation_timestamp"], "entry": s.get("entry_price"), "stop": s.get("stop_price"), "target": s.get("target_price")}
                resolved = _resolve(
                    side, candidate,
                    _bars(task["underlying"], task["contract_expiry"], STACKS[task["strategy_tf"]][-1]),
                    task.get("resolution_end"), task.get("expiry_control"),
                )
                if resolved.get("blocked_reason"):
                    setup.update({"eligible": 0, "blocked_reason": resolved["blocked_reason"], "permission_state": "BLOCKED"})
                if resolved["entry_timestamp"]:
                    risk = abs(float(candidate["entry"]) - float(candidate["stop"]))
                    signed = (float(resolved["exit_price"]) - float(candidate["entry"])) if side == "BUY" and resolved["exit_price"] is not None else ((float(candidate["entry"]) - float(resolved["exit_price"])) if resolved["exit_price"] is not None else None)
                    trade = {"symbol": task["symbol"], "strategy_tf": task["strategy_tf"], "side": side, "scan_timestamp": task["evaluation_timestamp"], "setup_timestamp": task["evaluation_timestamp"], **{k: resolved[k] for k in ("entry_timestamp","exit_timestamp")}, "entry_price": candidate["entry"], "stop_price": candidate["stop"], "target_price": candidate["target"], "exit_price": resolved["exit_price"], "outcome": resolved["outcome"], "exit_reason": resolved["exit_reason"], "target_hit": resolved["target_hit"], "stop_hit": resolved["stop_hit"], "bars_held": resolved["bars_held"], "gross_r": signed/risk if signed is not None and risk else None, "gross_return_pct": 100*signed/float(candidate["entry"]) if signed is not None else None,
                      "metrics": {"max_favorable_excursion": resolved["max_favorable_excursion"], "max_adverse_excursion": resolved["max_adverse_excursion"], "mfe_pct": None, "mae_pct": None, "max_favorable_pct_of_target": resolved["max_favorable_pct_of_target"], "bars_to_mfe": resolved["bars_to_mfe"], "bars_to_mae": resolved["bars_to_mae"], "bars_to_exit": resolved["bars_held"], "first_positive_bar": None, "first_negative_bar": None, "favorable_before_adverse": None, "outcome_direction": resolved["outcome_direction"]}}
                    setup["trade"] = trade
            setups.append(setup)
        runtime = (time.perf_counter() - started) * 1000
        rejection = None if any(s["eligible"] for s in setups) else (decision.reason if generated and decision.denied else (setups[0]["blocked_reason"] if setups else "no_production_setup"))
        scan = {"task_id": task["task_id"], "run_id": task["run_id"], "symbol": task["symbol"], "strategy_tf": task["strategy_tf"], "evaluation_timestamp": task["evaluation_timestamp"], "cmp": cmp, "signal_generated": int(generated), "setup_generated": int(generated), "entry_candidate": int(any(s["eligible"] for s in setups)), "rejection_reason": rejection, "final_bias": _value(ctx,"bias"), "allow_long": int(bool(_value(ctx,"allow_long",False))), "allow_short": int(bool(_value(ctx,"allow_short",False))), "permitted_setup": _value(ctx,"permitted_setup"), "trade_type_long": _value(ctx,"trade_type_long"), "trade_type_short": _value(ctx,"trade_type_short"), "dbr_required": _value(ctx,"dbr_required"), "rbd_required": _value(ctx,"rbd_required"), "htf_veto_longs": _value(ctx,"htf_veto_longs"), "htf_veto_shorts": _value(ctx,"htf_veto_shorts"), "htf_veto_reason": _value(ctx,"htf_veto_reason"), "production_runtime_ms": runtime, "gate_tier": decision.tier, "gate_size_multiplier": decision.size_multiplier, "gate_reason": decision.reason, "gate_denied": int(decision.denied), "raw_json": json.dumps(serial(raw),default=str) if store_raw_json else None}
        reg = {"E_regime": _value(ctx,"regime_E"), "A_regime": _value(ctx,"regime_A"), "X_regime": _value(ctx,"regime_X"), "E_quadrant": _value(ctx,"quadrant_E"), "A_quadrant": _value(ctx,"quadrant_A"), "X_quadrant": _value(ctx,"quadrant_X"), "E_rule_applied": _value(_value(ctx,"result_E"),"rule_applied"), "A_rule_applied": _value(_value(ctx,"result_A"),"rule_applied"), "X_rule_applied": _value(_value(ctx,"result_X"),"rule_applied"), "E_diagnosis": _value(_value(ctx,"result_E"),"diagnosis"), "A_diagnosis": _value(_value(ctx,"result_A"),"diagnosis"), "X_diagnosis": _value(_value(ctx,"result_X"),"diagnosis"), "E_htf_veto_applied": None, "A_htf_veto_applied": None, "X_htf_veto_applied": None, "E_reinforcers": None, "A_reinforcers": None, "X_reinforcers": None}
        if compute_reference_oracle: reg.update(_reference(task["underlying"], task["contract_expiry"], task["strategy_tf"], task["evaluation_timestamp"]))
        zones=[]
        for label, result in (("E",_value(ctx,"result_E")), ("A",_value(ctx,"result_A")), ("X",_value(ctx,"result_X"))):
            for role, attr in (("NEAREST_BZ","nearest_bz"),("NEAREST_SZ","nearest_sz"),("NEXT_BZ","next_bz"),("NEXT_SZ","next_sz")):
                z = _zone(_value(result,attr), label, role, cmp)
                if z: zones.append(z)
        return {"task":task,"result":{"scan":scan,"regime":reg,"zones":zones,"setups":setups},"duration_ms":runtime,"worker_id":str(os.getpid()),"max_retries":max_retries}
    except Exception as exc:
        return {"task":task,"error":{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()},"duration_ms":(time.perf_counter()-started)*1000,"worker_id":str(os.getpid()),"max_retries":max_retries}


class Coordinator:
    def __init__(self, cfg): self.cfg=cfg; self.store=SQLiteBacktestStorage(cfg.storage)
    def create(self):
        tasks=list(generate_tasks(self.cfg)); tasks=tasks[:self.cfg.limit_tasks] if self.cfg.limit_tasks else tasks
        rid=self.store.create_run(self.cfg,len(tasks)); self.store.register_tasks(rid,tasks); return rid
    def run(self,rid):
        self.store.reclaim_stale(rid); self.store.set_run_status(rid,"RUNNING"); kind="process" if self.cfg.executor=="auto" else self.cfg.executor; cls=futures.ProcessPoolExecutor if kind=="process" else futures.ThreadPoolExecutor; workers=self.cfg.resolved_workers(); self.store.set_execution(rid,kind,workers); writer=ResultWriter(self.store,self.cfg.write_batch_size,self.cfg.flush_seconds); writer.start(); active={}; last=time.monotonic(); stopping=False
        def stop(*_): nonlocal stopping; stopping=True
        old=(signal.signal(signal.SIGINT,stop),signal.signal(signal.SIGTERM,stop))
        try:
            with cls(max_workers=workers) as pool:
                while not stopping:
                    writer.raise_if_failed()
                    capacity=max(0,workers*2-len(active))
                    for task in self.store.claim_tasks(rid,capacity): active[pool.submit(execute_task,task,self.cfg.store_raw_json,self.cfg.max_retries,kind=="process",self.cfg.compute_reference_oracle,self.cfg.engine_overrides)]=task
                    if not active:
                        c=self.store.task_counts(rid)
                        if not (c.get("PENDING",0) or c.get("RETRY",0)): break
                        continue
                    done,_=futures.wait(active,timeout=.25,return_when=futures.FIRST_COMPLETED)
                    for f in done:
                        task=active.pop(f)
                        try: writer.submit(f.result())
                        except BaseException as ex: writer.submit({"task":task,"error":{"type":type(ex).__name__,"message":str(ex),"traceback":"future retrieval failure"},"duration_ms":None,"worker_id":"coordinator","max_retries":self.cfg.max_retries})
                    if time.monotonic()-last>=self.cfg.progress_seconds:
                        c=self.store.task_counts(rid); print(f"Run {rid}: {c.get('COMPLETED',0):,}/{c.get('TOTAL',0):,} ({100*c.get('COMPLETED',0)/max(1,c.get('TOTAL',1)):.1f}%), active={len(active)}, writer_queue={writer.queue.qsize()}, executor={kind}/{workers}",flush=True); last=time.monotonic()
                if not stopping:
                    for f in active: writer.submit(f.result())
        finally:
            writer.close(); self.store.finalise_counts(rid)
            # A supervisor/terminal may terminate a long foreground process
            # without delivering our SIGINT handler.  Never certify a run as
            # complete unless every registered task reached a terminal state.
            counts = self.store.task_counts(rid)
            terminal = counts.get("COMPLETED", 0) + counts.get("FAILED", 0)
            self.store.set_run_status(rid, "COMPLETED" if terminal == counts.get("TOTAL", 0) else "PAUSED")
            signal.signal(signal.SIGINT,old[0]); signal.signal(signal.SIGTERM,old[1])
        return self.status(rid)
    def status(self,rid):
        r=dict(self.store.get_run(rid)); c=self.store.task_counts(rid); sig=self.store.conn.execute("SELECT count(*) FROM scan_results WHERE run_id=? AND signal_generated=1",(rid,)).fetchone()[0]; tr=self.store.conn.execute("SELECT count(*) FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?",(rid,)).fetchone()[0]; return {"run":r,"task_counts":c,"signals":sig,"entered_trades":tr}


def _args(argv=None):
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    def common(x):
        x.add_argument("--run-name",default="current_production_futures_2y"); x.add_argument("--symbols",default="all",help="all, comma list, or a newline-delimited instruments file"); x.add_argument("--tfs",default="1,2,5,25",help="production futures TF IDs; TF6 is not configured"); x.add_argument("--expiries",type=int,default=3); x.add_argument("--start",default="2024-09-29"); x.add_argument("--end",default="2026-09-29"); x.add_argument("--executor",choices=("process","thread","auto"),default="process"); x.add_argument("--workers",default="4"); x.add_argument("--storage",default="audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite"); x.add_argument("--max-retries",type=int,default=2); x.add_argument("--write-batch-size",type=int,default=100); x.add_argument("--write-flush-seconds",type=float,default=2); x.add_argument("--progress-seconds",type=float,default=10); x.add_argument("--limit-tasks",type=int); x.add_argument("--sample-every",type=int,default=1); x.add_argument("--compute-reference-oracle",action="store_true"); x.add_argument("--engine-overrides-json",default="{}")
    for name in ("dry-run","run"): common(sub.add_parser(name))
    st=sub.add_parser("status"); st.add_argument("run_id"); st.add_argument("--storage",default="audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite")
    rs=sub.add_parser("resume"); rs.add_argument("run_id"); rs.add_argument("--storage",default="audit/futures_trend_backtest/storage/futures_backtest_2y.sqlite")
    return p.parse_args(argv)


def main(argv=None):
    a=_args(argv)
    if a.command in ("status","resume"):
        store=SQLiteBacktestStorage(a.storage); row=store.get_run(a.run_id)
        if row is None: raise SystemExit(f"unknown run_id: {a.run_id}")
        cfg=FuturesConfig(**json.loads(row["config_json"])); c=Coordinator(cfg)
        if a.command=="status": print(json.dumps(c.status(a.run_id),indent=2,default=str)); return
        print(json.dumps(c.run(a.run_id),indent=2,default=str)); return
    tfs=tuple(int(x) for x in a.tfs.split(",")); invalid=sorted(set(tfs)-set(STACKS))
    if invalid: raise SystemExit(f"unsupported futures TF IDs {invalid}; configured futures TF IDs are {sorted(STACKS)}")
    cfg=FuturesConfig(a.run_name,_parse_symbols(a.symbols),tfs,a.start,a.end,a.expiries,executor=a.executor,workers=a.workers,storage_path=a.storage,max_retries=a.max_retries,write_batch_size=a.write_batch_size,flush_seconds=a.write_flush_seconds,progress_seconds=a.progress_seconds,limit_tasks=a.limit_tasks,sample_every=a.sample_every,compute_reference_oracle=a.compute_reference_oracle,engine_overrides=json.loads(a.engine_overrides_json))
    tasks=list(generate_tasks(cfg)); tasks=tasks[:cfg.limit_tasks] if cfg.limit_tasks else tasks
    if a.command=="dry-run": print(json.dumps({"symbols_requested":len(cfg.symbols),"tfs":list(tfs),"expiries_per_symbol":cfg.expiries,"task_count":len(tasks),"config_hash":cfg.config_hash,"data_directory":str(DATA)},indent=2)); return
    c=Coordinator(cfg); rid=c.create(); print(f"run_id={rid}",flush=True); print(json.dumps(c.run(rid),indent=2,default=str))

if __name__ == "__main__": main()
