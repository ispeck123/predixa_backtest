# NSEFO expiry-aware research submission

Run `6737d85be9b94e0682d71adc646b692d` is **COMPLETED**; SQLite integrity and quick checks are `ok` and `ok`.

| Metric | Expiry-aware | Unfiltered baseline |
|---|---:|---:|
| Realized trades | 15,015 | 48,658 |
| Gross realized R | -1,305.373597 | 4,670.140173 |
| Profit factor | 0.877615 | 1.129784 |
| Win rate | 27.2594% | 26.0471% |

The gross-R change is `-5,975.513770R`. NSEFO map uses official NSE bhavcopy records, pending owner verification.

This is a BUY-only, research-gate-bypass continuous-series measurement. It is not live/paper approval and does not represent net cash P&L, costs, or slippage.
