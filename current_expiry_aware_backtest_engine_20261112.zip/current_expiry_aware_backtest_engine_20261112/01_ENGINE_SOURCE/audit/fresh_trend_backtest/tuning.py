"""Audit-only, process-local overrides for provisional engine parameters."""
from __future__ import annotations
from contextlib import contextmanager
from typing import Iterator, Mapping

TUNABLE_FIELDS = frozenset(("embed_sits_on_top_target_pct", "embed_overlap_threshold", "embed_strict_stop", "proximity_use_atr_tier", "proximity_atr_mult"))

def normalise_overrides(values: Mapping | None) -> dict:
    values = dict(values or {})
    unknown = set(values) - TUNABLE_FIELDS
    if unknown: raise ValueError(f"unsupported audit tuning fields: {sorted(unknown)}")
    return values

@contextmanager
def production_config_overrides(values: Mapping | None) -> Iterator[None]:
    """Override both live Config constructor paths only within this worker call."""
    values = normalise_overrides(values)
    if not values:
        yield; return
    import scripts.additional_engine_class as additional
    import scripts.models as models
    import scripts.setup_engine_new as setup
    import scripts.trend_engine as trend
    model_cls, trend_cls = models.Config, trend.Config
    def model_factory(*args, **kwargs): return model_cls(*args, **(values | kwargs))
    def trend_factory(*args, **kwargs): return trend_cls(*args, **(values | kwargs))
    originals = (setup.trade_config, setup.trend_config, additional.Config, trend.Config)
    setup.trade_config, setup.trend_config = model_factory, trend_factory
    additional.Config, trend.Config = trend_factory, trend_factory
    try: yield
    finally: setup.trade_config, setup.trend_config, additional.Config, trend.Config = originals
