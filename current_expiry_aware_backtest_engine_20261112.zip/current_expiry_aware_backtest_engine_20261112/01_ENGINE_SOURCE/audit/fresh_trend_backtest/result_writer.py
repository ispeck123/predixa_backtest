"""The only component allowed to write central backtest evidence."""
from __future__ import annotations
import queue, threading, time
import statistics

class ResultWriter:
    def __init__(self, storage, batch_size: int=100, flush_seconds: float=2.0):
        self.storage=storage; self.batch_size=batch_size; self.flush_seconds=flush_seconds
        # Bound the hand-off between workers and SQLite.  Without a bound the
        # coordinator can claim the whole task universe while the single
        # writer is still committing earlier results, leaving a large and
        # misleading RUNNING set on interruption.
        self.queue: queue.Queue = queue.Queue(maxsize=max(1000, batch_size * 4))
        self._stop=object(); self._thread=None; self.written=0; self.metrics={}; self._error=None
    def start(self):
        self._thread=threading.Thread(target=self._run,name="backtest-central-writer",daemon=True); self._thread.start()
    def submit(self,event):
        while True:
            self.raise_if_failed()
            try:
                self.queue.put(event, timeout=0.5)
                break
            except queue.Full:
                # Recheck the writer error instead of blocking forever if the
                # writer thread failed while the queue was full.
                continue
        self.raise_if_failed()
    def close(self):
        if self._thread is None: return
        # If the writer failed, putting a sentinel into a full queue would
        # deadlock the coordinator.  The caller will mark the run paused and
        # resume will reclaim the uncommitted RUNNING tasks.
        if self._error is None: self.queue.put(self._stop)
        self._thread.join()
    def raise_if_failed(self):
        if self._error is not None:
            raise RuntimeError("central backtest result writer failed") from self._error
    def _run(self):
        try:
            pending=[]; deadline=time.monotonic()+self.flush_seconds
            while True:
                timeout=max(0,deadline-time.monotonic()) if pending else self.flush_seconds
                try: item=self.queue.get(timeout=timeout)
                except queue.Empty: item=None
                if item is self._stop:
                    if pending: self._flush(pending)
                    self._persist_metrics()
                    return
                if item is not None: pending.append(item)
                if pending and (len(pending)>=self.batch_size or time.monotonic()>=deadline):
                    self._flush(pending); pending=[]; deadline=time.monotonic()+self.flush_seconds
        except BaseException as exc:
            # Surface the original exception to the coordinator.  A daemon
            # thread exception alone is otherwise invisible to long replays.
            self._error=exc
    def _flush(self, pending):
        self.storage.save_events(pending); self.written+=len(pending)
        for event in pending:
            worker=event.get("worker_id","unknown"); run=event["task"]["run_id"]; item=self.metrics.setdefault((run,worker),[]); item.append(event.get("duration_ms") or 0)
    def _persist_metrics(self):
        for (run,worker), vals in self.metrics.items():
            if not vals: continue
            self.storage.conn.execute("INSERT INTO worker_metrics(run_id,worker_id,tasks_processed,successful_tasks,failed_tasks,mean_runtime_ms,median_runtime_ms,p95_runtime_ms,start_time,last_heartbeat,memory_usage_mb) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(run,worker,len(vals),len(vals),0,sum(vals)/len(vals),statistics.median(vals),sorted(vals)[max(0,int(.95*len(vals))-1)],None,None,None))
        self.storage.conn.commit()
