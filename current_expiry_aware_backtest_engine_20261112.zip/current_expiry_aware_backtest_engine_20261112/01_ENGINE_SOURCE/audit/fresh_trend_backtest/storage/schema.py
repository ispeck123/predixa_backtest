"""SQLite DDL for the centralized audit evidence store."""

SCHEMA = r"""
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS backtest_runs (
 run_id TEXT PRIMARY KEY, run_name TEXT NOT NULL, git_commit TEXT, git_branch TEXT,
 created_at TEXT NOT NULL, started_at TEXT, finished_at TEXT, engine_version TEXT,
 config_hash TEXT NOT NULL, config_json TEXT NOT NULL, executor_type TEXT, workers INTEGER,
 symbol_count INTEGER, timeframe_count INTEGER, historical_start TEXT, historical_end TEXT,
 task_count INTEGER DEFAULT 0, completed_count INTEGER DEFAULT 0, failed_count INTEGER DEFAULT 0,
 status TEXT NOT NULL, variant_name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scan_tasks (
 task_id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES backtest_runs(run_id),
 symbol TEXT NOT NULL, strategy_tf INTEGER NOT NULL, strategy_tf_name TEXT NOT NULL,
 evaluation_timestamp TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', attempt_count INTEGER NOT NULL DEFAULT 0,
 assigned_worker TEXT, started_at TEXT, finished_at TEXT, duration_ms REAL, error_id INTEGER,
 UNIQUE(run_id, symbol, strategy_tf, evaluation_timestamp)
);
CREATE INDEX IF NOT EXISTS idx_scan_tasks_run_status ON scan_tasks(run_id,status,task_id);
CREATE TABLE IF NOT EXISTS scan_results (
 scan_id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL UNIQUE REFERENCES scan_tasks(task_id),
 run_id TEXT NOT NULL, symbol TEXT NOT NULL, strategy_tf INTEGER NOT NULL, evaluation_timestamp TEXT NOT NULL,
 cmp REAL, signal_generated INTEGER NOT NULL, setup_generated INTEGER NOT NULL, entry_candidate INTEGER NOT NULL,
 rejection_reason TEXT, final_bias TEXT, allow_long INTEGER, allow_short INTEGER, permitted_setup TEXT,
 trade_type_long TEXT, trade_type_short TEXT, dbr_required INTEGER, rbd_required INTEGER,
 htf_veto_longs INTEGER, htf_veto_shorts INTEGER, htf_veto_reason TEXT, production_runtime_ms REAL,
 gate_tier TEXT, gate_size_multiplier REAL, gate_reason TEXT, gate_denied INTEGER,
 raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_scans_run_context ON scan_results(run_id,symbol,strategy_tf,evaluation_timestamp);
CREATE TABLE IF NOT EXISTS regime_snapshots (
 scan_id INTEGER PRIMARY KEY REFERENCES scan_results(scan_id),
 E_regime TEXT, A_regime TEXT, X_regime TEXT, E_quadrant TEXT, A_quadrant TEXT, X_quadrant TEXT,
 E_rule_applied TEXT, A_rule_applied TEXT, X_rule_applied TEXT,
 E_diagnosis TEXT, A_diagnosis TEXT, X_diagnosis TEXT,
 E_htf_veto_applied INTEGER, A_htf_veto_applied INTEGER, X_htf_veto_applied INTEGER,
 E_reinforcers TEXT, A_reinforcers TEXT, X_reinforcers TEXT,
 reference_E TEXT, reference_A TEXT, reference_X TEXT,
 E_ema20 REAL, A_ema20 REAL, X_ema20 REAL, E_ema_slope REAL, A_ema_slope REAL, X_ema_slope REAL,
 return_20_E REAL, return_20_A REAL, return_20_X REAL, last_confirmed_swing_high REAL, last_confirmed_swing_low REAL
);
CREATE TABLE IF NOT EXISTS zone_snapshots (
 zone_snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER NOT NULL REFERENCES scan_results(scan_id),
 timeframe TEXT NOT NULL, zone_role TEXT NOT NULL, zone_id TEXT, zone_type TEXT, proximal REAL, distal REAL,
 created_idx INTEGER, created_timestamp TEXT, age_bars INTEGER, age_class TEXT, retest_count INTEGER,
 penetration_pct REAL, state TEXT, invalidated INTEGER, violation INTEGER, final_score REAL, nesting_tier TEXT,
 session_accepted INTEGER, removes_structure INTEGER, distance_from_cmp_pct REAL
);
CREATE TABLE IF NOT EXISTS setup_results (
 setup_id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER NOT NULL REFERENCES scan_results(scan_id),
 symbol TEXT NOT NULL, strategy_tf INTEGER NOT NULL, direction TEXT NOT NULL, setup_timestamp TEXT,
 pattern TEXT, zone_id TEXT, zone_signature TEXT, proposed_entry REAL, proposed_stop REAL, proposed_target REAL, rr REAL,
 setup_score REAL, setup_rank INTEGER, eligible INTEGER NOT NULL, blocked_reason TEXT, permission_state TEXT,
 gate_tier TEXT, gate_size_multiplier REAL, gate_reason TEXT
);
CREATE TABLE IF NOT EXISTS simulated_trades (
 trade_id INTEGER PRIMARY KEY AUTOINCREMENT, setup_id INTEGER NOT NULL UNIQUE REFERENCES setup_results(setup_id),
 scan_id INTEGER NOT NULL REFERENCES scan_results(scan_id), symbol TEXT NOT NULL, strategy_tf INTEGER NOT NULL,
 side TEXT NOT NULL, scan_timestamp TEXT NOT NULL, setup_timestamp TEXT, entry_timestamp TEXT, exit_timestamp TEXT,
 entry_price REAL, stop_price REAL, target_price REAL, exit_price REAL, outcome TEXT NOT NULL, exit_reason TEXT,
 target_hit INTEGER, stop_hit INTEGER, bars_held INTEGER, gross_r REAL, gross_return_pct REAL
);
CREATE TABLE IF NOT EXISTS trade_path_metrics (
 trade_id INTEGER PRIMARY KEY REFERENCES simulated_trades(trade_id), max_favorable_excursion REAL,
 max_adverse_excursion REAL, mfe_pct REAL, mae_pct REAL, max_favorable_pct_of_target REAL,
 bars_to_mfe INTEGER, bars_to_mae INTEGER, bars_to_exit INTEGER, first_positive_bar INTEGER,
 first_negative_bar INTEGER, favorable_before_adverse INTEGER, outcome_direction TEXT
);
CREATE INDEX IF NOT EXISTS idx_simulated_trades_scan ON simulated_trades(scan_id);
CREATE INDEX IF NOT EXISTS idx_setup_results_scan ON setup_results(scan_id);
CREATE TABLE IF NOT EXISTS worker_metrics (
 metric_id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL, worker_id TEXT NOT NULL,
 tasks_processed INTEGER, successful_tasks INTEGER, failed_tasks INTEGER, mean_runtime_ms REAL,
 median_runtime_ms REAL, p95_runtime_ms REAL, start_time TEXT, last_heartbeat TEXT, memory_usage_mb REAL
);
CREATE TABLE IF NOT EXISTS errors (
 error_id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL, task_id INTEGER, symbol TEXT, timeframe INTEGER,
 evaluation_timestamp TEXT, exception_type TEXT, exception_message TEXT, traceback TEXT, worker_id TEXT,
 attempt_number INTEGER, created_at TEXT NOT NULL
);
CREATE VIEW IF NOT EXISTS v_trade_context AS
 SELECT t.*, s.run_id, s.final_bias, r.E_regime, r.A_regime, r.X_regime, r.E_rule_applied, r.A_rule_applied, r.X_rule_applied,
        p.outcome_direction
 FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
 JOIN regime_snapshots r ON r.scan_id=s.scan_id LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id;
CREATE VIEW IF NOT EXISTS v_ea_performance AS
 SELECT E_regime, A_regime, count(*) trades, sum(outcome='WIN') wins, sum(outcome='LOSS') losses,
        round(100.0*sum(outcome='WIN')/nullif(count(*),0),4) win_rate
 FROM v_trade_context GROUP BY E_regime,A_regime;
CREATE VIEW IF NOT EXISTS v_rule_performance AS
 SELECT E_rule_applied rule_applied, count(*) trades, sum(outcome='WIN') wins,
        round(100.0*sum(outcome='WIN')/nullif(count(*),0),4) win_rate FROM v_trade_context GROUP BY E_rule_applied;
CREATE VIEW IF NOT EXISTS v_symbol_performance AS
 SELECT symbol,count(*) trades,sum(outcome='WIN') wins,round(100.0*sum(outcome='WIN')/nullif(count(*),0),4) win_rate FROM v_trade_context GROUP BY symbol;
CREATE VIEW IF NOT EXISTS v_timeframe_performance AS
 SELECT strategy_tf,count(*) trades,sum(outcome='WIN') wins,round(100.0*sum(outcome='WIN')/nullif(count(*),0),4) win_rate FROM v_trade_context GROUP BY strategy_tf;
CREATE VIEW IF NOT EXISTS v_yearly_performance AS
 SELECT substr(scan_timestamp,1,4) year,count(*) trades,sum(outcome='WIN') wins,round(100.0*sum(outcome='WIN')/nullif(count(*),0),4) win_rate FROM v_trade_context GROUP BY substr(scan_timestamp,1,4);
"""
