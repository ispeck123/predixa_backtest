"""Single-writer SQLite implementation for durable replay evidence."""
from __future__ import annotations

import json, sqlite3, subprocess, threading, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .base import BacktestStorage
from .schema import SCHEMA

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def git_value(args: list[str]) -> str | None:
    try:
        return subprocess.check_output(args, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return None

class SQLiteBacktestStorage(BacktestStorage):
    def __init__(self, path: str | Path):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        # The coordinator claims tasks on the main thread while ResultWriter
        # persists events on its dedicated thread.  Both use this connection;
        # serialize all connection access to avoid concurrent SQLite writes
        # and silent writer-thread termination.
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, timeout=60, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA busy_timeout=60000")
        # Views are replaceable audit conveniences; tables are persistent evidence.
        self.conn.executescript("DROP VIEW IF EXISTS v_trade_context; DROP VIEW IF EXISTS v_ea_performance; DROP VIEW IF EXISTS v_rule_performance; DROP VIEW IF EXISTS v_symbol_performance; DROP VIEW IF EXISTS v_timeframe_performance; DROP VIEW IF EXISTS v_yearly_performance;")
        self.conn.executescript(SCHEMA)
        # Audit-schema migration only.  This retains the literal pipeline
        # signature for future replays without touching production code or
        # changing pre-existing historical evidence.
        setup_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(setup_results)")}
        for name, declaration in {
            "zone_signature": "TEXT", "gate_tier": "TEXT",
            "gate_size_multiplier": "REAL", "gate_reason": "TEXT",
        }.items():
            if name not in setup_columns:
                self.conn.execute(f"ALTER TABLE setup_results ADD COLUMN {name} {declaration}")
        scan_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(scan_results)")}
        for name, declaration in {
            "gate_tier": "TEXT", "gate_size_multiplier": "REAL",
            "gate_reason": "TEXT", "gate_denied": "INTEGER",
        }.items():
            if name not in scan_columns:
                self.conn.execute(f"ALTER TABLE scan_results ADD COLUMN {name} {declaration}")
        self.conn.commit()

    def close(self):
        with self._lock: self.conn.close()

    def create_run(self, config, task_count: int = 0, run_id: str | None = None) -> str:
        run_id = run_id or uuid.uuid4().hex
        with self._lock:
            self.conn.execute("""INSERT INTO backtest_runs(run_id,run_name,git_commit,git_branch,created_at,engine_version,
          config_hash,config_json,executor_type,workers,symbol_count,timeframe_count,historical_start,historical_end,task_count,status,variant_name)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (run_id, config.run_name, git_value(["git","rev-parse","HEAD"]),
          git_value(["git","branch","--show-current"]), now(), "CURRENT_PRODUCTION", config.config_hash,
          json.dumps(config.canonical(), sort_keys=True), config.executor, config.resolved_workers(), len(config.symbols), len(config.tfs),
          config.start, config.end, task_count, "CREATED", config.variant_name))
            self.conn.commit()
        return run_id

    def get_run(self, run_id: str):
        with self._lock: return self.conn.execute("SELECT * FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone()

    def set_run_status(self, run_id: str, status: str):
        cols = "status=?, started_at=coalesce(started_at,?)" if status == "RUNNING" else "status=?, finished_at=?"
        with self._lock:
            self.conn.execute(f"UPDATE backtest_runs SET {cols} WHERE run_id=?", (status, now(), run_id)); self.conn.commit()

    def set_execution(self, run_id: str, executor_type: str, workers: int):
        with self._lock:
            self.conn.execute("UPDATE backtest_runs SET executor_type=?,workers=? WHERE run_id=?",(executor_type,workers,run_id)); self.conn.commit()

    def register_tasks(self, run_id: str, tasks: Iterable[dict]) -> int:
        rows = [(run_id,t["symbol"],t["strategy_tf"],t["strategy_tf_name"],t["evaluation_timestamp"]) for t in tasks]
        with self._lock:
            self.conn.executemany("""INSERT OR IGNORE INTO scan_tasks(run_id,symbol,strategy_tf,strategy_tf_name,evaluation_timestamp)
          VALUES(?,?,?,?,?)""", rows)
            self.conn.execute("UPDATE backtest_runs SET task_count=(SELECT count(*) FROM scan_tasks WHERE run_id=?) WHERE run_id=?",(run_id,run_id))
            self.conn.commit()
        return len(rows)

    def reclaim_stale(self, run_id: str):
        # A process exited before publishing an event. On resume its run is safe to retry.
        with self._lock:
            self.conn.execute("UPDATE scan_tasks SET status='RETRY',assigned_worker=NULL WHERE run_id=? AND status='RUNNING'", (run_id,)); self.conn.commit()

    def claim_tasks(self, run_id: str, limit: int) -> list[dict]:
        with self._lock:
            rows = self.conn.execute("SELECT * FROM scan_tasks WHERE run_id=? AND status IN ('PENDING','RETRY') ORDER BY task_id LIMIT ?",(run_id,limit)).fetchall()
            if not rows: return []
            ids=[r["task_id"] for r in rows]
            self.conn.executemany("UPDATE scan_tasks SET status='RUNNING',attempt_count=attempt_count+1,started_at=? WHERE task_id=?",[(now(),i) for i in ids])
            self.conn.commit()
        claimed=[]
        for row in rows:
            item=dict(row); item["attempt_count"] += 1; claimed.append(item)
        return claimed

    def task_counts(self, run_id: str) -> dict:
        with self._lock: rows=self.conn.execute("SELECT status,count(*) n FROM scan_tasks WHERE run_id=? GROUP BY status",(run_id,)).fetchall()
        out={r["status"]:r["n"] for r in rows}; out["TOTAL"]=sum(out.values()); return out

    def save_events(self, events: list[dict]):
        """Atomic batched writer entry point; workers never obtain this connection."""
        if not events: return
        with self._lock, self.conn:
            for event in events: self._save_event(event)

    def _save_event(self, event: dict):
        task=event["task"]; result=event.get("result"); error=event.get("error")
        if error:
            cur=self.conn.execute("""INSERT INTO errors(run_id,task_id,symbol,timeframe,evaluation_timestamp,exception_type,exception_message,traceback,worker_id,attempt_number,created_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (task["run_id"],task["task_id"],task["symbol"],task["strategy_tf"],task["evaluation_timestamp"],error["type"],error["message"],error["traceback"],event.get("worker_id"),task["attempt_count"],now()))
            status="RETRY" if task["attempt_count"] <= event.get("max_retries",0) else "FAILED"
            self.conn.execute("UPDATE scan_tasks SET status=?,finished_at=?,duration_ms=?,error_id=? WHERE task_id=?",(status,now(),event.get("duration_ms"),cur.lastrowid,task["task_id"]))
            return
        scan=result["scan"]
        scan_fields = ("task_id","run_id","symbol","strategy_tf","evaluation_timestamp","cmp","signal_generated","setup_generated","entry_candidate","rejection_reason","final_bias","allow_long","allow_short","permitted_setup","trade_type_long","trade_type_short","dbr_required","rbd_required","htf_veto_longs","htf_veto_shorts","htf_veto_reason","production_runtime_ms","gate_tier","gate_size_multiplier","gate_reason","gate_denied","raw_json")
        # A worker can finish and publish a scan row immediately before the
        # coordinator is terminated, leaving the task marked RUNNING. On
        # resume that task is replayed. INSERT OR REPLACE would delete the
        # existing scan parent first, which violates its regime/setup child
        # foreign keys. Use an in-place UPSERT so resume is idempotent.
        update_fields = tuple(k for k in scan_fields if k != "task_id")
        placeholders = ",".join("?" * len(scan_fields))
        assignments = ",".join(f"{k}=excluded.{k}" for k in update_fields)
        self.conn.execute(
            f"INSERT INTO scan_results({','.join(scan_fields)}) VALUES({placeholders}) "
            f"ON CONFLICT(task_id) DO UPDATE SET {assignments}",
            tuple(scan.get(k) for k in scan_fields),
        )
        scan_id=self.conn.execute("SELECT scan_id FROM scan_results WHERE task_id=?",(task["task_id"],)).fetchone()[0]
        reg=result["regime"]; reg["scan_id"]=scan_id
        fields=("scan_id","E_regime","A_regime","X_regime","E_quadrant","A_quadrant","X_quadrant","E_rule_applied","A_rule_applied","X_rule_applied","E_diagnosis","A_diagnosis","X_diagnosis","E_htf_veto_applied","A_htf_veto_applied","X_htf_veto_applied","E_reinforcers","A_reinforcers","X_reinforcers","reference_E","reference_A","reference_X","E_ema20","A_ema20","X_ema20","E_ema_slope","A_ema_slope","X_ema_slope","return_20_E","return_20_A","return_20_X","last_confirmed_swing_high","last_confirmed_swing_low")
        # Replace the derived children for this task only. This removes
        # duplicate zones/setups/trades on an official resume retry while
        # preserving every other task's durable evidence.
        self.conn.execute("DELETE FROM trade_path_metrics WHERE trade_id IN (SELECT trade_id FROM simulated_trades WHERE scan_id=?)", (scan_id,))
        self.conn.execute("DELETE FROM simulated_trades WHERE scan_id=?", (scan_id,))
        self.conn.execute("DELETE FROM setup_results WHERE scan_id=?", (scan_id,))
        self.conn.execute("DELETE FROM zone_snapshots WHERE scan_id=?", (scan_id,))
        self.conn.execute(f"INSERT OR REPLACE INTO regime_snapshots({','.join(fields)}) VALUES({','.join('?'*len(fields))})",tuple(reg.get(k) for k in fields))
        for zone in result.get("zones",[]):
            zone["scan_id"]=scan_id; cols=tuple(zone); self.conn.execute(f"INSERT INTO zone_snapshots({','.join(cols)}) VALUES({','.join('?'*len(cols))})",tuple(zone[k] for k in cols))
        for setup in result.get("setups",[]):
            setup = dict(setup); trade=setup.pop("trade", None); setup["scan_id"]=scan_id
            cols=tuple(setup); cur2=self.conn.execute(f"INSERT INTO setup_results({','.join(cols)}) VALUES({','.join('?'*len(cols))})",tuple(setup[k] for k in cols));
            if trade:
                trade = dict(trade); metrics=trade.pop("metrics", {}); trade["setup_id"]=cur2.lastrowid; trade["scan_id"]=scan_id; cols=tuple(trade); cur3=self.conn.execute(f"INSERT INTO simulated_trades({','.join(cols)}) VALUES({','.join('?'*len(cols))})",tuple(trade[k] for k in cols));
                metrics["trade_id"]=cur3.lastrowid; mc=tuple(metrics); self.conn.execute(f"INSERT INTO trade_path_metrics({','.join(mc)}) VALUES({','.join('?'*len(mc))})",tuple(metrics[k] for k in mc))
        self.conn.execute("UPDATE scan_tasks SET status='COMPLETED',finished_at=?,duration_ms=? WHERE task_id=?",(now(),event.get("duration_ms"),task["task_id"]))

    def finalise_counts(self, run_id: str):
        with self._lock:
            c=self.task_counts(run_id); self.conn.execute("UPDATE backtest_runs SET completed_count=?,failed_count=? WHERE run_id=?",(c.get("COMPLETED",0),c.get("FAILED",0),run_id)); self.conn.commit()
