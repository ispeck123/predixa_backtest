"""Collect contract expiry observations from a mirrored MCX daily bhavcopy archive.

The MCX production web endpoint is Akamai-gated in this environment.  This
collector uses a mirror whose documented upstream is the MCX bhavcopy viewer,
but labels every record as provisional.  It never promotes mirror data to
official verification and never uses FYERS filename labels as history.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import gzip
import hashlib
import io
import json
import urllib.request
from datetime import date
from pathlib import Path

import pandas as pd


INDEX_URL = "https://mtf.trading/mcx/index.json"
FILE_URL = "https://mtf.trading/mcx/{:%Y%m%d}.csv.gz"
SOURCE_NAME = "MCX Bhavcopy mirror (documented MCX browser capture)"
STATUS = "MIRROR_OF_MCX_BHAVCOPY_PENDING_OFFICIAL_VALIDATION"
SYMBOLS = ("GOLDM", "CRUDEOILM", "SILVERM", "NATGASMINI")
MAP_COLUMNS = [
    "exchange", "symbol", "instrument_type", "contract_slot", "expiry_date", "contract_identifier",
    "contract_month", "first_listed_date", "last_trading_date", "active_from", "active_to",
    "source_name", "source_file", "source_sha256", "verification_status", "mapping_evidence",
]
MANIFEST_COLUMNS = ["exchange_date", "source_name", "source_url", "source_sha256", "bytes", "selected_rows", "status", "error"]


def get(url: str, timeout: int = 45) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "PREDIXA expiry research; contact project owner"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def collect_one(day: date) -> tuple[list[dict], dict]:
    url = FILE_URL.format(day)
    try:
        payload = get(url)
        raw = gzip.decompress(payload)
        frame = pd.read_csv(io.BytesIO(raw))
        required = {"Date", "Symbol", "InstrumentName", "ExpiryDate"}
        if missing := required - set(frame.columns):
            raise ValueError(f"missing columns: {sorted(missing)}")
        selected = frame[(frame["InstrumentName"] == "FUTCOM") & (frame["Symbol"].isin(SYMBOLS))].copy()
        selected["expiry"] = pd.to_datetime(selected["ExpiryDate"], format="%d%b%Y", errors="coerce")
        selected = selected.dropna(subset=["expiry"]).sort_values(["Symbol", "expiry"])
        rows: list[dict] = []
        digest = hashlib.sha256(payload).hexdigest()
        for symbol, contracts in selected.groupby("Symbol", sort=True):
            for rank, contract in enumerate(contracts.drop_duplicates("ExpiryDate").itertuples(index=False), start=1):
                expiry = pd.Timestamp(contract.expiry).date()
                rows.append({
                    "exchange": "MCX", "symbol": symbol, "instrument_type": "FUTCOM",
                    "contract_slot": {1: "NEAR", 2: "NEXT", 3: "FAR"}.get(rank, f"DEFERRED_{rank}"),
                    "expiry_date": expiry.isoformat(),
                    "contract_identifier": f"FUTCOM:{symbol}:{contract.ExpiryDate}",
                    "contract_month": expiry.strftime("%Y-%m"), "first_listed_date": "",
                    "last_trading_date": expiry.isoformat(),
                    "active_from": f"{day.isoformat()}T09:00:00+05:30", "active_to": f"{day.isoformat()}T23:55:00+05:30",
                    "source_name": SOURCE_NAME, "source_file": url, "source_sha256": digest,
                    "verification_status": STATUS,
                    "mapping_evidence": "daily mirrored MCX bhavcopy; observed FUTCOM contracts ranked by ascending actual ExpiryDate",
                })
        return rows, {"exchange_date": day.isoformat(), "source_name": SOURCE_NAME, "source_url": url,
                      "source_sha256": digest, "bytes": len(payload), "selected_rows": len(rows), "status": STATUS, "error": ""}
    except Exception as exc:
        return [], {"exchange_date": day.isoformat(), "source_name": SOURCE_NAME, "source_url": url,
                    "source_sha256": "", "bytes": 0, "selected_rows": 0, "status": "MISSING_EVIDENCE",
                    "error": f"{type(exc).__name__}: {exc}"}


def write_csv(path: Path, columns: list[str], rows: list[dict]) -> None:
    with path.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns); writer.writeheader(); writer.writerows(rows)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--start", type=date.fromisoformat, default=date(2023, 3, 14)); p.add_argument("--end", type=date.fromisoformat, default=date(2026, 11, 2))
    p.add_argument("--output", type=Path, required=True); p.add_argument("--workers", type=int, default=6)
    args = p.parse_args(argv)
    if args.output.exists(): raise FileExistsError(f"output exists: {args.output}")
    index = json.loads(get(INDEX_URL).decode("utf-8"))
    days = [date.fromisoformat(item["date"][:4] + "-" + item["date"][4:6] + "-" + item["date"][6:]) for item in index["dates"]]
    days = [day for day in days if args.start <= day <= args.end]
    args.output.mkdir(parents=True)
    records: list[dict] = []; manifests: list[dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {pool.submit(collect_one, day): day for day in days}
        for n, future in enumerate(concurrent.futures.as_completed(futures), start=1):
            rows, manifest = future.result(); records.extend(rows); manifests.append(manifest)
            if n % 50 == 0 or n == len(days): print(f"MCX bhavcopy collection: {n}/{len(days)}; records={len(records)}", flush=True)
    records.sort(key=lambda row: (row["active_from"], row["symbol"], row["contract_slot"]))
    manifests.sort(key=lambda row: row["exchange_date"])
    write_csv(args.output / "MCX_historical_expiry_map_provisional.csv", MAP_COLUMNS, records)
    write_csv(args.output / "expiry_source_manifest.csv", MANIFEST_COLUMNS, manifests)
    coverage = pd.DataFrame(records)
    if len(coverage):
        report = coverage.groupby("symbol").agg(records=("symbol", "size"), source_dates=("active_from", lambda x: x.str[:10].nunique()), first_date=("active_from", "min"), last_date=("active_from", "max"), first_expiry=("expiry_date", "min"), last_expiry=("expiry_date", "max")).reset_index()
    else:
        report = pd.DataFrame(columns=["symbol", "records", "source_dates", "first_date", "last_date", "first_expiry", "last_expiry"])
    report.to_csv(args.output / "expiry_coverage_report.csv", index=False)
    (args.output / "README.md").write_text(
        "# MCX bhavcopy provisional expiry observations\n\n"
        "This map is derived from a mirror that documents browser capture of the public MCX bhavcopy page because direct MCX requests returned HTTP 403 in this environment. "
        "It is not an official-file capture, is never OFFICIAL_VERIFIED, and is not integrated into a final expiry-aware replay. "
        "Rows reflect observed daily FUTCOM expiries and ascending observed near/next/far rank only.\n",
        encoding="utf-8",
    )
    summary = {"source": INDEX_URL, "mirror_status": STATUS, "date_count": len(days), "confirmed_dates": sum(x["status"] == STATUS for x in manifests), "missing_dates": sum(x["status"] != STATUS for x in manifests), "records": len(records), "symbols": sorted(set(row["symbol"] for row in records))}
    (args.output / "result.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2)); return 0


if __name__ == "__main__":
    raise SystemExit(main())
