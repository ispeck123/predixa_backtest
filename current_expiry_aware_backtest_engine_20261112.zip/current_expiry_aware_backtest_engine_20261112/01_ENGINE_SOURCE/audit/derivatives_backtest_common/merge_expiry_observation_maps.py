"""Create a new, immutable merged expiry-observation map from source packages.

Inputs are never changed.  Duplicate point-in-time slot records must be byte
identical after normalisation; otherwise merge fails rather than selecting a
source silently.  This is for research expiry metadata only, never OHLC.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def merge(output: Path, map_name: str, inputs: list[Path]) -> dict:
    if output.exists():
        raise FileExistsError(f"output exists: {output}")
    frames = []
    manifests = []
    sources = []
    for root in inputs:
        map_path = root / map_name
        manifest_path = root / "expiry_source_manifest.csv"
        if not map_path.is_file() or not manifest_path.is_file():
            raise FileNotFoundError(f"missing map or manifest in {root}")
        frames.append(pd.read_csv(map_path, keep_default_na=False))
        manifests.append(pd.read_csv(manifest_path, keep_default_na=False))
        sources.append({"path": str(root.resolve()), "map_sha256": _sha256(map_path), "manifest_sha256": _sha256(manifest_path)})
    merged = pd.concat(frames, ignore_index=True)
    key = ["exchange", "symbol", "contract_slot", "active_from"]
    # Normalise and compare only the small subset of duplicate point-in-time
    # keys.  The historical NSE map has hundreds of thousands of unique rows;
    # iterating every group would turn a safety check into an unnecessary wait.
    normal = merged.fillna("").astype(str)
    duplicate = normal.loc[normal.duplicated(key, keep=False)]
    conflicts = 0
    if not duplicate.empty:
        for _, group in duplicate.groupby(key, sort=False, dropna=False):
            if len(group.drop_duplicates()) != 1:
                conflicts += 1
    if conflicts:
        raise ValueError(f"conflicting duplicate point-in-time slot records: {conflicts}")
    result = normal.drop_duplicates(subset=key, keep="first").sort_values(
        ["active_from", "symbol", "contract_slot"], kind="stable"
    )
    source_manifest = pd.concat(manifests, ignore_index=True).drop_duplicates().sort_values("exchange_date", kind="stable")
    output.mkdir(parents=True)
    result.to_csv(output / map_name, index=False)
    source_manifest.to_csv(output / "expiry_source_manifest.csv", index=False)
    report = {
        "map": map_name, "rows": len(result), "source_dates": int(result.active_from.astype(str).str[:10].nunique()),
        "first_date": str(result.active_from.astype(str).str[:10].min()), "last_date": str(result.active_from.astype(str).str[:10].max()),
        "map_sha256": _sha256(output / map_name), "inputs": sources,
    }
    (output / "merge_manifest.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--map-name", required=True)
    parser.add_argument("inputs", nargs="+", type=Path)
    args = parser.parse_args(argv)
    print(json.dumps(merge(args.output, args.map_name, args.inputs), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
