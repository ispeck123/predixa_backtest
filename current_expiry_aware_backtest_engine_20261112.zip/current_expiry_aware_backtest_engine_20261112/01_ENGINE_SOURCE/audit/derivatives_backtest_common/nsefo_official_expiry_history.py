"""Build a pending-owner NSEFO slot/expiry map from official daily bhavcopies.

Only exchange contract metadata is emitted.  Existing FYERS OHLC is neither
read for prices nor rewritten.  Each map row describes one official exchange
date and one observed FUTSTK/FUTIDX contract slot, so missing exchange dates
remain missing rather than being filled with a weekday rule.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import sqlite3
import time
import urllib.request
import zipfile
from datetime import date, timedelta
from pathlib import Path

import pandas as pd


STATUS = "OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER"
MAP_COLUMNS = [
    "exchange", "symbol", "instrument_type", "contract_slot", "expiry_date", "contract_identifier",
    "contract_month", "first_listed_date", "last_trading_date", "active_from", "active_to",
    "source_name", "source_file", "source_sha256", "verification_status", "mapping_evidence",
]
MANIFEST_COLUMNS = ["exchange_date", "source_name", "source_url", "source_sha256", "rows", "status", "error"]


def official_url(day: date) -> str:
    if day < date(2024, 7, 8):
        raise ValueError("this reader supports the NSE UDiFF era only (2024-07-08 onward)")
    return f"https://archives.nseindia.com/content/fo/BhavCopy_NSE_FO_0_0_0_{day:%Y%m%d}_F_0000.csv.zip"


def parse_bhavcopy(payload: bytes, exchange_date: date, symbols: set[str]) -> tuple[list[dict], int]:
    """Parse official UDiFF records; expiry order is observed, never calendar-derived."""
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = archive.namelist()
        if len(names) != 1 or not names[0].lower().endswith(".csv"):
            raise ValueError("expected exactly one CSV in official bhavcopy archive")
        frame = pd.read_csv(archive.open(names[0]))
    needed = {"TradDt", "FinInstrmTp", "TckrSymb", "XpryDt", "FinInstrmNm"}
    if missing := needed - set(frame.columns):
        raise ValueError(f"official UDiFF columns missing: {sorted(missing)}")
    trade_dates = pd.to_datetime(frame["TradDt"], errors="coerce").dt.date.dropna().unique()
    if set(trade_dates) != {exchange_date}:
        raise ValueError(f"archive trade date mismatch: expected {exchange_date}, got {sorted(map(str, trade_dates))}")
    subset = frame[(frame["FinInstrmTp"].isin(("STF", "IDF"))) & (frame["TckrSymb"].isin(symbols))].copy()
    subset["expiry"] = pd.to_datetime(subset["XpryDt"], errors="coerce")
    subset = subset.dropna(subset=["expiry"]).sort_values(["TckrSymb", "expiry", "FinInstrmNm"])
    rows: list[dict] = []
    for symbol, contracts in subset.groupby("TckrSymb", sort=True):
        # Slot rank is an observed ranking of contracts listed in this official
        # daily file. It never manufactures an absent contract.
        for rank, contract in enumerate(contracts.drop_duplicates("FinInstrmNm").itertuples(index=False), start=1):
            rows.append({
                "exchange": "NSEFO", "symbol": symbol, "instrument_type": contract.FinInstrmTp,
                "contract_slot": {1: "NEAR", 2: "NEXT", 3: "FAR"}.get(rank, f"DEFERRED_{rank}"),
                "expiry_date": pd.Timestamp(contract.expiry).date().isoformat(),
                "contract_identifier": contract.FinInstrmNm,
                "contract_month": pd.Timestamp(contract.expiry).strftime("%Y-%m"),
                "first_listed_date": "", "last_trading_date": pd.Timestamp(contract.expiry).date().isoformat(),
                # These are deliberately one exchange-date intervals.  A date
                # with no official record cannot leak a prior/future mapping.
                "active_from": f"{exchange_date.isoformat()}T09:15:00+05:30",
                "active_to": f"{exchange_date.isoformat()}T15:30:00+05:30",
                "source_name": "NSE F&O UDiFF Common Bhavcopy Final",
                "source_file": official_url(exchange_date), "source_sha256": "",
                "verification_status": STATUS,
                "mapping_evidence": "official same-date FUTSTK/FUTIDX record; slot is ascending observed expiry rank",
            })
    return rows, len(frame)


def fetch(day: date, timeout: int = 60) -> bytes:
    request = urllib.request.Request(official_url(day), headers={"User-Agent": "Mozilla/5.0 PREDIXA expiry research"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = response.read()
    if not payload.startswith(b"PK"):
        raise ValueError("official endpoint did not return a ZIP archive")
    return payload


def write_day(output: Path, day: date, symbols: set[str], payload: bytes) -> dict:
    rows, source_rows = parse_bhavcopy(payload, day, symbols)
    digest = hashlib.sha256(payload).hexdigest()
    for row in rows:
        row["source_sha256"] = digest
    return {"rows": rows, "manifest": {"exchange_date": day.isoformat(), "source_name": "NSE F&O UDiFF Common Bhavcopy Final", "source_url": official_url(day), "source_sha256": digest, "rows": source_rows, "status": STATUS, "error": ""}}


def collect_dates(days: list[date], symbols: set[str], delay_seconds: float) -> tuple[list[dict], list[dict]]:
    """Collect only source-backed exchange-date records; failures stay explicit."""
    map_rows: list[dict] = []
    manifest_rows: list[dict] = []
    for index, day in enumerate(days, start=1):
        try:
            result = write_day(Path("."), day, symbols, fetch(day))
            map_rows.extend(result["rows"]); manifest_rows.append(result["manifest"])
        except Exception as exc:
            manifest_rows.append({"exchange_date": day.isoformat(), "source_name": "NSE F&O UDiFF Common Bhavcopy Final",
                                  "source_url": official_url(day), "source_sha256": "", "rows": 0,
                                  "status": "MISSING_EVIDENCE", "error": f"{type(exc).__name__}: {exc}"})
        if index % 10 == 0 or index == len(days):
            confirmed = sum(row["status"] == STATUS for row in manifest_rows)
            print(f"NSEFO expiry metadata: {index}/{len(days)} dates; confirmed={confirmed}; rows={len(map_rows)}", flush=True)
        if index < len(days) and delay_seconds:
            time.sleep(delay_seconds)
    return map_rows, manifest_rows


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    requested = parser.add_mutually_exclusive_group(required=True)
    requested.add_argument("--date", type=date.fromisoformat)
    requested.add_argument("--start", type=date.fromisoformat)
    parser.add_argument("--end", type=date.fromisoformat, help="required with --start")
    parser.add_argument("--delay-seconds", type=float, default=0.25)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--symbols-file", type=Path)
    source.add_argument("--run-storage", type=Path, help="existing replay SQLite, opened mode=ro")
    parser.add_argument("--run", help="required with --run-storage")
    parser.add_argument("--output", required=True, type=Path, help="new output directory")
    args = parser.parse_args(argv)
    if args.symbols_file:
        symbols = {x.strip().upper() for x in args.symbols_file.read_text().splitlines() if x.strip() and not x.startswith("#")}
    else:
        if not args.run:
            parser.error("--run is required with --run-storage")
        uri = f"file:{args.run_storage.resolve()}?mode=ro"
        with sqlite3.connect(uri, uri=True) as db:
            config = db.execute("SELECT config_json FROM backtest_runs WHERE run_id=?", (args.run,)).fetchone()
        if config is None:
            parser.error(f"run not found: {args.run}")
        symbols = {str(value).upper() for value in json.loads(config[0]).get("symbols", [])}
    if args.start and not args.end:
        parser.error("--end is required with --start")
    if args.end and not args.start:
        parser.error("--start is required with --end")
    days = [args.date] if args.date else [
        args.start + timedelta(days=offset)
        for offset in range((args.end - args.start).days + 1)
        if (args.start + timedelta(days=offset)).weekday() < 5
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    rows, manifests = collect_dates(days, symbols, args.delay_seconds)
    with (args.output / "NSEFO_historical_expiry_map.csv").open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=MAP_COLUMNS); writer.writeheader(); writer.writerows(rows)
    with (args.output / "expiry_source_manifest.csv").open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=MANIFEST_COLUMNS); writer.writeheader(); writer.writerows(manifests)
    (args.output / "result.json").write_text(json.dumps({"map_rows": len(rows), "dates_requested": len(days), "dates_confirmed": sum(x["status"] == STATUS for x in manifests), "dates_missing": sum(x["status"] != STATUS for x in manifests)}, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "map_rows": len(rows), "dates_requested": len(days), "status": STATUS}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
