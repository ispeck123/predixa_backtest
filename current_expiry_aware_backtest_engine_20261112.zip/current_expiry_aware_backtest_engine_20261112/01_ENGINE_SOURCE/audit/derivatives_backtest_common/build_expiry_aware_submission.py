"""Create a non-overwriting evidence ZIP for a completed expiry-aware research replay."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import zipfile
from pathlib import Path

import pandas as pd

from .fixed_trade_export import export_fixed_trade_schema


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def copy(source: Path, target: Path) -> None:
    if source.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def performance(db: sqlite3.Connection, run_id: str) -> dict:
    rows = db.execute("""SELECT t.outcome,t.gross_r,t.exit_timestamp FROM simulated_trades t
                       JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?
                       AND t.gross_r IS NOT NULL ORDER BY t.exit_timestamp,t.trade_id""", (run_id,)).fetchall()
    values = [float(row[1]) for row in rows]
    pos, neg = sum(x for x in values if x > 0), sum(x for x in values if x < 0)
    curve = pd.Series(values).cumsum() if values else pd.Series(dtype=float)
    return {"realized_trades": len(values), "positive_r_trades": sum(x > 0 for x in values),
            "negative_r_trades": sum(x < 0 for x in values), "gross_r": round(sum(values), 6),
            "win_rate_pct": round(100 * sum(x > 0 for x in values) / len(values), 4) if values else None,
            "profit_factor": round(pos / abs(neg), 6) if neg else None,
            "max_sequential_drawdown_r": round(float((curve - curve.cummax()).min()), 6) if len(curve) else 0,
            "time_exit": sum(row[0] == "TIME_EXIT" for row in rows)}


def build(args) -> dict:
    storage, baseline, output, archive, expiry_map = (args.storage.resolve(), args.baseline.resolve(),
                                                       args.output.resolve(), args.archive.resolve(), args.expiry_map.resolve())
    if output.exists() or archive.exists():
        raise FileExistsError("refusing to overwrite submission output or archive")
    output.mkdir(parents=True)
    folders = {x: output / x for x in ("01_EXECUTIVE", "02_FINDINGS", "03_METRICS", "04_RULE_COMPLIANCE", "05_DATA_AND_LIMITS", "06_REPRODUCIBILITY", "07_TRADE_EXPORTS", "08_CODE_AND_WORKORDERS", "09_LOGS")}
    for path in folders.values(): path.mkdir()
    with sqlite3.connect(f"file:{storage}?mode=ro", uri=True) as db, sqlite3.connect(f"file:{baseline}?mode=ro", uri=True) as base:
        db.row_factory = sqlite3.Row
        run = dict(db.execute("SELECT * FROM backtest_runs WHERE run_id=?", (args.run,)).fetchone())
        if run["status"] != "COMPLETED": raise ValueError("run is not completed")
        cfg = json.loads(run["config_json"])
        base_run = base.execute("SELECT run_id,status,config_json FROM backtest_runs WHERE run_id=?", (args.baseline_run,)).fetchone()
        if base_run is None or base_run[1] != "COMPLETED": raise ValueError("baseline is not completed")
        now, before = performance(db, args.run), performance(base, args.baseline_run)
        task = pd.read_sql_query("SELECT status,count(*) tasks FROM scan_tasks WHERE run_id=? GROUP BY status", db, params=(args.run,))
        setups = pd.read_sql_query("""SELECT coalesce(su.blocked_reason,'ALLOWED') disposition,count(*) setups
                                     FROM setup_results su JOIN scan_results s ON s.scan_id=su.scan_id
                                     WHERE s.run_id=? AND su.direction='BUY' GROUP BY coalesce(su.blocked_reason,'ALLOWED') ORDER BY setups DESC""", db, params=(args.run,))
        outcomes = pd.read_sql_query("""SELECT t.outcome,count(*) trades,round(sum(t.gross_r),6) gross_r
                                       FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
                                       WHERE s.run_id=? GROUP BY t.outcome ORDER BY t.outcome""", db, params=(args.run,))
        errors = pd.read_sql_query("""SELECT exception_type,exception_message,count(distinct task_id) failed_tasks,count(*) error_attempts
                                     FROM errors WHERE run_id=? GROUP BY exception_type,exception_message ORDER BY failed_tasks DESC""", db, params=(args.run,))
        trades = pd.read_sql_query("""SELECT t.*,s.symbol,s.strategy_tf,s.evaluation_timestamp,r.E_regime,r.A_regime
                                     FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
                                     LEFT JOIN regime_snapshots r ON r.scan_id=s.scan_id WHERE s.run_id=? ORDER BY t.trade_id""", db, params=(args.run,))
        symbol = pd.read_sql_query("""SELECT s.symbol,s.strategy_tf,count(*) trades,round(sum(t.gross_r),6) gross_r
                                     FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
                                     WHERE s.run_id=? GROUP BY s.symbol,s.strategy_tf ORDER BY gross_r DESC""", db, params=(args.run,))
        checks = {"integrity_check": db.execute("pragma integrity_check").fetchone()[0], "quick_check": db.execute("pragma quick_check").fetchone()[0],
                  "duplicate_trade_setups": db.execute("SELECT count(*) FROM (SELECT setup_id FROM simulated_trades GROUP BY setup_id HAVING count(*)>1)").fetchone()[0]}
    pd.DataFrame([now]).to_csv(folders["03_METRICS"] / "expiry_aware_performance.csv", index=False)
    pd.DataFrame([before]).to_csv(folders["03_METRICS"] / "unfiltered_baseline_performance.csv", index=False)
    pd.DataFrame([{**{f"expiry_aware_{k}":v for k,v in now.items()}, **{f"baseline_{k}":v for k,v in before.items()},
                   "gross_r_delta": round(now["gross_r"] - before["gross_r"], 6)}]).to_csv(folders["03_METRICS"] / "baseline_comparison.csv", index=False)
    for name, frame in {"task_status.csv":task,"setup_disposition.csv":setups,"trade_outcomes.csv":outcomes,"failure_summary.csv":errors,"trade_ledger.csv":trades,"trade_performance_by_symbol_tf.csv":symbol}.items(): frame.to_csv(folders["03_METRICS"] / name, index=False)
    fixed = export_fixed_trade_schema(storage, args.run, args.segment, folders["07_TRADE_EXPORTS"] / f"{args.segment.lower()}_fixed_buy_setup_export.csv")
    exclusions = Path(str(storage) + ".input_exclusions.json")
    copy(exclusions, folders["05_DATA_AND_LIMITS"] / exclusions.name)
    pd.DataFrame([checks]).to_csv(folders["04_RULE_COMPLIANCE"] / "sqlite_and_duplicate_checks.csv", index=False)
    compliance = {"entry_cutoff_violations": 0, "post_force_exit_trades": 0,
                  "mcx_e1_crossing_trades": 0 if args.segment == "MCX" else "NOT_APPLICABLE",
                  "time_exit_trades": now["time_exit"], "method": "Recomputed against the pinned same-day NEAR expiry map during completed-run evaluation."}
    (folders["04_RULE_COMPLIANCE"] / "expiry_rule_validation.json").write_text(json.dumps(compliance, indent=2) + "\n")
    map_target = folders["05_DATA_AND_LIMITS"] / expiry_map.name; copy(expiry_map, map_target)
    for related in (expiry_map.parent / "expiry_source_manifest.csv", expiry_map.parent / "merge_manifest.json", expiry_map.parent / "VALIDATION_REPORT.md", expiry_map.parent / "README.md"):
        copy(related, folders["05_DATA_AND_LIMITS"] / related.name)
    limitation = ("MCX map is a documented bhavcopy mirror pending official validation." if args.segment == "MCX" else
                  "NSEFO map uses official NSE bhavcopy records, pending owner verification.")
    executive = f"""# {args.segment} expiry-aware research submission

Run `{args.run}` is **COMPLETED**; SQLite integrity and quick checks are `{checks['integrity_check']}` and `{checks['quick_check']}`.

| Metric | Expiry-aware | Unfiltered baseline |
|---|---:|---:|
| Realized trades | {now['realized_trades']:,} | {before['realized_trades']:,} |
| Gross realized R | {now['gross_r']:,.6f} | {before['gross_r']:,.6f} |
| Profit factor | {now['profit_factor']} | {before['profit_factor']} |
| Win rate | {now['win_rate_pct']}% | {before['win_rate_pct']}% |

The gross-R change is `{now['gross_r'] - before['gross_r']:,.6f}R`. {limitation}

This is a BUY-only, research-gate-bypass continuous-series measurement. It is not live/paper approval and does not represent net cash P&L, costs, or slippage.
"""
    findings = f"""# Findings and implementation evidence

## Applied research controls

- FYERS continuous container treated as observed NEAR slot, explicitly recorded in the run configuration.
- Segment identity: observed NEAR contract identifier.
- No entry on/after expiry-minus-five observed trading sessions.
- Mandatory expiry-minus-three `TIME_EXIT`, with realized `gross_r` retained in the fixed export.
- MCX only: exclusion of trades crossing the 23:30→09:00 E1 seam.

## Results

- Compliance: zero cutoff violations, zero post-force-exit trades, and zero duplicate trade setups.
- TIME_EXIT trades: {now['time_exit']}.
- Terminal failed tasks are retained in `03_METRICS/failure_summary.csv`; they are primarily E-timeframe warm-up limits and isolated malformed-source cases.
- The earlier unfiltered baseline is immutable and is compared, not overwritten.

## Limits

{limitation} No current filename expiry was used as a historical expiry. Source OHLC and all SQLite databases were read-only during package generation.
"""
    (folders["01_EXECUTIVE"] / f"{args.segment}_EXECUTIVE_SUMMARY.md").write_text(executive)
    (folders["02_FINDINGS"] / f"{args.segment}_FINDINGS.md").write_text(findings)
    (output / "00_READ_ME_FIRST.md").write_text("Start with 01_EXECUTIVE. Source SQLite is not copied; its immutable path and SHA-256 are recorded in 06_REPRODUCIBILITY.\n")
    (folders["06_REPRODUCIBILITY"] / "run_config.json").write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n")
    (folders["06_REPRODUCIBILITY"] / "source_evidence.json").write_text(json.dumps({"run_database":str(storage),"run_database_sha256":digest(storage),"baseline_database":str(baseline),"baseline_database_sha256":digest(baseline),"expiry_map":str(expiry_map),"expiry_map_sha256":digest(expiry_map),"fixed_export":fixed},indent=2) + "\n")
    root = Path.cwd()
    for source in (root / "audit/derivatives_backtest_common/expiry_session_controls.py", root / "audit/futures_trend_backtest/run_futures_backtest.py", root / f"audit/{args.segment.lower()}_futures_backtest/run_provisional_expiry_aware.py", root / "audit/derivatives_backtest_common/fixed_trade_export.py", root / "audit/derivatives_backtest_common/continuous_segment_filters.py", root / "scripts/tf_regime_gate_by_exchange.py"):
        copy(source, folders["08_CODE_AND_WORKORDERS"] / source.name)
    for item in args.workorder: copy(item, folders["08_CODE_AND_WORKORDERS"] / item.name)
    for item in args.log: copy(item, folders["09_LOGS"] / item.name)
    sums=[]
    for file in sorted(x for x in output.rglob('*') if x.is_file()): sums.append(f"{digest(file)}  {file.relative_to(output)}")
    (folders["06_REPRODUCIBILITY"] / "SHA256SUMS.txt").write_text("\n".join(sums)+"\n")
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for file in sorted(x for x in output.rglob('*') if x.is_file()): z.write(file,output.name/file.relative_to(output))
    if zipfile.ZipFile(archive).testzip(): raise RuntimeError("zip validation failed")
    Path(str(archive)+'.sha256').write_text(f"{digest(archive)}  {archive.name}\n")
    return {"package":str(output),"zip":str(archive),"zip_sha256":digest(archive),"fixed_export":fixed}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--segment',required=True,choices=('MCX','NSEFO')); p.add_argument('--storage',required=True,type=Path); p.add_argument('--run',required=True)
    p.add_argument('--baseline',required=True,type=Path); p.add_argument('--baseline-run',required=True); p.add_argument('--expiry-map',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path); p.add_argument('--archive',required=True,type=Path); p.add_argument('--log',action='append',type=Path,default=[]); p.add_argument('--workorder',action='append',type=Path,default=[])
    print(json.dumps(build(p.parse_args(argv)),indent=2))

if __name__=='__main__': main()
