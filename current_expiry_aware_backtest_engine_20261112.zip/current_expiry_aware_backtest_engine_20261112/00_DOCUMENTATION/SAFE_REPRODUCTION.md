# Reproduction and safe operation

Run from repository root with `PYTHONPATH=.`. Use a fresh SQLite path for a new run. For a paused run, verify no replay process is active, then invoke the runner's `resume RUN_ID --storage PATH --workers N` once. Do not manually edit, vacuum, move, overwrite, or run concurrent writers against a replay database.

The completed run configuration and exact source/database/map hashes are in `04_RUN_EVIDENCE`. The expiry-map collectors and merger are in `01_ENGINE_SOURCE`; their output must remain separately status-labelled and never be silently promoted to official verification.
