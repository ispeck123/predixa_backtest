# Current audit/backtest engine — submission documentation

## Scope

This package is a source and evidence snapshot of the **research-only** FYERS continuous-series backtest engine used for the completed MCX and NSEFO expiry-aware replays. It contains no market OHLC files, credentials, live/paper order code configuration, or SQLite databases. Source database paths and SHA-256 values are recorded in `04_RUN_EVIDENCE`.

## Architecture

1. The MCX/NSEFO runners generate one canonical continuous-source task per symbol, TF, and evaluation timestamp.
2. `ResultWriter` is the single SQLite writer; process workers never write SQLite directly.
3. `ExpirySessionControlMap` resolves same-day observed NEAR contract expiry from the separate bhavcopy map. Filename dates are not used as historical expiry metadata.
4. Research-only controls enforce no entry on/after expiry-minus-five observed sessions and a realized `TIME_EXIT` at expiry-minus-three. MCX also excludes E1 seam crossings.
5. The research gate bypass is contained in the audit adapter. Live/paper policy continues through `tf_regime_gate_by_exchange.py` and cannot use the bypass path.
6. Fixed exports preserve unresolved/blocked rows and expose realized `gross_r` separately from peak/MFE fields.

## Completed runs

| Exchange | Run ID | Status | Tasks (completed/failed) | Expiry-map status |
|---|---|---|---:|---|
| MCX | `fb7f4c2bef4743cb91b278fcb4c7b7a0` | `COMPLETED` | 136,397/957 | Mirror of MCX bhavcopy, pending official validation |
| NSEFO | `6737d85be9b94e0682d71adc646b692d` | `COMPLETED` | 239,777/5,803 | Official NSE source, pending owner verification |

## Verification and execution model

- Inputs are read-only; the engine does not rewrite OHLC.
- Completed rows survive interruption. Official `resume` reclaims stale RUNNING tasks only; never run a second writer against the same database.
- Completion is checked by terminal task counts and SQLite `integrity_check`.
- Focused unit tests under `02_TESTS` cover expiry-session subtraction, exclusive entry cutoff, TIME_EXIT, fixed export schema, read-only filters, historical expiry lookup, and replay-window boundaries.

## Known limits

- Results are BUY-only gross-R research simulation, not cash P&L after brokerage, exchange charges, slippage, or position aggregation.
- FYERS source containers are treated as observed NEAR slot only for this research mechanism; this assumption is persisted in each run configuration.
- MCX expiry observations are provisional mirror evidence; NSEFO observations await owner verification.
- Warm-up and malformed-source failures remain in evidence and are never converted into trades.
- This package does not grant live/paper promotion to any strategy cell.
