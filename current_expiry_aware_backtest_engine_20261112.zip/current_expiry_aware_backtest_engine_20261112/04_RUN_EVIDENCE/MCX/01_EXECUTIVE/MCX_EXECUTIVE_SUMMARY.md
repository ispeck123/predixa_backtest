# MCX expiry-aware research submission

Run `fb7f4c2bef4743cb91b278fcb4c7b7a0` is **COMPLETED**; SQLite integrity and quick checks are `ok` and `ok`.

| Metric | Expiry-aware | Unfiltered baseline |
|---|---:|---:|
| Realized trades | 6,328 | 37,482 |
| Gross realized R | -4,143.906942 | -754.045300 |
| Profit factor | 0.280821 | 0.973497 |
| Win rate | 8.9444% | 24.0942% |

The gross-R change is `-3,389.861642R`. MCX map is a documented bhavcopy mirror pending official validation.

This is a BUY-only, research-gate-bypass continuous-series measurement. It is not live/paper approval and does not represent net cash P&L, costs, or slippage.
