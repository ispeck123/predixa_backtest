# Findings and implementation evidence

## Applied research controls

- FYERS continuous container treated as observed NEAR slot, explicitly recorded in the run configuration.
- Segment identity: observed NEAR contract identifier.
- No entry on/after expiry-minus-five observed trading sessions.
- Mandatory expiry-minus-three `TIME_EXIT`, with realized `gross_r` retained in the fixed export.
- MCX only: exclusion of trades crossing the 23:30→09:00 E1 seam.

## Results

- Compliance: zero cutoff violations, zero post-force-exit trades, and zero duplicate trade setups.
- TIME_EXIT trades: 0.
- Terminal failed tasks are retained in `03_METRICS/failure_summary.csv`; they are primarily E-timeframe warm-up limits and isolated malformed-source cases.
- The earlier unfiltered baseline is immutable and is compared, not overwritten.

## Limits

MCX map is a documented bhavcopy mirror pending official validation. No current filename expiry was used as a historical expiry. Source OHLC and all SQLite databases were read-only during package generation.
