from audit.derivatives_backtest_common.historical_expiry import get_historical_expiry


def test_verified_slot_record_resolves_only_inside_its_historical_interval():
    rows = [{
        "exchange": "NSEFO", "symbol": "ABC", "instrument_type": "FUTSTK", "contract_slot": "NEAR",
        "contract_identifier": "ABC24OCTFUT", "expiry_date": "2024-10-31",
        "active_from": "2024-09-27", "active_to": "2024-10-31 15:30:00",
        "source_name": "NSE bhavcopy", "source_file": "fo01OCT2024", "verification_status": "OFFICIAL_VERIFIED",
    }]
    hit = get_historical_expiry(rows, "NSEFO", "ABC", "2024-10-01 09:15:00", "NEAR", "FUTSTK")
    assert hit.status == "OFFICIAL_VERIFIED"
    assert hit.historical_expiry_date == "2024-10-31"
    assert hit.historical_contract_identifier == "ABC24OCTFUT"
    miss = get_historical_expiry(rows, "NSEFO", "ABC", "2024-11-01", "NEAR", "FUTSTK")
    assert miss.status == "MISSING_EVIDENCE"


def test_pending_filename_label_cannot_resolve_historical_slot():
    rows = [{
        "exchange": "MCX", "symbol": "GOLDM", "instrument_type": "FUTCOM", "contract_slot": "NEAR",
        "contract_identifier": "", "expiry_date": "2026-12-04", "active_from": "2023-01-01", "active_to": "2026-12-04",
        "source_name": "filename", "source_file": "GOLDM_04122026_daily.csv",
        "verification_status": "FILENAME_EXTRACTED_PENDING_OWNER_VERIFICATION",
    }]
    result = get_historical_expiry(rows, "MCX", "GOLDM", "2024-01-15", "NEAR", "FUTCOM")
    assert result.status == "MISSING_EVIDENCE"
    assert result.historical_expiry_date is None


def test_overlapping_verified_slot_records_are_reported_not_arbitrarily_selected():
    rows = [
        {"exchange": "MCX", "symbol": "GOLDM", "instrument_type": "FUTCOM", "contract_slot": "NEAR", "expiry_date": "2024-01-05", "active_from": "2023-12-01", "active_to": "2024-01-05", "verification_status": "OFFICIAL_VERIFIED"},
        {"exchange": "MCX", "symbol": "GOLDM", "instrument_type": "FUTCOM", "contract_slot": "NEAR", "expiry_date": "2024-02-05", "active_from": "2023-12-15", "active_to": "2024-02-05", "verification_status": "OFFICIAL_VERIFIED"},
    ]
    result = get_historical_expiry(rows, "MCX", "GOLDM", "2023-12-20", "NEAR", "FUTCOM")
    assert result.status == "CONFLICT_REQUIRES_REVIEW"
