import pandas as pd

from audit.futures_trend_backtest.run_futures_backtest import _resolve


def test_resolution_never_uses_bar_after_declared_replay_end():
    bars = pd.DataFrame({
        "timestamp": pd.to_datetime(["2026-08-01 09:15", "2026-08-02 09:15", "2026-10-01 09:15"]),
        "low": [99.0, 99.0, 99.0],
        "high": [99.5, 99.5, 105.0],
    })
    candidate = {"scan_timestamp": "2026-08-01 09:15", "entry": 100.0, "stop": 95.0, "target": 104.0}
    result = _resolve("BUY", candidate, bars, "2026-08-31")
    assert result["outcome"] == "UNFILLED"
    assert result["entry_timestamp"] is None


def test_resolution_uses_future_bar_inside_declared_replay_window():
    bars = pd.DataFrame({
        "timestamp": pd.to_datetime(["2026-08-01 09:15", "2026-08-02 09:15"]),
        "low": [99.0, 99.0], "high": [99.5, 105.0],
    })
    candidate = {"scan_timestamp": "2026-08-01 09:15", "entry": 100.0, "stop": 95.0, "target": 104.0}
    result = _resolve("BUY", candidate, bars, "2026-08-02")
    assert result["outcome"] == "WIN"
    assert result["entry_timestamp"] == "2026-08-02T09:15:00"
