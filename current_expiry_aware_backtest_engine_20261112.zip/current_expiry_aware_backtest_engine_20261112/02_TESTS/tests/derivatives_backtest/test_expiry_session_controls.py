from __future__ import annotations

import pandas as pd

from audit.derivatives_backtest_common.expiry_session_controls import ExpirySessionControlMap
from audit.futures_trend_backtest.run_futures_backtest import _resolve


def _map(tmp_path):
    days = ["2026-01-02", "2026-01-05", "2026-01-06", "2026-01-07", "2026-01-08", "2026-01-09", "2026-01-12"]
    rows = [{
        "exchange": "MCX", "symbol": "TEST", "contract_slot": "NEAR",
        "expiry_date": "2026-01-12", "contract_identifier": "FUTCOM:TEST:12JAN2026",
        "active_from": f"{day}T09:00:00+05:30",
        "verification_status": "MIRROR_OF_MCX_BHAVCOPY_PENDING_OFFICIAL_VALIDATION",
    } for day in days]
    path = tmp_path / "map.csv"
    pd.DataFrame(rows).to_csv(path, index=False)
    return ExpirySessionControlMap.load(path, "MCX", ("TEST",), {"MIRROR_OF_MCX_BHAVCOPY_PENDING_OFFICIAL_VALIDATION"})


def test_map_uses_observed_sessions_and_contract_identifier_segment(tmp_path):
    controls = _map(tmp_path)
    control = controls.control("TEST", "2026-01-06 10:00", exclude_e1_gap=True)
    assert control["segment_id"] == "FUTCOM:TEST:12JAN2026"
    assert control["entry_cutoff_date"] == "2026-01-05"
    assert control["force_exit_date"] == "2026-01-07"
    assert control["exclude_e1_gap"] is True


def test_entry_cutoff_is_exclusive_and_time_exit_is_realized():
    candidate = {"scan_timestamp": "2026-01-02 09:00", "entry": 100.0, "stop": 95.0, "target": 110.0}
    bars = pd.DataFrame({
        "timestamp": pd.to_datetime(["2026-01-02 10:00", "2026-01-05 10:00", "2026-01-07 10:00"]),
        "open": [100.0, 100.0, 102.0], "high": [101.0, 101.0, 103.0],
        "low": [99.0, 99.0, 99.0], "close": [100.0, 100.0, 102.0],
    })
    control = {"entry_cutoff_date": "2026-01-05", "force_exit_date": "2026-01-07", "exclude_e1_gap": False}
    result = _resolve("BUY", candidate, bars, expiry_control=control)
    assert result["outcome"] == "TIME_EXIT"
    assert result["exit_price"] == 102.0

    late = _resolve("BUY", {**candidate, "scan_timestamp": "2026-01-02 10:00"}, bars, expiry_control=control)
    assert late["outcome"] == "UNFILLED"
    assert late["blocked_reason"] == "entry_window_closed"
