import io
import zipfile
from datetime import date

from audit.derivatives_backtest_common.nsefo_official_expiry_history import parse_bhavcopy


def test_official_bhavcopy_assigns_observed_future_slots_without_calendar_formula():
    csv = """TradDt,FinInstrmTp,TckrSymb,XpryDt,FinInstrmNm\n2024-10-03,STF,ABC,2024-10-31,ABC24OCTFUT\n2024-10-03,STF,ABC,2024-11-28,ABC24NOVFUT\n2024-10-03,STF,ABC,2024-12-26,ABC24DECFUT\n"""
    raw = io.BytesIO()
    with zipfile.ZipFile(raw, "w") as archive:
        archive.writestr("BhavCopy_NSE_FO_0_0_0_20241003_F_0000.csv", csv)
    rows, count = parse_bhavcopy(raw.getvalue(), date(2024, 10, 3), {"ABC"})
    assert count == 3
    assert [(row["contract_slot"], row["expiry_date"]) for row in rows] == [
        ("NEAR", "2024-10-31"), ("NEXT", "2024-11-28"), ("FAR", "2024-12-26"),
    ]
    assert {row["verification_status"] for row in rows} == {"OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER"}
