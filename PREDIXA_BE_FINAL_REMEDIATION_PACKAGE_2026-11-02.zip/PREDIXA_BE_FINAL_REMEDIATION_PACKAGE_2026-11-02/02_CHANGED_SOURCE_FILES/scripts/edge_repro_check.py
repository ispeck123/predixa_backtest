#!/usr/bin/env python3
"""
PREDIXA — edge-reproduction check (evidence guardrail).

The companion to the BE-drop verifier. The verifier checks the gate is *wired*
right (code regressions). THIS checks the gate is *pointed at a real edge*: for
each cell the gate treats as live, it recomputes REALIZED expectancy from the
raw trade export — net-of-cost, with win-rate and IS/OOS — and flags any live
cell that does not reproduce as a positive realized edge.

WHY THIS EXISTS: the MCX GOLD+CRUDE cells were populated from a finding doc whose
"+1.14R OOS" tracked PEAK favorable excursion, not what the exits realized; on
realized R the cells are OOS-negative (SW/SW/4: 6.6% win, -0.70R). Reading a
derived finding instead of the raw trades is the failure this tool prevents.
No cell backs real capital unless it reproduces here on realized R.

Realized R = gross_r from the export (verified = (exit-entry)/(entry-stop): a win
books its target R, a loss books -1). Net = gross_r - cost_in_R, cost_in_R =
round_trip_pct * entry / |entry-stop|.

Usage:
  python3 edge_repro_check.py <trade_export.csv> --segment NSE_CASH|NSEFO|MCX \
        --rt <round_trip_pct eg 0.0013> --split YYYY-MM-DD [--universe GOLDM,CRUDEOILM]
"""
from __future__ import annotations
import csv, sys, argparse, statistics as st
from pathlib import Path

# Support the documented standalone invocation from the repository root as
# well as module imports from release_preflight.  Without this bootstrap,
# ``python scripts/edge_repro_check.py`` resolves ``scripts`` relative to the
# script directory and exits before it can issue its intentional fail-closed
# validation verdict.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE

def live_cells(segment: str) -> dict:
    """Read the exact active gate schedule; never maintain a stale duplicate."""
    cfg = TF_REGIME_GATE.get(str(segment or "").upper())
    return dict(cfg.permit_cells) if cfg is not None else {}

def col(row, *cands):
    for c in cands:
        if c in row: return row[c]
    return None
def ff(x):
    try: return float(x)
    except: return None

def load(path, universe):
    rows=[]
    with open(path, encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        fields=set(reader.fieldnames or ())
        required_groups={
            "outcome": {"outcome"}, "symbol": {"symbol", "stock", "stock_name"},
            "entry": {"entry_price", "entry"}, "stop": {"stop_price", "stop"},
            "realized R": {"gross_r"}, "timestamp": {"setup_timestamp"},
            "E regime": {"E_regime", "e_regime"}, "A regime": {"A_regime", "a_regime"},
            "strategy TF": {"strategy_tf", "time_frame", "tf"},
        }
        missing=[name for name, choices in required_groups.items() if not (fields & choices)]
        if missing:
            raise ValueError("unsupported trade-export schema; missing " + ", ".join(missing))
        for r in reader:
            if (col(r,"side") or "BUY") != "BUY": continue
            oc=col(r,"outcome")
            if oc not in ("WIN","LOSS"): continue
            sym=(col(r,"symbol","stock","stock_name") or "").split("@")[0]
            if universe and sym not in universe: continue
            e=ff(col(r,"entry_price","entry")); s=ff(col(r,"stop_price","stop")); g=ff(col(r,"gross_r"))
            if None in (e,s,g) or (e-s)==0: continue
            cell=(col(r,"E_regime","e_regime"), col(r,"A_regime","a_regime"),
                  str(col(r,"strategy_tf","time_frame","tf")))
            try: cell=(cell[0],cell[1],int(float(cell[2])))
            except: continue
            rows.append(dict(cell=cell, oc=oc, g=g, e=e, s=s,
                             d=(col(r,"setup_timestamp") or "")[:10],
                             peak=ff(col(r,"mfe_R"))))
    return rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("export"); ap.add_argument("--segment", required=True)
    ap.add_argument("--rt", type=float, required=True, help="round-trip cost fraction, e.g. 0.0013")
    ap.add_argument("--split", required=True, help="IS/OOS boundary date YYYY-MM-DD")
    ap.add_argument("--universe", default=None, help="comma symbols to scope (e.g. GOLDM,CRUDEOILM)")
    a=ap.parse_args()
    uni=set(a.universe.split(",")) if a.universe else None
    try:
        rows=load(a.export, uni)
    except (OSError, ValueError) as exc:
        print(f"VERDICT: EVIDENCE INVALID — FAIL CLOSED: {exc}")
        return 2
    live=live_cells(a.segment)
    if not live:
        print("VERDICT: NO LIVE-ELIGIBLE CELLS — FAIL CLOSED")
        print("No finding may be promoted without an explicitly scoped realized-R OOS reproduction.")
        return 1
    mean=lambda x: sum(x)/len(x) if x else float("nan")
    def netvals(cell, part):
        out=[]; peak=[]
        for r in rows:
            if r["cell"]!=cell: continue
            if part=="IS" and not (r["d"]<a.split): continue
            if part=="OOS" and not (r["d"]>=a.split): continue
            out.append(r["g"] - a.rt*r["e"]/abs(r["e"]-r["s"]))
            if r["peak"] is not None: peak.append(r["peak"])
        return out, peak
    def wr(cell, part):
        c=[r for r in rows if r["cell"]==cell and ((part=="OOS")==(r["d"]>=a.split))]
        return 100*sum(1 for r in c if r["oc"]=="WIN")/len(c) if c else float("nan")

    print("="*86)
    print(f"EDGE-REPRODUCTION CHECK — segment {a.segment} — export {a.export}")
    print(f"realized R, net-of-cost (RT {a.rt*100:.3f}%), IS/OOS split {a.split}"
          + (f", universe {sorted(uni)}" if uni else ""))
    print("="*86)
    print(f"{'cell':13}{'tier':9}{'n_OOS':>6}{'win%':>7}{'IS netR':>9}{'OOS netR':>10}{'OOSpeak':>9}  verdict")
    fails=[]
    for cell,tier in live.items():
        isv,_=netvals(cell,"IS"); oosv,oospk=netvals(cell,"OOS")
        o=mean(oosv); i=mean(isv); w=wr(cell,"OOS"); pk=mean(oospk) if oospk else float("nan")
        v="REPRODUCES" if o>0 else "DOES NOT REPRODUCE"
        tag=""
        if o<=0 and not (pk!=pk) and pk>0.3: tag=" [positive only on PEAK excursion, not realized]"
        if o<=0: fails.append((cell,tier,o,w,pk))
        elif i>0 and o>0 and (i-o)>0.5: tag=" [IS≫OOS — watch overfit]"
        ck=f"{cell[0]}/{cell[1]}/{cell[2]}"
        print(f"{ck:13}{tier:9}{len(oosv):>6}{w:>6.1f}%{i:>9.3f}{o:>10.3f}{pk:>9.3f}  {v}{tag}")
    print("="*86)
    if fails:
        print(f"VERDICT: SEGMENT EDGE DOES NOT REPRODUCE — {len(fails)} live cell(s) OOS-nonpositive on realized R:")
        for cell,tier,o,w,pk in fails:
            extra = f"; peak {pk:+.2f}R (give-back)" if (pk==pk and pk>0.3) else ""
            print(f"  {cell[0]}/{cell[1]}/{cell[2]} ({tier}): OOS {o:+.3f}R, {w:.1f}% win{extra}")
        print("  -> these cells MUST NOT back real capital until they reproduce positive realized R.")
        rc=1
    else:
        print("VERDICT: all live cells reproduce a positive realized-R edge OOS.")
        rc=0
    print("-"*86)
    print("Validates the EDGE behind the gate cells on REALIZED R (what exits bank) — not peak")
    print("excursion, not a finding doc. Complements the code verifier (which checks wiring only).")
    print("No cell backs real capital unless it reproduces here. Clean data is the caller's duty")
    print("(contaminated series — roll/stitch/session-gap — invalidate the read in either direction).")
    return rc

if __name__=="__main__":
    sys.exit(main())
