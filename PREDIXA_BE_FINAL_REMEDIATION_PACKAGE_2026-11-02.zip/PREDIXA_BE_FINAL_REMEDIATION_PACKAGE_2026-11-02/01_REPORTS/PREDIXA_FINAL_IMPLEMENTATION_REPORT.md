# PREDIXA Final Implementation Report — 02 November 2026

## Scope and decision

This report closes repository-owned remediation under the 31 October 2026 work
order and the owner-approved NSE_CASH reduction. No deployment, service restart,
scanner launch, paper/live order, broker API call, or production access occurred.

- Repository remediation: **READY_FOR_APPROVAL**
- MCX safety deployment: **READY_FOR_APPROVAL** (subject to protected baseline,
  release review, and production operator checks)
- NSE_CASH approved reduction: **COMPLETED** in the repository
- External baseline/CI enforcement: **PENDING_EXTERNAL_ACTION**
- Production deployment: **NOT_DEPLOYED**
- MCX trading reactivation: **BLOCKED_MISSING_DATA** and **NOT READY**

Base revision reviewed: `5dba8231f0b3bb3b9dfc03ba037126f16d6aabba` on `prod`.
The worktree was already dirty; this package identifies remediation scope and
does not represent unrelated changes as part of this release.

## Seven-row remediation closure

| # | Work item | Previous status | Final status | Change | Validation evidence | Remaining dependency |
|---|---|---|---|---|---|---|
| 1 | MCX regime gate | COMPLETED | COMPLETED | Empty MCX allowlist plus early normalized deny | Alias/malformed regression coverage; 36 focused tests | Controlled release only |
| 2 | MCX allocator | COMPLETED | COMPLETED | `SEGMENT_NET_R["MCX"] = -0.18` remains independently blocking | Allocator regression and verifier C2 | None in repository |
| 3 | MCX scanner hold | COMPLETED | COMPLETED | Primary, legacy/Dagster, persistence, PAPER/REAL bucket and generic `MCX:` entry boundaries remain held | Scanner/bucket/API mocked regressions; verifier C12 | Runtime scheduler/process review |
| 4 | Clean-series revalidation | BLOCKED_MISSING_DATA | BLOCKED_MISSING_DATA | No synthetic clean series or trade export created | Inventory identifies 216 stitched/continuous sources | Raw dated contracts, rolls, adjustment and execution provenance, E1/export inputs |
| 5 | Phase-A root cause | BLOCKED_MISSING_ARTIFACT | BLOCKED_MISSING_ARTIFACT | Schema-confirmation tool fails closed; no unsupported attribution made | Candidate CSV rejected; source inspection found no proven MFE misaggregation | Original export, run ID, publishing analysis artifact |
| 6 | NSE_CASH four-cell review | PENDING_OWNER_APPROVAL | COMPLETED | Removed `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, `UP/UP/25`; candidate baseline reduced | Four DENY assertions; retained cash/NSEFO assertions; 36 tests | Protected external candidate-baseline publication |
| 7 | Validation guardrails | PARTIALLY_COMPLETED | PARTIALLY_COMPLETED | External baseline required; strict `reduction` mode added; promotion active-gate equivalence tightened | C1-C12 PASS; preflight PASS; missing inputs fail closed | External CI/deployment must enforce nonzero exit |

## Implemented controls

| Path | Relevant control | Final behavior |
|---|---|---|
| `scripts/tf_regime_gate_by_exchange.py` | `TF_REGIME_GATE`, `gate()` | MCX always denies; four approved cash cells now deny; retained cash/NSEFO permissions unchanged. |
| `scripts/position_sizing.py` | `SEGMENT_NET_R`, `CapitalAllocator.segment_status()` | MCX is `-0.18` and `BLOCKED`. |
| `scripts/graduated_live_config.py` | MCX execution hold | Code-controlled, non-environment override hold remains active. |
| `scripts/mcx_graduated_live_scanner.py`, `scripts/scanner_fc.py` | scanner entry points | Block before engine, signal/persistence, or execution. |
| `apps/pipelines/stock_process.py` | Dagster MCX job/schedule | Repository schedule is registered with `DefaultScheduleStatus.STOPPED`; its invoked scanner remains independently held. |
| `apps/backend/api/bucket_orders_commodity.py`, `apps/backend/api/commodity_orders.py`, `apps/backend/api/fyers_order_management.py` | commodity/PAPER/REAL/API boundaries | New MCX entries block before database/broker work; cancellation/exits remain available for exposure reduction. |
| `scripts/release_preflight.py` | safety/reduction/promotion contract | Safety requires external approved baseline; reduction requires prior/candidate external baselines and strict removal; promotion additionally needs realized-`gross_r` evidence. |

## Permission-baseline publication procedure

1. Release governance verifies hashes and reviews
   `config/predixa_release_permission_baseline_candidate_2026-11-02.json`.
2. A release authority (separate from the code author) copies that exact content
   into the protected external approval location and records its revision/hash.
3. Keep `config/predixa_release_permission_baseline_pre_nse_cash_approval.json`
   available as the historical predecessor; do not overwrite it.
4. The external release workflow invokes:

```bash
<python> scripts/release_preflight.py --mode reduction \
  --previous-approved-baseline <protected-previous-baseline> \
  --approved-baseline <protected-candidate-baseline> \
  --python <python> --report-dir <release-evidence-directory>
```

Any nonzero status blocks deployment. A copied file outside the checkout proves
only the interface during local testing; it is not independent approval.

## Actual validation

| Command | Exit/result |
|---|---|
| `.../python -m pytest -q tests/test_release_preflight.py tests/test_tf_regime_gate_by_exchange.py tests/test_mcx_remediation_guardrails.py tests/test_commodity_bucket_approval.py tests/test_mcx_golive_policy.py` | `0`; **36 passed**, 7 dependency warnings |
| `.../python scripts/release_preflight.py --mode reduction --approved-baseline <temporary candidate> --previous-approved-baseline <temporary predecessor> ...` | `0`; C1-C12 PASS, then 36 focused tests PASS |
| `.../python -m py_compile` over all remediation Python files | `0` |
| `release_preflight.py --mode safety` without `--approved-baseline` | `2`; expected fail closed |
| `release_preflight.py --mode promotion` without required approval/evidence | nonzero expected fail closed |
| `git diff --check` scoped to final remediation paths | Existing unrelated trailing whitespace in `apps/backend/api/bucket_orders_commodity.py:562,605`; not altered in this work |

The drop verifier's existing `CLEAR FOR PAPER` wording is a regression-verifier
verdict only; it does not authorize MCX PAPER or REAL operation. MCX remains
blocked at every repository-owned boundary.

## MCX quantitative and production blockers

MCX cannot be reactivated without verified dated contract data, deterministic
roll dates/prices and back-adjustment methodology, E1-enforced construction,
executable-price provenance, realized-R export with OOS partition, an actual
`edge_repro_check.py` PASS, and separate activation authorization. The 216
available files are stitched/continuous, not verified dated-contract history.

Before deployment, a production operator must record deployed revision/image,
run the release preflight with the protected baseline, inspect runtime entry
points/schedules/processes, and reconcile broker-side MCX pending orders/GTTs
using approved read-only broker tools. Application holds do not cancel existing
broker orders. Never roll back to an older MCX-enabled revision; recovery must
be a forward fix retaining the hold (or an independently verified operational
hold covering every old path).
