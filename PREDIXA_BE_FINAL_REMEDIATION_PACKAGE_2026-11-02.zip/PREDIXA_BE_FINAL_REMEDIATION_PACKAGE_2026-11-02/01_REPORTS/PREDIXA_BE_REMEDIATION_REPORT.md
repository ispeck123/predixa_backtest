# PREDIXA BE Remediation Report — 31 October 2026 Work Order

Run timestamp: 2026-11-02T12:03:29+05:30. Repository branch: `prod`.

## Scope and repository assessment

The worktree was already dirty before this remediation, including all three target
execution files and unrelated API, ingestion, database, scanner, test, generated
output, and research changes. No reset, checkout, deletion, historical-data
overwrite, scanner launch, paper order, live order, or deployment was performed.

The repository owns the MCX scanner and its Dagster pipeline entry point
(`apps/pipelines/stock_process.py`), but it does not expose deployed process,
container, scheduler, or broker-account state. Repository configuration is therefore
not proof of deployed configuration.

The named `mcx_trade_export.csv` was not found. The closest candidate is
`audit/mcx_futures_backtest/results/mcx_phase_a_available_history/mcx_fut_regime_tf_backtest_labeled.csv`
(SHA-256 `cfaf3b7d3f756756a3a84a55dfeb90544dee38697090cd9fe7bbf8f664cd116d`).
It is not the required confirmation export: it lacks `partition`, `mfe_R`,
`symbol`, `E_regime`, and `A_regime` under the required names. It cannot establish
the claimed result.

| # | Work item | Previous state | Action taken | New state | Test evidence | Status | Remaining dependency |
|---|---|---|---|---|---|---|---|
| 1 | MCX regime gate mandatory deny | Empty allowlist existed, but invalid MCX TF could reach a fail-open branch | Added an early MCX deny before parsing/scoping | Every configured MCX request, including aliases and malformed inputs, denies | 7 focused tests pass | COMPLETED | Release authorization is still required before any future change |
| 2 | MCX capital allocator block | `SEGMENT_NET_R[MCX]` was `0.41` and allocator could be ACTIVE | Set it to `-0.18`; verifier expects a negative hold value | `CapitalAllocator.segment_status("MCX") == "BLOCKED"` | Focused allocator test and drop verifier C2 pass | COMPLETED | None for repository control |
| 3 | MCX scanner operational hold | PAPER/REAL paths could invoke engine/persistence | Added non-environment-overridable hold ahead of engine invocation | PAPER and REAL jobs emit `MCX_EXECUTION_BLOCKED`; no engine/signal/persistence calls | Focused mocked scanner test passes | COMPLETED | Disable any external scheduler/deployment not controlled by this repository |
| 4 | Clean-series MCX revalidation | Available Phase-A method uses stitched/continuous sources; roll attribution is explicitly inferred | Investigated only; no fabricated export or backtest run | MCX remains blocked; no replacement export generated | Preflight found 216 sources, all `STITCHED_OR_CONTINUOUS` | BLOCKED_MISSING_DATA | Verified historical contract OHLC, roll dates/prices/rules, adjustment specification, and export-compatible provenance |
| 5 | Peak vs realized root-cause confirmation | Confirmation utility could print a conclusion even when input contained zero qualifying rows | Made its schema/no-row behavior fail closed | Candidate artifact is rejected as incompatible; no exact Phase-A MFE aggregation defect identified | Confirmation exits 2 with missing required columns | BLOCKED_MISSING_ARTIFACT | Original `mcx_trade_export.csv`, Phase-A run ID, and script/notebook that published the claim |
| 6 | NSE_CASH four-cell review | All four cells were permitted with pending-review annotations | Owner approval received; removed only `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and `UP/UP/25`; created predecessor/candidate baselines | Four cells deny; retained cash/NSEFO permissions unchanged | Focused retained/removed-cell regression coverage; 36 tests pass | COMPLETED | Protected external candidate-baseline publication before deployment |
| 7 | Permanent validation guardrails | Verifiers still modeled withdrawn MCX cells as live | Updated MCX verifier schedules to fail closed and made drop-report output directory creation reliable | Drop verifier passes current known controls; edge checker rejects empty MCX schedule | Drop verifier exit 0; edge checker exit 1 (expected fail closed) | PARTIALLY_COMPLETED | No CI/release pipeline found; release process must run commands below |

## Source changes

| File | Change and reason | Regression evidence |
|---|---|---|
| `scripts/tf_regime_gate_by_exchange.py` | Early exact-`MCX` operational deny prevents all MCX cells, aliases, missing values, and malformed TF values from reaching generic fail-open code. Existing NSEFO/NSE_CASH tables were not changed. | Gate tests pass. |
| `scripts/position_sizing.py` | Changed only MCX net R from `0.41` to `-0.18`; existing allocator logic then blocks real allocation. | Allocator test and verifier C2 pass. |
| `scripts/graduated_live_config.py` | Added a deliberate, non-environment-configurable MCX execution suspension helper. | Scanner hold test passes. |
| `scripts/mcx_graduated_live_scanner.py` | Checks the hold before invoking the engine, market data, signal insertion, or persistence; writes auditable blocked records only. | Mocked PAPER and REAL jobs make no side-effect calls. |
| `scripts/edge_repro_check.py` | Removed hard-coded MCX live cells; an empty MCX approval schedule exits nonzero rather than passing vacuously. | MCX invocation exits 1 with `NO LIVE-ELIGIBLE CELLS — FAIL CLOSED`. |
| `scripts/predixa_drop_verifier.py` | Validates negative MCX allocator value and empty MCX permit set; creates its requested report directory. | C1–C11 pass; reports written to `/tmp/predixa-remediation-drop-verifier/`. |
| `scripts/confirm_peak_vs_realized.py` | Requires the documented Phase-A export schema and exits nonzero for missing data/no qualifying cells; it no longer makes an unsupported conclusion. | Candidate export rejected with exit 2. |
| `tests/test_tf_regime_gate_by_exchange.py` | Updated stale MCX-positive expectations to deny. | Included in 7 passing tests. |
| `tests/test_mcx_remediation_guardrails.py` | Added focused MCX gate, allocator, and scanner-hold regression coverage. | 3 tests pass. |
| `audit/proposed_nse_cash_gate_removal.patch` | Unapplied, minimal proposal removing only `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and `UP/UP/25`. | Review artifact only; active gate unchanged. |

The identifiable 2026-11-02 gate backup has SHA-256
`f2bad45acfaa27ed2d4271ab6c2e7046c7148cb20dc95219d1f0d90496d95608`,
which differs from the active gate. It was not a supplied replacement artifact
with verifiable provenance, so it was not deployed verbatim. The active gate
already had `MCX.permit_cells = {}`; this remediation made its MCX behavior
unambiguously fail closed.

## MCX Phase-A assessment

The available Phase-A analysis implementation is
`audit/derivatives_backtest_common/analyze_phase_a.py:9`. Its aggregation is
`avg_r=('gross_r','mean')`, not `mfe_R`; the repository search found no available
Phase-A script/notebook that aggregates MFE as realized expectancy. Consequently,
the exact alleged bug location, affected publication list, and Phase-A run ID
cannot be truthfully supplied from repository evidence.

The closest Phase-A method is explicitly a stitched-series method:
`audit/mcx_futures_backtest/PHASE_A_METHOD.md` says contract attribution is not
verified. `python3 -m audit.mcx_futures_backtest.preflight` reported 216 sources,
all `STITCHED_OR_CONTINUOUS`. The code has E1 support and the method states the
23:30→09:00 IST seam policy, but verified raw-contract continuity, actual roll
dates, roll prices, back-adjustment rules, and executable-price mapping are absent.
No clean-series output was created and no edge is established.

## Verification record

| Command | Result |
|---|---|
| `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q tests/test_tf_regime_gate_by_exchange.py tests/test_mcx_remediation_guardrails.py` | PASS — 7 passed (5 pre-existing dependency deprecation warnings) |
| `python3 -m py_compile scripts/tf_regime_gate_by_exchange.py scripts/position_sizing.py scripts/graduated_live_config.py scripts/mcx_graduated_live_scanner.py scripts/edge_repro_check.py scripts/predixa_drop_verifier.py scripts/confirm_peak_vs_realized.py` | PASS |
| `python3 scripts/predixa_drop_verifier.py . --report-dir /tmp/predixa-remediation-drop-verifier` | PASS — C1–C11 pass; exit 0; reports written |
| `python3 scripts/edge_repro_check.py audit/mcx_futures_backtest/results/mcx_phase_a_available_history/mcx_fut_regime_tf_backtest_labeled.csv --segment MCX --rt 0.001 --split 2026-01-01 --universe GOLDM,CRUDEOILM` | FAIL CLOSED — exit 1: no live-eligible MCX cells |
| `python3 scripts/confirm_peak_vs_realized.py audit/mcx_futures_backtest/results/mcx_phase_a_available_history/mcx_fut_regime_tf_backtest_labeled.csv` | BLOCKED — exit 2: missing required export columns |
| `python3 -m audit.mcx_futures_backtest.preflight` | PASS as inventory only; confirms stitched/continuous source limitation |

No automated release pipeline was found. Mandatory release preflight is:

```bash
python3 scripts/predixa_drop_verifier.py . --report-dir /path/to/release-evidence
python3 scripts/edge_repro_check.py /verified/new_trade_export.csv --segment <segment> --rt <round_trip_cost> --split <oos_date> [--universe ...]
```

Any nonzero exit, `HOLD`, missing evidence, or MCX empty schedule blocks release/promotion.

## Outstanding decisions and operational status

1. The four cash cells require explicit owner approval before applying
   `audit/proposed_nse_cash_gate_removal.patch`.
2. MCX clean-series revalidation requires verified contract data and roll/E1/execution provenance.
3. MCX re-enablement is prohibited until a verified OOS realized-R reproduction passes and a separate owner authorizes release.
4. Operations must disable/check external MCX schedules, containers, and deployed processes; repository inspection cannot attest to their state.

- MCX REAL: **BLOCKED**.
- MCX PAPER: **BLOCKED**.
- NSE_CASH: **EXISTING CONFIGURATION PRESERVED**.
- NSEFO: **EXISTING CONFIGURATION PRESERVED**.
- Production deployment: **NOT PERFORMED**.

## Phase 2 verification update — 02 November 2026

Phase 2 found and closed two repository-owned MCX bypasses that were outside
the original graduated scanner: the legacy `scripts/scanner_fc.py` commodity
jobs initialized the setup engine before their gate check, and
`approve_existing_commodity_candidate` could submit a pre-existing REAL MCX
bucket. The legacy scanner now returns `MCX_EXECUTION_BLOCKED` before engine
initialization. REAL approval and direct candidate persistence also fail before
database/broker work. Rejection/cancellation remains permitted to reduce
existing exposure. Exchange matching in the regime gate now normalizes case and
whitespace (`" mcx "` also denies).

`edge_repro_check.py` now rejects unsupported evidence schemas before analysis.
The drop verifier gained C12, which checks both scanner paths, direct
persistence, and the commodity approval hold. There remains no repository CI,
release workflow, or deployment hook that invokes either verifier; Task 7
therefore remains `PARTIALLY_COMPLETED`.

Phase 2 focused validation used:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_tf_regime_gate_by_exchange.py tests/test_mcx_remediation_guardrails.py \
  tests/test_commodity_bucket_approval.py tests/test_mcx_golive_policy.py
python3 scripts/predixa_drop_verifier.py . --report-dir /tmp/predixa-phase2-drop-verifier
```

Results: **28 passed** (seven dependency deprecation warnings); drop verifier
C1–C12 passed. The original worktree contains pre-existing unrelated whitespace
errors, so a whole-worktree `git diff --check` exits nonzero; no newly introduced
whitespace issue was identified in Phase 2 files.

## Final safety-handoff update — 02 November 2026

The final audit found and closed a generic broker-API bypass: the generic FYERS
entry endpoints could accept explicit `MCX:` symbols outside scanner and bucket
paths. They now reject those entry requests with `MCX_EXECUTION_BLOCKED` before
risk checks, database work, or broker calls. Cancellation and position-exit
operations remain available for authorized exposure reduction.

The release baseline was also strengthened. A checked-in baseline could have
been changed beside the gate in one unreviewed diff. `release_preflight.py` now
requires an independently supplied `--approved-baseline` outside the checkout;
promotion additionally needs a previous independently supplied baseline and
realized-R evidence. Missing approval fails closed with exit 2. The external
artifact and its write controls remain an operational/CI dependency because no
CI configuration is present in this repository.

Final local validation: **33 focused tests passed**; a safety preflight using a
temporary external test baseline passed C1–C12 plus **33** preflight tests.
See `PREDIXA_MCX_SAFETY_RELEASE_HANDOFF.md` for the operator runbook, package
scope, rollback constraints, and production verification steps. Repository
status is ready for approval only; production deployment remains not performed
and MCX reactivation remains not ready.

## Final approved NSE_CASH closure — 02 November 2026

The owner explicitly approved removal of `SW/UP/2`, `UP/UP/2`, `UP/UP/5`, and
`UP/UP/25`. They were present in `NSE_CASH.permit_cells` and have been removed;
each now reaches the existing `default="DENY"` path. All retained cash cells
(`SW/SW/2,6,25`, `SW/UP/6`, and `UP/SW/2,5`) and the NSEFO schedule are unchanged.
The focused suite is now **36 passed**. The new release-preflight `reduction`
mode requires the previous and candidate external baselines, requires the
active and checked-in gate to equal the candidate, and accepts only strict
permission removals. Promotion remains evidence-gated for any increase.

The checked-in candidate baseline is not independent approval. Its protected
external publication remains `PENDING_EXTERNAL_ACTION`; local validation used
temporary copies solely to prove the interface. MCX clean-series evidence,
production deployment, and MCX activation remain blocked/not performed.

The documented standalone `edge_repro_check.py` invocation was also repaired
to bootstrap the repository import path before validating evidence. It now
reaches its intended nonzero MCX empty-schedule verdict rather than failing at
module import.
