# NSE_CASH permission-reduction approval record

Source: explicit owner authorization in the 02 November 2026 PREDIXA final
approved remediation instruction. This repository record documents scope; it
does not replace the separately protected release-baseline approval artifact.

Approved removals from `NSE_CASH.permit_cells`:

- `SW/UP/2` (`CORE`; recorded OOS realized R `-0.13R`)
- `UP/UP/2` (`CORE`; recorded OOS realized R `-0.05R`)
- `UP/UP/5` (`CORE`; recorded OOS realized R `-0.19R`)
- `UP/UP/25` (`MARGINAL`; recorded OOS realized R `-0.08R`)

No NSEFO or MCX permission increase is authorized. MCX remains an empty,
operationally held gate. The release operator must publish the candidate
baseline through the independently protected approval location and invoke
`scripts/release_preflight.py --mode reduction` with both external baseline
paths before controlled deployment.
