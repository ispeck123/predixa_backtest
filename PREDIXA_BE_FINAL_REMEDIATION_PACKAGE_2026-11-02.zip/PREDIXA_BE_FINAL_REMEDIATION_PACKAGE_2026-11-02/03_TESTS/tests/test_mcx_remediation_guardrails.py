from scripts.position_sizing import CapitalAllocator, PortfolioPolicy, SEGMENTS
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE, gate


def test_mcx_gate_is_fail_closed_for_known_aliases_and_malformed_inputs():
    assert TF_REGIME_GATE["MCX"].permit_cells == {}
    for symbol in ("GOLDM", "GOLD", "GOLDGUINEA", "CRUDE", "CRUDEOILM", None):
        assert gate("MCX", 4, "SW", "SW", symbol)[:2] == ("DENY", 0.0)
    assert gate(" mcx ", 4, "SW", "SW", "GOLDM")[:2] == ("DENY", 0.0)
    assert gate("MCX", "not-a-tf", None, None, "GOLDM")[:2] == ("DENY", 0.0)


def test_mcx_allocator_is_independently_blocked():
    portfolio = PortfolioPolicy(1_000_000, 5, 10, 3, 10)
    assert CapitalAllocator(portfolio, SEGMENTS).segment_status("MCX") == "BLOCKED"


def test_mcx_scanner_hold_does_not_invoke_engine_or_persistence(tmp_path):
    from scripts.mcx_graduated_live_scanner import MCXGraduatedLiveScanner, MCXScanJob
    called = []
    scanner = MCXGraduatedLiveScanner(
        engine=lambda *_: called.append("engine"),
        signal_inserter=lambda *_: called.append("insert"),
        candidate_persister=lambda *_: called.append("persist"),
    )
    records = scanner.run(
        [MCXScanJob("CRUDEOILM", "30102026", 4, [], None, "PAPER"),
         MCXScanJob("GOLDM", "30102026", 4, [], None, "REAL")],
        tmp_path / "mcx-hold.jsonl",
    )
    assert [r["status"] for r in records] == ["MCX_EXECUTION_BLOCKED", "MCX_EXECUTION_BLOCKED"]
    assert called == []


def test_mcx_direct_real_approval_is_blocked_before_db_or_broker_access():
    from fastapi import HTTPException
    from apps.backend.api.bucket_orders_commodity import approve_existing_commodity_candidate

    try:
        approve_existing_commodity_candidate(
            bucket_id=1, status="approved", approved_by="operator",
            session_factory=lambda: (_ for _ in ()).throw(AssertionError("DB accessed")),
        )
    except HTTPException as exc:
        assert exc.status_code == 409
        assert exc.detail == "MCX_EXECUTION_BLOCKED"
    else:
        raise AssertionError("MCX approval unexpectedly reached execution path")


def test_mcx_direct_persistence_is_blocked_before_db_access():
    from scripts.mcx_graduated_live_scanner import MCXScanJob, persist_mcx_candidate

    try:
        persist_mcx_candidate({}, MCXScanJob("GOLDM", "30102026", 4, [], None, "REAL"), None)
    except RuntimeError as exc:
        assert str(exc) == "MCX_EXECUTION_BLOCKED"
    else:
        raise AssertionError("MCX persistence unexpectedly reached database path")


def test_legacy_mcx_scanner_is_blocked_before_engine_initialization(monkeypatch):
    from scripts import scanner_fc

    monkeypatch.setattr(scanner_fc, "process_setup_fc", lambda *_: (_ for _ in ()).throw(
        AssertionError("engine initialized")))
    result = scanner_fc.SetupScannerOrchestrator_FC().run(
        scanner_fc.ScanJob_FC([], 4, None, is_future=False),
    )
    assert result["blocked_reason"] == "MCX_EXECUTION_BLOCKED"


def test_generic_broker_entry_boundary_blocks_mcx_symbols():
    from fastapi import HTTPException
    from apps.backend.api import fyers_order_management as order_api

    assert order_api._is_mcx_symbol(" MCX:CRUDEOILM26NOVFUT ")
    assert not order_api._is_mcx_symbol("NSE:RELIANCE-EQ")
    try:
        order_api._block_mcx_entry("MCX:GOLD26DECFUT")
    except HTTPException as exc:
        assert exc.status_code == 409
        assert exc.detail == "MCX_EXECUTION_BLOCKED"
    else:
        raise AssertionError("generic broker endpoint unexpectedly accepts MCX entry")


def test_edge_repro_checker_is_importable_for_documented_standalone_execution():
    import importlib.util
    from pathlib import Path

    path = Path("scripts/edge_repro_check.py")
    spec = importlib.util.spec_from_file_location("edge_repro_standalone_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    assert module.live_cells("MCX") == {}
