# Change summary

MCX remains denied at gate, allocator, scanner, legacy scanner, commodity bucket, paper bucket, and generic broker-entry boundaries.

The owner-approved NSE_CASH reduction removes SW/UP/2, UP/UP/2, UP/UP/5, and UP/UP/25. The release preflight has a strict reduction mode requiring independently supplied predecessor and candidate baselines. Permission increases continue to require realized-R evidence.

External CI/release integration and protected baseline publication remain operational prerequisites; no production action occurred.
