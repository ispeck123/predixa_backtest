# PREDIXA remediation package

This package contains final remediation source snapshots, focused tests, candidate/predecessor baseline artifacts, reports, patches, and actual local validation output.

It excludes unrelated dirty-worktree files, raw market data, credentials, production logs, virtual environments, and deployment artifacts. A checked-in candidate baseline is not approval; publish it through the protected external release system before deployment.

Validation evidence reflects local repository execution only. Production deployment was not performed and MCX reactivation is not authorized.
