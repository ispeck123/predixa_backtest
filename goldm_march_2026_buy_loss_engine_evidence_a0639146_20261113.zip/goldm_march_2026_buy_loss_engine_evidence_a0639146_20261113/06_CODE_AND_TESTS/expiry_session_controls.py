"""Research-only session-relative expiry controls for continuous futures runs.

This module does not read or alter OHLC data and has no import from a live or
paper execution path.  It turns a point-in-time NEAR observation map into the
control facts needed by the audit replay: contract segment, exclusive entry
cut-off, and mandatory time-exit session.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import pandas as pd


REQUIRED_COLUMNS = {
    "exchange", "symbol", "contract_slot", "expiry_date",
    "contract_identifier", "active_from", "verification_status",
}


class ExpiryControlCoverageError(ValueError):
    """The map lacks future sessions needed to derive a locked control."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class ExpirySessionControlMap:
    """Resolve the observed NEAR contract for each exchange trading date.

    The session list is deliberately derived from the observation map, rather
    than a weekday formula.  This preserves exchange holidays and the actual
    sparse product cycles (for example SILVERM).
    """

    path: Path
    exchange: str
    allowed_statuses: frozenset[str]
    rows: pd.DataFrame
    by_day: dict[tuple[str, str], object]
    sessions: tuple[str, ...]
    digest: str

    @classmethod
    def load(cls, path: Path, exchange: str, symbols: tuple[str, ...],
             allowed_statuses: set[str] | frozenset[str]) -> "ExpirySessionControlMap":
        source = path.resolve()
        if not source.is_file():
            raise FileNotFoundError(f"expiry observation map is unavailable: {source}")
        raw = pd.read_csv(source)
        missing = REQUIRED_COLUMNS - set(raw.columns)
        if missing:
            raise ValueError(f"expiry observation map missing columns: {sorted(missing)}")
        exchange = exchange.upper()
        statuses = frozenset(str(value).upper() for value in allowed_statuses)
        raw = raw[
            raw.exchange.astype(str).str.upper().eq(exchange)
            & raw.symbol.astype(str).str.upper().isin({value.upper() for value in symbols})
            & raw.contract_slot.astype(str).str.upper().eq("NEAR")
        ].copy()
        if raw.empty:
            raise ValueError(f"expiry observation map has no requested {exchange} NEAR rows")
        observed_statuses = set(raw.verification_status.astype(str).str.upper())
        if not observed_statuses <= statuses:
            raise ValueError(
                f"expiry map verification statuses are not permitted for this research run: "
                f"{sorted(observed_statuses - statuses)}"
            )
        raw["symbol"] = raw.symbol.astype(str).str.upper()
        raw["trade_date"] = pd.to_datetime(raw.active_from, errors="coerce").dt.date.astype(str)
        raw["expiry_date"] = pd.to_datetime(raw.expiry_date, errors="coerce").dt.date.astype(str)
        if raw[["trade_date", "expiry_date", "contract_identifier"]].isna().any().any():
            raise ValueError("expiry observation map has an invalid date or missing contract identifier")
        if raw.duplicated(["symbol", "trade_date"]).any():
            raise ValueError("expiry observation map has duplicate same-day NEAR observations")
        raw = raw.sort_values(["symbol", "trade_date"]).reset_index(drop=True)
        by_day = {(row.symbol, row.trade_date): row for row in raw.itertuples(index=False)}
        # Bhavcopy is an exchange-day observation.  Use its complete observed
        # date index for session-relative subtraction, rather than assuming
        # weekdays or grouping a contract label.  This also handles an
        # exchange-issued expiry-date correction without creating a false roll
        # (some NSE identifiers do not encode a unique year/expiry).
        sessions = tuple(sorted(set(raw.trade_date.tolist())))
        return cls(source, exchange, statuses, raw, by_day, sessions, sha256(source))

    def control(self, symbol: str, timestamp: object, *, exclude_e1_gap: bool,
                replay_end: object | None = None) -> dict:
        trade_date = pd.Timestamp(timestamp).date().isoformat()
        row = self.by_day.get((str(symbol).upper(), trade_date))
        if row is None:
            raise KeyError(f"no {self.exchange} NEAR expiry observation for {symbol} on {trade_date}")
        expiry = row.expiry_date
        eligible_sessions = tuple(day for day in self.sessions if day <= expiry)
        if not eligible_sessions or eligible_sessions[-1] < expiry and self.sessions[-1] < expiry:
            end = pd.Timestamp(replay_end).date().isoformat() if replay_end is not None else None
            observed_after_end = [day for day in self.sessions if end and end < day <= expiry]
            # If at least five actual exchange sessions are already observed
            # after the replay boundary, the later final expiry session makes
            # both -5 and -3 necessarily fall
            # outside this replay.  Return an explicit no-op control rather
            # than inventing dates or requiring future metadata.
            if end and expiry > end and len(observed_after_end) >= 5:
                return {
                    "contract_slot": "NEAR", "historical_contract_identifier": row.contract_identifier,
                    "historical_expiry_date": expiry, "segment_id": row.contract_identifier,
                    "entry_cutoff_date": None, "force_exit_date": None,
                    "exclude_e1_gap": bool(exclude_e1_gap), "map_observation_date": trade_date,
                    "map_verification_status": row.verification_status,
                    "slot_assumption": "FYERS_CONTINUOUS_CONTAINER_TREATED_AS_OBSERVED_NEAR_SLOT",
                    "expiry_rule_scope": "AFTER_REPLAY_WINDOW",
                }
            raise ExpiryControlCoverageError(
                f"{self.exchange} {row.symbol} {row.contract_identifier} is only observed through "
                f"{self.sessions[-1]}, before expiry {expiry}; later bhavcopy sessions are required"
            )
        # An expiry may fall on an exchange holiday.  The last observed
        # bhavcopy date not later than expiry is the actual final session for
        # trading-session arithmetic.
        final = len(eligible_sessions) - 1
        if final < 5:
            raise ExpiryControlCoverageError(
                f"{self.exchange} {row.symbol} {row.contract_identifier} has fewer than five observed "
                f"sessions before expiry {expiry}"
            )
        # Locked, trading-session semantics: no new entry ON OR AFTER -5;
        # open positions are force-flattened on -3.
        return {
            "contract_slot": "NEAR",
            "historical_contract_identifier": row.contract_identifier,
            "historical_expiry_date": row.expiry_date,
            "segment_id": row.contract_identifier,
            "entry_cutoff_date": eligible_sessions[final - 5],
            "force_exit_date": eligible_sessions[final - 3],
            "exclude_e1_gap": bool(exclude_e1_gap),
            "map_observation_date": trade_date,
            "map_verification_status": row.verification_status,
            "slot_assumption": "FYERS_CONTINUOUS_CONTAINER_TREATED_AS_OBSERVED_NEAR_SLOT",
            "expiry_rule_scope": "ENFORCED",
        }

    def has_observation(self, symbol: str, timestamp: object) -> bool:
        day = pd.Timestamp(timestamp).date().isoformat()
        return (str(symbol).upper(), day) in self.by_day

    def unresolved_terminal_segments(self) -> list[dict[str, str]]:
        """Return only segments that need additional *metadata*, never OHLC."""
        unresolved = []
        last_session = self.sessions[-1]
        near = self.rows[["symbol", "contract_identifier", "expiry_date"]].drop_duplicates()
        for row in near.itertuples(index=False):
            if row.expiry_date > last_session:
                unresolved.append({
                    "symbol": row.symbol, "contract_identifier": row.contract_identifier,
                    "last_observed_session": last_session, "expiry_date": row.expiry_date,
                    "reason": "terminal NEAR segment does not include its expiry session",
                })
        return unresolved

    def assert_controls_complete(self, replay_end: object | None = None) -> None:
        unresolved = self.unresolved_terminal_segments()
        if replay_end is not None:
            end = pd.Timestamp(replay_end).date().isoformat()
            retained = []
            for row in unresolved:
                observed_after_end = [day for day in self.sessions if end < day <= row["expiry_date"]]
                if not (row["expiry_date"] > end and len(observed_after_end) >= 5):
                    retained.append(row)
            unresolved = retained
        if unresolved:
            text = "; ".join(
                f"{row['symbol']} {row['contract_identifier']} observed through {row['last_observed_session']} "
                f"but expires {row['expiry_date']}" for row in unresolved
            )
            raise ExpiryControlCoverageError(
                "expiry-session controls are incomplete; collect the listed post-window bhavcopy sessions: " + text
            )
