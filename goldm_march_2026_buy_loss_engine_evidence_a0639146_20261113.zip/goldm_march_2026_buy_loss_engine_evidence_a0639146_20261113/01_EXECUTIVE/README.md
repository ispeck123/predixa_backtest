# GOLDM March-2026 BUY-loss anomaly — engine evidence package

## Observed cohort

- Completed source run: `a0639146f7144e6591db0950dc330059`.
- Exactly `99` GOLDM TF2 BUY trades entered during March 2026.
- All `99` are persisted `LOSS` outcomes at exactly `-1.0R`; none are WIN or TIME_EXIT.
- Evaluation timestamps span 6–17 March; entries cluster only on 18–19 March. This is evidence of delayed limit-entry resolution and is a primary review lead.

## What this package proves

It preserves the persisted task/scan/setup/regime/trade evidence and regenerates the engine output for every exact task through the same audit adapter. `03_REGENERATED_ENGINE_OUTPUT/replay_comparison.json` states whether regenerated decisions match the completed database.

## What it does not prove

An all-loss cohort does not alone prove that trend classification is wrong. The research gate bypass was enabled for this run, so this package must be used to review engine context, zones, setup cascade, entry delay, and execution assumptions before changing live or research strategy rules.
