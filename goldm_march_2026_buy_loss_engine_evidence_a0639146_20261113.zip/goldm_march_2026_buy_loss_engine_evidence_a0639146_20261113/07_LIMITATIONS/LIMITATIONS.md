# Limits and safe interpretation

- The original replay did not store `raw_json`; payloads in this package are deterministic regenerated audit evidence, not newly persisted replay rows.
- No new SQLite database/run was created. The source database was read-only and is referenced by SHA-256.
- Candle windows are selected evidence only; original OHLC files remain unchanged and are referenced by checksum, not copied.
- The run used an audit-only research gate bypass. Do not use this cohort as a justification to change live/paper gating without an independent strategy review.
- This package diagnoses an anomaly. It does not apply any strategy modification.
