Start with 01_EXECUTIVE/README.md, then 02_PERSISTED_COHORT and 03_REGENERATED_ENGINE_OUTPUT. The package contains diagnostics only and no strategy changes.
