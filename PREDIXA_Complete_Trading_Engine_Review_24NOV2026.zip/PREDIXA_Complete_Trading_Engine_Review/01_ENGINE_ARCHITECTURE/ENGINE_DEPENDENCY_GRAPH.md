# Engine dependency graph

Start with `STATIC_IMPORT_EDGES.csv`, keyed by caller, source line, callee and import kind. `SEGMENT_DEPENDENCY_MATRIX.csv` gives shortest inspected caller chains for each segment plus a separate bootstrap column. Namespace folders are preserved. Existing initializers are included when needed. Function-local imports and conditional branches are conservatively traversed.
