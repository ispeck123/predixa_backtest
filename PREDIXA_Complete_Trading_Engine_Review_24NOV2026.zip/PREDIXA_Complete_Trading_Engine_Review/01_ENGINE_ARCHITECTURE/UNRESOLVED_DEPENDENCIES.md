# Unresolved dependencies

No missing first-party edge was found in the indexed generation graph. The remaining unknowns are the deployed scheduler workspace, process/container revision, runtime environment values, provider symbol masters, candle files, refresh state and the optional exchange calendar. Real replay requires approved source data and evidence bundle manifests. Optional model predictor paths require approved serialized artifacts. PM2 process declarations and its external service state are not established by this checkout. The static dynamic-call table covers source call sites, including external command and path-dependent review branches. No remote dependency or live module was contacted.

Source includes hardcoded path insertions in startup/helpers. The offline runner excludes the original checkout from import resolution. Outside that harness, normal service startup requires operator-controlled path configuration and the appropriate deployment environment.
