# Module call graph

The segment maps show the execution graphs from market input to persistence. The function index contains source locations, signatures, raw syntactic callees and candidate callers by name. Calls through injected functions, object aliases, registration and scheduler callbacks require reading the indicated source. Name matches in the index can be ambiguous. `RULE_TRACEABILITY.csv` identifies manually reviewed decision anchors.
