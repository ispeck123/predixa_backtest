# Complete architecture

The scanner wrappers call `scripts/setup_engine_new.py::process_setup` or `process_setup_fc`, which instantiate `SDEnginePipeline` and convert exceptions to strings. The core is a CSV consumer. The upstream updater publishes or derives bars before the setup call. The CASH wrapper leaves is_cash unset inside run, so resolve_segment falls through to MCX for that internal side-policy call. Both keys currently have identical side flags. The formatter is explicitly called as CASH, and E1 still stays off when is_future is unset. The core builds E (Evaluate), A (Analyze) and X (Execute) from the first, second and last stack elements.

| Stage | Implementation and operators | Input → output / rejection |
|---|---|---|
| Read and prepare | `SDEnginePipeline.get_candle_series_data` → `scripts/models.py::load_preprocess_data` | Load OHLC and `tradeDate` or `timestamp` at the as-of cut. Keep a violation frame, trim the current period out of the setup frame, apply the two-year intraday window and derive Unix timestamps. X violation close supplies `get_cmp`. History under 7/15/50 E/A/X bars yields `data_insufficient` where loading already produced nonempty frames. An empty frame may raise on last-row access first. |
| Trend inputs and indicators | `scripts/trade_engine.py::process_trend_zones`, `ZoneDetector.detect`, `atr`, `ema`, `volatility_regime` | Build E/A regular zones through trend-zone processing and detect X zones directly. ATR, EMA and volatility feed gap detection, rules and scoring. MCX passes session labels through these call paths. |
| Gap/regular zones | `GapModule.detect`, `SlidingWindowManager.filter_zones_in_window`, `ZoneQualifier.update_violation`, `check_session_acceptance`, `ZoneAgeManager.update_zone_age` | Merge gap and regular zones, filter distance/age window, validate HTF levels, calculate gap acceptance and ages. Rule C membership excludes gap candidates whose acceptance does not qualify. |
| HTF context and rules | `SDEnginePipeline._reduce_to_nearest` and `calculate_trend_context` → `MultiTimeframeTrendCalculator.calculate_full_context` → `TrendEngine.calculate_trend` | E/A candidates, CMP and OHLC produce regimes, quadrant, Rule B/C context and permissions. `ThreeWayConflictResolver.resolve` handles combined E/A/X conditions. Rule B uses available surviving single-sided structure. Rule C reasons about both sides, chronology, relative nearby zones and breach/acceptance. It is implemented within the trend engine. |
| Qualification | `MultiZoneHandler.process_overlaps` / `find_consecutive_stack`, `WickViolationHandler.update_wick_status`, `ZoneQualifier.compute_structure_removal`, `ZoneNestingClassifier.classify_with_debug` | Execution zones carry overlap decisions, retests, structure removal and nesting. The pipeline selects enclosures and checks opposing obstructions plus entry reachability. |
| Entry, stop and target | `RiskTargetCalculator.calculate` → `HardGateChecker.check_gates_pre_rr` → reversal validation branches | Entry/stop/target depend on boundaries, ATR/risk floors, opposing structure and nesting. Gate logic writes warnings and block reasons. DBR/RBR checks are conditional on trade type and zone side. |
| Final selection | `SetupExtractor.extract` → `WeightedZoneScorer.compute_weighted_score` → `HardGateChecker.check_g9_rr` and `_validate_setup_sanity` | GREEN/proximity candidates score and sort descending per direction. Cascade past candidates that fail G9 or sanity. A selected direction returns a `SetupPayload`. The extractor also applies an A-supply constraint to long candidates. |
| Emission boundary | `SideEnablementPolicy` in the pipeline, then `format_calculate_setup_response` → `tf_regime_gate_by_exchange.gate` | Format prices, timestamps, zone signature, E/A regimes, strategy TF and X zones. Permission returns tier, size multiplier and reason. Zero size removes actionable side fields. The checked-in side-policy table sets both LONG and SHORT True for all canonical segment keys despite its long-only comments. Wet-run and graduated classifiers still select BUY and MCX is held. Scanners perform further gates and persistence. |

The final weighted score uses trend 20%, base quality 18%, freshness 16%, RR 15%, departure 12%, confluence 10%, EMA 4%, age 3% and proximity 2%. The G9 default is 2.1. `ZoneQualityScorer`, `ZoneScorerV38` and `ZoneRanker` are related scoring/ranking code. The final setup selector sorts the weighted score itself. See the rule CSV and source symbol index for exact predicates and call sites.

```mermaid
flowchart LR
  D["Provider history and instrument masters"] --> W["Updater and timeframe preparation"]
  W --> F["Reviewed CSV contract"]
  S["Dagster jobs or HTTP requests"] --> P["Shared E/A/X setup pipeline"]
  F --> P
  P --> T["Zones → trend → rules → weighted selection"]
  T --> G["Side policy and exchange formatter gate"]
  G --> B["Segment-specific signal or candidate boundary"]
  G --> A["Formatted zones and status"]
```
