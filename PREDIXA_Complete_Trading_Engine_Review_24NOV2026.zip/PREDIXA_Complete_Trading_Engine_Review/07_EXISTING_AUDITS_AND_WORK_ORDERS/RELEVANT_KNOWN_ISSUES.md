# Known review issues

- The side policy comments describe a long-only default, while the table explicitly enables both LONG and SHORT at recognized keys. CASH wet-run and the graduated scanners apply their own BUY paths. The general scanners retain conditional SELL logic. The CASH wrapper leaves is_cash unset at the core's side-resolution point, so that internal check currently uses the MCX key.
- `alert_engine/alert.py:259` has a pre-existing compiler error because `cached_alerts` is referenced before its global declaration. It affects the adjacent legacy alert entrypoint and alternate stock jobs bootstrap.
- The local `prod` checkout is two commits ahead of its tracking ref, and process/container revision is unverified.
- MCX trading and paper observation are held in the selected source. Clean realized-R analysis and owner authorization remain distinct conditions from mechanics and alert behavior.
- The CASH status evaluator gives target precedence when SL and TP both hit in the same bar in its default route. Prior Rev3 reports describe correction on a separate branch.
- Empty candle frames can produce an exception before the minimum-history return. The wrapper turns the exception into a string and the scanner can record a processing error.
- The general derivatives scanner and graduated futures updater use differently named expiry state artifacts. The live deployment and state handover must be reviewed for the intended operational topology.
- Source runtime path configuration and private artifacts require a controlled deployment environment. Historical replay reproducibility also needs approved candle, metadata and provenance inputs.
