# Existing audit database schema

Baseline revision `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046` uses SQLite through `SQLiteBacktestStorage`. The database is an offline replay evidence store, not the production order database.

| Table | Key | Relevant relationships and fields |
|---|---|---|
| `backtest_runs` | `run_id` | Run configuration, variant, source interval and status |
| `scan_tasks` | `task_id` | Unique `(run_id, symbol, strategy_tf, evaluation_timestamp)` |
| `scan_results` | `scan_id`, unique `task_id` | Carries `run_id` and the point-in-time scan identity |
| `regime_snapshots` | `scan_id` | One row per scan, including E/A regimes and quadrants |
| `zone_snapshots` | `zone_snapshot_id` | Many zones per scan, selected through `(scan_id, timeframe='X', zone_id)` |
| `setup_results` | `setup_id` | Many setups per scan, one durable setup parent per trade |
| `simulated_trades` | `trade_id`, unique `setup_id` | Completed and unresolved trade economics |

The baseline schema already contained the regime quadrants, zone retest count, age class, zone type, nesting tier, pattern and setup-score columns. Producer defects left several values null. The addendum therefore requires two new nullable setup columns only, `spot_gap_validated` and `gap_reject_reason`.

Historical NSEFO database `futures_core8_2y.sqlite` has 93,102 scans, 481,914 zone snapshots, 25,424 setups and 21,030 trade records. Its completed population is 20,704 trades.
