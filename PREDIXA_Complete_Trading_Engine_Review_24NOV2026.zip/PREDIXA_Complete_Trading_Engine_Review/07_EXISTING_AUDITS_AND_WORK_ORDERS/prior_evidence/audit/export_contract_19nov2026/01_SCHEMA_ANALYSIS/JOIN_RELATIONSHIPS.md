# Join relationships

The export scope starts from completed `simulated_trades` whose entry timestamp, exit timestamp, exit price and gross R are present. It joins the immutable scan parent by `simulated_trades.scan_id = scan_results.scan_id` and restricts `scan_results.run_id` to the requested run.

Regime state is joined by the same stored `scan_id`. The schema makes `regime_snapshots.scan_id` a primary key, so later regime states cannot fan out the trade.

Setup state is joined by both `setup_id` and `scan_id`. `simulated_trades.setup_id` is unique and foreign-keyed to `setup_results`, giving one setup per trade while the scan guard prevents a mismatched setup.

Zone state is joined by `scan_id`, `timeframe = 'X'` and the setup's selected `zone_id`. The writer now adds a `SELECTED_SETUP` snapshot when the selected zone is outside the four nearest context snapshots. Export preflight counts zero, one and multiple matches. Multiple matches fail validation and are never hidden with `DISTINCT`, `MAX` or `LIMIT`.

Run IDs are included through the scan parent. Repeated zone identifiers in different runs cannot collide.
