# Schema change summary

Two nullable columns are added to `setup_results`.

- `spot_gap_validated INTEGER CHECK (spot_gap_validated IN (0,1) OR spot_gap_validated IS NULL)`
- `gap_reject_reason TEXT`

Two read-optimization indexes are added.

- `idx_zone_snapshot_selected(scan_id,timeframe,zone_id)`
- `idx_setup_results_zone(scan_id,zone_id)`

No economic table or economic column is altered. Nullable columns are required because historical DATA-2 evidence and approved non-rejection semantics are unavailable. No `NOT NULL` constraint is applied prematurely.
