# Backfill plan

`backfill_export_contract.py` requires an explicit run ID and defaults to dry-run. It updates null values only, emits an audit CSV, commits in configurable batches and can resume safely because populated values are skipped.

The historical NSEFO dry run found 481,914 deterministic zone-type candidates and no pattern, score or DATA-2 candidates. Raw JSON was unavailable for all 25,424 setups. Production use must remain blocked until a database owner approves the run scope, backup and write window.

No entry, stop, target, exit, gross R, timestamps or trade IDs are touched.
