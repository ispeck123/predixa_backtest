# Migration verification

The migration was tested against an isolated copy of the 154,423,296-byte NSEFO historical database. The source database was never modified.

- Upgrade added both nullable columns and both indexes.
- A second upgrade was covered by automated idempotency tests.
- Foreign-key check returned no violations.
- The controlled backfill updated 481,914 deterministically classified zone types on the isolated copy.
- Economic row count remained 21,030.
- Aggregate gross R remained `-1168.9396022935816`.
- Canonical economic hash remained `e598f0368e900080b39b2ab0f82bd5d11768ca706c5cf47b31072ea77d47f2b9`.
- Downgrade removed only addendum-owned columns and indexes.

SQLite table rewrites for column downgrade can lock a large audit database. Deployment should use an approved maintenance window and verified backup. Upgrade column additions are additive, while index creation cost scales with the 481,914-row zone table.
