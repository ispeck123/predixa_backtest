# Rollback instructions

Stop audit writers and exports, verify a current database backup, then run the migration utility with `--direction downgrade --apply` against the explicitly approved offline database. Confirm `PRAGMA foreign_key_check` and compare the canonical economic hash with the pre-migration value.

Rollback removes `idx_zone_snapshot_selected`, `idx_setup_results_zone`, `gap_reject_reason` and `spot_gap_validated`. Producer code should be rolled back before the schema so it does not attempt to write removed columns.

No rollback command has been run against production infrastructure.
