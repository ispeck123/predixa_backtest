# Execution instructions

Run the strict exporter with the repository environment and an explicit historical run ID.

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.export_rescore_ledger \
  --storage /approved/offline/replay.sqlite \
  --run RUN_ID \
  --output RE_SCORE_LEDGER.csv
```

Strict mode publishes no ledger when validation fails. Add `--allow-partial` only for a clearly named diagnostic output.

Run a dry-run backfill before requesting database-owner approval.

```bash
PYTHONPATH=. python -m audit.fresh_trend_backtest.backfill_export_contract \
  --storage /approved/offline/replay.sqlite \
  --run RUN_ID \
  --audit-output BACKFILL_DRY_RUN.csv
```

The controlled fixture command and source hashes are recorded by `run_controlled_export_fixture.py`.
