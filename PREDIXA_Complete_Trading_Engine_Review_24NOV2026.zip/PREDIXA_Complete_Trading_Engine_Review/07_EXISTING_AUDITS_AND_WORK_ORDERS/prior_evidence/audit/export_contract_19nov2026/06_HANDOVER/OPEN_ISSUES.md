# Open issues

1. DATA-2 has no authoritative producer in this checkout, so both gap-validation fields remain unavailable.
2. The canonical non-rejection representation for `gap_reject_reason` requires owner clarification.
3. The historical NSEFO run omitted raw JSON and cannot reconstruct pattern or setup score without an approved immutable replay.
4. Historical selected-zone coverage is incomplete for 9,758 completed trades.
5. Historical quadrant fields are incomplete for 6,422 E rows and 1,345 A rows.
6. The broader repository retains 12 unrelated baseline failures.
