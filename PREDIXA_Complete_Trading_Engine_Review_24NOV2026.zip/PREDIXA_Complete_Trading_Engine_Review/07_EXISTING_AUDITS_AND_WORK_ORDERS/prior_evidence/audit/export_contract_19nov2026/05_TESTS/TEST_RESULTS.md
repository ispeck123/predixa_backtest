# Test results

Focused and relevant regression command passed 64 tests with five deprecation warnings and no failures. The JUnit report is in `raw/focused_and_regression.xml`.

The broader suite passed 597 tests and failed the same 12 pre-existing tests documented by the revision-2 baseline. Failures concern missing historical fixtures, date-sensitive expired-contract expectations, pre-existing paper-observation schema drift, release-preflight checkout context and unrelated websocket fixtures. No failure is in the addendum modules. The JUnit report is in `raw/full_regression.xml`.

The addendum-specific suite contains 14 tests covering the score bug, zero-score preservation, four zone types, selected-zone persistence, deterministic export, strict and partial modes, fan-out detection, formula-injection detection, empty scope, migration upgrade/rerun/downgrade and dry-run/idempotent backfill.
