# Join cardinality results

The controlled fixture has one completed trade, one export row, one distinct trade ID and no relationship errors. Synthetic tests prove that duplicated selected-zone matches produce a duplicate count and hard validation failure.

The historical NSEFO diagnostic has 20,704 completed trades, 20,704 rows, 20,704 distinct trade IDs and zero duplicates. It reports 9,758 unmatched selected zones without dropping those trades. Scan, setup and regime parents are fully matched.
