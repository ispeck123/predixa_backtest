# Field completeness results

The controlled fixture has zero missing values for every independent workbook field. `spot_gap_validated` and `gap_reject_reason` each have one missing value because DATA-2 is unavailable.

The historical diagnostic has no missing exchange, symbol, side, strategy timeframe, E/A regime, economic price, gross R or timestamp values. Detailed missing counts and representative trade IDs are in `../04_EXPORT/DATA_QUALITY_REPORT.csv` and `EXPORT_VALIDATION.json`.
