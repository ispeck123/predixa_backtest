# Economic parity results

The controlled fixture source and export both contain trade ID 1, one trade and aggregate gross R `-1.0`. Entry, stop, target, exit, side, strategy timeframe, timestamps and gross R compare exactly.

On the isolated full historical migration and backfill test, 21,030 trade rows, aggregate gross R `-1168.9396022935816` and canonical hash `e598f0368e900080b39b2ab0f82bd5d11768ca706c5cf47b31072ea77d47f2b9` were unchanged before and after.

No trading rule, resolver, entry, exit, risk, eligibility or gross-R calculation was modified.
