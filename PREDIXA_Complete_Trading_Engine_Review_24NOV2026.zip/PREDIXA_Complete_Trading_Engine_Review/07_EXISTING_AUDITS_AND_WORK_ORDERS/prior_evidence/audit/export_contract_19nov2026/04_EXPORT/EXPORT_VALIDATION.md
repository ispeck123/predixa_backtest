# Export validation

## Controlled new-run fixture

Run `export-contract-controlled` used the pinned INFY CASH TF2 setup at `2024-11-11T09:15:00`. It produced one completed trade and one exported row, one distinct trade ID, zero duplicates, zero ambiguous joins and zero missing scan, setup, regime or zone relationships. All independent contract fields were populated. Only the two DATA-2 fields were absent. Gross R was `-1.0`, and direct source-to-export economic comparison was exact.

## Historical NSEFO diagnostic

Run `e67be356a1214503bde231aa7112ed9f` produced 20,704 completed trades and exactly 20,704 export rows with 20,704 distinct trade IDs. There were zero duplicate or ambiguous rows. The diagnostic is deliberately named `RE_SCORE_LEDGER_DIAGNOSTIC_PARTIAL.csv` because mandatory historical fields are incomplete.

Notable missing counts are 9,758 selected-zone relationships, 6,422 E quadrants, 1,345 A quadrants, and 20,704 each for pattern, setup score, nesting tier, zone type and both DATA-2 fields. Historical gross R totals `-1168.9396022935925` in export iteration order. The source fingerprint is `f28ee8011b0bd3f9b3b62acdbb15813b39fc12d7029305ef851804485f7cf100`.
