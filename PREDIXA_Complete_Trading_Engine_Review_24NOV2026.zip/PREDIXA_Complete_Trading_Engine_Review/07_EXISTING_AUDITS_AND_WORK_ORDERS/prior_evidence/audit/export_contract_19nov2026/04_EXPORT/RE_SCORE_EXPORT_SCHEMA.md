# Re-score export schema

The CSV order is `trade_id`, `exchange`, `symbol`, `side`, `strategy_tf`, `E_regime`, `A_regime`, `E_quadrant`, `A_quadrant`, `retest_count`, `age_class`, `pattern`, `zone_type`, `nesting_tier`, `setup_score`, `entry`, `stop`, `target`, `exit`, `gross_r`, `entry_timestamp`, `exit_timestamp`, `spot_gap_validated`, `gap_reject_reason`.

Rows are ordered by original entry timestamp and trade ID. Numeric values use their stored SQLite values without rounding. Timestamps are emitted unchanged. Boolean values serialize as lowercase `true` and `false`, while unavailable values remain empty and fail validation. CSV fields are always quoted. Potential formula-leading text is counted as a contract violation rather than silently mutated.

Completed trades require non-null entry timestamp, exit timestamp, exit price and gross R. The export is read-only and streams rows in batches.
