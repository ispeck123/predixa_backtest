# PREDIXA re-score export contract implementation report

## Outcome

The OBS-1 addendum is implemented across the audit producer, SQLite schema, historical backfill interface and deterministic export path. New controlled records populate every independently available workbook field, and export cardinality and trade economics are verified. DATA-2 remains an explicit acceptance dependency.

## Implementation

The score writer now uses `zone_score_v38` in CASH and futures paths. Zone type comes from `Zone.ztype`. Pattern/confirmation records the actual DBR/RBD formation when available and the engine's existing `AUTO` confirmation mode otherwise. The selected zone is durably snapshotted at setup time, preventing missing joins when it is outside the nearest-zone list. DATA-2 values flow through optional typed fields without fabricated defaults.

The read-only exporter streams exactly one row per completed trade in stable entry-time and trade-ID order, preserves stored numeric and timestamp values, validates every required field, rejects fan-out and emits detailed quality evidence. Strict mode does not publish an incomplete ledger.

## Database

`setup_results` gains nullable `spot_gap_validated` and `gap_reject_reason` columns. Join indexes are additive. Upgrade, rerun and downgrade were tested on isolated databases. A full historical copy retained the same 21,030 economic rows, aggregate gross R and canonical economic hash through migration and deterministic zone-type backfill.

## Actual results

The controlled new-run fixture exported one of one completed trades, one distinct trade ID, zero duplicates and no relationship failures. All independent fields were populated. DATA-2 fields were null, so contract completeness correctly failed.

The authorized NSEFO historical diagnostic exported 20,704 of 20,704 completed trades with no duplicates. It remains partial because immutable historical evidence is absent for several mandatory fields. Detailed counts are in `04_EXPORT/EXPORT_VALIDATION.json`.

## Verification

Focused and relevant regression testing passed 64 tests. The broad suite passed 597 and retained the same 12 unrelated baseline failures. The controlled source and export economic projection match exactly. No trading behavior or economics were changed.

## Final status

**ENGINEERING COMPLETE — DATA CONTRACT / DATA-2 VALIDATION PENDING**

No live trading, scanner activation, unauthorized production DDL, data update or production deployment occurred.
