# DATA-2 integration status

The schema, setup payload, writers, exporter and validator support `spot_gap_validated` and `gap_reject_reason`. Values are captured only when an authoritative DATA-2 producer supplies them.

No DATA-2 producer or canonical non-rejection reason was present in the repository. The controlled real setup therefore records null for both fields, and the validator correctly marks the ledger incomplete. False is never substituted for unavailable evidence, and no `NONE`, `UNKNOWN` or `N/A` sentinel was introduced.

Overall acceptance remains blocked until DATA-2 supplies the values and the owner approves non-rejection semantics.
