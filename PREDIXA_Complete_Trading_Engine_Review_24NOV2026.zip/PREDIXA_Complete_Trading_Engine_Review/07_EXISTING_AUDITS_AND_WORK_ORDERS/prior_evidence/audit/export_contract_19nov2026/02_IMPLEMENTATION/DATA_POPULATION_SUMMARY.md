# Data population summary

New runs capture zone type from `Zone.ztype`, pattern from `associated_pattern` or `zone_pattern`, and the established `entry_mode` value `AUTO` when a setup has no candle-pattern requirement. This uses existing engine semantics and does not add a trading enum.

The selected zone snapshot is generated from the emitted setup payload at decision time. It includes zone identity, type, proximal and distal values, age class, retest count, nesting tier, score and proximity. No later zone state is consulted.

Historical `zone_type` is deterministically backfillable from the immutable zone ID suffix. Pattern and setup score require stored raw setup JSON. The reviewed historical NSEFO run stored no raw JSON for all 25,424 setups, so these fields cannot be backfilled without immutable replay evidence.
