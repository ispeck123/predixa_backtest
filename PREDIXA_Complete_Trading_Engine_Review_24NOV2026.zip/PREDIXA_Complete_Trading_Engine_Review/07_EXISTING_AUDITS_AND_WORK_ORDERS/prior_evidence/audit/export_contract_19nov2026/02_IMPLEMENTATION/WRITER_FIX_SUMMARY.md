# Writer fixes

Both CASH and futures audit writers now map `zone_score_v38` directly to `setup_score`. The obsolete `score` lookup is gone from these writer boundaries. Legitimate zero remains zero and a missing producer value remains null for data-quality reporting.

The shared mapper also captures pattern/confirmation and DATA-2 values without defaults. Zone snapshots now read the engine's real `ztype` attribute. The selected setup's point-in-time zone is persisted even when it is outside the nearest-zone context list.

The controlled production-path fixture produced setup score `10`, confirmation `AUTO`, zone type `GDZ`, age class `FRESH` and nesting tier `TIER_1`.
