# PREDIXA revision 2 backend

**PARTIAL IMPLEMENTATION — ACTION REQUIRED**

Branch predixa/be-rev2 starts at 7ac0a972d3e89e7beeb1743391e2cfbedbdcd046. Review the source diff and CHANGE_MANIFEST.csv. Checks covered all ten workbook rows. A2 holds production insertion if enabled, and A3 supplies a tested database schema awaiting scanner and order transaction integration. The configured features are OFF.

The bounded CASH replay showed unchanged +2.603 net R and 7/7 populated observation rows for B. C removed four Execute-Q2 trades and reached +3.902 net R. D fell to −4.500 net R and did not improve the requested excursion counts. E reproduced at +0.358R OOS mean across 2,970 completed trades, so legacy size and permission were retained. G applied the exact revised cell set to CASH and reduced OOS net R by 1,062.862R in the fixed-ledger comparison. The owner event is missing for F.

All seven deterministic flag-OFF artifact hashes matched. Full offline regression retained the same 12 baseline failures. The isolated MySQL audit migration passed tested schema and concurrency primitives. Row-level engineering and acceptance status, hashes, commands, per-cell R, trade IDs and unresolved work are in the linked evidence directories. No production system, broker, order, scanner, migration, activation or deployment was operated.
