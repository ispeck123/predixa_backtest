# Integration results

Focused tests cover the native CASH worker, sizing and a transactional SQLite observation writer/export. Native bounded CASH ledgers and the permitted-cell population are in 04_edge_repro. Signal holds were verified before provider or DB access. Full atomic scanner winner behavior is outstanding.
