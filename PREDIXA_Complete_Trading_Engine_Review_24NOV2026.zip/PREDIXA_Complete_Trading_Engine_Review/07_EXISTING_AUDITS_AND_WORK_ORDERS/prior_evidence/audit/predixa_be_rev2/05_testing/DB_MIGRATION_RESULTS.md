# Migration results

MySQL 8.4 ran with TCP disabled and a private Unix socket in a temporary directory. Upgrade, migration rerun, downgrade, retention of an existing business-row surrogate, candidate retry key rejection, transaction rollback and a concurrent unique winner passed. The optional SQLite sidecar migration is additive and writer tests confirm old trade columns and outcomes. No production database was accessed.
