# Concurrency results

Two independent MySQL sessions raced to claim a chosen candidate in one group. One committed and one encountered duplicate-key rejection. This validates the database uniqueness primitive. No concurrent scanner or order-writer arbitration was exercised.
