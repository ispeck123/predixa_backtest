# Unit results

The final focused run recorded 60 passed and five dependency warnings. See final-focused-pytest.txt and tests/test_predixa_be_rev2.py. The suite exercises Decimal geometry, G7 reasons, the existing strict stop, excursion orientation and ordering, gap event types and session seams, the exact whitelist and fail-closed policy.
