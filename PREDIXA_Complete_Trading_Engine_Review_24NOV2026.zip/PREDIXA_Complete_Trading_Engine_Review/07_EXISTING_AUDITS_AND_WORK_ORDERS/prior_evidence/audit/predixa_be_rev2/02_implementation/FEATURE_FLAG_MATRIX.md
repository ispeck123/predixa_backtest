# Feature flag matrix

| Rows | Config field | Default | Dependency |
|---|---|---|---|
| A1–A3 | cross_tf_region_dedup_enabled | False | Approved historical ranking version, collection boundary and A2/A3 integration |
| B1–B2 | trade_observability_wiring_enabled | False | Valid fill/exit bars; region formatting is shared with A1 without requiring A |
| C | range_midcurve_hard_block | False | G7 receives Execute quadrant |
| D | embed_strict_stop | False | Already declared and passed by production; B measures excursion outcomes |
| E | No new switch | n/a | Conditional source change depends on failed fresh reproduction; current evidence reproduced |
| F | corp_action_gap_guard_enabled | False | Empty owner metadata tuple by default; only unadjusted CASH is eligible |
| G | realized_r_cell_whitelist_enabled | False | UP/SW/2 held pending E reconciliation |

The engine dataclass constructors and asdict expose the fields. Historical replay accepts explicit engine override values. No deployed config file was edited.
