# Baseline configuration

All revision switches are absent from the original dataclasses except strict stop, already False in both model and trend Config. Final defaults are in FEATURE_FLAG_MATRIX.md. Baseline market permission is the unchanged TF_REGIME_GATE mapping. MCX gate denies throughout. Legacy CASH UP/SW/2 and UP/SW/5 are marginal, SW/UP/6 was core. The sampled historical split and delivery cost follow the baseline CASH gate source, 2025-11-01 and 0.2% round trip.
