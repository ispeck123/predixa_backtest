# Baseline test results

System Python lacked FastAPI. The finpro environment has the needed backend dependencies. An initial attempt without environment overrides could not import DBConnection. Offline runs use dummy loopback settings and never load the production .env. The clean baseline produced 556 passed, 12 failed and 27 warnings in full-offline-pytest.txt. The same four manual/infrastructure modules were excluded from the baseline and corrected runs. The original scanner collection in the first corrected run attempted only the dummy loopback configuration and failed to connect.
