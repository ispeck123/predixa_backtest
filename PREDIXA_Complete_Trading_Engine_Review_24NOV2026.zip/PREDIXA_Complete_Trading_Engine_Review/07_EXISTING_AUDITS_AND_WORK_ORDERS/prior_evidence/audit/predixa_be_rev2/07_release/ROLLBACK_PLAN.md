# Rollback plan

Turn the affected switch OFF first. Preserve any candidate and trade observations for review. Roll back application source using the reviewed baseline. If the owner also approves schema rollback, archive the candidate data then apply scripts/db_migrations/rollback/20261118_cross_tf_candidates.sql. Applicable SQLite stores may retain the unused sidecar or remove it after exporting its contents. Rollback should never rewrite historical trade outcomes.
