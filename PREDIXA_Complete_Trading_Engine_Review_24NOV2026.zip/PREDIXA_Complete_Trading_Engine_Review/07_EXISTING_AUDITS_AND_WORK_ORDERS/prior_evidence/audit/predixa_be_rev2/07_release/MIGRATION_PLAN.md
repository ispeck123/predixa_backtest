# Future migration plan

Keep all switches False. After owner review, back up affected schema metadata and verify the exact MySQL server version and migration checksum. Apply scripts/db_migrations/20261118_cross_tf_candidates.sql in the approved deployment sequence. MySQL DDL commits separately from business DML. Verify the candidate primary key, generated winner unique constraint, window check, lookup index and unchanged existing rows. SQLite creates its evidence table additively on local replay writer startup.
