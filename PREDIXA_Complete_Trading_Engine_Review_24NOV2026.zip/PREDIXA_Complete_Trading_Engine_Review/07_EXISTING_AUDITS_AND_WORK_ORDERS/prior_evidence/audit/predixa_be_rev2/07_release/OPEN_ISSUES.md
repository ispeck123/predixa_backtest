# Open issues

- A2/A3 need closed-window coordination, a dated and approved cell evidence source, and a transactional scanner/order integration.
- C needs the exact NSEFO SW/SW/25 evaluation, with frozen input and comparable cost schedule.
- D failed the sampled CASH economic and excursion criteria.
- E's workbook result needs source reconciliation before it can determine G treatment.
- F needs the owner cash instrument, exchange-local ex-date, event classification, input price-adjustment provenance and replay data.
- G and overall flag-OFF parity need native order and broader export coverage. The CASH ledger G result shows the economic impact of holding pending E.
