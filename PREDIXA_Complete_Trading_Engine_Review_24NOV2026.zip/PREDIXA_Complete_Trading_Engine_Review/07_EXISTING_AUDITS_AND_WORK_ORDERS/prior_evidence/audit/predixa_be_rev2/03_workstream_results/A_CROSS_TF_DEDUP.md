# Cross-timeframe region and arbitration

A1 emits canonical SYMBOL:proximal:distal with half-up 0.01 price rounding. Comparison also needs raw endpoints, exact exchange, instrument including any contract namespace, zone side, positive overlap and caller-supplied endpoint tolerance and intersection-over-union floor. Samples use a 0.01 band and 0.95 floor as fixture values. Production has no approved setting. The CASH A1-only diagnostic stayed at 7 trades and +2.603 net R.

A2 currently holds at signal and automated order writes. There is no effective winner selection, no observed duplicate-order suppression, and no durable scanner candidate integration. Independent regions are also held with A ON. Approval is needed for the collection window and evidence version with historical availability dates. The existing first-arrival scanner loop cannot choose a higher-R candidate arriving later without a collection/finalization stage.

A3 schema is tested on MySQL 8.4. Candidate keys block duplicate retry rows, and only one chosen candidate can share a group. The SQL constraints alone cannot arbitrate equivalent geometry or make scanner decisions atomic. The integration belongs in the same transaction as order insertion and remains pending.
