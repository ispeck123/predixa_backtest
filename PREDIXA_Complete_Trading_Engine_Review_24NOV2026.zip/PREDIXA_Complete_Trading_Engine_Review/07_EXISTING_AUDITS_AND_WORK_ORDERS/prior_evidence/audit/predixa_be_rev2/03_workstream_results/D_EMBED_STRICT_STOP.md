# Strict structural stop

Both Config classes already declare embed_strict_stop=False, and the trend config reaches the existing RiskTargetCalculator. The TIER_3 test confirms the wider structural stop can fail RR and the tight X stop is emitted only with strict stop OFF. No stop algorithm or ATR floor changed.

In the bounded CASH replay, B-only versus B+D, losers with MFE at least 1R stayed at 2 and winners with MAE above 1R stayed at 0. Completed trades fell from 7 to 4, and net R fell from +2.603 to −4.500. OOS net R fell from +2.822 to −2.207. The loss of all three sampled winning trades makes this run fail the requested no-regression test. A representative SW/SW replay and owner disposition remain outstanding.
