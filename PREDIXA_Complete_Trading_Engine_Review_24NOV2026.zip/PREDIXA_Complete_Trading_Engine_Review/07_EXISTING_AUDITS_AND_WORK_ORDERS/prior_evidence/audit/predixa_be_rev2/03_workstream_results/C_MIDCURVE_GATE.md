# G7 Q2 BUY hard block

ON rejects an Execute Q2 RANGE_EXTREME BUY with G7_Q2_MIDCURVE_RED_RANGE and marks G7_Q2_MIDCURVE. OFF preserves G7_NOT_Q1. The tested unit matrix covers Q1/Q2/Q3 on both sides. The bounded CASH replay removed all 4 Execute Q2 trades, including one winner. The three remaining trades were Execute Q3. Net R rose from +2.603 to +3.902, with OOS +2.822 to +5.028. The requested NSEFO SW/SW/25 economic reference has not been reproduced.
