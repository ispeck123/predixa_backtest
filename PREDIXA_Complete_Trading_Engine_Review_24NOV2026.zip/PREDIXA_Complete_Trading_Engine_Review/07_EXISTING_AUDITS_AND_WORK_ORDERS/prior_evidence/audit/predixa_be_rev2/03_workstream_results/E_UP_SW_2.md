# CASH UP/SW/2

At the documented 0.2% delivery cost and 2025-11-01 split, the official checker reported 2,970 OOS trades, 32.8% wins, +0.076R IS and +0.358R OOS net expectancy. The comparable gate code documents roughly +0.36R. The workbook cites a different result and the exact accompanying evidence was not found. No conditional denial or weight reduction was applied to legacy. G keeps this cell pending owner reconciliation. No confidence interval was published by the official checker.
