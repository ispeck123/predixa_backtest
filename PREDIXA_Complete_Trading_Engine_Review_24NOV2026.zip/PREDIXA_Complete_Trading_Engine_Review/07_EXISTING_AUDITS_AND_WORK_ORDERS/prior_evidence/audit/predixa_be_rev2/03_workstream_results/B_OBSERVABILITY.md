# Trade observability

B1 and B2 ran on the same CASH OHLC and unchanged exit rules before and after. The legacy completed CSV was byte-identical and all 7 trades populated excursion metrics, order fields, score, entry ATR, rank, signatures and strategy TF. Gross R stayed +3.536 and net of costs stayed +2.603. The writer persists a SQLite sidecar and an explicit optional CSV. OOS sample counts were 4 trades and +2.822 net R in both runs.

Bars are indexed from the fill candle and ties use the first occurrence. Metrics include fill and exit bars under the legacy atomic OHLC model with its target-first convention. Intrabar ordering cannot be determined from OHLC. The ATR uses only candles timestamped before the fill bar and the setup's existing ATR period. Missing/invalid OHLC receives a quality status. Legacy maximum-excursion and indexing fields retain their prior semantics.
