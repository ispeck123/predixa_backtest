# Historical observability gaps

| Original dataset | Completed rows | Missing selected X-zone relationship | Missing setup score | Missing pattern |
| --- | ---: | ---: | ---: | ---: |
| CASH completed 2y | 47,815 | 14,627 | 47,815 | 47,815 |
| NSEFO Core-8 | 20,704 | 9,758 | 20,704 | 20,704 |
| MCX Phase A | 4,930 | 1,533 | 4,930 | 4,930 |

A selected zone outside the recorded nearest X-zone set lacked an exact saved relationship in these old runs. The established join is on scan ID, setup ID and selected X-zone ID. New writes use the existing selected-zone snapshot fallback. Legacy final scores cannot be substituted for v38 values. Recovery needs original immutable setup payloads or a separately versioned replay using the original input data and engine. No historical rows were populated by inference.
