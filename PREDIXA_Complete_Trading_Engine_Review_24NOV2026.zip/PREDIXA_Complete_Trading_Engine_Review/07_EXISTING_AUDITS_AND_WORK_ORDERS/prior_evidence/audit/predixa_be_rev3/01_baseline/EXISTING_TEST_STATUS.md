# Existing test status

The default Python lacks application dependencies and produced 45 collection errors. Running a bare `finpro` test collection exposed missing local DB credentials and a network demo that connects during import. The comparable offline command excludes four demos or environment-dependent manual tests and pins the `scripts` namespace to the tested checkout.

The exact pre-change scratch baseline ran 609 tests. 598 passed, 11 failed and 27 warning instances were emitted. The failure node IDs and tracebacks are in [offline.log](offline.log). The same 11 failure node IDs are present in the final run. The previous addendum's 597/12 result is a separate baseline. [Final regression](../08_regression/TEST_RESULTS.md).
