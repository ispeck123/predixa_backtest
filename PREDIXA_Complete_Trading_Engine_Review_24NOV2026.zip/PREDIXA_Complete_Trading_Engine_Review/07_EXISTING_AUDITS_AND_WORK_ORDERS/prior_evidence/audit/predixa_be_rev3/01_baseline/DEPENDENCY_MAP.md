# Dependency map

| Workstream | Data and code path | Acceptance dependency |
| --- | --- | --- |
| EV-1 | Cash, FC, futures and FinProd evaluators plus forensic capture and the two audit resolvers | Covered by controlled tests and historical changed trades. Stop-first is explicit. Existing tick/websocket workflows are outside this OHLC change. |
| EV-2 | Frozen scan/setup/trade SQLite rows and source OHLC → exchange, E regime, A regime and strategy TF → realized R and optional cost/OOS | Immutable matching candles and original run metadata are missing for some recorded trades. Failed scans and open paths require a separate replay. |
| OBS-1 | SetupExtractor → shared setup field mapper → selected X-zone snapshot → SQLite → existing re-score ledger. Fill/exit bar path → completed_excursions → optional trade_observability sidecar | Older runs lack opt-in R metrics and score/pattern snapshots. Full point-in-time replays or original immutable snapshots are required. |
| DATA-1 | Dated contract bars and approved roll schedule → ratio snapshot → staged E/A/X feeds → raw contract execution resolver | Approved active intervals, reference publication times, real calendars, tick sizes, multipliers and cross-roll order/position treatment. |
| DATA-2 | GapModule E/A/X detection and X re-detection → exact spot interval comparison → candidate audit sink and shared setup/export fields | Pinned scope, authorized spot mappings, data availability, exchange interval grid and missing-evidence decision. |
| DATA-3 | Official audit harness with a frozen four-way comparison | All upstream coverage and execution gates plus pinned scope and dataset versions. |
