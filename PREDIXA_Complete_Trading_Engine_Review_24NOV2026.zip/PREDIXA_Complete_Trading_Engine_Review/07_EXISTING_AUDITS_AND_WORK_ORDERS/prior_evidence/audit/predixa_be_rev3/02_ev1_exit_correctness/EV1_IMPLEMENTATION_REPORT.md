# EV-1 exit correctness

The evaluator calculated both boundary hits, required a stop-only bar before returning a loss, and next returned a win whenever the target hit. The same precedence was duplicated in forensic capture, FC, futures, FinProd and the audit resolvers. Each evaluator now delegates precedence to `scripts/bar_exit_policy.py`.

In corrected mode, an already-entered trade whose candle reaches both boundaries returns the existing stop result immediately. It uses the existing stop price, timestamp and quantity. The futures audit resolver clears target realization for that stop. Reprocessing yields the same first terminal result. FinProd and active jobs retain legacy behavior through the unset keyword default. Pending entry still requires the entry price to be in candle range. A dual touch on the fill candle retains the original chronology convention because OHLC provides no sequence before and after entry. Inclusive boundary and existing gap-fill conventions are preserved. The futures audit expiry time exit retains precedence where configured.

Historical evidence includes 32 changed trades, 31 CASH and one NSEFO, with a combined change of −120.096444 gross R across identical verified trade rows. Each changed trade identifies its source candle, OHLC, levels, exit reasons and R. [Before-and-after trades](EV1_STOP_TARGET_BEFORE_AFTER.csv).
