# EV-1 tests

Focused coverage exercises BUY and SELL stop-only, target-only and dual-touch cases, inclusive equality, untouched active positions, pending entries, ambiguous fill candles, gap-open prices, duplicate candle processing, terminal result stability and realized R. Ordinary and forensic evaluators and both FinProd entry points are tested. The captured release regression includes these cases. [Tests](../../../tests/test_predixa_be_rev3_exits.py)
