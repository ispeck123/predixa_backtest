# Rollback

Review the change manifest against the pre-change worktree before removing any rev3 edits. The baseline includes existing staged, unstaged and untracked rev2/addendum changes. Restore only the listed rev3 changes or revert an owner-created rev3 commit on an isolated branch. The baseline digests distinguish previously existing source from new files. Keep audit CSVs, logs and prior artifacts when reverting code.

The work added no migration and wrote no production database records. Existing caller defaults disable all new behavior. For isolated reruns, omit the exit override and the explicit continuous and spot inputs to restore legacy evaluation. [Change manifest](CHANGE_MANIFEST.csv).
