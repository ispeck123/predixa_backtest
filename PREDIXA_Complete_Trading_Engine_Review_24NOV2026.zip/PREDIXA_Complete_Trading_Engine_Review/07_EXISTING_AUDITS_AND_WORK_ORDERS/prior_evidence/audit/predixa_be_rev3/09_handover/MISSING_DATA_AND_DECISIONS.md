# Missing data and decisions

The exact pinned-universe Markdown, approved spot mapping, historical futures contract roll schedule and verified continuous timeline are the primary blockers. The owner also needs to select cross-roll execution and missing-spot handling for research. The local cash and futures files cannot establish that scope on their own. Historical OBS recovery requires original selected-zone and setup-score lineage, or a versioned recreation. [DATA-3 dependency details](../07_data3_final_rescore/DATA3_UNRESOLVED_DEPENDENCIES.md).
