# PREDIXA backend rev3 implementation report

**PARTIAL IMPLEMENTATION — DEPENDENCIES OUTSTANDING**

Work was done in `/tmp/predixa-be-rev2-work` on branch `predixa/be-rev2`, starting at `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`. This preserves the earlier rev2 and OBS addendum changes present in that worktree. The workbook was read in full. The exact referred pinned-universe attachment is unavailable in the inspected workspace. [Baseline and workbook](01_baseline/REPOSITORY_AUDIT.md)

## Implementation

EV-1 adds conservative opt-in precedence for an already-open position touching both levels on the same completed candle. CASH, FC, futures, FinProd, forensic capture and the offline simulators use the same predicate. Fill-bar ambiguity retains the former convention. Current production call sites remain on legacy defaults. DATA-1 adds a ratio snapshot builder and an isolated NSEFO adapter with raw execution prices bounded to the current contract. DATA-2 adds exact futures/spot interval matching, reason handling, a separate candidate audit and wiring into the existing OBS export fields. [File-level changes](09_handover/CHANGE_MANIFEST.csv)

## EV-1 and EV-2 historical results

| Exchange | Archived completed rows | Source-verified rows | Ambiguous exits | Changed exits | Legacy gross R | Corrected gross R | Delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| NSE CASH | 48,003 | 48,003 | 473 | 31 | 13,370.511115 | 13,253.515173 | −116.995942 |
| NSEFO | 96,953 | 23,443 | 157 | 1 | −1,953.629848 | −1,956.730351 | −3.100503 |
| MCX | 4,930 | 78 | 5 | 0 | 121.431857 | 121.431857 | 0.000000 |
| Combined diagnostic scope | 149,886 | 71,524 | 635 | 32 | 11,538.313124 | 11,418.216680 | −120.096444 |

The R columns include only the source-verified rows. There are 141 run/cell rows across 96 exchange/cell keys, including 24 rows with no completed trades. Three run/cell outcomes change. The frozen-setup comparison leaves 78,362 completed records unverified due to unavailable files or a legacy fill, exit or economics mismatch on available inputs. The original stored R is retained for each. The archived runs can overlap in period, so the combined number is a diagnostic aggregate. The established 0.2% round-trip CASH OOS comparison has identical means for all three scoped cells in both modes. Two small official Phase A runs completed 20 ABB scans each with identical scan and setup projections and zero entered trades. [EV-1 examples](02_ev1_exit_correctness/EV1_STOP_TARGET_BEFORE_AFTER.csv) · [EV-2 report](03_ev2_cell_rescore/EV2_VALIDATION_REPORT.md)

## OBS-1

The legacy Core-8 ledger has 20,704 completed trades and 20,704 unique exported rows. Legacy price-space MFE and MAE each have 20,704 values. Persisted R-space MFE/MAE, setup scores and v38 scores each have zero. Selected X-zone relationships are missing for 9,758 rows and patterns for all 20,704. CASH and MCX also lack the requested persisted observability fields in their inspected runs. Core-8 economic hashes match across the original and isolated migrated databases. [Completeness and verification](04_obs1/OBS1_VALIDATION_REPORT.md)

## DATA-1 and DATA-2

The ratio engine was verified on controlled roll chains and raw-price reconciliation. A dated CRUDEOILM overlap audit verified 195 same-time 60m observations across two contracts, with ratios between 0.950958 and 0.982717. No switch meets the requirements for an approved historical roll. Historical acceptance needs an approved dated schedule, coverage and contract rules across the eight requested timeframes.

The spot validator validates or rejects only futures gap candidates. The historical pinned mapping and calendar-aligned spot inputs have not been confirmed. The required 2020-01-01 through 2026-11-18 coverage and historical confirmation/rejection counts remain unknown. The market-data fixtures are engineering tests. [DATA-1](05_data1_continuous_futures/DATA1_CONTINUOUS_FUTURES_VALIDATION.md) · [DATA-2](06_data2_spot_gaps/DATA2_VALIDATION_REPORT.md)

## DATA-3

The four-case integrated pinned-universe replay was blocked. No baseline or corrected integrated R, per-cell differences, or changed-trade counts are asserted. Exact next inputs are the workbook-referenced universe or an owner-confirmed equivalent, verified dated futures and mapped spot interval history, and the roll, execution and missing-spot policies. [Blocked results and dependencies](07_data3_final_rescore/DATA3_FINAL_VALIDATION.md)

## HOLD, KEEP and release

Whitelist contents and sizing are preserved. Q2 hard blocking and embed strict stops remain off. Cross-timeframe region identity and the corporate-action guard remain present, with the arbiter and guard disabled. No production studies, broker orders, scanning processes, production database writes or remote pushes were authorized or performed. [HOLD and KEEP checks](08_regression/HOLD_KEEP_VERIFICATION.md)

The comparable offline suite finished with **714 passed, 11 failed, 0 skipped and 27 warnings**. The exact recovered baseline had 598 passed, the same 11 failures and 27 warnings. Four manual or environment-dependent files were excluded in both runs. [Regression results](08_regression/TEST_RESULTS.md) · [Traceability](09_handover/REQUIREMENTS_TRACEABILITY.csv) · [Artifact hashes](09_handover/artifact-sha256.txt)
