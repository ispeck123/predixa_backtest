# EV-2 frozen-setup re-score

**PARTIAL HISTORICAL COVERAGE.** The same saved setups were resolved against the local OHLC supplied under the archived source filenames. Each comparison requires the first eligible fill time, first exit time, classified outcome, exit price and gross R to match the legacy ledger. A mismatch is retained in the trade ledger with its status and original stored R. Corrected R is computed only after verification. Window end is bounded by the archived completion. Dual touches on fill candles follow the historical convention. This comparison does not recreate failed scans or regenerate setup candidates.

For the 71,524 verified rows, gross R moved from **11,538.313124 to 11,418.216680**. Of 635 verified dual-touch exits, 32 change. Thirty-one are CASH and one is NSEFO. These totals combine diagnostic runs that can overlap in calendar scope, so the combined figure measures this evidence set and is unsuitable as a portfolio statistic. Drawdown is realized R in exit order with a stable trade-ID tie-break. Cell metrics use only verified rows, and the CSV reports the unverified count and original ledger total separately. [Cells](EV2_CELL_RESCORE.csv) · [Trades](EV2_TRADE_LEVEL_DIFF.csv) · [Sources and frozen configs](source_manifest.json).

The existing Phase A launch path also completed 20 ABB scans in each mode with identical settings apart from the exit switch. Both produced seven signals and zero entries under the published gate. This verifies runner and configuration wiring. The historical changed trades come from the frozen-setup comparison. [Phase A run log](../08_regression/phase-a.log).

## Reproduce

Run from the linked worktree using the `finpro` interpreter.

```bash
python -m audit.predixa_be_rev3.rescore_frozen /home/ispeck/STOCK_PROJECT/STP_LATEST /tmp/predixa-rev3-evidence
```

The historical sources include 48,003 CASH, 96,953 NSEFO and 4,930 MCX completed records. Of those, 48,003, 23,443 and 78 respectively matched the currently available candle paths. Full EV-2 acceptance requires the archived futures input versions or a separately authorized whole-scope replay with reconciled configuration. Gross R comes from the ledger's established price and initial-risk model. No uniform cost schedule was applied to the combined historical comparison.

The output enumerates 141 exchange/run/cell rows across 96 distinct exchange and cell keys. Twenty-four rows have scanned cases and zero completed trades. Ninety-one run/cell rows have verified comparisons and three changed. CASH UP/UP/25 changed 27 trades at −101.748453 R. CASH UP/UP/5 changed four at −15.247489 R. NSEFO UP/SW/5 changed one at −3.100503 R.

The existing scoped CASH edge check applied the established 0.2% round-trip cost and 2025-11-01 split to the completed CASH run. OOS net mean R was unchanged at 1.019 for SW/SW/2, 0.474 for SW/SW/6 and 1.685 for SW/SW/25. This comparison applies to these three existing CASH cells. It makes no integrated futures deployment claim. [Legacy OOS](edge_repro_baseline.txt) · [Corrected OOS](edge_repro_stop_first.txt).
