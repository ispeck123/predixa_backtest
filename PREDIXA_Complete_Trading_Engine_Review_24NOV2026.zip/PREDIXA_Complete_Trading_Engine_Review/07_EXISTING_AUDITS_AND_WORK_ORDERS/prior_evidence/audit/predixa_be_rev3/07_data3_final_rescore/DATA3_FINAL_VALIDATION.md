# DATA-3 pinned-universe re-score

**BLOCKED.** Final scoring requires the exact approved pinned-universe Markdown, historical candles and both upstream data policies. EV-1 historical evidence and partial EV-2 totals describe frozen setups drawn from saved runs. They cannot establish an integrated rev3 outcome.

The planned comparisons are legacy, EV-1, EV-1 plus DATA-1, and EV-1 plus both data features. The existing futures worker accepts the isolated stop-first configuration and candidate validator. The continuous adapter supplies detection files and raw in-contract execution bars on approved inputs. The independent legacy/corrected Phase A command succeeded on a limited ABB scan smoke. No approved four-way historical run was executed. The required files record blocked status with no asserted baseline R, corrected R, or trade counts. [Open dependencies](DATA3_UNRESOLVED_DEPENDENCIES.md).
