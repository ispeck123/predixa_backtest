# DATA-3 unresolved dependencies

1. Provide the exact workbook-referenced Markdown or a confirmed equivalent manifest containing instruments, exchanges and contract identifiers.
2. Supply approved revisioned dated futures and spot datasets for 2020-01-01 through 2026-11-18. Include mappings, exchange session calendars, completed interval labels, publication times, tick and multiplier history, and checksums.
3. Approve the roll selection schedule and overlap reference availability. Specify completion and aggregation for higher-timeframe candles crossing a roll, and treatment of live working orders or positions during a contract change in the simulator.
4. Approve handling of unavailable spot evidence for the pinned replay. Decide eligible spot price adjustment basis without enabling the pending corporate-action guard.
5. Reconstruct the missing historical source versions or define the accepted rescore scope, and regenerate the OBS lineage where available. Freeze the cost assumptions and official IS/OOS cut before starting the four comparisons.
