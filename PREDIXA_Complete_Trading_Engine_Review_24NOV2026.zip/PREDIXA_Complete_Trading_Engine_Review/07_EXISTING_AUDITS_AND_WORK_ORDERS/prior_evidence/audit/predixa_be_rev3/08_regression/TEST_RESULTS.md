# Test results

Comparable baseline **598 passed, 11 failed, 0 skipped**. Final **714 passed, 11 failed, 0 skipped**. Both emitted 27 warning instances. The 116 additional tests passed and no failure node changed. The four excluded files are manual/demo or environment-dependent imports. Two have external-service side effects, one opens a database during import, and one requires local candle files. The documented offline wrapper preserves the normal automation suite and pins namespace resolution to the isolated checkout.

```bash
DB_PASSWORD=offline DB_HOST=127.0.0.1 PYTHONHASHSEED=0 python -m audit.predixa_be_rev3.run_offline_tests
```

The original focused run and unpinned collection attempts are retained as diagnostic logs. The exact baseline and final comparable logs establish the regression result. [Baseline](../01_baseline/offline.log) · [Final log](final.log) · [JUnit](final.xml) · [Phase A smoke](phase-a.log).
