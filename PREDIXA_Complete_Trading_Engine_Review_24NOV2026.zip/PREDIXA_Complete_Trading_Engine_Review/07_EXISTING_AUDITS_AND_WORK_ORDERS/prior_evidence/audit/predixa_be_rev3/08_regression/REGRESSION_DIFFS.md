# Regression comparison

The exact recovered baseline tracked-diff digest matches the initial checkout fingerprint. Comparing failure node IDs shows no additions or removals. Existing failures cover archived input paths, derivative ingestor fixtures, MCX PAPER observation fixtures, OMS winner handling, trend shape-filter expectations, and preserved wet-run attribution files. The final test log contains their tracebacks. No pre-existing tests were edited.

The repeated frozen-trade run reproduced the trade-level and changed-trade CSV checksums before additional cell summary columns were added. The final cell file includes scan counts, published gate tier and unverified counts. Timing data and ephemeral run IDs are excluded from the Phase A economic projection. The unchanged-source checks compare full bytes. [Hash inventory](preserved-files.csv) · [Artifact checksums](../09_handover/artifact-sha256.txt).
