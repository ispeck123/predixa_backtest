# HOLD and KEEP verification

The active and proposed whitelist tables, sizing module, region identity, corporate-action guard, previous database schema and storage writers match the recovered starting baseline where listed in the hash inventory. The Q2 hard block, embed strict stop, cross-TF arbiter and corporate-action guard remain disabled. MCX policy retains its operational deny. No eligibility, sizing, broker routing or production database settings were changed. [Hash inventory](preserved-files.csv) · [Feature flags](REV3_FEATURE_FLAG_MATRIX.md).
