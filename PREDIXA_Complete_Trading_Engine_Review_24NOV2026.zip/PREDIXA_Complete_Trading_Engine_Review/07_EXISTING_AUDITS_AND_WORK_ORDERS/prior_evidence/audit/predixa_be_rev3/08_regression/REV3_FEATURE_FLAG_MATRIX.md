# Feature flags

| Setting | Configuration source and affected path | Default / checked baseline | Replay use and economics | Production activation |
| --- | --- | --- | --- | --- |
| `stop_first` | Keyword in OHLC evaluators and forensics | False | True for corrected comparison. May change exit and gross R. | Existing callers use the default. |
| `bar_exit_stop_first` | `scripts.models.Config`, used by audit replay workers | False | True in corrected Phase A override. Stays outside detection configuration. | Audit-only override. |
| Continuous replay | Explicit `execute_continuous_task` adapter and approved input grids | Off by absence | Code tests use supplied frames. May alter setups and economics. | No live routing activation. |
| Spot gap validation | Explicit validator given to futures setup and GapModule | Off by absence | Code tests use verified fixture intervals and explicit missing-data policies. May suppress candidates. | No production caller activates it. |
| `trade_observability_wiring_enabled` | Existing Config and audit storage | False | Archived audit reads only. Opt-in writer regression tested separately. No economic effect. | Unchanged. |
| `realized_r_cell_whitelist_enabled` | Existing Config and gate | False | OFF in all rev3 runs. | HOLD respected. |
| `range_midcurve_hard_block` | Existing Config and Q2 | False | OFF in all rev3 runs. | HOLD respected. |
| `embed_strict_stop` | Existing Config and risk/target setup | False | OFF in all rev3 runs. | HOLD respected. |
| `cross_tf_region_dedup_enabled` | Existing Config and region identity / persistence | False | OFF in all rev3 runs. | Arbiter awaits approval. |
| `corp_action_gap_guard_enabled` | Existing Config and cash gap guard | False | OFF in all rev3 runs. | Guard awaits historical evidence. |
