# Flag-off compatibility

The comparable offline suite reproduces the exact baseline failure set. Flag-off exit paths retain the original API, order of returns and timestamps. Futures clears the target-realization field only when a corrected stop-first exit wins precedence. The official ABB smoke has identical scan and setup projections when the stop-first override is enabled. It contains no eligible entries, so trade parity for this cohort is vacuous. [Smoke hashes](phase-a-economic-hashes.json).

The frozen-ledger path verifies 71,524 legacy results against current candles. Unverified legacy-path rows are recorded openly and excluded from prospective deltas. Data flags were disabled throughout the historical EV-2 comparison. HOLD and KEEP hashes are recorded separately. [Preserved files](preserved-files.csv) · [Frozen trade differences](../03_ev2_cell_rescore/EV2_TRADE_LEVEL_DIFF.csv).
