# DATA-2 source provenance

The shared checkout contains broker-derived cash OHLC CSVs under `data/indian_stock_data/latest_data_csv` and a local `lake/warehouse/nse_cash/bars` cache. These are candidate sources. The cash cache file counts by required timeframe are in the coverage matrix. No approved futures/spot mapping or instrument grid is available to attribute the files to the rev3 work-order universe. MCX comparison instruments require explicit approval. A local cache filename cannot establish data lineage or support a market-level coverage claim. [Coverage inventory](DATA2_SPOT_COVERAGE_MATRIX.csv).

The owner mapping must identify futures exchange, underlying and exact contract identity, spot venue and source instrument ID, calendar, timezone, bar label, interval availability timestamp, native or aggregated provenance, source checksum, adjustment basis and mapping-effective dates.
