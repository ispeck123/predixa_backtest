# Source schema locations

Review original paths under the source section. The MySQL DDL is in `scripts/db_migrations/`, ORM models in `shared/db/db_model.py`, audit SQLite DDL in `audit/fresh_trend_backtest/storage/schema.py`, and the audit writer in `audit/fresh_trend_backtest/storage/sqlite_storage.py`. The SQL and ORM contract indexes provide references without creating duplicate schema copies.
