# Database schema reference

### MySQL and candidate records

`shared/db/dbconn.py::DBConnection` uses SQLAlchemy over PyMySQL. The source expects `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_SCHEMA` and declares `DB_PORT` in configuration. Inspect the connection constructor for the exact DSN interpolation, which omits explicit port here. ORM definitions in `shared/db/db_model.py` contain identifiers, execution provenance, candidate status, and trade/order linkage. `FuturesMaster`, `Ind_StockMaster` and `CommoditiesMaster` are inventory/master input. `TradeSignal` stores the signal identity and payload. CASH links to `Order` and `OMSOrderBucket`, NSEFO to `Future_Order` and `OMSOrderBucketFuture`, MCX to `Commodity_Order` and `OMSOrderBucketCommodity`. Follow source-level joins using `trade_id`, symbol, expiry and mode/source as applicable. Treat the per-segment writer and SQL migration as review authorities for logical joins, uniqueness and physical schema details.

The paper DB is an independent MySQL schema with required `PREDIXA_PAPER_DB_` inputs via `scripts/paper_db_config.py`. The NSEFO paper migration describes the reduced signal/order/bucket contract. The included phase provenance and MCX idempotency SQL describe the segment-specific additions. MCX alerts use logical IDs, revisions and a unique event identity. Discord delivery references the alert event ID with a foreign key. No migration was applied.

### SQLite and review telemetry

`finprod.sqlite` is the runtime token/object store accessed by SqliteDict. The separate audit SQLite schema joins run → task → scan. The scan owns regime, zone and setup snapshots, a simulated trade links to its setup, and per-trade excursion metrics link to the simulated trade. `audit/fresh_trend_backtest/storage/schema.py` supplies DDL and `sqlite_storage.py` supplies the active selected-tree writer. OBS-1 additive columns/migration/export helpers belong to the historical work described separately. Candidate rejection information resides in scanner diagnostic/status output and logs, with different emit sites per scanner.
