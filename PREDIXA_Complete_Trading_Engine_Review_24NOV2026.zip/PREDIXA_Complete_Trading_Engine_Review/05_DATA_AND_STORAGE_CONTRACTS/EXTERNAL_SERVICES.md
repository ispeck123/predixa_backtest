# External services

| Service | Role and connection contract |
|---|---|
| FYERS history, master and ticks | History responses and expiry-symbol data feed CSV updaters. The SDK and token handler use FYERS keys from `fyers_config_credentials` and the private SqliteDict store. Socket service is declared externally under PM2. |
| SQL services | MySQL via the primary DB settings and the separately configured PAPER schema. ORM creation does not prove the deployed schema is migrated or writable. |
| Redis, push and Discord | Ancillary quotes/alert paths can use Redis and alert-worker configuration. Discord delivery needs the private webhook, and Web Push needs application key material. The sanitized environment template describes operator inputs. |
| Kite, Sharekhan and other data adapters | Compatibility/broker and related history utilities appear through broader service imports. Review the conditional call sites and contract configuration. Sanitized copies require secure internal handover if those integration topics are in scope. |
| Dagster and HTTP workers | Dagster Definitions plus in-process jobs for scheduled scanners. FastAPI service entrypoints are referenced by Uvicorn/Gunicorn. No process or instance was started. |
| Serialized models | Optional inference/modeled routes reference locally fitted Python pickle artifacts through `stock_model_config`. The standard wet-run and graduated signal writers populate prediction fields with NA/0 for the routes reviewed here. |
| Research assets | Historical candle series, expiry manifests, external spot series and approved audit inputs are separate controlled datasets. |
