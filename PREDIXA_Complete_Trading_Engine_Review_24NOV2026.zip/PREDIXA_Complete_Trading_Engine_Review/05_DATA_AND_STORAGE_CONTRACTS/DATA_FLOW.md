# Market data and storage flow

FYERS history and contract/symbol master data enter through updater handlers. The updater prepares rolling, chronological OHLCV before scanner reads. Upstream `normalize_fyers_ohlc` rejects malformed history on configured paths and `safe_replace_csv` publishes atomically. Candles usually enter setup generation as per-symbol or per-contract CSV, not as relational candle tables. Order-state evaluation reads the processed candle stream. Alert snapshot persistence and independent ticks form an adjacent publishing flow.

`DATA_DEPENDENCIES.csv` lists reviewed contracts. `RESOURCE_REFERENCES.csv` indexes literal paths; formatted names such as `<symbol>_<expiry>_<frame>.csv` appear in the segment maps. Files whose path is provided by CLI, environment or manifests require an approved handover.
