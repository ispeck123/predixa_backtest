# Source revision and worktree

| Item | Verified local evidence |
|---|---|
| Selected repository root | `/home/ispeck/STOCK_PROJECT/STP_LATEST` |
| Branch and commit | `prod` at `9ac9ecb734f0f4bb1dabd9bb5a3ebe7bb052274c` |
| Snapshot | 24 November 2026 IST, working-tree bytes compared with the verified opening baseline |
| Branch relation | Local `prod` is two commits ahead of the local `origin/prod` tracking ref. No remote fetch. |
| Track state | No staged changes. Modified files were PID files, CASH wet-run output JSONL and the historical audit gitlink. Untracked Rev2/OBS-1 reports are historical evidence. No modified tracked engine source was identified. |
| Historical worktree | `/tmp/predixa-be-rev2-work`, branch `predixa/be-rev2`, base `7ac0a972d3e89e7beeb1743391e2cfbedbdcd046`. Its source has modified and untracked Rev2/OBS-1/Rev3 files. Only selected Rev3 Markdown evidence is carried under `prior_evidence`. |
| Audit worktree | `.audit_worktrees/cash_signature_614`, detached at `6140a07046b72ced7377edcf4ae1c9d59e228010`. The index stores a gitlink and `git submodule status` reports a missing .gitmodules mapping. It is a historical registered worktree with no identified runtime import. |
| Service and schedule evidence | `apps/pipelines/stock_process.py::defs` defines all three scanner routes. It has a checkout-specific path insertion. Shell and Compose files point to `apps.backend.main:app` and `apps.finprod_backend.app:app`; Compose also has MCX zone worker services. |
| Deployed revision | UNKNOWN. No scanner/backend process was visible in the review execution namespace. Dagster run state, container image revision and deployed overrides could not be verified. |

The two local commits cover updater and reconciliation code as well as tracked evidence and artifacts. The older historical branch and tracking ref share the same base commit. See the three execution maps for segment-specific entrypoints. Worktree before/after evidence is checked locally during verification.
