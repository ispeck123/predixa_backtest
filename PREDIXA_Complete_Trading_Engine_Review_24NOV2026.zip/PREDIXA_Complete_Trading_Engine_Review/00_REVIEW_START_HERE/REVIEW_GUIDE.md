# Review guide

1. Check the selected branch and local-versus-deployed distinction in SOURCE_REVISION.
2. Trace upstream inputs, core decisions and persistence in each segment map.
3. Inspect the rule CSV and function/call-site index, then open the corresponding source.
4. Check defaults, external contracts and historical limitations before interpreting outputs.
5. Verify the ZIP and repeat the sanctioned synthetic checks using the offline harness.
