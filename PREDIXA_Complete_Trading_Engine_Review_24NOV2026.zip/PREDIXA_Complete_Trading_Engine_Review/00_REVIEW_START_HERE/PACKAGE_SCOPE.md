# Package scope

The current checkout supplies one source snapshot for CASH, NSEFO and MCX, including scanner and API paths, upstream candle preparation, runtime gates and relevant candidate/exit, data contract and replay support. Registered but inactive-by-default jobs remain inspectable. Historical research and prior branch evidence are marked separately. The integrity inventory describes 368 repository source paths and the prior-evidence paths. Project Git internals, worktree copies, dumps, logs, oversized datasets, live environment files and serialized models are excluded.

Deployment bootstraps can import other service routes while loading. The segment matrix shows scanner/API/updater seed closure separately from deployment bootstrap reachability. It measures static reach, including conditional and function-local imports. Co-imported modules may not make trading decisions.
