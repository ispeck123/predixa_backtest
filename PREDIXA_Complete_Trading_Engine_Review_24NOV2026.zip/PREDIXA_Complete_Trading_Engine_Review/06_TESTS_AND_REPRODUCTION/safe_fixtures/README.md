# Synthetic OHLC fixtures

The three scenarios use deterministic, invented OHLCV values. Names stand in for segment-specific instrument identities. They contain 130 observations per timeframe before slicing and contain no provider or customer data. The harness regenerates the same fixtures in scratch space, loads them through staged source and records resource reads and source imports. Runtime traces capture the resulting gate and the MCX E1 boundary count.
