# Safe execution commands

Run from the extracted `PREDIXA_Complete_Trading_Engine_Review` directory and use an interpreter with the documented libraries. Use the actual absolute original repository path as `origin` if it exists on your host. Keep it separate from the extraction.

```bash
stage="$PWD"
origin="/home/ispeck/STOCK_PROJECT/STP_LATEST"
review_python="/absolute/path/to/python"
scratch="$(mktemp -d)"
for segment in CASH NSEFO MCX TESTS; do
  mkdir "$scratch/$segment"
  args=()
  if [[ "$segment" != TESTS ]]; then args+=("$segment"); fi
  env -i PATH=/usr/bin:/bin TZ=Asia/Kolkata "$review_python" -I -B     "$stage/06_TESTS_AND_REPRODUCTION/offline_review.py"     "$stage/02_COMPLETE_ENGINE_SOURCE" "$scratch/$segment" "$origin" "${args[@]}"
done
```

This runs only targeted fixtures and selected tests in scratch. Scanner CLIs, service bootstrap, production migrations and full historical replay were outside the execution scope.
