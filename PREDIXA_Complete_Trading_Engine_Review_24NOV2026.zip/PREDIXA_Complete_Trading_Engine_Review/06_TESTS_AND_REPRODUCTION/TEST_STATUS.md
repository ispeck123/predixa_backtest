# Test status

**Latest focused result** — 53 passed, 5 warnings in 1.01s. Failed 0, skipped 0. Warnings are SQLAlchemy and Pydantic API deprecations.

Executed with the commands in [Safe execution commands](SAFE_EXECUTION_COMMANDS.md). Focused files:

- `tests/test_tf_regime_gate_by_exchange.py`
- `tests/test_consumed_zone_dedup.py`
- `tests/test_futures_readonly_scanner.py`
- `tests/test_mcx_e1_session_boundary.py`
- `tests/test_interval_stitching.py`

All three synthetic CSV cases passed the setup-engine/formatter assertions and isolated scanner assertions. The CASH and NSEFO scanner tests use supplied jobs and disallow persistence. The MCX scanner must stop at its existing hold before any injected engine or persistence call. CASH and NSEFO exercised their distinct filenames and wrapper paths. MCX additionally proved session IDs and enforced DENY. No fixture emitted a BUY/SELL, so the fixture result does not validate live candidate writes. The unit cases use substitutes for candidate flows and go through isolated tests. The final extracted synthetic cases made no attempts to access the original checkout. The focused tests triggered the scratch-write guard. Initial harness runs used a runner stored in the workspace and blocked inspection of checkout paths. No network or subprocess activity was observed.

During harness setup an initial fixture generated stale intraday bars, and an import-isolation hook initially hid distribution metadata. Both harness issues were corrected. A synthetic empty X input did expose the early last-row access. The controlled run was rerun with bars inside the two-year window. Earlier Rev3's historical 714 passed and 11 baseline-matching failures are separate evidence, on a different working tree. Full replay and the broad suite were not run.
