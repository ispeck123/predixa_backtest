# Reproduction guide

Extract the ZIP in a temporary review directory and run the included harness with the source folder and fresh scratch directory. The separately supplied origin path, when relevant, blocks import resolution from the production checkout. The isolated run uses fake DB settings and denies socket, subprocess and writes outside scratch through Python audit hooks. The harness does not import the Dagster service definition. Native external clients, production DB and broker credentials are unnecessary for the selected runs. Use the commands in SAFE_EXECUTION_COMMANDS.
