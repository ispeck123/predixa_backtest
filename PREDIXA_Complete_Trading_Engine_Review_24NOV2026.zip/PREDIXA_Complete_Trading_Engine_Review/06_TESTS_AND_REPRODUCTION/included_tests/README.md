# Included tests

The source tree preserves selected test files in `02_COMPLETE_ENGINE_SOURCE/tests/`, including regression and audit references. The focused executed set is listed in TEST_STATUS. Other staged tests can rely on external fixtures and legacy source assumptions. Only the selected offline commands were used.
