"""Run fixed offline cases from a freshly extracted review tree."""
from contextlib import redirect_stdout
import csv
from datetime import datetime, timedelta
import io
from importlib.machinery import PathFinder
import json
import os
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
scratch = Path(sys.argv[2]).resolve()
original = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else None
assert scratch.is_dir() and source.is_dir() and source != scratch
assert not original or not source.is_relative_to(original)
os.chdir(scratch)
sys.path.insert(0, str(source))
sys.dont_write_bytecode = True
os.environ.update({
    'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
    'PYTHON_DOTENV_DISABLED': '1',
    'DB_HOST': 'offline.invalid',
    'DB_USER': 'offline',
    'DB_PASSWORD': 'offline',
    'DB_SCHEMA': 'offline',
    'MPLCONFIGDIR': str(scratch / 'matplotlib'),
    'XDG_CACHE_HOME': str(scratch / 'cache'),
})
import dotenv
# Older python-dotenv versions do not honor PYTHON_DOTENV_DISABLED.
dotenv.load_dotenv = lambda *a, **k: False
class IsolatedFinder:
    find_distributions = staticmethod(PathFinder.find_distributions)
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        search = sys.path if path is None else path
        filtered = [item for item in search if not original or not Path(item).resolve().is_relative_to(original)]
        return PathFinder.find_spec(fullname, filtered, target)

sys.meta_path[sys.meta_path.index(PathFinder)] = IsolatedFinder()
current = set()
opened_source = set()
denied = set()
def audit(event, args):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'socket.gethostbyname', 'socket.sendto',
                 'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'os.forkpty'}:
        denied.add(event)
        raise PermissionError('Offline review blocks ' + event)
    if event in {'open','sqlite3.connect'} and isinstance(args[0], (str, bytes, os.PathLike)):
        name = os.fsdecode(args[0])
        if name == ':memory:':
            return
        if name.startswith('file:'):
            name = name[5:].partition('?')[0]
        path = Path(name).resolve()
        if original and path.is_relative_to(original):
            denied.add('original checkout access')
            raise PermissionError('Offline review blocks original checkout access')
        if event == 'sqlite3.connect' or (len(args) > 2 and args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT)):
            if not path.is_relative_to(scratch) and path != Path('/dev/null'):
                denied.add('write outside scratch')
                raise PermissionError('Offline review blocks writes outside scratch')
        if path.is_relative_to(source) and path.suffix == '.py':
            opened_source.add(path.relative_to(source).as_posix())
        if path.is_relative_to(scratch) and path.suffix == '.csv':
            current.add(path.relative_to(scratch).as_posix())
sys.addaudithook(audit)

def first_party():
    found = {}
    for name, module in list(sys.modules.items()):
        if name in {"__main__", "__mp_main__"}:
            continue
        filename = getattr(module, '__file__', None)
        if not isinstance(filename, str):
            continue
        path = Path(filename).resolve()
        if original and path.is_relative_to(original):
            raise AssertionError(f'Imported code from original working tree: {name} ({path.name})')
        if path.is_relative_to(source):
            found[name] = path.relative_to(source).as_posix()
    return set(found.values()) | opened_source

def write_candles(path, frame):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['open','high','low','close','qty','tradeDate'])
        base = datetime(2025, 1, 2, 9)
        for i in range(130):
            if frame == 'weekly':
                when = base + timedelta(weeks=i)
            elif frame == 'daily':
                when = base + timedelta(days=i)
            elif frame == 'two_forty':
                when = base + timedelta(days=i//4, hours=(i%4)*4)
            else:
                when = base + timedelta(days=i//2, hours=14*(i%2))
            price = 100 + (i % 16 if i % 32 < 16 else 16-i % 16)
            writer.writerow([price,price+2,price-2,price+0.25,1000+i,when.strftime('%d/%m/%Y %H:%M:%S')])

if len(sys.argv) > 4:
    from scripts import setup_engine_new as engine
    seg = sys.argv[4]
    config = engine.stock_data_dir_config
    location = scratch / seg
    expiry = '27112026'
    cases = {
        'CASH': ('RELIANCE', 25, ['weekly','daily','seventy_five'], None, 'indian_stock_data_dir'),
        'NSEFO': ('RELIANCE', 25, ['weekly','daily','seventy_five'], True, 'indian_stock_future_data_dir'),
        'MCX': ('GOLDM', 4, ['daily','two_forty','sixty'], False, 'indian_commodity_data'),
    }
    symbol, tf, stack, is_future, path_attr = cases[seg]
    setattr(config, path_attr, str(location))
    for frame in stack:
        name = f'{symbol}_{frame}' if is_future is None else f'{symbol}_{expiry}_{frame}'
        write_candles(location / 'latest_data_csv' / (name+'.csv'), frame)
    current.clear()
    cutoff = datetime(2026,11,20,16)
    with redirect_stdout(io.StringIO()):
        raw = engine.process_setup(symbol, stack, cutoff) if is_future is None else engine.process_setup_fc(symbol, stack, expiry, cutoff, is_future)
        assert isinstance(raw,dict) and not raw.get('data_insufficient'), 'engine failed or fixture insufficient'
        formatted = engine.format_calculate_setup_response(raw, stock_name=symbol, time_fr=tf,
            last_d_time=cutoff, exp_num=expiry if is_future is not None else None,
            is_future=is_future, is_cash=is_future is None)
    assert raw['trend_context'] is not None and len(current) == 3
    assert (raw['e1_session_boundary_count'] > 0) == (seg == 'MCX')
    write_attempted = []
    def forbidden_writer(*args, **kwargs):
        write_attempted.append(True)
        raise AssertionError('Fixture scanner unexpectedly attempted persistence')

    with redirect_stdout(io.StringIO()):
        if seg == 'CASH':
            from scripts import cash_wetrun_scanner as scanner
            scanner.get_available_stock_syms_by_timeframe = lambda _: [symbol]
            scanner.insert_trade_signals = scanner.insert_order_and_oms_bucket = forbidden_writer
            output = location/'review_scan.jsonl'
            job = scanner.ScanJob([stack], tf, cutoff, str(output), False)
            scan = scanner.SetupScannerOrchestrator().run(job)
            record = json.loads(output.read_text())
            assert scan['total_jobs'] == scan['ok'] == 1 and scan['failed'] == 0
            scanner_status = record['status']
        elif seg == 'NSEFO':
            from scripts import futures_graduated_live_scanner as scanner
            job = scanner.FuturesScanJob(symbol, expiry, expiry, tf, stack, cutoff,
                contract='NSE:RELIANCE26NOVFUT', lot_size=1, execution_mode='PAPER', tick_size=0.05)
            scan = scanner.FuturesGraduatedLiveReadonlyScanner(
                job_provider=lambda *args: [job], signal_inserter=forbidden_writer,
                candidate_persister=forbidden_writer).run(timeframe_ids=[tf], write_files=False)
            assert scan.total_jobs == scan.processed == 1 and not scan.candidates and not scan.errors
            scanner_status = scan.diagnostics[0]['scan_status']
            assert scanner_status == 'NO_SETUP'
        else:
            from scripts import mcx_graduated_live_scanner as scanner
            job = scanner.MCXScanJob(symbol, expiry, tf, stack, cutoff, 'PAPER')
            scan = scanner.MCXGraduatedLiveScanner(
                engine=forbidden_writer, formatter=forbidden_writer, signal_inserter=forbidden_writer,
                candidate_persister=forbidden_writer, candidate_reconciler=forbidden_writer)
            records = scan.run([job], location/'review_scan.jsonl')
            scanner_status = records[0]['status']
            assert len(records) == 1 and scanner_status == 'MCX_EXECUTION_BLOCKED'
    assert not write_attempted
    outcome = dict(scanner_status=scanner_status, segment=seg, symbol=symbol, strategy_tf=tf, e=formatted['e_regime'], a=formatted['a_regime'],
        gate=formatted['gate_tier'], setup_sides=sorted(set(formatted)&{'BUY','SELL'}),
        e1_boundaries=raw['e1_session_boundary_count'], resources=sorted(current), first_party=sorted(first_party()), denied=sorted(denied))
    (scratch/f'{seg}.json').write_text(json.dumps(outcome,indent=2)+'\n')
else:
    import pytest
    tests = [
        'test_tf_regime_gate_by_exchange.py',
        'test_consumed_zone_dedup.py',
        'test_futures_readonly_scanner.py',
        'test_mcx_e1_session_boundary.py',
        'test_interval_stitching.py',
    ]
    result = pytest.main(['-q', '-p', 'no:cacheprovider', '--rootdir='+str(source), '--basetemp='+str(scratch/'test_tmp'),
                         *[str(source/'tests'/p) for p in tests]])
    (scratch/'TEST_MODULES.json').write_text(json.dumps(dict(first_party=sorted(first_party()),denied=sorted(denied)),indent=2)+'\n')
    raise SystemExit(result)
