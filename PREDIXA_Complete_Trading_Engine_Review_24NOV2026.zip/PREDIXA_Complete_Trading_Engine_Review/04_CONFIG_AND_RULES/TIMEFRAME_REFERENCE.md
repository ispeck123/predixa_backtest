# Timeframe reference

From `shared/config/settings.py::stock_logic_config`. The shared setup uses the first, second and last elements as E/A/X. Strategy TF IDs key the permission tables and are distinct from executable labels. Registered, configured, and approved timeframes differ.

| Setting | Configured order |
|---|---|
| `TIME_FRAMES_1` | monthly → weekly → daily |
| `TIME_FRAMES_2` | weekly → daily → sixty |
| `TIME_FRAMES_3` | daily → seventy_five → sixty → fifteen |
| `TIME_FRAMES_4` | monthly → weekly → one_twenty_five |
| `TIME_FRAMES_5` | weekly → daily → one_twenty_five |
| `TIME_FRAMES_6` | daily → one_twenty_five → twenty_five |
| `TIME_FRAME_EXE_1` | monthly → weekly → daily |
| `TIME_FRAMES_25` | weekly → daily → seventy_five |
| `TIME_FRAME_EXE_25` | weekly → daily → seventy_five |
| `TIME_FRAME_EXE_2` | weekly → daily → sixty |
| `TIME_FRAME_EXE_3` | daily → sixty → fifteen |
| `TIME_FRAME_EXE_4` | monthly → weekly → one_twenty_five |
| `TIME_FRAME_EXE_5` | weekly → daily → one_twenty_five |
| `TIME_FRAME_EXE_6` | daily → one_twenty_five → twenty_five |
| `FUTURE_TIME_FRAME_1` | monthly → weekly → daily |
| `FUTURE_TIME_FRAME_25` | weekly → daily → seventy_five |
| `FUTURE_TIME_FRAME_2` | weekly → daily → sixty |
| `FUTURE_TIME_FRAME_3` | daily → seventy_five → sixty → fifteen |
| `FUTURE_TIME_FRAME_4` | weekly → daily → one_twenty_five |
| `FUTURE_TIME_FRAME_5` | daily → one_twenty_five → twenty_five |
| `COMMODITY_TIME_FRAME_1` | monthly → weekly → daily |
| `COMMODITY_TIME_FRAME_2` | weekly → daily → two_forty |
| `COMMODITY_TIME_FRAME_3` | daily → two_forty → one_twenty |
| `COMMODITY_TIME_FRAME_4` | daily → two_forty → sixty |
| `COMMODITY_TIME_FRAME_5` | weekly → daily → sixty |
