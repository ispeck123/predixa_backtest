# Offline configuration example

The harness constructs synthetic data paths and dummy DB inputs inside its isolated process. It disables dotenv, sockets and subprocess launch. The example contains no provider keys, authorization toggles or deployment environment values. See the reproduction guide for the exact executable command.
