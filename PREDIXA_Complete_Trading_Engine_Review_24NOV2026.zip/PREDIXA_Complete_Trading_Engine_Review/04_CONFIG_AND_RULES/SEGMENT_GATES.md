# Segment gates

- CASH CORE cells are SW/SW/2, SW/SW/6, SW/SW/25 and SW/UP/6. UP/SW/2 and UP/SW/5 are MARGINAL. TF1 is excluded. Wet-run sizing can retain a one-share unit for a permitted marginal cell.
- NSEFO permits SW/SW/25 CORE. The PAPER Tier-0 governor separately checks BUY, the eligible cell and execution metadata. Audit-only bypass is isolated to replay.
- MCX is held before engine invocation in the trade scanner, and the formatter gate independently denies the exchange. Its dormant table retains the GOLDM/CRUDEOILM universe, with empty permits.
- `ExchangeGate.tf_set` is descriptive in this revision because the explicit membership condition is commented out. The implemented per-cell/default/excluded-TF logic determines the outcome. Unconfigured exchange keys return PERMIT in this helper. The reviewed formatters pass explicit recognized keys.
- The setup-flow diagram comment omits G11 in its short enumeration. `HardGateChecker.check_gates_pre_rr` executes G11 first and includes hard G4 freshness and conditional G6b handling. This is one reason to review actual predicates with the rule index.
