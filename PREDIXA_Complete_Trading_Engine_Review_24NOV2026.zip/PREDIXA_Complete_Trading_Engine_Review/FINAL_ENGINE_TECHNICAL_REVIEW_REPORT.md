# PREDIXA final engine technical review

## 1. Executive summary

**ENGINE REVIEW PACKAGE READY — DOCUMENTED LIMITATIONS**

The source snapshot is the local `prod` checkout at `9ac9ecb734f0f4bb1dabd9bb5a3ebe7bb052274c`, as of 24 November 2026 IST. The package contains 368 files from the selected source tree, including 316 Python files, and 69 separately labeled prior reports. CASH and NSEFO synthetic cases reached the shared formatter and received CORE cell results. MCX independently exercised E1 session handling and received DENY. Focused tests reported 53 passed, 5 warnings in 1.01s. The live deployed commit, operational flags and production service behavior remain unverified.

## 2. Source revision and environment

Local `prod`, commit `9ac9ecb734f0f4bb1dabd9bb5a3ebe7bb052274c`. The reviewed filesystem is `/home/ispeck/STOCK_PROJECT/STP_LATEST`. Source provenance, active definition references, worktrees and status are in [Source revision](00_REVIEW_START_HERE/SOURCE_REVISION.md). The local tree is two commits ahead of `origin/prod`; deployment revision and effective overrides are unknown.

## 3. Scope

The three independent scanner and preview paths are included from the same checkout along with segment-specific updater paths, shared engine, storage and relevant research. Historical Rev2/OBS-1/Rev3 reports are context. Production dumps, credentials, broker activity and bulk history are outside scope.

## 4. Architecture

The shared engine consumes completed E/A/X candles, qualifies regular and gap zones, derives context, selects/ranks execution zones and returns at most one payload per direction before the side and formatter gates. Scanners consume the result and decide emission and persistence. [Architecture and call graphs](01_ENGINE_ARCHITECTURE/COMPLETE_ARCHITECTURE.md).

## 5. CASH engine

The wet-run uses equity OHLC, a fixed 24-symbol scope, frozen TF stacks, the CASH permission table and consumed-zone deduplication before sizing and signal/order persistence. The general scanner and HTTP preview paths are also covered. [CASH execution map](03_SEGMENT_EXECUTION_MAPS/CASH_ENGINE_EXECUTION_MAP.md).

## 6. NSEFO engine

The graduated scanner selects dated near/next contracts using the futures master and provider metadata. It gates BUY by SW/SW/25, uses original-target RR and applies the TP50 overlay on the Tier-0 PAPER path. [NSEFO execution map](03_SEGMENT_EXECUTION_MAPS/NSEFO_ENGINE_EXECUTION_MAP.md).

## 7. MCX engine

MCX has an independent commodity contract map and E1 session handling. The graduated and general trade paths are held before setup evaluation and the shared formatter also denies publications of actionable setups. Alerts and previews are distinct paths. [MCX execution map](03_SEGMENT_EXECUTION_MAPS/MCX_ENGINE_EXECUTION_MAP.md).

## 8. Shared core logic

`setup_engine_new.py` coordinates `trade_engine.py`, `trend_engine.py`, `additional_engine_class.py` and models. Weighted selection uses a nine-dimension score and descends through G9 and sanity checks. [Setup generation flow](01_ENGINE_ARCHITECTURE/SETUP_GENERATION_FLOW.md).

## 9. Configuration and rule implementation

The configuration index separates constructor defaults, environment overrides, service schedule defaults and policy constants. Historical HOLD/KEEP items are resolved by actual current code locations where applicable. [Feature flags](04_CONFIG_AND_RULES/FEATURE_FLAG_MATRIX.csv) and [Rules](04_CONFIG_AND_RULES/RULE_TRACEABILITY.csv).

## 10. Data and storage

Production readers use market CSVs, instrument master tables and operational state, with MySQL signal/order/alert storage. Research has its own SQLite schema. External provider tokens, model artifacts and maintenance paths require approved handover. [Data dependencies](05_DATA_AND_STORAGE_CONTRACTS/DATA_DEPENDENCIES.csv).

## 11. Test and reproducibility status

Three guarded fixture cases passed and the focused test run reported 53 passed, 5 warnings in 1.01s. No branch coverage claim is made for production schedulers, database and broker flows or historical replays. [Test status](06_TESTS_AND_REPRODUCTION/TEST_STATUS.md).

## 12. Known outstanding technical issues

Live revision and operator state are unknown. MCX remains held. Historical OBS-1 and DATA-3 acceptance, vintage market series and model artifacts need independent evidence. The current default CASH status evaluator retains target precedence on dual-hit candles. [Known review issues](07_EXISTING_AUDITS_AND_WORK_ORDERS/RELEVANT_KNOWN_ISSUES.md).

## 13. Package completeness

The staged resolver reported zero missing local import edges. Runtime traces support the exercised paths. The source index distinguishes core, shared, conditional, adjacent and reference scope. A pre-existing compile error in the adjacent legacy alert module is recorded below and in the package verification report. Operator datasets, external execution branches and deployed state remain limitations. [Closure report](08_SECURITY_AND_INTEGRITY/DEPENDENCY_CLOSURE_REPORT.md).

## 14. Security screening

11 staged files have labeled sanitizations. Local credential files, private datasets and production operational state were excluded. [Security screening](08_SECURITY_AND_INTEGRITY/SECURITY_SCREENING_REPORT.md).

## 15. Final package inventory

368 selected-tree paths and 69 historical reports are indexed. The nonrecursive full manifest covers the remaining archive members and the detached SHA-256 authenticates the final ZIP as delivered. [Inventory summary](08_SECURITY_AND_INTEGRITY/INVENTORY_SUMMARY.md).

## 16. Reviewer instructions

Start with Source revision and the three execution maps. Use the rule IDs to inspect the engine statements and match contract and feature-flag references. Repeat controlled verification using the isolated commands, and interpret prior branch reports only in their source context.
