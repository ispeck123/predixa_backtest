# Inventory summary

The classified inventory covers 437 physical upstream files, including 368 source-tree paths and 69 historical reports. Generated reviewer materials, synthetic inputs and indexes are covered by the complete package checksum manifest.

| Component | Files |
|---|---:|
| configuration | 27 |
| core engine | 8 |
| data loading | 39 |
| database/storage | 17 |
| handlers | 66 |
| supporting documentation | 96 |
| tests | 77 |
| utilities | 107 |

| Source classification | Files |
|---|---:|
| CONDITIONAL_RUNTIME | 20 |
| CORE_RUNTIME | 51 |
| SETUP_ADJACENT | 86 |
| SHARED_DEPENDENCY | 41 |
| TEST_OR_REFERENCE | 239 |
