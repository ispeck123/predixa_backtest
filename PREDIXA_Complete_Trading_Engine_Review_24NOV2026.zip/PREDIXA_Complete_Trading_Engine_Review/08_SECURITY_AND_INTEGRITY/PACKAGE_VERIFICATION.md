# Package verification

The nonrecursive manifest uses UTF-8 CSV with paths relative to the archive root. Every archive file has a SHA-256 and byte size in `FILE_MANIFEST_SHA256.csv` except the manifest itself, whose bytes are covered by the detached SHA-256 for the ZIP. A local verification pass checks ZIP CRCs, filenames, regular-file member type, extracted paths and manifest membership. It compares physical source hashes against the selected checkout and checks each staged Python file's syntax and local import paths without importing the service. Standard Info-ZIP validation is included in the verification. Generated synthetic fixtures and independent runtime trace evidence are under section 06.

The before/after repository comparison checks HEAD, porcelain status and the recorded SHA-256 values for tracked text/source candidates. Unchanged included paths are also compared directly against the working-tree bytes. Sanitized copies are indexed separately. The sibling package summary records the final archive result and detached checksum.

From the directory holding the ZIP and checksum sidecar, run:

```bash
sha256sum -c PREDIXA_Complete_Trading_Engine_Review_24NOV2026.zip.sha256
unzip -t PREDIXA_Complete_Trading_Engine_Review_24NOV2026.zip
```

Use the actual delivered filename if it has a revision suffix. See SAFE_EXECUTION_COMMANDS for the guarded synthetic and focused test checks.

### Source compile exception

`alert_engine/alert.py:259` was included byte-for-byte as an adjacent legacy alert dependency. CPython 3.13.5 reports that `cached_alerts` is used prior to its global declaration. The verifier checks for this exact unchanged exception and fails on any additional compile error. This file lies outside the CASH, NSEFO and MCX segment setup closure sets. It is reachable from the standalone legacy alert entrypoint and alternate stock jobs bootstrap.
