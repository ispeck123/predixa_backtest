# Dependency closure report

| Segment | Static Python files | Shared Python files | Exclusive Python files | Conditional Python files |
|---|---:|---:|---:|---:|
| CASH | 54 | 37 | 17 | 3 |
| NSEFO | 54 | 43 | 11 | 5 |
| MCX | 61 | 45 | 16 | 6 |

Counts are per-segment over conservative scanner, API, updater and lifecycle seeds. Shared and exclusive partition the corresponding static Python circle, and conditional overlaps those counts. Deployment-only, tests and replay roots have separate edges. The exact seed lists are in DISCOVERY_STATS.

The resolver used Python AST for absolute and relative imports, imports in functions, namespace packages, package initializers, explicit literal dynamic imports, and selected reviewed file-based call sites. Imported symbols are distinguished from local module paths. Sibling script-path imports are retained where resolved. It found 0 missing package edges and 0 unresolved project-root import names. It indexed 23 recognized dynamic/subprocess call sites for manual reading. External dependencies are indexed independently.

Dynamic review includes named timeframe attributes in the formatter and data handlers, decorator-registered Dagster operations and FastAPI routes, mode-based storage dispatch and model-weight paths. The backend token route calls the included `manage_dashboard.sh`; its service import is supported by the deployment graph where reached. The FYERS token handler reloads an externally configured PM2 process. The reviewed MCX research CLI invokes the packaged edge-repro checker. The interval stitching test uses the included path-loaded `tests/t17.py`. The highly variable resource paths need the external data handover described in the data contracts. Runtime observations cover only the guarded fixtures and the focused pytest run. A separate compiler pass found one existing late-global declaration error in the legacy alert bootstrap outside the three segment closures.
