import pandas as pd
from datetime import datetime
# from apps.finprod_backend.futures.nsep import start_date
from shared.config.settings import stock_data_dir_config as sddcfg
from shared.db.dbconn import DBConnection
from shared.db.db_model import CommoditiesMaster
from sqlitedict import SqliteDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from scripts.stock_logic import proc_delta_stock_items
import os, re, csv
from datetime import datetime, timedelta
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from fyers_apiv3 import fyersModel
import time
import requests
from io import StringIO
from tqdm import tqdm
import logging
from data_fetchers.fyers.expiry_refresh import normalize_fyers_ohlc, safe_replace_csv
from data_fetchers.interval_stitching import aggregate_daily_periods, stitch_mcx_intraday

logger = logging.getLogger(__name__)


def _fyers_rate_limit_wait_seconds(attempt: int) -> float:
    """Return a conservative, configurable cooldown for FYERS code -360."""
    try:
        base = float(os.getenv("FYERS_HISTORY_RATE_LIMIT_SLEEP_SECONDS", "60"))
        maximum = float(os.getenv("FYERS_HISTORY_RATE_LIMIT_MAX_SLEEP_SECONDS", "300"))
    except ValueError:
        logger.warning("[FYERS] Invalid rate-limit sleep configuration; using 60s to 300s")
        base, maximum = 60.0, 300.0
    base = max(base, 1.0)
    maximum = max(maximum, base)
    return min(base * (2 ** attempt), maximum)

class MCXFutureDataHandler:
    def __init__(self, *, history_start: datetime | None = None,
                 bootstrap_full_history: bool = True,
                 download_path: str | None = None,
                 persist_expiries: bool = True,
                 max_ohlc_repair_fraction: float | None = 0.02):
        full_access_token = fyers_access_token_handler().get_access_token()
        self.fyers = fyersModel.FyersModel(client_id=full_access_token.rsplit(":", 1)[0], is_async=False, token=full_access_token.rsplit(":", 1)[1], log_path="")
        # ``download_path`` is intentionally injectable for archival/backtest
        # exports.  The normal scheduler leaves it unset and therefore keeps
        # using the existing live location.
        self.download_path = download_path or os.path.join(
            sddcfg.indian_commodity_data, 'latest_data_csv')
        self.output_path = os.path.join(sddcfg.indian_commodity_data, 'processed_data_files')
        os.makedirs(self.download_path, exist_ok=True)
        self.commodities = self.get_commodity_symbols()
        self.lite_db = SqliteDict('finprod.sqlite') if persist_expiries else None
        self.name_interval_dict = {
            "D" : "daily", 
            "60": "sixty", 
            "15": "fifteen",
            "120": "one_twenty",
            "240": "two_forty",
        }
        # A clean local commodity archive must be re-anchored consistently.
        # FYERS receives this as bounded interval requests below, never as one
        # oversized historical request.  Existing files still use the small
        # delta path unless an explicit full refresh is requested.
        self.full_history_start = history_start or datetime(2020, 1, 1)
        self.bootstrap_full_history = bool(bootstrap_full_history)
        self.max_ohlc_repair_fraction = (
            None if max_ohlc_repair_fraction is None else float(max_ohlc_repair_fraction)
        )
        if (self.max_ohlc_repair_fraction is not None
                and not 0 <= self.max_ohlc_repair_fraction <= 1):
            raise ValueError("max_ohlc_repair_fraction must be between 0 and 1")
        if persist_expiries:
            self.update_latest_3_expiries_mcx()
    
    def get_commodity_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(CommoditiesMaster.symbol).filter(CommoditiesMaster.is_active == 1).all()
        sym_list = [s[0] for s in symbols]
        dbc.close_engine()
        return sym_list

    def get_latest_fyers_commodity_symbol_expiry(self, product: str):
        try:
            # Step 1: Download the latest file
            url = "https://public.fyers.in/sym_details/MCX_COM.csv"
            response = requests.get(url)
            response.raise_for_status()  # Raise error if request failed
            # Step 2: Read into DataFrame (no headers in file)
            df = pd.read_csv(StringIO(response.text), header=None)
            # Step 3: Filter for product
            df = df[df[9].astype(str).str.contains(f"MCX:{product}", na=False)]
            df = df[df[9].astype(str).str.contains("FUT", na=False)]
            # Step 4: Convert expiry column (index 10) to datetime
            df["parsed_date"] = df[1].apply(self.extract_date)
            df = df.drop_duplicates(subset=["parsed_date"], keep='last').reset_index(drop=True)
            df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date", ascending=True)
            df['parsed_date'] = df['parsed_date'].dt.strftime('%d-%m-%Y')
            # Step 5: Sort and return latest symbol
            print(df.tail()['parsed_date'])
            fdf = pd.DataFrame({
                "symbol": df[9].to_list()[:3],
                "expiry": df["parsed_date"].to_list()[:3]
            })
            # Step 5: Sort and return latest symbol
            return fdf.to_dict('records')

        except Exception as e:
            print(f"Error fetching latest symbol: {e}")
            return None

    def extract_date(self, entry):
        match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
        if match:
            # year, month, day = match.groups()
            day, month, year = match.groups()
            full_date_str = f"20{year} {month} {day}"
            return datetime.strptime(full_date_str, "%Y %b %d")
        return None

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        result_df = aggregate_daily_periods(df, sample)
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        # Do not expose a half-written derived timeframe to charts or the
        # post-refresh zone publisher.  ``safe_replace_csv`` validates and
        # atomically swaps a sibling staging file.
        # A sparse FYERS stitched-source envelope defect can survive an OHLC
        # aggregation when the first open is outside the source high/low.
        # Repair the derived envelope before the atomic validation gate.
        result_df = normalize_fyers_ohlc(result_df, max_invalid_fraction=0.02)
        safe_replace_csv(result_df, out_file_name, validate_ohlc=True)
    
    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        # Compatibility helper for callers that ask the handler for a fresh
        # history window.  ``fetch_candle_data`` chunks this interval to the
        # provider's documented per-resolution request limit.
        start_date = (self.full_history_start if self.bootstrap_full_history
                      else now_date - timedelta(days=365))
        # if frame == 'D' or frame == 'M' or frame == 'W':
        #     start_date = now_date - timedelta(days=365)
        # elif frame == '60':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '15':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '120':
        #     start_date = now_date - timedelta(days=100)
        # elif frame == '240':
        #     start_date = now_date - timedelta(days=100)
        return now_date, start_date


    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_mcx_intraday(df, 75, base_minutes=15).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")


    
    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(sddcfg.indian_commodity_data,'latest_data_csv', csv_file)
        derived_df = pd.DataFrame(data, columns=header)
        derived_df = normalize_fyers_ohlc(derived_df, max_invalid_fraction=0.02)
        safe_replace_csv(derived_df, csv_dump_path, validate_ohlc=True)
        print(f'CSV file "{csv_file}" created.')

    def _max_days_for_interval(self, interval: str) -> int:
        if interval in ("D", "1D", "W", "M"):
            return 366
        return 100

    def _iter_date_chunks(self, start_date: datetime, end_date: datetime, chunk_days: int):
        current = start_date
        while current <= end_date:
            chunk_to = min(current + timedelta(days=chunk_days - 1), end_date)
            yield current, chunk_to
            current = chunk_to + timedelta(days=1)

    def update_latest_3_expiries_mcx(self):
        out_res = []
        for symbol in self.commodities:
            int_dict = {}
            int_dict['symbol'] = symbol
            contracts = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            expiry_list = [item["expiry"] for item in contracts]
            int_dict['expiry'] = expiry_list
            out_res.append(int_dict)
            
        if self.lite_db is not None:
            self.lite_db['indian_commodity_expiries'] = out_res
            self.lite_db.commit()
            self.lite_db.close()

    def fetch_candle_data(self, instrument_token, from_date, to_date, interval, max_retries=10,
                          show_progress=False):
        chunk_days = self._max_days_for_interval(interval)
        dfs = []
        chunks = list(self._iter_date_chunks(from_date, to_date, chunk_days))
        iterator = tqdm(chunks, desc=f"MCX {instrument_token} {interval} chunks",
                        unit="chunk", leave=False) if show_progress else chunks
        for chunk_from, chunk_to in iterator:
            df_chunk = self._fetch_candle_data_once(
                instrument_token,
                chunk_from,
                chunk_to,
                interval,
                max_retries
            )

            if df_chunk is not None and not df_chunk.empty:
                dfs.append(df_chunk)

        if not dfs:
            return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'qty', 'tradeDate'])

        df = pd.concat(dfs, ignore_index=True)

        # remove duplicates (edge overlaps)
        df.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)

        # sort properly
        df['_dt'] = pd.to_datetime(df['tradeDate'], dayfirst=True, errors='coerce')
        df.sort_values('_dt', inplace=True)
        df.drop(columns=['_dt'], inplace=True)
        df.reset_index(drop=True, inplace=True)

        return df

    def _fetch_candle_data_once(self, instrument_token, from_date, to_date, interval, max_retries=10):
        for attempt in range(max_retries):
            try:
                data = {
                        "symbol": instrument_token,
                        "resolution":interval,
                        "date_format":"1",
                        "range_from":from_date.strftime("%Y-%m-%d"),
                        "range_to":to_date.strftime("%Y-%m-%d"),
                        "cont_flag":"1"
                    }

                response = self.fyers.history(data=data)
                if 'candles' in response.keys():
                    df = pd.DataFrame(response['candles'], columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
                    df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
                    df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                    df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
                    return df
                else:
                    # FYERS uses -50 (and, for some dated/far MCX contracts,
                    # the less specific -99/Bad request) when an intraday
                    # request precedes the history available for that series.
                    # These are availability boundaries, not transient
                    # errors.  The outer chunk loop must continue with later
                    # dates rather than exponentially retrying a request that
                    # can never succeed.
                    response_text = " ".join(
                        str(part) for part in (
                            response.get("message", ""),
                            response.get("data", ""),
                        )
                    ).lower()
                    response_code = str(response.get("code"))
                    is_pre_availability = (
                        response_code == "-50"
                        and "outside the available historical data" in response_text
                    ) or (
                        response_code == "-99"
                        and response_text.strip() == "bad request"
                    )
                    if is_pre_availability:
                        logger.info(
                            "[FYERS] MCX %s %s unavailable for %s to %s "
                            "(FYERS code %s); skipping this pre-availability chunk",
                            instrument_token, interval,
                            from_date.date(), to_date.date(),
                            response_code,
                        )
                        return pd.DataFrame(
                            columns=['open', 'high', 'low', 'close', 'qty', 'tradeDate'])
                    if response_code == "-360":
                        # Rate limiting is a service-wide, temporary state.
                        # A 1/2/4-second generic retry immediately exhausts
                        # the retry budget, so wait for a full stabilization
                        # window before trying this exact request again.
                        wait = _fyers_rate_limit_wait_seconds(attempt)
                        logger.warning(
                            "[FYERS] MCX rate limit for %s %s; retry %d/%d after %.0fs",
                            instrument_token, interval, attempt + 1, max_retries, wait,
                        )
                        time.sleep(wait)
                        continue
                    logger.warning("[FYERS] MCX history response for %s %s; retry %d/%d: %s",
                                   instrument_token, interval, attempt + 1, max_retries, response)
                    wait = 2 ** attempt
                    time.sleep(wait)
            except Exception as e:
                logger.exception("[FYERS] MCX request failed for %s %s: %s", instrument_token, interval, e)
                return pd.DataFrame()

    def active_contracts(self):
        """Return the current valid master snapshot or None when it cannot be read."""
        contracts = []
        for symbol in self.commodities:
            discovered = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            if not discovered:
                return None
            contracts.extend({**contract, "underlying": symbol} for contract in discovered)
        return contracts

    def download_all(self, intervals=['D', '60', '15', '120', '240'], force_full_refresh=False,
                     underlyings=None, build_derived=True):
        # today = datetime.now()
        selected_underlyings = set(underlyings) if underlyings is not None else None
        symbols = [symbol for symbol in self.commodities
                   if selected_underlyings is None or symbol in selected_underlyings]
        if force_full_refresh and not symbols:
            raise RuntimeError("No rolled MCX underlyings were selected for full refresh")
        operation = "full re-anchor" if force_full_refresh else "delta update"
        logger.info("[FYERS] Starting MCX %s for %d underlyings: %s",
                    operation, len(symbols), symbols)
        progress = tqdm(total=len(symbols), desc=f"MCX {operation}", unit="symbol")
        completed_contracts = []
        for symbol in symbols:
            contracts = self.get_latest_fyers_commodity_symbol_expiry(symbol)
            if not contracts:
                message = f"No active FYERS MCX contract metadata for {symbol}"
                if force_full_refresh:
                    progress.close()
                    raise RuntimeError(message)
                logger.warning("[FYERS] %s", message)
                progress.update(1)
                continue
            logger.info("[FYERS] %s: discovered %d active contracts", symbol, len(contracts))
            for items in contracts:
                future_token = items['symbol']
                expiry = items['expiry']
                contract_complete = True
                contract_changed = False
                numbers = re.findall(r'\d+', expiry)
                # Join all found numbers into one string
                exp_num = ''.join(numbers)
                for interval in intervals:
                    # end_dt, start_dt = self.return_now_and_previous_date(interval)
                    # df = self.fetch_candle_data(future_token, start_dt, end_dt, interval)
                    # if not df.empty:
                    fname = f"{symbol}_{exp_num}_{self.name_interval_dict[interval]}.csv"
                    file_path = os.path.join(self.download_path, fname)
                    if os.path.exists(file_path) and not force_full_refresh:
                        try:
                            existing_df = pd.read_csv(file_path)
                            if not existing_df.empty:
                                last_date = pd.to_datetime(existing_df['tradeDate'], dayfirst=True, errors='coerce').max()
                                # fetch only recent data (small window instead of full history)
                                if pd.isna(last_date):
                                    delta_start = datetime.now() - timedelta(days=365)
                                else:
                                    delta_start = last_date - timedelta(days=5)

                                delta_end = datetime.now()
                                df_delta = self._fetch_candle_data_once(future_token, delta_start, delta_end, interval)
                                if df_delta is not None and not df_delta.empty:
                                    combined = pd.concat([existing_df, df_delta], ignore_index=True)
                                    # remove duplicates
                                    combined.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)
                                    # sort
                                    combined['_dt'] = pd.to_datetime(combined['tradeDate'], dayfirst=True, errors='coerce')
                                    combined.sort_values('_dt', inplace=True)
                                    combined.drop(columns=['_dt'], inplace=True)
                                    combined.reset_index(drop=True, inplace=True)

                                    # Repair the known sparse FYERS continuous
                                    # envelope issue before strict atomic CSV
                                    # validation.  This also cleans old rows
                                    # already present in the local snapshot.
                                    combined = normalize_fyers_ohlc(
                                        combined, max_invalid_fraction=self.max_ohlc_repair_fraction)
                                    safe_replace_csv(combined, file_path, validate_ohlc=True)
                                    logger.info("[FYERS] MCX delta updated %s (%d candles)", fname, len(combined))
                                    contract_changed = True
                                else:
                                    logger.warning("[FYERS] MCX delta returned no candles for %s", fname)
                                    # A source interval with no confirmed
                                    # response means this contract batch is
                                    # incomplete for alert publication.  The
                                    # prior snapshot remains authoritative.
                                    contract_complete = False

                        except Exception as exx:
                            logger.exception("[FYERS] MCX delta failed for %s: %s", fname, exx)
                            contract_complete = False

                        # df.to_csv(os.path.join(self.download_path, fname), index=False)
                        # print(f"Saved: {fname}")
                    else:
                        
                        # A missing local CSV is a clean bootstrap.  Start it
                        # at the configured historical anchor (2020-01-01 by
                        # default), using provider-safe chunks.  This is a
                        # continuous FYERS request (cont_flag=1), not proof
                        # of dated-contract attribution.
                        end_dt = datetime.now()
                        start_dt = (self.full_history_start
                                    if force_full_refresh or self.bootstrap_full_history
                                    else end_dt - timedelta(days=365))
                        logger.info("[REFRESH] MCX fetching %s from %s to %s",
                                    fname, start_dt.date(), end_dt.date())
                        df_full = self.fetch_candle_data(
                            future_token, start_dt, end_dt, interval,
                            show_progress=force_full_refresh,
                        )
                        if df_full is not None and not df_full.empty:
                            # FYERS MCX continuous history has recurring
                            # sparse stitch-envelope defects.  Normalize both
                            # bootstrap and roll-refresh paths so a malformed
                            # raw candle cannot later break a derived bar.
                            df_full = normalize_fyers_ohlc(
                                df_full, max_invalid_fraction=self.max_ohlc_repair_fraction)
                            # Stage then atomically replace. Existing history remains readable on failure.
                            # Normal bootstrap preserves legacy FYERS acceptance;
                            # expiry refreshes additionally enforce OHLC bounds.
                            safe_replace_csv(df_full, file_path, validate_ohlc=force_full_refresh)
                            logger.info("[REFRESH] MCX replaced %s with %d candles", fname, len(df_full))
                            contract_changed = True
                        else:
                            logger.warning("[FYERS] MCX full history returned no candles for %s", fname)
                            contract_complete = False
                            if force_full_refresh:
                                raise RuntimeError(f"Full FYERS history unavailable for {symbol} {interval}")

                # A monitor snapshot is published only for a contract whose
                # entire source interval set completed.  A failure in one CSV
                # therefore leaves the prior version live and cannot produce
                # false NEW/MODIFIED/REMOVED events.
                if contract_complete and contract_changed:
                    completed_contracts.append({"underlying": symbol, "expiry": expiry,
                                                "provider_symbol": future_token})

            progress.update(1)
        progress.close()

        if not build_derived:
            logger.info("[FYERS] MCX source export complete; derived bars were intentionally skipped")
            self.last_completed_contracts = completed_contracts
            return completed_contracts

        all_file_list = sorted(os.listdir(self.download_path))
        all_file_list = [
            item for item in all_file_list
            if any(str(item).startswith(f"{symbol}_") for symbol in symbols)
        ]
        logger.info("[FYERS] Building derived MCX bars for %d files", len(all_file_list))
        for items in tqdm(all_file_list, desc="MCX derived bars", unit="file"):
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            elif str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
        self.last_completed_contracts = completed_contracts
        return completed_contracts
    
    # def process_all(self):
    #     with ThreadPoolExecutor(max_workers=10) as executor:
    #         for stock_item in os.listdir(self.download_path):
    #             executor.submit(proc_delta_stock_items, stock_item, self.download_path, self.output_path)
    #     print("all_stock_process_complete...................")
    def process_all(self, underlyings=None):
        all_files = sorted(os.listdir(self.download_path))
        if underlyings is not None:
            selected = set(underlyings)
            all_files = [item for item in all_files
                         if any(str(item).startswith(f"{symbol}_") for symbol in selected)]
        logger.info("[FYERS] Processing %d MCX files into processed-data output", len(all_files))

        with ProcessPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(
                    proc_delta_stock_items,
                    stock_item,
                    self.download_path,
                    self.output_path
                )
                for stock_item in all_files
            ]

            for future in tqdm(
                as_completed(futures),
                total=len(futures),
                desc="MCX processed bars",
                unit="file",
            ):
                try:
                    future.result()
                except Exception as e:
                    logger.exception("[FYERS] Error processing MCX file: %s", e)

        logger.info("[FYERS] MCX processed-data build complete")
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv')
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_mcx_intraday(df, 125, base_minutes=5).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "one_twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 125-minute chunks to save.")




