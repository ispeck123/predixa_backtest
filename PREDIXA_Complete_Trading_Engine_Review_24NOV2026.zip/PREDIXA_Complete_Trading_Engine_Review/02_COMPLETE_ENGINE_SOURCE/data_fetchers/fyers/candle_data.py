import sys, os
sys.path.insert(0, os.path.abspath("/home/ispeck/STOCK_PROJECT/STP_LATEST/"))


from fyers_apiv3 import fyersModel
from datetime import datetime, timedelta
import pandas as pd
import os
# print(os.getcwd())
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.config.settings import stock_data_dir_config
from data_fetchers.interval_stitching import stitch_nse_intraday
import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# client_id = "9OG15PCU6X-100"
# access_token = "REVIEW_REDACTED"

# # Initialize the FyersModel instance with your client_id, access_token, and enable async mode
# fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# data = data = {
#     "symbol":"NSE:SBIN-EQ",
#     "resolution":"D",
#     "date_format":"0",
#     "range_from":"1690895316",
#     "range_to":"1691068173",
#     "cont_flag":"1"
# }

# response = fyers.history(data=data)
# print(response)


class CandleDateFetcher:

    def __init__(self):
        fyers_access_token = fyers_access_token_handler().get_access_token()
        self.client_id = fyers_access_token.split(':')[0]
        self.access_token = fyers_access_token.split(':')[1]
        #self.output_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
        self.output_path = "/home/ispeck/STOCK_PROJECT/STP_LATEST/"

    def get_resolution_frame_name(self, resolution: str):
        if resolution == "5":
            return "five"
        elif resolution == "15":
            return "fifteen"
        elif resolution == "60":
            return "sixty"
        elif resolution == "1D":
            return "daily"
        elif resolution == "W":
            return "weekly"
        elif resolution == "ME":
            return "monthly"
    
    def fetch_candle_data_custom_resolution(self, 
                                           stock_tick: str,
                                           symbol: str, 
                                           start_date: str = "2020-01-01",
                                           end_date: str = datetime.now().strftime("%Y-%m-%d"),
                                           resolution: str = "5"):
        
        start_date = datetime.strptime(start_date, "%Y-%m-%d")
        end_date = datetime.strptime(end_date, "%Y-%m-%d")
        total_days = (end_date - start_date).days + 1
        print(f"Total days: {total_days}")
        symbol = symbol # f"NSE:{symbol}-EQ"
        days_list = []
        if resolution == "1D" or resolution == "D":
            max_day = 366
        else:
            max_day = 100
        if total_days > max_day:
            divident = total_days // max_day
            remainder = total_days % max_day
            for i in range(divident):
                days_list.append(max_day)
            if remainder > 0:
                days_list.append(remainder)
        else:
            days_list.append(total_days)
        
        if len(days_list) > 0:
            all_candles = []
            fyers = fyersModel.FyersModel(client_id=self.client_id, is_async=False, token=self.access_token, log_path="")
            range_to = end_date
            for days in days_list:
                #print(days)
                #range_to = datetime.now() - timedelta(minutes=1)
                #range_to = range_to.replace(second=0, microsecond=0)
                range_from = range_to - timedelta(days=days-1)
                # print(range_to)
                # print(range_from)
                # print(range_to.timestamp())
                # print(range_from.timestamp())
                range_to = datetime.strftime(range_to, "%Y-%m-%d")
                range_from = datetime.strftime(range_from, "%Y-%m-%d")
                print(range_from)
                print(range_to)

                data = {
                    "symbol": symbol,
                    "resolution": resolution,
                    "date_format": "1",
                    # "range_from": range_from.timestamp(),
                    # "range_to": range_to.timestamp(),
                    "range_from": range_from,
                    "range_to": range_to,
                    "cont_flag": "1"
                }
                
                #print(response)
                retry = 20
                candle_found = False
                for i in range(retry):
                    response = fyers.history(data=data)
                    #print(response)
                    if 'candles' in response:
                        candles = response['candles']
                        if len(candles) > 0:
                            #print("candles", len(candles))
                            candles.extend(all_candles)
                            all_candles = candles
                            #print("all candles", len(all_candles))
                            candle_found = True
                            break
                        else:
                            print(response)
                            logger.info(response)
                            break
                    else:
                        #print(f"No candle found for {symbol} from {range_from} to {range_to}")
                        print(response)
                        logger.info(response)
                    time.sleep(5)
                if candle_found == False:
                    print(f"No candle found for {symbol} from {range_from} to {range_to}")
                    logger.info(f"No candle found for {symbol} from {range_from} to {range_to}")
                range_to = datetime.strptime(range_from, "%Y-%m-%d") - timedelta(days=1)  # Adjust range_to for the next iteration
            
            df = pd.DataFrame(all_candles, columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
            frame_name = self.get_resolution_frame_name(resolution)
            df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata')
            df = df.sort_values('tradeDate', kind='mergesort')
            df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
            full_file_path = f"{self.output_path}/{stock_tick.lower()}_{frame_name}.csv"
            print("Saving:", full_file_path)
            if os.path.exists(full_file_path):
                os.remove(full_file_path)
            logger.info(f"Saving: {full_file_path}")
            df.to_csv(full_file_path, index=False)
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        logger.info(f"Reading: {file_path}")

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_nse_intraday(df, 125)
        if not output.empty:
            csv_file_name = file_name.replace("five", "one_twenty_five")
            output.to_csv(os.path.join(txt_dir, csv_file_name), index=False)
            print("Saved as:", csv_file_name)
            logger.info(f"Saved as: {csv_file_name}")
        else:
            print("No complete 125-minute chunks to save.")
            logger.info("No complete 125-minute chunks to save.")
    

# cls = CandleDateFetcher()
# cls.fetch_candle_data_custom_resolution(symbol="NSE:NIFTYBANK-INDEX", stock_tick="BANKNIFTY", start_date="2020-01-01", resolution="5")
