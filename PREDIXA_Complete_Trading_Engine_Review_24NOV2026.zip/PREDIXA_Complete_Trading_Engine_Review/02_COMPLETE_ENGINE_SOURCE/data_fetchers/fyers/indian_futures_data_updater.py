import pandas as pd
from fyers_apiv3 import fyersModel
from datetime import datetime
from shared.config.settings import stock_data_dir_config
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from dateutil.relativedelta import relativedelta
from calendar import monthrange, THURSDAY
from datetime import timedelta, datetime
from nselib.derivatives import expiry_dates_future
from shared.db.db_model import FuturesMaster
from sqlalchemy import distinct
from shared.db.dbconn import DBConnection
from concurrent.futures import ThreadPoolExecutor, as_completed
from scripts.stock_logic import proc_delta_stock_items
import re, os, csv, time
import threading
import logging
import requests
from io import StringIO
from tqdm import tqdm
from data_fetchers.fyers.expiry_refresh import normalize_fyers_ohlc, safe_replace_csv
from data_fetchers.interval_stitching import aggregate_daily_periods, stitch_nse_intraday
import gspread
from shared.config.settings import Config as cfg

logger = logging.getLogger()

class Indian_future_data_handler:
    def __init__(self):
        self.time_format = "%d-%m-%Y"
        self.download_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        full_access_token = fyers_access_token_handler().get_access_token()
        self.fyers = fyersModel.FyersModel(client_id=full_access_token.rsplit(":", 1)[0], is_async=False, token=full_access_token.rsplit(":", 1)[1], log_path="")
        self.name_interval_dict = {
            "D" : "daily", 
            "60" : "sixty", 
            "15" : "fifteen",
            "5" : "five"
        }
        self.historical_lock = threading.Lock()
        self.last_historical_time = [0]
        self.total_days_of_data = 365 * 3   #3 years
        self.full_history_start = datetime(2020, 1, 1)
        # One master snapshot is enough for the coordinator and the following
        # downloader run.  Reusing it avoids downloading NSE_FO.csv once per
        # symbol twice on every 30-minute cycle.
        self._contract_cache = {}
        self._instrument_master = None
        self._instrument_master_lock = threading.Lock()

    def return_now_and_previous_date(self, frame: str, now_date = None):
        if not now_date:
            now_date = datetime.now()
        if frame == 'D' or frame == 'W' or frame == 'ME':
            start_date = now_date - timedelta(days=365)
            return now_date, start_date, 365
        elif frame == '60':
            start_date = now_date - timedelta(days=100)
            return now_date, start_date, 100
        elif frame == '15':
            start_date = now_date - timedelta(days=100)
            return now_date, start_date, 100
        elif frame == '5':
            start_date = now_date - timedelta(days=100)
            return now_date, start_date, 100
        else:
            start_date = now_date - timedelta(days=100)
            return now_date, start_date, 100
        return now_date, start_date, 100

    @staticmethod
    def _build_descending_history_ranges(start_date, end_date, chunk_days):
        """Build non-overlapping inclusive date ranges, newest first.

        FYERS receives calendar dates (not timestamps). Keeping range
        construction in one place makes it impossible for pagination to send
        ``range_from`` later than ``range_to`` when the last chunk is partial.
        The historical request span preserves the previous chunk convention:
        each chunk may cover ``chunk_days + 1`` inclusive dates.
        """
        start = pd.Timestamp(start_date)
        end = pd.Timestamp(end_date)
        if pd.isna(start) or pd.isna(end):
            raise ValueError("NSEFO history start/end must be valid dates")
        start_day, end_day = start.date(), end.date()
        if start_day > end_day:
            raise ValueError(
                f"NSEFO history start date {start_day} is after end date {end_day}"
            )
        if chunk_days <= 0:
            raise ValueError("chunk_days must be positive")

        ranges = []
        cursor = end_day
        while cursor >= start_day:
            range_start = max(start_day, cursor - timedelta(days=chunk_days))
            ranges.append((range_start, cursor))
            cursor = range_start - timedelta(days=1)
        return ranges

    def join_numbers_from_string(self, input_string):
        # Find all digits using regex
        numbers = re.findall(r'\d+', input_string)
        # Join all found numbers into one string
        result = ''.join(numbers)
        return result

    def get_all_stock_symbols(self, exchange=None):
        # dbc = DBConnection()
        # session = dbc.get_session()
        # query = session.query(distinct(FuturesMaster.symbol))
        # if exchange is not None:
        #     query = query.filter(FuturesMaster.exchange == exchange)
        # symbols = query.all()
        # sym_list = [s[0] for s in symbols]
        # #sym_list = ["AARTIIND", "ABFRL", "ACC", "ABCAPITAL"]
        # dbc.close_engine()
        gc = gspread.service_account(filename="google_cloud_credential.json")
        sh = gc.open(cfg.FUTURES_LIQUIDITY_GOOGLE_SHEET)
        worksheet = sh.sheet1
        # Read all records into a DataFrame
        data = worksheet.get_all_records()
        symbol_df = pd.DataFrame(data)
        sym_list = list(symbol_df['SYMBOLS'].values)
        return sym_list
    

    def fetch_future_candles(self, instrument_token, from_date, to_date, interval='day', max_retries=10):
        from_day = pd.Timestamp(from_date)
        to_day = pd.Timestamp(to_date)
        if pd.isna(from_day) or pd.isna(to_day):
            raise ValueError("NSEFO history request requires valid from/to dates")
        if from_day.date() > to_day.date():
            raise ValueError(
                f"Invalid NSEFO history range: from {from_day.date()} after {to_day.date()}"
            )
        for attempt in range(max_retries):
            try:
                with self.historical_lock:
                    now = time.time()
                    elapsed = now - self.last_historical_time[0]
                    wait_time = max(0, 1/3 - elapsed)  # 3 requests/sec
                    if wait_time > 0:
                        time.sleep(wait_time)
                    self.last_historical_time[0] = time.time()
                    data = {
                    "symbol": instrument_token,
                    "resolution":interval,
                    "date_format":"1",
                    "range_from":from_date.strftime("%Y-%m-%d"),
                    "range_to":to_date.strftime("%Y-%m-%d"),
                    "cont_flag":"1"
                    }
                    response = self.fyers.history(data=data)
                    if 'candles' in response.keys():
                        df = pd.DataFrame(response['candles'], columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
                        df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
                        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                        df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
                        return df
                    else:
                        range_label = f"{from_day:%Y-%m-%d} to {to_day:%Y-%m-%d}"
                        error_data = response.get('data') or {}
                        if (response.get('code') == -50 and isinstance(error_data, dict)
                                and 'range_from' in error_data):
                            logger.error("[FYERS] NSEFO rejected date range %s for %s %s: %s",
                                         range_label, instrument_token, interval, response)
                            return None
                        logger.warning("[FYERS] NSEFO history response for %s %s (%s); retry %d/%d: %s",
                                       instrument_token, interval, range_label,
                                       attempt + 1, max_retries, response)
                        wait = 2 ** attempt
                        time.sleep(wait)
            except Exception as e:
                logger.exception("[FYERS] NSEFO request failed for %s %s: %s",
                                 instrument_token, interval, e)
                if '429' in str(e):
                    wait = 2 ** attempt
                    logger.warning("[FYERS] Rate limit for %s; retrying in %ds", instrument_token, wait)
                    time.sleep(wait)
                else:
                    raise e
    

    
    def get_upcoming_expiry_list(self):
        return expiry_dates_future()

    def _nsefo_instrument_master(self):
        """Load NSE_FO.csv once per updater run, not once per underlying."""
        with self._instrument_master_lock:
            if self._instrument_master is None:
                response = requests.get("https://public.fyers.in/sym_details/NSE_FO.csv", timeout=20)
                response.raise_for_status()
                self._instrument_master = pd.read_csv(StringIO(response.text), header=None)
                logger.info("[FYERS] Loaded NSE_FO instrument master (%d rows)",
                            len(self._instrument_master))
            return self._instrument_master
    
    def _contracts_for(self, symbol, refresh=False):
        if refresh or symbol not in self._contract_cache:
            self._contract_cache[symbol] = self.get_latest_fyers_futures_symbol(symbol)
        return self._contract_cache[symbol]

    def get_future_ohlc(self, symbol, force_full_refresh=False):
        token = self._contracts_for(symbol)
        logger.info("[FYERS] %s: discovered %s active contracts", symbol, len(token or []))
        if force_full_refresh and not token:
            raise RuntimeError(f"No active FYERS contract metadata for {symbol}")
        changed_files = []
        if token:
            for items in token:
                future_token = items['symbol']
                expiry_date_str = items['expiry']
                format_idt = self.join_numbers_from_string(expiry_date_str)
                file_name = f"{symbol}_{format_idt}.csv"
                for interval in ['D', '60', '15', '5']:
                    
                    filepath = f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}"
                    
                    if os.path.exists(filepath) and not force_full_refresh:
                        merged_df = pd.read_csv(filepath)
                        end_date, start_date, days_per_request = self.return_now_and_previous_date(interval)
                        df = self.fetch_future_candles(future_token, start_date, end_date, interval)
                        if df is None or df.empty:
                            logger.warning("[FYERS] NSEFO delta returned no candles for %s %s", symbol, interval)
                            continue
                        if not merged_df.empty:
                            merged_df = pd.concat([merged_df, df], ignore_index=True)
                        else:
                            merged_df = df
                        merged_df.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)
                        merged_df['_sort_ts'] = pd.to_datetime(merged_df['tradeDate'], dayfirst=True, errors='coerce')
                        merged_df.sort_values('_sort_ts', kind='mergesort', inplace=True)
                        merged_df.drop(columns=['_sort_ts'], inplace=True)
                        merged_df.reset_index(drop=True, inplace=True)
                        merged_df.to_csv(f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}", index=False)
                        changed_files.append(filepath)
                        logger.info("[FYERS] NSEFO delta updated %s %s (%d candles)",
                                    symbol, interval, len(merged_df))
                    
                    else:
                        logger.info("[FYERS] %s %s: starting %s history export from %s",
                                    symbol, interval,
                                    "roll refresh" if force_full_refresh else "missing-file bootstrap",
                                    (self.full_history_start if force_full_refresh
                                     else datetime.now() - timedelta(days=self.total_days_of_data)).date())
                        # FYERS cont_flag=1 history is re-anchored from the
                        # current broker-master front contract after a roll.
                        # Retain the existing request chunking by expressing
                        # the requested period in its normal chunk sizes.
                        # A normal missing-file bootstrap retains the legacy
                        # three-year window; only an expiry roll re-exports
                        # FYERS's continuous history from 2020.
                        history_start = (self.full_history_start if force_full_refresh
                                         else datetime.now() - timedelta(days=self.total_days_of_data))
                        history_end = datetime.now()
                        merged_df = pd.DataFrame()
                        received_history = False
                        request_failed = False
                        chunk_days = 365 if interval == 'D' else 100
                        history_ranges = self._build_descending_history_ranges(
                            history_start, history_end, chunk_days
                        )
                        chunk_progress = (
                            tqdm(total=len(history_ranges),
                                  desc=f"NSEFO {symbol} {interval} chunks", unit="chunk", leave=False)
                            if force_full_refresh else None
                        )
                        for start_day, end_day in history_ranges:
                            start_date = datetime.combine(start_day, datetime.min.time())
                            end_date = datetime.combine(end_day, datetime.min.time())
                            df = self.fetch_future_candles(future_token, start_date, end_date, interval)
                            if df is None:
                                # A transport/API failure is not an historical
                                # boundary.  Never replace an existing series
                                # with a partial re-export in this case.
                                message = (f"FYERS request failed for {symbol} {interval} "
                                           f"({start_date:%Y-%m-%d} to {end_date:%Y-%m-%d})")
                                if force_full_refresh:
                                    raise RuntimeError(message)
                                logger.warning(message)
                                request_failed = True
                                break
                            if df.empty:
                                if not received_history:
                                    # The latest requested period has no
                                    # candles.  A forced roll refresh must
                                    # retain the old file and retry later.
                                    message = f"Full FYERS history unavailable for {symbol} {interval}"
                                    if force_full_refresh:
                                        raise RuntimeError(message)
                                    logger.warning(message)
                                    break
                                # Continuous history legitimately stops before
                                # an instrument was listed.  This is the lower
                                # available-history boundary, not a failure.
                                logger.info("FYERS history boundary for %s %s at %s",
                                            symbol, interval, end_date.date())
                                break
                            if merged_df.empty:
                                merged_df = df
                            else:
                                merged_df = pd.concat([df, merged_df], ignore_index=True)
                            received_history = True
                            if chunk_progress is not None:
                                chunk_progress.update(1)
                        if chunk_progress is not None:
                            chunk_progress.close()
                        if request_failed or merged_df.empty:
                            # Normal bootstrap has no old CSV to protect; do
                            # not turn an unavailable symbol into a scheduler
                            # failure.  A forced refresh has already raised.
                            continue
                        # FYERS range boundaries can overlap.  A full export
                        # must satisfy the same ordered, unique series shape
                        # as commodity history before its atomic replacement.
                        merged_df.drop_duplicates(subset=['tradeDate'], keep='last', inplace=True)
                        merged_df['_dt'] = pd.to_datetime(
                            merged_df['tradeDate'], dayfirst=True, errors='coerce')
                        merged_df.sort_values('_dt', inplace=True)
                        merged_df.drop(columns=['_dt'], inplace=True)
                        merged_df.reset_index(drop=True, inplace=True)
                        if force_full_refresh:
                            # FYERS continuous futures occasionally return a
                            # sparse stitched OHLC envelope defect.  Apply the
                            # same bounded repair policy as MCX; broader
                            # corruption remains a failed refresh.
                            merged_df = normalize_fyers_ohlc(
                                merged_df, max_invalid_fraction=0.02)
                        safe_replace_csv(
                            merged_df,
                            f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}",
                            validate_ohlc=force_full_refresh,
                        )
                        changed_files.append(filepath)
                        logger.info("[FYERS] %s %s: wrote %d candles", symbol, interval, len(merged_df))
        return changed_files

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    def extract_date(self, entry):
        try:
            if not entry or not isinstance(entry, str):
                return None

            match = re.search(r'\b(\d{1,2})\s([A-Za-z]{3})\s(\d{2})\b', entry.strip())
            if not match:
                return None

            day, month, year = match.groups()
            return datetime.strptime(f"{day} {month} 20{year}", "%d %b %Y")

        except Exception:
            return None

    # def get_latest_fyers_futures_symbol(self, product: str):
    #     try:
    #         # Step 1: Download the latest file  
    #         url = "https://public.fyers.in/sym_details/NSE_FO.csv"
    #         response = requests.get(url)
    #         response.raise_for_status()  # Raise error if request failed
    #         # Step 2: Read into DataFrame (no headers in file)
    #         df = pd.read_csv(StringIO(response.text), header=None)
    #         # Step 3: Filter for product
    #         df = df[df[9].astype(str).str.contains(f"NSE:{product}", na=False)]
    #         df = df[df[9].astype(str).str.contains("FUT", na=False)]
    #         # Step 4: Convert expiry column (index 10) to datetime
    #         df["parsed_date"] = df[1].apply(self.extract_date)
    #         df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")
    #         print("parsed_date", df['parsed_date'])
    #         df['parsed_date'] = df['parsed_date'].dt.strftime('%d-%m-%Y')

    #         fdf = pd.DataFrame({
    #             "symbol": df[9].to_list()[:3],
    #             "expiry": df["parsed_date"].to_list()[:3]
    #         })
    #         # Step 5: Sort and return latest symbol
    #         return fdf.to_dict('records')

    #     except Exception as e:
    #         logger.exception(e)
    #         print(f"Error fetching latest symbol: {product}  {e}")
    #         return None    
    def get_latest_fyers_futures_symbol(self, product: str, max_contracts=3):
        try:
            df = self._nsefo_instrument_master().copy()

            # symbol column
            df[9] = df[9].astype(str)
            df[1] = df[1].astype(str)

            # match only this product's futures
            # df = df[df[9].str.startswith(f"NSE:{product}", na=False)]
            # df = df[df[9].str.contains("FUT", na=False, regex=False)]
            df = df[df[9].str.match(rf"NSE:{re.escape(product)}\d{{2}}[A-Za-z]+FUT$", na=False)]

            if df.empty:
                print(f"No futures found for {product}")
                return []

            # parse expiry from description column
            df["parsed_date"] = df[1].apply(self.extract_date)
            df["parsed_date"] = pd.to_datetime(df["parsed_date"], errors="coerce")

            df = df.dropna(subset=["parsed_date"]).sort_values("parsed_date")

            if df.empty:
                print(f"No valid expiries found for {product}")
                return []

            # remove duplicate symbols if any
            df = df.drop_duplicates(subset=[9, "parsed_date"])

            result = df[[9, "parsed_date"]].copy()
            if max_contracts is not None:
                result = result.head(max_contracts)
            result.columns = ["symbol", "expiry"]
            result["expiry"] = result["expiry"].dt.strftime("%d-%m-%Y")

            return result.to_dict("records")

        except Exception as e:
            logger.exception(e)
            print(f"Error fetching latest symbol: {product} {e}")
            return None


    def active_contracts(self):
        self._contract_cache.clear()
        # A scheduler run starts with a fresh authoritative master snapshot;
        # calls made by that run then reuse the same in-memory response.
        self._instrument_master = None
        contracts = []
        for symbol in self.get_all_stock_symbols():
            discovered = self._contracts_for(symbol, refresh=True)
            if not discovered:
                return None
            contracts.extend({**contract, "underlying": symbol} for contract in discovered)
        return contracts

    def process(self, max_workers=10, batch_size=200, delay_between_batches=10, force_full_refresh=False,
                underlyings=None, configured_symbols=None):
        # A one-off full-history run can pass the exact, preflighted universe
        # snapshot so a changing remote sheet cannot silently alter its scope.
        all_symbols = (self.get_all_stock_symbols() if configured_symbols is None
                       else list(configured_symbols))
        if underlyings is not None:
            selected_underlyings = set(underlyings)
            all_symbols = [symbol for symbol in all_symbols if symbol in selected_underlyings]
        if force_full_refresh and not all_symbols:
            raise RuntimeError("No rolled NSEFO underlyings were selected for full refresh")
        # all_symbols = ["ADANIPORTS"]
        # Prepare all (symbol, expiry) combinations
        tasks = [sym for sym in all_symbols]
        refresh_failures = []
        changed_files = []
        operation = "full re-anchor" if force_full_refresh else "delta update"
        logger.info("[FYERS] Starting %s for %d NSEFO symbols", operation, len(tasks))
        completed = tqdm(total=len(tasks), desc=f"NSEFO {operation}", unit="symbol")
        for i in range(0, len(tasks), batch_size):
            current_batch = tasks[i:i + batch_size]
            logger.info("[FYERS] NSEFO batch %d: %d symbols", i // batch_size + 1, len(current_batch))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self.get_future_ohlc, sym, force_full_refresh): (sym)
                    for sym in current_batch
                }
                for future in as_completed(futures):
                    sym = futures[future]
                    try:
                        changed_files.extend(future.result() or [])
                        logger.info("[FYERS] %s complete (%s)", sym, operation)
                    except Exception as e:
                        logger.exception("[FYERS] %s failed during %s: %s", sym, operation, e)
                        refresh_failures.append(f"{sym}: {e}")
                    finally:
                        completed.update(1)


            if i + batch_size < len(tasks):
                logger.info("[FYERS] Batch %d complete; waiting %d seconds", i // batch_size + 1,
                            delay_between_batches)
                time.sleep(delay_between_batches)  # prevent API ban
        completed.close()
        if force_full_refresh and refresh_failures:
            raise RuntimeError("Full refresh failed for " + "; ".join(refresh_failures))
        logger.info("[FYERS] NSEFO %s changed %d source files", operation, len(changed_files))
        return sorted(set(changed_files))

        

class future_data_processer:
    def __init__(self, handler=None):
        # The processor does not fetch candles.  Avoid a second FYERS client
        # and token lookup for every scheduled updater run.
        self.ifdh = handler
        self.input_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        self.output_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'processed_data_files')
        self.time_format = "%d-%m-%Y"

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_nse_intraday(df, 75).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")


    def create_25munite_from_5munite(self, file_name: str):
            txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
            file_path = os.path.join(txt_dir, file_name)
            print("Reading:", file_path)
            df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
            output = stitch_nse_intraday(df, 25).to_dict('records')
    
            if output:
                headers = output[0].keys()
                csv_file_name = file_name.replace("five", "twenty_five")
                self.dump_csv(headers, csv_file_name, output)
                print("Saved as:", csv_file_name)
            else:
                print("No complete 25-minute chunks to save.")


    def create_125munite_from_5munite(self, file_name: str):
                txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
                file_path = os.path.join(txt_dir, file_name)
                print("Reading:", file_path)
                df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
                output = stitch_nse_intraday(df, 125).to_dict('records')
        
                if output:
                    headers = output[0].keys()
                    csv_file_name = file_name.replace("five", "one_twenty_five")
                    self.dump_csv(headers, csv_file_name, output)
                    print("Saved as:", csv_file_name)
                else:
                    print("No complete 125-minute chunks to save.")


    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        result_df = aggregate_daily_periods(df, sample)
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name, index=False)



    def process_all_files(self, symbols=None, source_files=None):
        """Build derived bars only for the supplied futures universe."""
        all_file_list = sorted(os.listdir(self.input_dir))
        allowed_symbols = set(symbols) if symbols is not None else None
        if allowed_symbols is not None:
            all_file_list = [
                item for item in all_file_list
                if any(str(item).startswith(f"{symbol}_") for symbol in allowed_symbols)
            ]
        if source_files is not None:
            source_names = {os.path.basename(path) for path in source_files}
            all_file_list = [item for item in all_file_list if item in source_names]
        logger.info("[FYERS] Processing derived bars for %d futures files", len(all_file_list))
        for items in tqdm(all_file_list, desc="NSEFO derived bars", unit="file"):
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            if str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
            # Underlying symbols may contain punctuation (for example M&M or
            # BAJAJ-AUTO); only the dated-contract and interval suffixes matter.
            pattern = r'^.+_\d{8}_five\.csv$'
            if re.match(pattern, str(items)):
                self.create_25munite_from_5munite(items)
                self.create_125munite_from_5munite(items)
            
        # all_files_to_process = self.get_all_stock_files()
        # self.remove_old_files(all_files_to_process)
        # with ThreadPoolExecutor(max_workers=10) as executor:
        #     for stock_item in os.listdir(self.input_dir):
        #         executor.submit(proc_delta_stock_items, stock_item, self.input_dir, self.output_dir)
        logger.info("[FYERS] NSEFO derived-bar build complete")



