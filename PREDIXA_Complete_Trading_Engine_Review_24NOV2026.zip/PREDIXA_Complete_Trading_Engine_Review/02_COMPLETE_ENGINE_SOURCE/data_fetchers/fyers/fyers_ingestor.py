#!/usr/bin/env python3
"""Shared FYERS DataSocket -> Redis latest-price ingestor.

Cash retains ``price:<symbol>``/``prices:<symbol>``. Derivatives use isolated
``market:<segment>:latest:<symbol>`` hashes and tick channels.
"""
import json, logging, os, queue, signal, threading, time
from typing import Any, Dict, Tuple

import redis
from shared.db.dbconn import DBConnection
from shared.market_data_symbols import DYNAMIC_CONTROL_CHANNEL, load_dynamic_derivative_symbols, load_segmented_symbols
try:
    from fyers_apiv3.FyersWebsocket import data_ws
except ImportError as e:
    raise SystemExit("Missing fyers-apiv3. Install with: pip install fyers-apiv3") from e
from data_fetchers.fyers.fyers_session import fyers_access_token_handler

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
MARKET_DATA_TTL_SECONDS = max(60, int(os.getenv("MARKET_DATA_REDIS_TTL_SECONDS", "172800")))
MAX_SYMBOLS = int(os.getenv("FYERS_DATA_SOCKET_MAX_SYMBOLS", "50"))
BATCH_SIZE = max(1, int(os.getenv("FYERS_SUBSCRIBE_BATCH_SIZE", "50")))
REFRESH_SECONDS = max(15, int(os.getenv("FYERS_SYMBOL_REFRESH_SECONDS", "30")))
QUEUE_SIZE = max(100, int(os.getenv("FYERS_TICK_QUEUE_SIZE", "10000")))
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s")
log = logging.getLogger("fyers.ingestor")

def now_ms(): return int(time.time() * 1000)
def coerce_ts_ms(value: Any) -> int:
    try:
        value = int(value); return value * 1000 if value < 1_000_000_000_000 else value
    except (TypeError, ValueError): return now_ms()
def redis_key(segment, symbol): return f"price:{symbol}" if segment == "cash" else f"market:{segment}:latest:{symbol}"
def redis_channel(segment, symbol): return f"prices:{symbol}" if segment == "cash" else f"market:{segment}:ticks:{symbol}"

class RedisWriter(threading.Thread):
    def __init__(self, client, tick_queue):
        super().__init__(daemon=True, name="RedisWriter")
        self.client, self.tick_queue, self.stop_event = client, tick_queue, threading.Event()
    def stop(self): self.stop_event.set()
    def _write(self, pipe, payload):
        # Redis cannot write None; missing FYERS fields remain missing, never zero.
        mapping = {k: v for k, v in payload.items() if v is not None}
        key = redis_key(payload["segment"], payload["symbol"])
        pipe.hset(key, mapping=mapping)
        # Latest values are a cache, not an unbounded tick archive. A refreshed
        # symbol keeps its value; stale/rolled contracts disappear automatically.
        pipe.expire(key, MARKET_DATA_TTL_SECONDS)
        pipe.publish(redis_channel(payload["segment"], payload["symbol"]), json.dumps(payload, separators=(",", ":")))
    def run(self):
        pipe, pending, flushed = self.client.pipeline(), 0, time.monotonic()
        while not self.stop_event.is_set():
            try: self._write(pipe, self.tick_queue.get(timeout=.1)); pending += 1
            except queue.Empty: pass
            if pending and (pending >= 200 or time.monotonic() - flushed >= .1):
                try: pipe.execute()
                except redis.RedisError: log.exception("Redis write/publish failed")
                pipe, pending, flushed = self.client.pipeline(), 0, time.monotonic()
        if pending:
            try: pipe.execute()
            except redis.RedisError: log.exception("Final Redis flush failed")

class FyersIngestor:
    def __init__(self, *, db_connection=None, redis_client=None, socket_factory=None):
        self.db = db_connection or DBConnection(); self.symbol_info = {}; self.subscribed = set()
        self.last_seen: Dict[str, Tuple[int, Any]] = {}; self.last_tick_by_segment = {}
        self.stopping, self.symbol_lock = threading.Event(), threading.Lock()
        self.r = redis_client or redis.Redis.from_url(
            REDIS_URL,
            decode_responses=True,
            health_check_interval=30,
            socket_connect_timeout=5,
            socket_timeout=5,
        )
        self.queue = queue.Queue(maxsize=QUEUE_SIZE); self.writer = RedisWriter(self.r, self.queue)
        factory = socket_factory or data_ws.FyersDataSocket
        self.ws = factory(access_token=fyers_access_token_handler().get_access_token(), log_path="", litemode=False,
            write_to_file=False, reconnect=True, on_connect=self.on_open, on_close=self.on_close,
            on_error=self.on_error, on_message=self.on_message)
    def _load_symbols(self):
        all_symbols = load_segmented_symbols(self.db)
        all_symbols.update(load_dynamic_derivative_symbols(self.r))
        cash = [x for x in all_symbols.values() if x["segment"] == "cash"]
        derivatives = [x for x in all_symbols.values() if x["segment"] != "cash"]
        selected = cash + derivatives
        if len(selected) > MAX_SYMBOLS:
            if len(cash) >= MAX_SYMBOLS:
                log.error("FYERS cap=%d reached by cash=%d; derivatives not subscribed", MAX_SYMBOLS, len(cash)); selected = cash
            else:
                dropped = selected[MAX_SYMBOLS:]; selected = selected[:MAX_SYMBOLS]
                log.error("FYERS cap=%d; rejected derivative symbols=%s", MAX_SYMBOLS, [x["symbol"] for x in dropped])
        return {x["symbol"]: x for x in selected}
    def _subscribe(self, symbols):
        for start in range(0, len(symbols), BATCH_SIZE): self.ws.subscribe(symbols=symbols[start:start+BATCH_SIZE], data_type="SymbolUpdate")
    def refresh_symbols(self, *, apply_changes):
        desired = self._load_symbols()
        with self.symbol_lock:
            old, desired_set = set(self.symbol_info), set(desired)
            removed, added = old - desired_set, desired_set - old; self.symbol_info = desired
            if apply_changes and removed:
                try: self.ws.unsubscribe(symbols=list(removed)); self.subscribed.difference_update(removed)
                except Exception: log.exception("FYERS unsubscribe failed: %s", sorted(removed))
            if apply_changes and added:
                try: self._subscribe(sorted(added)); self.subscribed.update(added)
                except Exception: log.exception("FYERS subscribe failed: %s", sorted(added))
        counts = {s: sum(x["segment"] == s for x in desired.values()) for s in ("cash", "futures", "commodity")}
        log.info("Subscription inventory %s", counts)
    def on_open(self):
        desired = self._load_symbols()
        with self.symbol_lock:
            self.symbol_info, self.subscribed = desired, set()
            try: self._subscribe(sorted(desired)); self.subscribed.update(desired); log.info("FYERS connected; subscribed=%d", len(desired))
            except Exception: log.exception("FYERS initial subscription failed")
        self.ws.keep_running()
    def on_close(self, message): log.warning("FYERS socket closed: %s", message)
    def on_error(self, message): log.error("FYERS socket error: %s", message)
    def on_message(self, message):
        for tick in message if isinstance(message, list) else [message]:
            if not isinstance(tick, dict) or tick.get("ltp") is None: continue
            symbol = tick.get("symbol")
            with self.symbol_lock: info = self.symbol_info.get(symbol)
            if not info:
                log.warning("Ignoring tick for unsubscribed/unknown symbol=%r", symbol); continue
            exchange_time = coerce_ts_ms(tick.get("exch_feed_time") or tick.get("last_traded_time")); signature = (exchange_time, tick.get("ltp"))
            prior = self.last_seen.get(symbol)
            if prior and (exchange_time < prior[0] or prior == signature): continue
            self.last_seen[symbol] = signature
            payload = {"symbol": symbol, "segment": info["segment"], "display_name": info["display_name"],
                "open": tick.get("open_price"), "high": tick.get("high_price"), "low": tick.get("low_price"), "close": tick.get("ltp"), "ltp": tick.get("ltp"),
                "previous_close": tick.get("prev_close_price"), "change": tick.get("ch"), "change_percent": tick.get("chp"), "volume": tick.get("vol_traded_today"),
                "open_interest": tick.get("open_interest") if tick.get("open_interest") is not None else tick.get("oi"), "exchange_timestamp": exchange_time, "received_at": now_ms()}
            self.last_tick_by_segment[info["segment"]] = payload["received_at"]
            try: self.queue.put_nowait(payload)
            except queue.Full:
                try: self.queue.get_nowait(); self.queue.put_nowait(payload)
                except (queue.Empty, queue.Full): log.warning("Tick queue full; dropped symbol=%s", symbol)
    def _refresh_loop(self):
        while not self.stopping.wait(REFRESH_SECONDS):
            try: self.refresh_symbols(apply_changes=True)
            except Exception: log.exception("Symbol refresh failed")
    def _control_loop(self):
        """Apply Dashboard registrations immediately; periodic refresh is fallback."""
        pubsub = self.r.pubsub(ignore_subscribe_messages=True)
        try:
            pubsub.subscribe(DYNAMIC_CONTROL_CHANNEL)
            while not self.stopping.is_set():
                if pubsub.get_message(timeout=1):
                    try: self.refresh_symbols(apply_changes=True)
                    except Exception: log.exception("Dashboard subscription refresh failed")
        except redis.RedisError:
            log.exception("Derivative subscription control channel failed")
        finally:
            try: pubsub.close()
            except Exception: pass
    def start(self):
        self.writer.start(); self.refresh_symbols(apply_changes=False)
        threading.Thread(target=self._refresh_loop, daemon=True, name="SymbolRefresh").start()
        threading.Thread(target=self._control_loop, daemon=True, name="DerivativeControl").start()
        self.ws.connect()
    def stop(self):
        if self.stopping.is_set(): return
        self.stopping.set()
        try: self.ws.close_connection()
        except Exception: pass
        self.writer.stop(); self.writer.join(timeout=2)

def main():
    ingestor = FyersIngestor()
    def stop(*_): ingestor.stop()
    signal.signal(signal.SIGINT, stop); signal.signal(signal.SIGTERM, stop); ingestor.start()
if __name__ == "__main__": main()
