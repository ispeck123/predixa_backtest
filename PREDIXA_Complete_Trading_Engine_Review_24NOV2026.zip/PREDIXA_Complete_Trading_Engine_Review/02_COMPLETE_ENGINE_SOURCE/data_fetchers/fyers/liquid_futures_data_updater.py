"""NSEFO updater variants built on the established FYERS downloader."""

from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
from scripts.scanner_fc import parse_expiry_date, select_near_next_expiries


LIQUID_NSEFO_SYMBOLS = (
    "BANKNIFTY", "FINNIFTY", "NIFTY", "HDFCBANK", "RELIANCE", "ICICIBANK",
    "BSE", "INFY", "AXISBANK", "BHARTIARTL", "SBIN", "PAYTM", "ETERNAL",
    "TCS", "ADANIENT", "LAURUSLABS", "KOTAKBANK", "TATASTEEL", "BAJFINANCE",
    "MIDCPNIFTY", "DIXON", "MCX", "SOLARINDS", "LT", "COFORGE",
    "ADANIPORTS", "M&M", "BHEL", "JIOFIN", "COALINDIA",
)


class LiquidFuturesDataHandler(Indian_future_data_handler):
    """Run the standard NSEFO ingestion path for approved liquid symbols only."""

    def get_all_stock_symbols(self):
        return list(LIQUID_NSEFO_SYMBOLS)


class GraduatedPaperFuturesDataHandler(Indian_future_data_handler):
    """Full configured NSEFO universe, with the scanner's NEAR/NEXT cutoff.

    The base class retains ownership of transport, throttling, file naming and
    candle generation.  This variant changes only the graduated-PAPER source
    and expiry selection; it is not used by the legacy liquid workflow.
    """

    def get_all_stock_symbols(self):
        return super().get_all_stock_symbols(exchange="NSEFO")

    def get_latest_fyers_futures_symbol(self, product: str):
        contracts = super().get_latest_fyers_futures_symbol(product, max_contracts=None) or []
        selected = set(select_near_next_expiries(
            [item.get("expiry") for item in contracts], min_days=5))
        eligible = [
            item for item in contracts
            if item.get("expiry") is not None
            and parse_expiry_date(item["expiry"]) in selected
        ]
        if not eligible:
            import logging
            logging.getLogger(__name__).warning(
                "[UNIVERSE] NSEFO symbol skipped: no NEAR/NEXT contract beyond five-day cutoff: %s",
                product,
            )
        return eligible
