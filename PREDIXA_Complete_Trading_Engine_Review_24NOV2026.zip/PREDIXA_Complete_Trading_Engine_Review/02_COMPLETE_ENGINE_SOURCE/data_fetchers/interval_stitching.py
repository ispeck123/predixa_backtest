"""Deterministic timestamp-anchored OHLCV stitching helpers.

NSE intraday bars are anchored to the 09:15 cash-market open. MCX bars are
anchored to the 09:00 exchange session (or 17:00 when the available session is
evening-only), and are split at the existing E1 close-to-open boundary.
"""
from __future__ import annotations

import pandas as pd


OHLCV_COLUMNS = ["open", "high", "low", "close", "qty"]
OUTPUT_COLUMNS = [*OHLCV_COLUMNS, "tradeDate"]


def _timestamp_series(frame: pd.DataFrame, *, dayfirst: bool = True) -> pd.Series:
    if "tradeDate" not in frame.columns:
        raise ValueError("candle data must contain tradeDate")
    values = frame["tradeDate"]
    # A few yfinance paths store the clock separately from the date.
    if "tradeTime" in frame.columns:
        parsed = pd.to_datetime(values, dayfirst=dayfirst, errors="coerce")
        date_only = parsed.notna() & (parsed.dt.hour == 0) & (parsed.dt.minute == 0) & (parsed.dt.second == 0)
        if date_only.any():
            combined = values.astype(str).str.strip() + " " + frame["tradeTime"].astype(str).str.strip()
            parsed.loc[date_only] = pd.to_datetime(combined.loc[date_only], dayfirst=dayfirst, errors="coerce")
        return parsed
    return pd.to_datetime(values, dayfirst=dayfirst, errors="coerce")


def _prepare_candles(frame: pd.DataFrame, *, dayfirst: bool = True) -> pd.DataFrame:
    missing = [column for column in OHLCV_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"candle data missing required columns: {missing}")
    result = frame.copy()
    result["_stitch_ts"] = _timestamp_series(result, dayfirst=dayfirst)
    result = result.dropna(subset=["_stitch_ts"])
    return result.sort_values("_stitch_ts", kind="mergesort").reset_index(drop=True)


def aggregate_daily_periods(
    frame: pd.DataFrame,
    sample: str,
    *,
    dayfirst: bool = True,
) -> pd.DataFrame:
    """Create chronological weekly/monthly OHLCV bars from daily candles."""
    data = _prepare_candles(frame, dayfirst=dayfirst)
    if data.empty:
        return pd.DataFrame(columns=OUTPUT_COLUMNS)
    data = data.set_index("_stitch_ts")
    frequency = "W-FRI" if sample.upper() == "W" else pd.offsets.MonthEnd(1)
    grouped = data.groupby(pd.Grouper(freq=frequency), sort=True)
    rows = []
    for _, group in grouped:
        if group.empty:
            continue
        rows.append({
            "open": group["open"].iloc[0],
            "high": group["high"].max(),
            "low": group["low"].min(),
            "close": group["close"].iloc[-1],
            "qty": group["qty"].sum(),
            "tradeDate": group.index[0],
        })
    result = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)
    if not result.empty:
        result["tradeDate"] = pd.to_datetime(result["tradeDate"]).dt.strftime("%d/%m/%Y %H:%M:%S")
    return result


def _aggregate_buckets(
    data: pd.DataFrame,
    keys: list[str],
    bucket_starts: pd.Series,
    *,
    expected_rows: int | None = None,
) -> pd.DataFrame:
    working = data.copy()
    working["_bucket_start"] = bucket_starts
    grouped = working.groupby(keys + ["_bucket_start"], sort=True, dropna=False)
    rows = []
    for _, group in grouped:
        if group.empty or (expected_rows is not None and len(group) < expected_rows):
            continue
        start = group["_bucket_start"].iloc[0]
        row = {
            "open": group["open"].iloc[0],
            "high": group["high"].max(),
            "low": group["low"].min(),
            "close": group["close"].iloc[-1],
            "qty": group["qty"].sum(),
            "tradeDate": start.strftime("%d/%m/%Y %H:%M:%S"),
        }
        if "tradeTime" in group.columns:
            row["tradeTime"] = start.strftime("%H:%M:%S")
        rows.append(row)
    columns = [*OHLCV_COLUMNS]
    if "tradeTime" in data.columns:
        columns.append("tradeTime")
    columns.append("tradeDate")
    result = pd.DataFrame(rows)
    if result.empty:
        return pd.DataFrame(columns=columns)
    return result[columns]


def stitch_nse_intraday(
    frame: pd.DataFrame,
    target_minutes: int,
    *,
    dayfirst: bool = True,
) -> pd.DataFrame:
    """Aggregate NSE base candles into fixed 09:15-anchored session buckets.

    Partial buckets are retained, matching the existing exporter policy; missing
    source bars cannot shift any later bucket because assignment uses timestamps.
    """
    if target_minutes <= 0:
        raise ValueError("target_minutes must be positive")
    data = _prepare_candles(frame, dayfirst=dayfirst)
    if data.empty:
        return pd.DataFrame([*OHLCV_COLUMNS, "tradeDate"])
    ts = data["_stitch_ts"]
    day = ts.dt.normalize()
    session_open = day + pd.Timedelta(hours=9, minutes=15)
    elapsed = (ts - session_open).dt.total_seconds() / 60
    in_session = (elapsed >= 0) & (elapsed < 375)
    data = data.loc[in_session].copy()
    if data.empty:
        return pd.DataFrame([*OHLCV_COLUMNS, "tradeDate"])
    elapsed = elapsed.loc[in_session]
    bucket = (elapsed // target_minutes).astype(int)
    starts = (day.loc[in_session] + pd.Timedelta(hours=9, minutes=15)
              + pd.to_timedelta(bucket * target_minutes, unit="m"))
    data["_day"] = day.loc[in_session].values
    return _aggregate_buckets(data, ["_day"], starts)


def stitch_mcx_intraday(
    frame: pd.DataFrame,
    target_minutes: int,
    *,
    base_minutes: int | None = None,
    dayfirst: bool = True,
) -> pd.DataFrame:
    """Aggregate MCX candles on 09:00-anchored exchange sessions.

    Uses the platform's E1 close-to-next-open session IDs. If a date's available
    data begins at/after 17:00 and has no earlier candle, it is treated as an
    evening-only session and anchored at 17:00; callers should validate special
    holiday schedules separately when that distinction is material.
    """
    if target_minutes <= 0:
        raise ValueError("target_minutes must be positive")
    data = _prepare_candles(frame, dayfirst=dayfirst)
    if data.empty:
        return pd.DataFrame([*OHLCV_COLUMNS, "tradeDate"])
    from scripts.mcx_session import mcx_e1_session_ids

    data["_session_id"] = mcx_e1_session_ids(data["_stitch_ts"].tolist())
    if data["_session_id"].isna().any():
        raise ValueError("could not determine MCX E1 session boundaries")
    ts = data["_stitch_ts"]
    # The E1 session normally maps to one MCX exchange date. Determine whether
    # the first available timestamp is an evening-only session without using
    # row counts or positional chunk boundaries.
    anchors = {}
    for session_id, group in data.groupby("_session_id", sort=False):
        for exchange_day, day_group in group.groupby(group["_stitch_ts"].dt.normalize(), sort=False):
            first = day_group["_stitch_ts"].iloc[0]
            anchor_hour = 17 if first.hour >= 17 else 9
            anchors[(session_id, exchange_day)] = exchange_day + pd.Timedelta(hours=anchor_hour)
    data["_exchange_day"] = ts.dt.normalize()
    row_keys = list(zip(data["_session_id"], data["_exchange_day"]))
    session_open = pd.Series([anchors[key] for key in row_keys], index=data.index)
    elapsed = (ts - session_open).dt.total_seconds() / 60
    valid = elapsed >= 0
    data = data.loc[valid].copy()
    if data.empty:
        return pd.DataFrame([*OHLCV_COLUMNS, "tradeDate"])
    elapsed = elapsed.loc[valid]
    starts = (session_open.loc[valid]
              + pd.to_timedelta((elapsed // target_minutes) * target_minutes, unit="m"))
    expected_rows = None
    if base_minutes is not None:
        if base_minutes <= 0 or target_minutes % base_minutes:
            raise ValueError("base_minutes must be positive and divide target_minutes")
        expected_rows = target_minutes // base_minutes
    return _aggregate_buckets(
        data, ["_exchange_day", "_session_id"], starts, expected_rows=expected_rows
    )
