"""Audit-only NSEFO Phase-A backtest tooling; intentionally separate from MCX."""
