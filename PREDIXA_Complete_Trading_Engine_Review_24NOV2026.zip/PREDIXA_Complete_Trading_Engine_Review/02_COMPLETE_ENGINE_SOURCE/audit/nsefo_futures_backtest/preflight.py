"""NSEFO Phase-A source readiness report.

It does not execute trading logic.  A strict run fails rather than silently
mislabeling a stitched history as an historical listed contract.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

from audit.derivatives_backtest_common.contract_inventory import contract_summary, inventory_contract_data

NSEFO_ROOT = Path("data/indian_stocks_future_data/latest_data_csv")
NSEFO_FRAMES = ("monthly", "weekly", "daily", "seventy_five", "sixty", "fifteen", "one_twenty_five", "twenty_five", "five")
NSEFO_STACKS = {
    1: ("monthly", "weekly", "daily"),
    2: ("weekly", "daily", "sixty"),
    3: ("daily", "seventy_five", "sixty", "fifteen"),
    4: ("weekly", "daily", "one_twenty_five"),
    5: ("daily", "one_twenty_five", "twenty_five"),
    25: ("weekly", "daily", "seventy_five"),
}
NSEFO_SYMBOL_METADATA = {
    "BANKNIFTY": {"avg_volume_month": 595960.5, "avg_turnover_month": 32899502112, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "FINNIFTY": {"avg_volume_month": 11562, "avg_turnover_month": 287947754.4, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "NIFTY": {"avg_volume_month": 3879131.75, "avg_turnover_month": 88312111778, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "HDFCBANK": {"avg_volume_month": 42981802.5, "avg_turnover_month": 30830902658, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "ICICIBANK": {"avg_volume_month": 16343145, "avg_turnover_month": 22063765511, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "RELIANCE": {"avg_volume_month": 17534025, "avg_turnover_month": 21088742348, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "AXISBANK": {"avg_volume_month": 12889062.5, "avg_turnover_month": 15852917628, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "INFY": {"avg_volume_month": 14965920, "avg_turnover_month": 15846135281, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "BHARTIARTL": {"avg_volume_month": 7901696.25, "avg_turnover_month": 14440675386, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "TCS": {"avg_volume_month": 5823225, "avg_turnover_month": 12951067120, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "BSE": {"avg_volume_month": 3706110, "avg_turnover_month": 12076152562, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "SBIN": {"avg_volume_month": 12116850, "avg_turnover_month": 11711443007, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "KOTAKBANK": {"avg_volume_month": 27157200, "avg_turnover_month": 11565666355, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "BAJFINANCE": {"avg_volume_month": 9589275, "avg_turnover_month": 9295161542, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "BHEL": {"avg_volume_month": 21006956.25, "avg_turnover_month": 9070542797, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "PAYTM": {"avg_volume_month": 4583450, "avg_turnover_month": 7734591653, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "ETERNAL": {"avg_volume_month": 23361116.25, "avg_turnover_month": 7545351101, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "TECHM": {"avg_volume_month": 4620360, "avg_turnover_month": 7412888055, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "HCLTECH": {"avg_volume_month": 5748900, "avg_turnover_month": 7384770116, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "LAURUSLABS": {"avg_volume_month": 3508842.5, "avg_turnover_month": 7096342236, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "MIDCPNIFTY": {"avg_volume_month": 515670, "avg_turnover_month": 7070211915, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "ITC": {"avg_volume_month": 26319187.5, "avg_turnover_month": 6935714706, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "WIPRO": {"avg_volume_month": 37446150, "avg_turnover_month": 6407210706, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "ADANIENT": {"avg_volume_month": 2279894.7, "avg_turnover_month": 6306927717, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "LT": {"avg_volume_month": 1663803.75, "avg_turnover_month": 6208654749, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "TATASTEEL": {"avg_volume_month": 34044312.5, "avg_turnover_month": 6152018485, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "POLYCAB": {"avg_volume_month": 744556.25, "avg_turnover_month": 6125672350, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "HINDALCO": {"avg_volume_month": 6421485, "avg_turnover_month": 5982240063, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "FEDERALBNK": {"avg_volume_month": 17778375, "avg_turnover_month": 5927684206, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
    "PERSISTENT": {"avg_volume_month": 1049268.75, "avg_turnover_month": 5893563119, "near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"},
}
NSEFO_FULL_UNIVERSE = frozenset({
    "ABB", "ABCAPITAL", "ADANIENSOL", "ADANIENT", "ADANIGREEN", "ADANIPORTS",
    "ALKEM", "AMBUJACEM", "ANGELONE", "APLAPOLLO", "APOLLOHOSP", "ASHOKLEY",
    "ASIANPAINT", "ASTRAL", "AUBANK", "AUROPHARMA", "AXISBANK", "BAJAJ-AUTO",
    "BAJAJFINSV", "BAJFINANCE", "BANDHANBNK", "BANKBARODA", "BANKINDIA", "BANKNIFTY",
    "BEL", "BHARATFORG", "BHARTIARTL", "BHEL", "BIOCON", "BOSCHLTD", "BPCL",
    "BRITANNIA", "BSE", "CAMS", "CANBK", "CDSL", "CGPOWER", "CHOLAFIN", "CIPLA",
    "COALINDIA", "COFORGE", "COLPAL", "CONCOR", "CROMPTON", "CUMMINSIND", "DABUR",
    "DALBHARAT", "DELHIVERY", "DIVISLAB", "DIXON", "DLF", "DMART", "DRREDDY",
    "EICHERMOT", "ETERNAL", "EXIDEIND", "FEDERALBNK", "FINNIFTY", "GAIL", "GLENMARK",
    "GMRAIRPORT", "GODREJCP", "GODREJPROP", "GRASIM", "HAL", "HAVELLS", "HCLTECH",
    "HDFCAMC", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO", "HINDALCO", "HINDPETRO",
    "HINDUNILVR", "HINDZINC", "HUDCO", "ICICIBANK", "ICICIGI", "ICICIPRULI", "IDEA",
    "IDFCFIRSTB", "IEX", "INDHOTEL", "INDIANB", "INDIGO", "INDUSINDBK", "INDUSTOWER",
    "INFY", "INOXWIND", "IOC", "IREDA", "IRFC", "ITC", "JINDALSTEL", "JIOFIN",
    "JSWENERGY", "JSWSTEEL", "JUBLFOOD", "KALYANKJIL", "KEI", "KOTAKBANK", "KPITTECH",
    "LAURUSLABS", "LICHSGFIN", "LICI", "LODHA", "LT", "LTF", "LUPIN", "M&M",
    "MANAPPURAM", "MARICO", "MARUTI", "MAXHEALTH", "MCX", "MFSL", "MIDCPNIFTY",
    "MOTHERSON", "MPHASIS", "MUTHOOTFIN", "NATIONALUM", "NAUKRI", "NBCC", "NESTLEIND",
    "NHPC", "NIFTY", "NIFTYNXT50", "NMDC", "NTPC", "NYKAA", "OBEROIRLTY", "OFSS",
    "OIL", "ONGC", "PAGEIND", "PATANJALI", "PAYTM", "PERSISTENT", "PETRONET", "PFC",
    "PHOENIXLTD", "PIDILITIND", "PIIND", "PNB", "PNBHOUSING", "POLICYBZR", "POLYCAB",
    "POWERGRID", "PRESTIGE", "RBLBANK", "RECLTD", "RELIANCE", "SAIL", "SBICARD",
    "SBILIFE", "SBIN", "SHREECEM", "SHRIRAMFIN", "SIEMENS", "SOLARINDS", "SONACOMS",
    "SRF", "SUNPHARMA", "SUPREMEIND", "SYNGENE", "TATACONSUM", "TATAELXSI", "TATAPOWER",
    "TATASTEEL", "TATATECH", "TCS", "TECHM", "TIINDIA", "TITAN", "TORNTPHARM",
    "TORNTPOWER", "TRENT", "TVSMOTOR", "ULTRACEMCO", "UNIONBANK", "UNITDSPR", "UPL",
    "VBL", "VEDL", "VOLTAS", "WIPRO", "YESBANK", "ZYDUSLIFE",
})
NSEFO_COMPLETED_SYMBOLS = frozenset({
    "BANKNIFTY", "FINNIFTY", "NIFTY", "HDFCBANK", "ICICIBANK", "RELIANCE", "AXISBANK",
    "INFY", "BHARTIARTL", "TCS", "BSE", "SBIN", "KOTAKBANK", "BAJFINANCE", "BHEL",
    "PAYTM", "ETERNAL", "TECHM", "HCLTECH", "LAURUSLABS", "MIDCPNIFTY", "ITC", "WIPRO",
    "ADANIENT", "LT", "TATASTEEL", "POLYCAB", "HINDALCO", "FEDERALBNK", "PERSISTENT",
})
if NSEFO_FULL_UNIVERSE - set(NSEFO_SYMBOL_METADATA):
    NSEFO_SYMBOL_METADATA.update({
        symbol: {"near_expiry": "2026-10-27", "next_expiry": "2026-11-23", "far_expiry": "2026-12-29"}
        for symbol in NSEFO_FULL_UNIVERSE - set(NSEFO_SYMBOL_METADATA)
    })
NSEFO_ALLOWED_SYMBOLS = frozenset(NSEFO_FULL_UNIVERSE - NSEFO_COMPLETED_SYMBOLS)
NSEFO_EXPIRY_SCHEDULE = {
    symbol: ("27102026", "23112026", "29122026")
    for symbol in NSEFO_FULL_UNIVERSE
}
NSEFO_ACTIVE_EXPIRY_TIER = "near"
NSEFO_ACTIVE_EXPIRIES = {
    symbol: (datetime.strptime(metadata["near_expiry"], "%Y-%m-%d").strftime("%d%m%Y"),)
    for symbol, metadata in NSEFO_SYMBOL_METADATA.items()
}
NSEFO_APPROVED_EXPIRIES = frozenset(expiry for values in NSEFO_ACTIVE_EXPIRIES.values() for expiry in values)
INDEX_SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate NSEFO Phase-A source data before clean replay.")
    parser.add_argument("--root", type=Path, default=NSEFO_ROOT)
    parser.add_argument("--output", type=Path, default=Path("audit/nsefo_futures_backtest/results"))
    parser.add_argument("--strict-contract-history", action="store_true", help="return non-zero if files predate plausible contract start")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    inv = inventory_contract_data(args.root, NSEFO_FRAMES, NSEFO_STACKS, "NSEFO")
    inv = inv[inv["symbol"].isin(NSEFO_ALLOWED_SYMBOLS) & inv["expiry"].isin(NSEFO_APPROVED_EXPIRIES)].copy()
    inv["instrument_class"] = inv["symbol"].map(lambda x: "index" if x in INDEX_SYMBOLS else "stock")
    summary = contract_summary(inv)
    summary["instrument_class"] = summary["symbol"].map(lambda x: "index" if x in INDEX_SYMBOLS else "stock")
    inv.to_csv(args.output / "nsefo_source_file_inventory.csv", index=False)
    summary.to_csv(args.output / "nsefo_contract_inventory.csv", index=False)
    modes = inv.source_mode.value_counts(dropna=False).to_dict()
    ready = summary.tf_ready.fillna("").value_counts().head(20).to_dict()
    print(f"NSEFO source files: {len(inv):,}; contract keys: {len(summary):,}; symbols: {summary.symbol.nunique():,}")
    print(f"Allowed symbols: {len(NSEFO_ALLOWED_SYMBOLS)}; discovered allowed symbols: {summary.symbol.nunique():,}; approved expiries: {sorted(NSEFO_APPROVED_EXPIRIES)}")
    print(f"Source mode counts: {modes}")
    print(f"Top TF-readiness signatures: {ready}")
    if args.strict_contract_history and (inv.source_mode == "STITCHED_OR_CONTINUOUS").any():
        print("STRICT FAILURE: supplied files predate their stated contract expiry window; historical contract-live attribution is not evidenced.")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
