"""Contract-file inventory and continuity safety checks.

This module deliberately does not alter production data or production trading
logic.  It identifies what the supplied files can support before a replay is
allowed to call ``process_setup_fc``.
"""
from __future__ import annotations

from collections import defaultdict
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd
from dateutil.relativedelta import relativedelta


@dataclass(frozen=True)
class ContractFile:
    symbol: str
    expiry: str
    timeframe: str
    path: Path


def parse_contract_filename(path: Path, frames: Iterable[str]) -> ContractFile | None:
    """Parse ``SYMBOL_DDMMYYYY_TIME_FRAME.csv`` without assuming one-word TFs."""
    stem = path.stem
    for frame in sorted(set(frames), key=len, reverse=True):
        suffix = f"_{frame}"
        if not stem.endswith(suffix):
            continue
        prefix = stem[: -len(suffix)]
        try:
            symbol, expiry = prefix.rsplit("_", 1)
        except ValueError:
            return None
        if symbol and len(expiry) == 8 and expiry.isdigit():
            return ContractFile(symbol.upper(), expiry, frame, path)
    return None


def read_timestamp_range(path: Path) -> tuple[pd.Timestamp | None, pd.Timestamp | None, int, str | None]:
    """Read first/last records only; inventories must not load thousands of OHLC files."""
    try:
        with path.open("r", newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            column = "tradeDate" if "tradeDate" in (reader.fieldnames or []) else "timestamp" if "timestamp" in (reader.fieldnames or []) else None
            first_row = next(reader, None)
        if column is None:
            return None, None, 0, "missing tradeDate/timestamp column"
        # A typical row is short. Reading the final 64 KiB avoids a complete CSV
        # scan while still safely captures the final physical record.
        with path.open("rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 65536))
            lines = fh.read().decode("utf-8", errors="replace").splitlines()
        last_row = next((row for row in reversed(lines) if row.strip()), "")
        first_value = first_row.get(column) if first_row else None
        last_values = next(csv.reader([last_row]), [])
        header = (reader.fieldnames or [])
        last_value = last_values[header.index(column)] if len(last_values) > header.index(column) else None
        first = pd.to_datetime(first_value, dayfirst=True, errors="coerce")
        last = pd.to_datetime(last_value, dayfirst=True, errors="coerce")
        if pd.isna(first) or pd.isna(last):
            return None, None, 0, "unparseable first/last timestamp"
        return pd.Timestamp(first), pd.Timestamp(last), 0, None
    except Exception as exc:
        return None, None, 0, f"{type(exc).__name__}: {exc}"


def expected_contract_start(expiry: str) -> pd.Timestamp:
    """Conservative three-calendar-month plausibility boundary for an NFO/MCX contract."""
    return pd.to_datetime(expiry, format="%d%m%Y") - relativedelta(months=3) - pd.Timedelta(days=7)


def inventory_contract_data(root: Path, frames: Iterable[str], required_stacks: dict[int, tuple[str, ...]], segment: str) -> pd.DataFrame:
    """Return one row per physical source file with continuity and TF-readiness facts."""
    records: list[dict] = []
    required_by_tf = {tf: set(stack) for tf, stack in required_stacks.items()}
    parsed: list[ContractFile] = []
    for path in sorted(root.glob("*.csv")):
        item = parse_contract_filename(path, frames)
        if item is not None:
            parsed.append(item)
    available: dict[tuple[str, str], set[str]] = defaultdict(set)
    for item in parsed:
        available[(item.symbol, item.expiry)].add(item.timeframe)
    for item in parsed:
        first, last, n, error = read_timestamp_range(item.path)
        legal_start = expected_contract_start(item.expiry)
        source_mode = "UNREADABLE" if error else ("STITCHED_OR_CONTINUOUS" if first < legal_start else "CONTRACT_WINDOW_PLAUSIBLE")
        available_frames = available[(item.symbol, item.expiry)]
        ready_tfs = ",".join(str(tf) for tf, stack in required_by_tf.items() if stack.issubset(available_frames))
        records.append({
            "segment": segment,
            "symbol": item.symbol,
            "expiry": item.expiry,
            "timeframe": item.timeframe,
            "path": str(item.path),
            "rows": n,
            "source_start": first.isoformat() if first is not None else None,
            "source_end": last.isoformat() if last is not None else None,
            "expected_contract_start_not_before": legal_start.isoformat(),
            "source_mode": source_mode,
            "tf_ready": ready_tfs,
            "read_error": error,
        })
    return pd.DataFrame(records)


def contract_summary(inventory: pd.DataFrame) -> pd.DataFrame:
    """Summarise a physical-contract inventory without conflating rows/files."""
    if inventory.empty:
        return pd.DataFrame(columns=["segment", "symbol", "expiry", "frames", "source_mode", "tf_ready"])
    return (inventory.groupby(["segment", "symbol", "expiry"], dropna=False)
        .agg(frames=("timeframe", lambda x: ",".join(sorted(set(x)))),
             source_mode=("source_mode", lambda x: ",".join(sorted(set(x)))),
             tf_ready=("tf_ready", lambda x: ",".join(sorted(set(filter(None, x))))),
             earliest_source=("source_start", "min"), latest_source=("source_end", "max"))
        .reset_index())
