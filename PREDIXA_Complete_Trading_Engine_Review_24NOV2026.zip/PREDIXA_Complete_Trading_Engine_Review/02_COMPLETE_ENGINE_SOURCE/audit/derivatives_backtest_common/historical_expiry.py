"""Fail-closed historical expiry and contract-slot lookup for research replays.

The supplied OHLC containers are not treated as dated-contract evidence.  A
resolution is returned only when a separately supplied map has both an
``OFFICIAL_VERIFIED`` record and an explicit historical contract slot interval.
This keeps exchange expiry facts, provider-series construction, and current
filename labels as separate evidence streams.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

import pandas as pd


APPROVED_STATUS = "OFFICIAL_VERIFIED"
REQUIRED_COLUMNS = {
    "exchange", "symbol", "instrument_type", "contract_slot", "expiry_date",
    "active_from", "active_to", "verification_status",
}


@dataclass(frozen=True)
class ExpiryResolution:
    status: str
    exchange: str
    symbol: str
    contract_slot: str
    trade_timestamp: str
    historical_contract_identifier: str | None = None
    historical_expiry_date: str | None = None
    source_name: str | None = None
    source_file: str | None = None
    reason: str | None = None


def _ist(value: object) -> pd.Timestamp:
    stamp = pd.Timestamp(value)
    if pd.isna(stamp):
        raise ValueError(f"invalid timestamp: {value!r}")
    return stamp.tz_localize("Asia/Kolkata") if stamp.tzinfo is None else stamp.tz_convert("Asia/Kolkata")


def load_historical_expiry_map(path: Path) -> list[dict[str, str]]:
    """Load an owner-approved map and reject incomplete/ambiguous definitions."""
    if not path.is_file():
        raise FileNotFoundError(f"historical expiry map is unavailable: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError("historical expiry map is empty")
    missing = REQUIRED_COLUMNS - set(rows[0])
    if missing:
        raise ValueError(f"historical expiry map missing columns: {', '.join(sorted(missing))}")
    for row in rows:
        if row.get("verification_status", "").strip().upper() != APPROVED_STATUS:
            continue
        for key in ("exchange", "symbol", "instrument_type", "contract_slot", "expiry_date", "active_from", "active_to"):
            if not str(row.get(key, "")).strip():
                raise ValueError(f"verified expiry row missing {key}")
        _ist(row["active_from"]); _ist(row["active_to"]); _ist(row["expiry_date"])
    return rows


def get_historical_expiry(
    records: list[dict[str, str]], exchange: str, symbol: str, trade_timestamp: object,
    contract_slot: str, instrument_type: str | None = None,
) -> ExpiryResolution:
    """Resolve only an approved, point-in-time slot record; never infer one."""
    stamp = _ist(trade_timestamp)
    exchange, symbol, slot = exchange.upper(), symbol.upper(), contract_slot.upper()
    candidates = []
    for row in records:
        if row.get("verification_status", "").strip().upper() != APPROVED_STATUS:
            continue
        if row.get("exchange", "").strip().upper() != exchange or row.get("symbol", "").strip().upper() != symbol:
            continue
        if row.get("contract_slot", "").strip().upper() != slot:
            continue
        if instrument_type and row.get("instrument_type", "").strip().upper() != instrument_type.upper():
            continue
        if _ist(row["active_from"]) <= stamp <= _ist(row["active_to"]):
            candidates.append(row)
    if len(candidates) != 1:
        return ExpiryResolution(
            "MISSING_EVIDENCE" if not candidates else "CONFLICT_REQUIRES_REVIEW",
            exchange, symbol, slot, stamp.isoformat(),
            reason="no unique OFFICIAL_VERIFIED point-in-time slot-to-contract record",
        )
    row = candidates[0]
    return ExpiryResolution(
        APPROVED_STATUS, exchange, symbol, slot, stamp.isoformat(),
        row.get("contract_identifier") or None, _ist(row["expiry_date"]).date().isoformat(),
        row.get("source_name") or None, row.get("source_file") or None,
    )
