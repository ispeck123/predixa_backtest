"""Extract a reviewable *candidate* expiry map from contract-style filenames.

This is deliberately an audit-preparation utility, not a source of official
exchange facts.  Every emitted row is marked
``FILENAME_EXTRACTED_PENDING_OWNER_VERIFICATION``.  An owner must verify and
replace that status with ``OFFICIAL_VERIFIED`` before the continuous-series
filter will accept the map.

The utility never reads or modifies market-data contents and refuses to
overwrite an existing artefact.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import pandas as pd

from .contract_inventory import parse_contract_filename


MCX_FRAMES = ("monthly", "weekly", "daily", "two_forty", "one_twenty", "seventy_five", "sixty", "fifteen")
NSEFO_FRAMES = ("monthly", "weekly", "daily", "one_twenty_five", "seventy_five", "twenty_five", "sixty", "fifteen", "five")
PENDING_STATUS = "FILENAME_EXTRACTED_PENDING_OWNER_VERIFICATION"
MAP_COLUMNS = ("symbol", "roll_date", "verification_status", "source_filenames", "extraction_rule")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_candidate_expiry_map(data_root: Path, segment: str, output: Path) -> dict:
    """Write unique ``symbol, expiry`` filename facts, without official stamping."""
    segment = segment.upper()
    if segment not in {"MCX", "NSEFO"}:
        raise ValueError("segment must be MCX or NSEFO")
    if output.exists():
        raise FileExistsError(f"refusing to overwrite map artifact: {output}")
    frames = MCX_FRAMES if segment == "MCX" else NSEFO_FRAMES
    facts: dict[tuple[str, str], list[str]] = defaultdict(list)
    for path in sorted(data_root.glob("*.csv")):
        item = parse_contract_filename(path, frames)
        if item is not None:
            facts[(item.symbol, item.expiry)].append(path.name)
    if not facts:
        raise ValueError(f"no {segment} contract-style filenames found in {data_root}")

    rows = []
    for (symbol, expiry), names in sorted(
        facts.items(), key=lambda item: (item[0][0], pd.to_datetime(item[0][1], format="%d%m%Y"))
    ):
        rows.append({
            "symbol": symbol,
            "roll_date": pd.to_datetime(expiry, format="%d%m%Y").date().isoformat(),
            "verification_status": PENDING_STATUS,
            "source_filenames": "|".join(sorted(names)),
            "extraction_rule": "SYMBOL_DDMMYYYY_TIMEFRAME.csv filename date; expiry equals roll boundary per locked 10-Nov-2026 specification",
        })
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=MAP_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    manifest = output.with_suffix(output.suffix + ".manifest.json")
    manifest.write_text(json.dumps({
        "schema": "PREDIXA_FILENAME_EXTRACTED_EXPIRY_MAP_CANDIDATE_V1",
        "segment": segment,
        "data_root": str(data_root.resolve()),
        "row_count": len(rows),
        "symbol_count": len({row["symbol"] for row in rows}),
        "min_expiry": min(row["roll_date"] for row in rows),
        "max_expiry": max(row["roll_date"] for row in rows),
        "verification_status": PENDING_STATUS,
        "owner_action_required": "Verify against official exchange expiry schedules, replace status with OFFICIAL_VERIFIED, then use as --roll-calendar.",
        "map_sha256": sha256(output),
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"output": str(output), "manifest": str(manifest), "rows": len(rows), "sha256": sha256(output)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--segment", required=True, choices=("MCX", "NSEFO"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    print(json.dumps(build_candidate_expiry_map(args.data_root, args.segment, args.output), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
