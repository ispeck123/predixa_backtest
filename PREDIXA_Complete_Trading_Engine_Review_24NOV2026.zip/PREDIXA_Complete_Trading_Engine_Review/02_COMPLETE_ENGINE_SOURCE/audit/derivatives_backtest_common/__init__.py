"""Shared, audit-only source validation for the separate NSEFO and MCX replays."""
