"""Transparent calendar-inferred contract labels for stitched derivative series.

These labels identify the assumed front-month period only.  They are not a
claim that the supplied OHLC belongs to the named historical contract.
"""
from __future__ import annotations

import pandas as pd


def _last_weekday(day: pd.Timestamp, weekday: int) -> pd.Timestamp:
    month_end = day + pd.offsets.MonthEnd(0)
    return month_end - pd.Timedelta(days=(month_end.weekday() - weekday) % 7)


def nsefo_contract_live(symbol: str, timestamp: object, roll_business_days: int = 2) -> tuple[str, bool]:
    """Infer a front-month label using last-Tuesday expiry and a two-day roll.

    This is deliberately a calendar policy, rather than expiry-file evidence.
    """
    ts = pd.Timestamp(timestamp)
    expiry = _last_weekday(ts.normalize(), weekday=1)  # Tuesday
    roll = expiry - pd.offsets.BDay(roll_business_days)
    if ts.normalize() >= roll:
        next_month = ts.normalize() + pd.offsets.MonthBegin(1)
        expiry = _last_weekday(next_month, weekday=1)
        return f"{symbol.upper()}@{expiry:%d%m%Y}", True
    return f"{symbol.upper()}@{expiry:%d%m%Y}", False


def mcx_contract_live(symbol: str, timestamp: object) -> tuple[str, bool]:
    """Infer a monthly MCX contract-period label; expiry day is not evidenced."""
    ts = pd.Timestamp(timestamp)
    first = ts.normalize().replace(day=1)
    return f"{symbol.upper()}@{first:%Y%m}", bool(ts.day == 1)
