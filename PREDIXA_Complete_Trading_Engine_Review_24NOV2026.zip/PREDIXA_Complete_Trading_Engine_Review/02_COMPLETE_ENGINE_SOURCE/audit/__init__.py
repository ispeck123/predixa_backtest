"""Audit-only tooling package; production code does not import this package."""
