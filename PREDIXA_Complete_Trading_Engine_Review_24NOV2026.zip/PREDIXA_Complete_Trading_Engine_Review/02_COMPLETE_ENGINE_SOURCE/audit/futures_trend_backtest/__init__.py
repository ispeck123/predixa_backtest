"""Audit-only, durable replay of the current NSE futures setup pipeline."""
