"""Derive PREDIXA's configured commodity frames from exact dated 60-minute bars.

This is an OHLC aggregation utility, not a contract selector or a strategy.
All groups remain inside the Task-1 E1 session IDs. The configured commodity
stacks use monthly/weekly/daily/240m/120m/60m; no 75m frame is inferred here.
"""
from __future__ import annotations

import pandas as pd

from scripts.mcx_session import mcx_e1_session_ids

FRAME_NAMES = ("sixty", "one_twenty", "two_forty", "daily", "weekly", "monthly")


def _validate_hourly(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"timestamp", "open", "high", "low", "close", "volume"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"60-minute dated bars missing fields: {sorted(missing)}")
    out = frame.copy()
    out["timestamp"] = pd.to_datetime(out.timestamp, errors="coerce")
    if out.timestamp.isna().any():
        raise ValueError("60-minute bars contain invalid timestamps")
    if out.timestamp.dt.tz is None:
        raise ValueError("60-minute timestamps must be timezone-aware")
    out["timestamp"] = out.timestamp.dt.tz_convert("Asia/Kolkata")
    out = out.sort_values("timestamp", kind="stable").reset_index(drop=True)
    if out.timestamp.duplicated().any():
        raise ValueError("60-minute bars contain duplicate timestamps")
    for col in ("open", "high", "low", "close", "volume"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    if out[["open", "high", "low", "close", "volume"]].isna().any().any():
        raise ValueError("60-minute bars contain non-numeric or missing OHLCV")
    if ((out.high < out[["open", "low", "close"]].max(axis=1)) |
            (out.low > out[["open", "high", "close"]].min(axis=1)) | (out.volume < 0)).any():
        raise ValueError("60-minute bars contain invalid OHLCV")
    session_ids = mcx_e1_session_ids(out.timestamp.tolist())
    if session_ids is None or len(session_ids) != len(out):
        raise ValueError("Task-1 E1 session identification failed")
    out["e1_session_id"] = session_ids
    return out


def _aggregate(frame: pd.DataFrame, keys: list[str], *, target_name: str) -> pd.DataFrame:
    grouped = frame.groupby(keys, sort=True, dropna=False)
    rows = []
    for _, part in grouped:
        part = part.sort_values("timestamp", kind="stable")
        first = part.iloc[0]
        rows.append({"timestamp": first.timestamp, "open": first.open,
            "high": part.high.max(), "low": part.low.min(), "close": part.close.iloc[-1],
            "volume": part.volume.sum(), "e1_session_id": first.e1_session_id,
            "source_bar_count": len(part), "timeframe": target_name,
            **({"underlying": first.underlying} if "underlying" in part else {}),
            **({"contract_symbol": first.contract_symbol} if "contract_symbol" in part else {}),
            **({"contract_expiry": first.contract_expiry} if "contract_expiry" in part else {})})
    return pd.DataFrame(rows)


def derive_strategy_timeframes(hourly: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Aggregate OHLCV without crossing E1 sessions or fabricating bars.

    120m/240m buckets are anchored at the 09:00 IST session open. A short final
    bucket is retained with ``source_bar_count`` so the consumer can audit it;
    missing intraday bars are not interpolated. Daily bars are per E1 session.
    Weekly/monthly bars follow the updater's W-FRI/month-end grouping, with
    timestamp set to the first observed daily candle in the period.
    """
    frame = _validate_hourly(hourly)
    result: dict[str, pd.DataFrame] = {"sixty": frame.assign(timeframe="sixty").copy()}
    local_minutes = frame.timestamp.dt.hour * 60 + frame.timestamp.dt.minute - 9 * 60
    if (local_minutes < 0).any():
        raise ValueError("MCX source candle precedes the 09:00 strategy session open")
    for name, width in (("one_twenty", 120), ("two_forty", 240)):
        buckets = (local_minutes // width).astype(int)
        part = frame.assign(_bucket=buckets)
        result[name] = _aggregate(part, ["e1_session_id", "_bucket"], target_name=name)
    daily = _aggregate(frame, ["e1_session_id"], target_name="daily")
    result["daily"] = daily
    dated = daily.copy()
    calendar_ts = dated.timestamp.dt.tz_localize(None)
    dated["_period_week"] = calendar_ts.dt.to_period("W-FRI").astype(str)
    dated["_period_month"] = calendar_ts.dt.to_period("M").astype(str)
    result["weekly"] = _aggregate(dated, ["_period_week"], target_name="weekly")
    result["monthly"] = _aggregate(dated, ["_period_month"], target_name="monthly")
    for name, out in result.items():
        if out.empty or out.timestamp.duplicated().any() or not out.timestamp.is_monotonic_increasing:
            raise ValueError(f"derived {name} frame is empty, duplicated or unordered")
        if ((out.high < out[["open", "low", "close"]].max(axis=1)) |
                (out.low > out[["open", "high", "close"]].min(axis=1))).any():
            raise ValueError(f"derived {name} OHLC envelope is invalid")
    return result
