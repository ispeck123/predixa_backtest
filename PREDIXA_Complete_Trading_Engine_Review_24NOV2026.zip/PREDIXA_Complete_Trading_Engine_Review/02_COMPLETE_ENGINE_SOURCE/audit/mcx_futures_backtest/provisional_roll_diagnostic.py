"""Real-price, non-authoritative CRUDEOILM roll arithmetic diagnostic.

This utility exists to exercise the Task-2 builder on the two independently
identified FYERS dated contracts currently cached in this repository.  It does
not infer listing dates, approve a roll policy, construct an authoritative
research bundle, or run a strategy/export.  The candidate session switch is a
clearly-labelled input assumption and the resulting series must remain outside
the authoritative replay path.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

from .contract_roll import DatedContract, RollPolicy, RollTransition, build_back_adjusted_series


ROOT = Path(__file__).resolve().parents[2]
AUGMENTED = ROOT / "research/mcx_fyers_expired/CRUDEOILM/MCX_CRUDEOILM26AUGFUT/60/2026-08-01_2026-10-08_4e190c2a3217/bars.csv"
OCTOBER = ROOT / "research/zone_series_comparison/data/CRUDEOILM_19OCT_raw_60m.csv"
EFFECTIVE_AT = pd.Timestamp("2026-08-17 09:00:00", tz="Asia/Kolkata")


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load(path: Path, symbol: str, expiry: str) -> pd.DataFrame:
    frame = pd.read_csv(path).rename(columns={"timestamp_ist": "timestamp", "qty": "volume"})
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="raise")
    frame["underlying"] = "CRUDEOILM"
    frame["contract_symbol"] = symbol
    frame["contract_expiry"] = expiry
    return frame


def build_provisional_diagnostic(august: pd.DataFrame, october: pd.DataFrame, *, effective_at=EFFECTIVE_AT):
    """Use observed raw close/open values for a candidate, pending-policy roll.

    Contract symbols and OHLCV are provider-evidenced.  The selection boundary
    is intentionally supplied by the caller because no approved historical
    calendar/policy record presently proves it.
    """
    effective_at = pd.Timestamp(effective_at)
    if effective_at.tzinfo is None:
        effective_at = effective_at.tz_localize("Asia/Kolkata")
    else:
        effective_at = effective_at.tz_convert("Asia/Kolkata")
    august = august.copy(); october = october.copy()
    august["timestamp"] = pd.to_datetime(august.timestamp)
    october["timestamp"] = pd.to_datetime(october.timestamp)
    outgoing = august[august.timestamp < effective_at]
    incoming = october[october.timestamp >= effective_at]
    if outgoing.empty or incoming.empty:
        raise ValueError("candidate switch has no observed outgoing close or incoming open")
    outgoing_price = float(outgoing.iloc[-1].close)
    incoming_price = float(incoming.iloc[0].open)
    contracts = [
        DatedContract("CRUDEOILM", "MCX:CRUDEOILM26AUGFUT", "MCX:CRUDEOILM26AUGFUT", "MCX", "2026-08-19",
                      pd.Timestamp(august.timestamp.min()), effective_at, "FYERS:expired:aug", listed_from=None),
        DatedContract("CRUDEOILM", "MCX:CRUDEOILM26OCTFUT", "MCX:CRUDEOILM26OCTFUT", "MCX", "2026-10-19",
                      effective_at, None, "FYERS:sidecar:oct", listed_from=None),
    ]
    roll = RollTransition("CRUDEOILM", contracts[0].contract_symbol, contracts[1].contract_symbol,
                          effective_at, effective_at, outgoing_price, incoming_price,
                          "FYERS:aug-close/oct-open:observed", verified=True)
    return build_back_adjusted_series(
        contracts,
        {("CRUDEOILM", contracts[0].contract_symbol): august,
         ("CRUDEOILM", contracts[1].contract_symbol): october},
        [roll],
        RollPolicy("candidate-three-session-before-expiry-additive", "additive", "PENDING_APPROVAL"),
        naive_timezone=None,
        expected_interval="60min",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "research/mcx_fyers_expired/diagnostics/provisional_aug_oct_roll")
    args = parser.parse_args()
    if not AUGMENTED.is_file() or not OCTOBER.is_file():
        raise SystemExit("required FYERS dated raw cache is unavailable")
    august = _load(AUGMENTED, "MCX:CRUDEOILM26AUGFUT", "2026-08-19")
    october = _load(OCTOBER, "MCX:CRUDEOILM26OCTFUT", "2026-10-19")
    result = build_provisional_diagnostic(august, october)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result.series.to_csv(args.output_dir / "CRUDEOILM_AUG_OCT_PROVISIONAL_RESEARCH_SERIES.csv", index=False)
    payload = {
        "status": "PROVISIONAL_ROLL_ARITHMETIC_ONLY",
        "authoritative": False,
        "outgoing_contract": "MCX:CRUDEOILM26AUGFUT",
        "incoming_contract": "MCX:CRUDEOILM26OCTFUT",
        "candidate_effective_at": EFFECTIVE_AT.isoformat(),
        "candidate_boundary_basis": "three observed source-session dates remain through expiry; official calendar and policy approval absent",
        "source_hashes": {str(AUGMENTED.relative_to(ROOT)): _digest(AUGMENTED), str(OCTOBER.relative_to(ROOT)): _digest(OCTOBER)},
        "roll_metadata": result.roll_metadata,
        "builder_validation": result.validation_summary,
        "prohibitions": ["not an approved roll schedule", "not a point-in-time contract-selection proof", "not an executable-price backtest", "not an authoritative export", "not eligible for edge reproduction"],
    }
    (args.output_dir / "provisional_roll_manifest.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": payload["status"], "rows": len(result.series), "rolls": len(result.roll_metadata), "validation": result.validation_summary["status"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
