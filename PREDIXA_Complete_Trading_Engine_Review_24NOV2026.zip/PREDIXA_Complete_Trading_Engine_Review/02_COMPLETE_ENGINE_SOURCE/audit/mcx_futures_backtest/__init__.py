"""Audit-only MCX Phase-A backtest tooling; intentionally separate from NSEFO."""
