"""NON_AUTHORITATIVE diagnostic for two FYERS exact dated-contract overlaps.

This reports simultaneous raw prices only. It neither selects a roll timestamp
nor generates a continuous series or P&L.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import pandas as pd


def compare_overlap(left_path: Path, right_path: Path, *, left_symbol: str,
                    right_symbol: str, output_dir: Path) -> dict:
    if left_symbol == right_symbol:
        raise ValueError("overlap diagnostic requires two distinct dated symbols")
    left, right = pd.read_csv(left_path), pd.read_csv(right_path)
    left_time = "timestamp" if "timestamp" in left else "timestamp_ist" if "timestamp_ist" in left else None
    right_time = "timestamp" if "timestamp" in right else "timestamp_ist" if "timestamp_ist" in right else None
    if not left_time or not right_time:
        raise ValueError("both raw contract files require timestamp fields")
    for frame, col in ((left, left_time), (right, right_time)):
        frame[col] = pd.to_datetime(frame[col], errors="coerce", utc=True)
        if frame[col].isna().any() or frame[col].duplicated().any() or not frame[col].is_monotonic_increasing:
            raise ValueError("raw contract timestamps must be valid, unique, and ordered")
    if {"open", "high", "low", "close", "volume"} - set(left) or {"open", "high", "low", "close", "volume"} - set(right):
        raise ValueError("raw contract files must contain OHLCV")
    l = left[[left_time, "open", "high", "low", "close", "volume"]].rename(columns={left_time: "timestamp", **{k:f"{k}_left" for k in ("open","high","low","close","volume")}})
    r = right[[right_time, "open", "high", "low", "close", "volume"]].rename(columns={right_time: "timestamp", **{k:f"{k}_right" for k in ("open","high","low","close","volume")}})
    joined = l.merge(r, on="timestamp", how="inner", validate="one_to_one").sort_values("timestamp")
    if joined.empty:
        raise ValueError("the dated contract histories have no exact timestamp overlap")
    joined["timestamp_ist"] = joined.timestamp.dt.tz_convert("Asia/Kolkata").astype(str)
    joined["left_contract"] = left_symbol
    joined["right_contract"] = right_symbol
    joined["close_difference_left_minus_right"] = joined.close_left - joined.close_right
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "crudeoilm_aug_oct_60m_raw_overlap.csv"
    columns = ["timestamp_ist", "left_contract", "right_contract",
        "open_left", "high_left", "low_left", "close_left", "volume_left",
        "open_right", "high_right", "low_right", "close_right", "volume_right",
        "close_difference_left_minus_right"]
    joined[columns].to_csv(csv_path, index=False)
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    manifest = {"status": "NON_AUTHORITATIVE_RAW_OVERLAP_DIAGNOSTIC",
        "provider": "FYERS", "underlying": "CRUDEOILM", "left_contract": left_symbol,
        "right_contract": right_symbol, "left_source": str(left_path), "right_source": str(right_path),
        "left_source_sha256": sha(left_path), "right_source_sha256": sha(right_path),
        "output": str(csv_path), "output_sha256": sha(csv_path), "exact_overlap_rows": len(joined),
        "overlap_start_ist": joined.timestamp_ist.iloc[0], "overlap_end_ist": joined.timestamp_ist.iloc[-1],
        "mean_close_difference": float(joined.close_difference_left_minus_right.mean()),
        "roll_selected": False, "roll_prices_claimed": False, "continuous_series_created": False,
        "pnl_or_realized_r_calculated": False}
    (output_dir / "crudeoilm_aug_oct_60m_raw_overlap.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return manifest
