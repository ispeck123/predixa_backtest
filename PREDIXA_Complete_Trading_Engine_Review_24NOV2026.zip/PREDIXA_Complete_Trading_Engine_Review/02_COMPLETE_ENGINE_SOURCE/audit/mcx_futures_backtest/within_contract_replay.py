"""Revised MCX within-contract segmentation and research-admissibility layer.

This deliberately does *not* back-adjust prices or recover expired contracts.
It segments an owner-attested continuous source at explicit local expiry labels,
keeps the original source classification intact, and marks any missing calendar
or boundary evidence instead of silently admitting it to authoritative replay.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, asdict
from datetime import date, datetime, timedelta
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Iterable

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.mcx_session import mcx_e1_session_ids

DEFAULT_DATA_ROOT = ROOT / "data/indian_commodity_data"
DEFAULT_OUTPUT = ROOT / "research/mcx_within_contract_segments"
FILENAME = re.compile(r"^(?P<variant>[A-Z]+)_(?P<expiry>\d{8})_(?P<timeframe>[a-z_]+)\.csv$")
FAMILY = {"GOLDM": "GOLD", "SILVERM": "SILVER", "NATGASMINI": "NATGAS", "CRUDEOILM": "CRUDEOIL", "ZINC": "ZINC", "ZINCMINI": "ZINC"}
ATTESTATION = "OWNER_ATTESTED_SK_CONTINUOUS_EQUALS_DATED_WITHIN_ACTIVE_WINDOW_REVISED_WORK_ORDER_02NOV2026"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_expiry(label: str) -> date:
    return datetime.strptime(label, "%d%m%Y").date()


def _timestamps(frame: pd.DataFrame) -> pd.Series:
    field = next((x for x in ("timestamp_ist", "timestamp", "tradeDate", "date") if x in frame), None)
    if field is None:
        raise ValueError("source has no timestamp field")
    values = pd.to_datetime(frame[field], dayfirst=True, errors="coerce")
    if values.isna().any() or values.duplicated().any() or not values.is_monotonic_increasing:
        raise ValueError("source timestamps are invalid, duplicated, or unordered")
    if values.dt.tz is None:
        values = values.dt.tz_localize("Asia/Kolkata")
    else:
        values = values.dt.tz_convert("Asia/Kolkata")
    return values


def discover_sources(data_root: Path = DEFAULT_DATA_ROOT) -> list[dict]:
    """Inventory local continuous-source candidates without changing provenance."""
    records = []
    # The retained 2025 labelled archive supplies boundary evidence for the
    # current continuous source.  It is not promoted to raw data and variants
    # remain separate; it merely prevents an avoidable loss of pre-2026 local
    # boundary labels during the owner-authorized Stage-1 reconstruction.
    directories = [data_root / "processed_data_files", data_root / "latest_data_csv"]
    legacy = ROOT / "data_old/indian_commodity_data"
    if legacy.resolve() != data_root.resolve():
        directories.extend([legacy / "processed_data_files", legacy / "latest_data_csv"])
    for directory in directories:
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.csv")):
            match = FILENAME.match(path.name)
            if not match or match["variant"] not in FAMILY:
                continue
            try:
                frame = pd.read_csv(path, usecols=lambda name: name in {"timestamp_ist", "timestamp", "tradeDate", "date"})
                stamps = _timestamps(frame)
            except (OSError, ValueError, pd.errors.ParserError):
                continue
            records.append({"source_path": str(path.relative_to(ROOT)), "source_kind": directory.name,
                            "family": FAMILY[match["variant"]], "variant": match["variant"],
                            "expiry_date": parse_expiry(match["expiry"]).isoformat(), "timeframe": match["timeframe"],
                            "first_timestamp": stamps.iloc[0].isoformat(), "last_timestamp": stamps.iloc[-1].isoformat(),
                            "source_sha256": sha256(path),
                            "original_source_classification": "UNVERIFIED",
                            "owner_attestation_reference": ATTESTATION,
                            "boundary_evidence": "LOCAL_CONTRACT_EXPIRY_FILENAME_LABEL"})
    return records


def boundary_dates(records: Iterable[dict], variant: str) -> list[date]:
    return sorted({date.fromisoformat(row["expiry_date"]) for row in records if row["variant"] == variant})


def select_source(records: Iterable[dict], variant: str, timeframe: str) -> dict | None:
    choices = [r for r in records if r["variant"] == variant and r["timeframe"] == timeframe]
    # Prefer the most recently covered current source; this is deterministic
    # and does not treat its filename as a raw-contract attribution.
    return max(choices, key=lambda r: (r["last_timestamp"], r["source_kind"], r["source_path"])) if choices else None


def _calendar_covers(part: pd.DataFrame, calendar_records: dict[str, dict] | None, timeframe: str) -> bool:
    """Validate intraday intervals while retaining valid daily/weekly context.

    Daily/weekly source bars are labelled at a provider's period convention
    (often midnight), not an executable intraday timestamp. They require a
    verified *open exchange date*, whereas intraday bars require a verified
    calendar interval. This prevents a false midnight rejection without
    allowing intraday closure bridging.
    """
    if not calendar_records:
        return False
    from audit.mcx_futures_backtest.mcx_historical_session_calendar import session_contains
    if timeframe in {"daily", "weekly", "monthly"}:
        return all(calendar_records.get(stamp.date().isoformat(), {}).get("verification_status") == "OFFICIAL_VERIFIED"
                   and calendar_records.get(stamp.date().isoformat(), {}).get("trading_status") == "OPEN"
                   for stamp in part.timestamp)
    return all(session_contains(calendar_records.get(stamp.date().isoformat(), {}), stamp.to_pydatetime()) for stamp in part.timestamp)


def segment_source(source: dict, boundaries: list[date], *, calendar_verified: bool = False,
                   calendar_records: dict[str, dict] | None = None) -> list[tuple[dict, pd.DataFrame]]:
    path = ROOT / source["source_path"]
    frame = pd.read_csv(path)
    stamps = _timestamps(frame)
    frame = frame.copy(); frame["timestamp"] = stamps
    output = []
    prior: date | None = None
    for expiry in boundaries:
        has_prior_boundary = prior is not None
        start = prior + timedelta(days=1) if prior else stamps.iloc[0].date()
        mask = (stamps.dt.date >= start) & (stamps.dt.date <= expiry)
        part = frame.loc[mask].copy()
        prior = expiry
        if part.empty:
            continue
        part["e1_session_id"] = mcx_e1_session_ids(part.timestamp.tolist())
        stable = hashlib.sha256(f"{source['variant']}|{source['timeframe']}|{start}|{expiry}|{source['source_sha256']}".encode()).hexdigest()[:20]
        boundary_confidence = ("OWNER_ATTESTED_LOCAL_LABEL" if has_prior_boundary and source["boundary_evidence"] == "LOCAL_CONTRACT_EXPIRY_FILENAME_LABEL"
                               else "UNVERIFIED_PREVIOUS_BOUNDARY")
        calendar_ok = _calendar_covers(part, calendar_records, source["timeframe"]) if calendar_records is not None else calendar_verified
        eligible = bool(calendar_ok and boundary_confidence == "OWNER_ATTESTED_LOCAL_LABEL")
        reason = None if eligible else ("UNVERIFIED_CONTRACT_WINDOW" if not has_prior_boundary else "UNVERIFIED_SESSION")
        manifest = {**source, "segment_id": f"{source['variant']}@{expiry:%Y%m%d}:{source['timeframe']}:{stable}",
                    "contract_identifier": f"{source['variant']}@{expiry:%Y%m%d}", "contract_expiry": expiry.isoformat(),
                    "segment_start": part.timestamp.iloc[0].isoformat(), "segment_end": part.timestamp.iloc[-1].isoformat(),
                    "rows": len(part), "data_timezone": "Asia/Kolkata", "segment_boundary_confidence": boundary_confidence,
                    "session_calendar_status": "VERIFIED" if calendar_ok else "UNVERIFIED",
                    "within_contract_eligibility": "ELIGIBLE" if eligible else "INELIGIBLE",
                    "replay_eligibility": "ELIGIBLE" if eligible else f"INELIGIBLE_{reason}",
                    "exclusion_reason": reason}
        output.append((manifest, part))
    return output


def build_segments(data_root: Path = DEFAULT_DATA_ROOT, output_dir: Path = DEFAULT_OUTPUT, *, calendar_verified: bool = False,
                   calendar_records: dict[str, dict] | None = None) -> list[dict]:
    data_root = Path(data_root).resolve()
    output_dir = Path(output_dir).resolve()
    records = discover_sources(data_root)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifests = []
    # Build the union of source frames required by the three approved export
    # stacks: W-D-60, D-240-60, and D-240-120.
    frames = {variant: ("weekly", "daily", "two_forty", "one_twenty", "sixty")
              for variant in ("GOLDM", "CRUDEOILM", "SILVERM", "NATGASMINI")}
    for variant, timeframes in frames.items():
        boundaries = boundary_dates(records, variant)
        for timeframe in timeframes:
            source = select_source(records, variant, timeframe)
            if not source:
                continue
            for manifest, part in segment_source(source, boundaries, calendar_verified=calendar_verified, calendar_records=calendar_records):
                target = output_dir / "segments" / variant / timeframe / f"{manifest['segment_id'].replace(':', '_')}.csv"
                target.parent.mkdir(parents=True, exist_ok=True)
                part.to_csv(target, index=False)
                manifest["segment_path"] = str(target.relative_to(ROOT))
                manifests.append(manifest)
    fields = ["family", "variant", "segment_id", "contract_identifier", "contract_expiry", "segment_start", "segment_end", "rows", "source_path", "source_sha256", "timeframe", "data_timezone", "original_source_classification", "owner_attestation_reference", "boundary_evidence", "segment_boundary_confidence", "session_calendar_status", "within_contract_eligibility", "replay_eligibility", "exclusion_reason", "segment_path"]
    with (output_dir / "MCX_WITHIN_CONTRACT_SEGMENT_MANIFEST.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore"); writer.writeheader(); writer.writerows(manifests)
    return manifests


def write_reports(manifests: list[dict], output_dir: Path) -> None:
    counts: dict[str, int] = {}
    for m in manifests:
        counts[m["family"]] = counts.get(m["family"], 0) + 1
    lines = ["# MCX within-contract boundary audit", "", "## Method", "", f"- Attestation: `{ATTESTATION}`.", "- Local expiry-labelled continuous files are segmented independently; original provenance classifications remain unchanged.", "- No additive/ratio adjustment is calculated.", "- The revised workbook file was not present in the workspace; this report records the owner instruction supplied in the task instead.", "", "## Result", "", "| Family | Segments | Replay eligible |", "|---|---:|---:|"]
    for family in ("GOLD", "SILVER", "NATGAS", "CRUDEOIL", "ZINC"):
        values = [m for m in manifests if m["family"] == family]
        lines.append(f"| {family} | {len(values)} | {sum(m['replay_eligibility'] == 'ELIGIBLE' for m in values)} |")
    eligible_total = sum(m["replay_eligibility"] == "ELIGIBLE" for m in manifests)
    lines += ["", f"Replay-eligible segments after this segmentation pass: {eligible_total}. Eligibility reflects calendar and boundary inputs only; it does not itself constitute a strategy or edge result."]
    (output_dir / "MCX_CONTRACT_BOUNDARY_AUDIT.md").write_text("\n".join(lines) + "\n")
    calendar_csv = output_dir / "MCX_HISTORICAL_SESSION_CALENDAR.csv"
    if not calendar_csv.exists():
        (output_dir / "MCX_SESSION_CALENDAR_COVERAGE.md").write_text("# MCX session-calendar coverage\n\nNo session calendar run was present.\n")
    else:
        calendar = list(csv.DictReader(calendar_csv.open()))
        official = sum(x.get("verification_status") == "OFFICIAL_VERIFIED" for x in calendar)
        (output_dir / "MCX_SESSION_CALENDAR_COVERAGE.md").write_text(
            "# MCX session-calendar coverage\n\n"
            f"- Generated exchange-date rows: {len(calendar)}.\n- `OFFICIAL_VERIFIED` exchange dates: {official}.\n"
            "- E1 code remains active. Only segments whose candle dates/intervals pass `OFFICIAL_VERIFIED` validation are admitted.\n")
    with (output_dir / "MCX_TRADE_EXCLUSIONS.csv").open("w", newline="") as handle:
        fields = ["segment_id", "family", "variant", "timeframe", "partition", "reason_code", "count", "detail"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for item in manifests:
            if item["replay_eligibility"] != "ELIGIBLE":
                writer.writerow({"segment_id": item["segment_id"], "family": item["family"], "variant": item["variant"],
                                 "timeframe": item["timeframe"], "partition": "UNASSIGNED", "reason_code": item["exclusion_reason"],
                                 "count": item["rows"], "detail": "segment excluded before setup discovery"})
    (output_dir / "MCX_EXCLUSION_SUMMARY.md").write_text(
        "# MCX revised exclusion summary\n\n`MCX_TRADE_EXCLUSIONS.csv` records source rows excluded before setup discovery. It is separate from the Stage-1 trade-level ledger (`MCX_TRADE_EXCLUSIONS_STAGE1.csv`).\n")
    (output_dir / "MCX_REPLAY_SUMMARY.md").write_text(
        "# MCX revised replay summary\n\nSegmentation is complete for this pass. The Stage-1 runner, if executed, emits separately labelled provisional outputs; no authoritative `mcx_trade_export.csv` is created by this module.\n")
    with (output_dir / "MCX_OVERNIGHT_DIRECTION_REPORT.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["family", "variant", "source", "coverage_start", "coverage_end", "availability_status", "overnight_dir", "trade_count"])
        writer.writeheader()
        for family, variant, source in (("GOLD", "GOLDM", "XAU_USD.csv"), ("SILVER", "SILVERM", "XAG_USD.csv"), ("CRUDEOIL", "CRUDEOILM", "WTI_USD.csv"), ("NATGAS", "NATGASMINI", "NATURAL_GAS_USD.csv"), ("ZINC", "ZINCMINI", "")):
            writer.writerow({"family": family, "variant": variant, "source": source, "coverage_start": "", "coverage_end": "", "availability_status": "UNKNOWN_CLOSE_AVAILABILITY" if source else "NO_CONFIGURED_SERIES", "overnight_dir": "UNKNOWN", "trade_count": 0})
    (output_dir / "MCX_OVERNIGHT_EDGE_ANALYSIS.md").write_text(
        "# MCX overnight-direction analysis\n\nInternational files were found. The revised work order supplies a 17:00 America/New_York reference convention; `overnight_direction.py` can apply it as an explicitly owner-policy-labelled as-of time with DST-aware conversion. Provider daily-bar close/availability metadata remains absent, so this cannot independently establish a provider-verified overlay. No trades exist because no segment passed calendar eligibility. No UP/DOWN edge claim is made.\n")
    (output_dir / "MCX_EDGE_REPRO_RESULTS.md").write_text(
        "# MCX revised edge reproduction results\n\nNOT_EVALUABLE. The 2025–26 Stage-1 window is provisional and unpartitioned. No frozen acceptance specification or approved IS/OOS configuration exists; `edge_repro_check.py` was not run on fixture, sampled, or unapproved data.\n")
    (output_dir / "MCX_PHASE1_REVISED_FINAL_STATUS.md").write_text(
        "# MCX Phase-1 revised status\n\n- Task 1 back-adjustment: REMOVED FROM SCOPE for revised edge measurement.\n- Task 2 FYERS recollection: REMOVED FROM SCOPE for revised edge measurement.\n- Task 3 segmentation: PARTIAL — local segments emitted with explicit source/attestation/boundary statuses.\n- Task 4 E1: COMPLETE in code; all revised segments carry E1 ids.\n- Task 5 exclusions: PARTIAL — pre-replay ledger emitted; Stage-1 trade exclusions are separate.\n- Task 6 realized-R export: STAGE-1 PROVISIONAL ONLY — no authoritative partitioned export.\n- Task 7 overnight overlay: PARTIAL — owner 17:00 ET as-of policy implemented; provider convention remains unverified.\n- Task 8 frozen-spec validation: BLOCKED — owner explicitly left specification unfrozen until Stage 2.\n\nMCX PAPER and REAL remain OFF.\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--calendar-verified", action="store_true", help="only for a separately validated calendar integration")
    parser.add_argument("--calendar-csv", type=Path, help="generated MCX session calendar; only OFFICIAL_VERIFIED rows admit candles")
    args = parser.parse_args()
    calendar_records = None
    if args.calendar_csv:
        calendar_records = {row["exchange_date"]: row for row in csv.DictReader(args.calendar_csv.open())}
    manifests = build_segments(args.data_root, args.output_dir, calendar_verified=args.calendar_verified,
                               calendar_records=calendar_records)
    write_reports(manifests, args.output_dir)
    print(json.dumps({"segments": len(manifests), "replay_eligible": sum(x["replay_eligibility"] == "ELIGIBLE" for x in manifests)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
