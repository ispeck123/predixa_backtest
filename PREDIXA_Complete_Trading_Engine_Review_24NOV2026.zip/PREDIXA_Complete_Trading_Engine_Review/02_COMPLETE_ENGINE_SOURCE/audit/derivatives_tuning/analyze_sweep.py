"""Consolidate a completed B-W-EMBED/proximity sweep without rerunning it."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

import pandas as pd

from audit.derivatives_tuning.cost_model import load_lot_sizes, load_schedule, paper_lot_sizes
from audit.fresh_trend_backtest.analyze_tuning import _metric


def _rows(conn, run_id: str, tfs: set[int]) -> pd.DataFrame:
    q = """SELECT t.*,p.max_favorable_excursion,p.max_adverse_excursion,r.E_regime,r.A_regime
    FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
    JOIN regime_snapshots r ON r.scan_id=s.scan_id
    LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id
    WHERE s.run_id=? AND t.side='BUY'"""
    frame = pd.read_sql_query(q, conn, params=[run_id])
    if frame.empty: return frame
    frame = frame[frame.strategy_tf.isin(tfs)].copy()
    frame["entry_timestamp"] = pd.to_datetime(frame.entry_timestamp, errors="coerce")
    frame["exit_timestamp"] = pd.to_datetime(frame.exit_timestamp, errors="coerce")
    pivot = frame.entry_timestamp.dropna().sort_values()
    frame["partition"] = "OOS"
    if not pivot.empty: frame.loc[frame.entry_timestamp <= pivot.iloc[len(pivot)//2], "partition"] = "IS"
    return frame


def _summarise(frame: pd.DataFrame, *, segment: str, schedule: dict, lots: dict, combo: dict) -> list[dict]:
    out=[]
    for part, part_rows in [*frame.groupby("partition"), ("POOLED", frame)]:
        cells=[("POOLED", part_rows), *[(f"TF{tf}:{e}/{a}", x) for (tf,e,a),x in part_rows.groupby(["strategy_tf","E_regime","A_regime"])]]
        for cell, data in cells:
            out.append({"combo_id":combo["combo_id"],"sweep":combo["sweep"], **combo["overrides"], "partition":part, "cell":cell,
                        **_metric(data, 0.0, segment=segment, schedule=schedule, lot_sizes=lots)})
    return out


def _pass_table(metrics: pd.DataFrame) -> pd.DataFrame:
    base=metrics[(metrics.combo_id == "CONTROL") & (metrics.cost_bps_round_trip == 0)]
    results=[]
    for combo, cand in metrics[metrics.combo_id.ne("CONTROL")].groupby("combo_id"):
        reasons=[]; passed=True
        for part in ("IS", "OOS"):
            b=base[(base.partition==part)&(base.cell=="POOLED")]
            c=cand[(cand.partition==part)&(cand.cell=="POOLED")]
            if len(b)!=1 or len(c)!=1 or pd.isna(c.iloc[0].net_R_mean_full_cost): passed=False; reasons.append(f"{part}:missing full-cost pooled control/candidate"); continue
            b,c=b.iloc[0],c.iloc[0]
            if c.M1_give_back_rate > b.M1_give_back_rate-.03: passed=False; reasons.append(f"{part}:M1")
            if c.M2_wick_out_rate > b.M2_wick_out_rate-.03: passed=False; reasons.append(f"{part}:M2")
            if c.net_R_mean_full_cost < b.net_R_mean_full_cost: passed=False; reasons.append(f"{part}:net_R")
            bcells=base[(base.partition==part)&base.cell.ne("POOLED")].set_index("cell")
            ccells=cand[(cand.partition==part)&cand.cell.ne("POOLED")].set_index("cell")
            for cell in bcells.index.intersection(ccells.index):
                bn,cn=bcells.loc[cell].net_R_mean_full_cost,ccells.loc[cell].net_R_mean_full_cost
                if pd.isna(bn) or pd.isna(cn) or cn < bn-.05: passed=False; reasons.append(f"{part}:{cell}:cell_net_R")
                if part=="OOS" and bn >= 0 > cn: passed=False; reasons.append(f"{part}:{cell}:sign_flip")
        results.append({"combo_id":combo,"pass_all_clauses":passed,"failed_clauses":";".join(reasons) or None})
    return pd.DataFrame(results)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest",required=True);p.add_argument("--storage",required=True);p.add_argument("--segment",required=True,choices=("NSEFO","MCX"));p.add_argument("--lot-sizes",help="optional reviewed JSON; default is paper quantity 10");p.add_argument("--cost-schedule",default="audit/derivatives_tuning/cost_schedules/fyers_derivatives_2023_2026.json");p.add_argument("--output-dir",required=True)
    args=p.parse_args(argv); manifest=json.loads(Path(args.manifest).read_text());schedule=load_schedule(args.cost_schedule);lots=load_lot_sizes(args.lot_sizes) if args.lot_sizes else paper_lot_sizes();tfs={int(x) for x in str(manifest["whitelisted_tfs"]).split(",")}
    conn=sqlite3.connect(args.storage); rows=[]; missing=[]
    for combo in manifest["runs"]:
        rid=combo.get("run_id")
        if not rid: missing.append(combo["combo_id"]);continue
        status=conn.execute("SELECT status FROM backtest_runs WHERE run_id=?",(rid,)).fetchone()
        if not status or status[0] != "COMPLETED": missing.append(combo["combo_id"]);continue
        rows.extend(_summarise(_rows(conn,rid,tfs),segment=args.segment,schedule=schedule,lots=lots,combo=combo))
    out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True);metrics=pd.DataFrame(rows); metrics.to_csv(out/"tuning_metrics.csv",index=False)
    decisions=_pass_table(metrics) if not metrics.empty else pd.DataFrame(columns=("combo_id","pass_all_clauses","failed_clauses")); decisions.to_csv(out/"tuning_pass_decision.csv",index=False)
    passing=decisions[decisions.pass_all_clauses] if not decisions.empty else decisions
    recommendation="NO_LOCK_INCOMPLETE_SWEEP" if missing else ("BASELINE_RETAINED_NO_COMBO_PASSES" if passing.empty else "OWNER_SIGNOFF_REQUIRED: candidates pass arithmetic")
    quantity_mode=f"reviewed lot-size file: `{args.lot_sizes}`" if args.lot_sizes else "PAPER_QTY_10 (not contract-accurate)"
    (out/"tuning_recommendation.md").write_text("# Tuning protocol decision\n\n"+f"- Segment: {args.segment}\n- Decision: **{recommendation}**\n- Missing/incomplete combos: {', '.join(missing) or 'none'}\n- Full-cost schedule: `{schedule['schedule_id']}`\n- Quantity mode: `{quantity_mode}`\n\nNo live Config is modified by this audit report.\n")
    print(f"wrote {out}; rows={len(metrics)}; {recommendation}")

if __name__=="__main__": main()
