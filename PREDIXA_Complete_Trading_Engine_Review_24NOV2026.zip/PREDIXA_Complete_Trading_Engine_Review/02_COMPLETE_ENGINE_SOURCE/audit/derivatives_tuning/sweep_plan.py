"""Build and execute the locked B-W-EMBED/proximity parameter sweep.

Each physical replay remains an independent, resumable run in the existing
central SQLite store.  This creates a logical sweep manifest that ties the
baseline and all candidate run IDs together without changing production code.
"""
from __future__ import annotations

import argparse
import itertools
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

EMBED = [(target, overlap, strict) for target, overlap, strict in itertools.product((.3, .4, .5, .6, .7), (.4, .5, .6), (False, True))]
PROXIMITY = (None, 1.0, 1.5, 2.0, 2.5)
DEFAULT_TFS = {"NSEFO": "1,25", "MCX": "4,3"}
MODULE = {"NSEFO": "audit.nsefo_futures_backtest.run_phase_a", "MCX": "audit.mcx_futures_backtest.run_phase_a"}


def plan(segment: str) -> list[dict]:
    baseline = {"combo_id": "CONTROL", "sweep": "CONTROL", "overrides": {"embed_sits_on_top_target_pct": .5, "embed_overlap_threshold": .5, "embed_strict_stop": False, "proximity_use_atr_tier": False}}
    embed = [{"combo_id": f"EMBED_{i:02d}", "sweep": "EMBED", "overrides": {"embed_sits_on_top_target_pct": a, "embed_overlap_threshold": b, "embed_strict_stop": c, "proximity_use_atr_tier": False}} for i, (a,b,c) in enumerate(EMBED, 1)]
    proximity = [{"combo_id": f"PROX_{'OFF' if m is None else str(m).replace('.', '_')}", "sweep": "PROXIMITY", "overrides": {"embed_sits_on_top_target_pct": .5, "embed_overlap_threshold": .5, "embed_strict_stop": False, "proximity_use_atr_tier": m is not None, **({} if m is None else {"proximity_atr_mult": m})}} for m in PROXIMITY]
    return [baseline, *embed, *proximity]


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--segment", required=True, choices=tuple(MODULE))
    p.add_argument("--storage", required=True); p.add_argument("--output", required=True)
    p.add_argument("--symbols", default="all"); p.add_argument("--tfs")
    p.add_argument("--start", default="2023-01-01"); p.add_argument("--end", default="2026-10-22")
    p.add_argument("--workers", default="4"); p.add_argument("--execute", action="store_true")
    p.add_argument("--compute-reference-oracle", action="store_true")
    args = p.parse_args(argv); out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    rows = plan(args.segment)
    # A long sweep may be interrupted. Retain completed physical run IDs and
    # commands in the same manifest instead of silently starting them again.
    previous = json.loads(out.read_text()) if out.exists() else {}
    old = {x.get("combo_id"): x for x in previous.get("runs", [])}
    for row in rows:
        if row["combo_id"] in old:
            row.update({k:v for k,v in old[row["combo_id"]].items() if k in {"run_id", "exit_code", "stdout"}})
    manifest = {"protocol": "PREDIXA_Tuning_Run_Gap_and_Instruction_22OCT2026", "created_at": previous.get("created_at", datetime.now(timezone.utc).isoformat()), "segment": args.segment, "start": args.start, "end": args.end, "long_only": True, "whitelisted_tfs": args.tfs or DEFAULT_TFS[args.segment], "runs": rows}
    for row in rows:
        cmd = [sys.executable, "-m", MODULE[args.segment], "run", "--run-name", f"{args.segment.lower()}_tuning_{row['combo_id'].lower()}", "--symbols", args.symbols, "--tfs", args.tfs or DEFAULT_TFS[args.segment], "--start", args.start, "--end", args.end, "--executor", "process", "--workers", str(args.workers), "--storage", args.storage, "--engine-overrides-json", json.dumps(row["overrides"], separators=(",", ":"))]
        if args.segment == "NSEFO": cmd.append("--buy-only")
        if args.compute_reference_oracle: cmd.append("--compute-reference-oracle")
        row["command"] = cmd
        if args.execute and row.get("exit_code") == 0 and row.get("run_id"):
            continue
        if args.execute:
            result = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            row["exit_code"], row["stdout"] = result.returncode, result.stdout
            for line in result.stdout.splitlines():
                if line.startswith("run_id="): row["run_id"] = line.split("=", 1)[1].strip(); break
            manifest["runs"] = rows; out.write_text(json.dumps(manifest, indent=2))
            if result.returncode: raise SystemExit(f"{row['combo_id']} failed; inspect manifest stdout")
    out.write_text(json.dumps(manifest, indent=2))
    print(f"wrote {out}; planned {len(rows)} runs ({len(EMBED)} embed + {len(PROXIMITY)} proximity + control)")

if __name__ == "__main__": main()
