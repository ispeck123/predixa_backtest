"""Audit-only statutory derivative-cost model.

This module never changes the production engine.  It produces Net-R only when
the caller supplies contract lot sizes; silently assuming a one-unit order
would make FYERS' per-order brokerage cap materially misleading.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

PAPER_DEFAULT_QUANTITY = 10.0


@dataclass(frozen=True)
class CostResult:
    gross_pnl: float
    total_cost: float
    net_pnl: float
    risk_inr: float
    gross_r: float
    net_r: float
    components: dict[str, float]


def load_schedule(path: str | Path) -> dict:
    data = json.loads(Path(path).read_text())
    if not data.get("segments"):
        raise ValueError("cost schedule has no segments")
    return data


def load_lot_sizes(path: str | Path) -> dict[str, float]:
    data = json.loads(Path(path).read_text())
    result = {str(k).upper(): float(v) for k, v in data.items()}
    if any(v <= 0 for v in result.values()):
        raise ValueError("lot sizes must be positive")
    return result


def paper_lot_sizes() -> dict[str, float]:
    """Sentinel map: missing instruments use paper quantity 10 in the caller."""
    return {}


def _period(segment: Mapping, timestamp: object) -> Mapping:
    day = str(timestamp)[:10]
    choices = sorted(segment["periods"], key=lambda x: x["effective_from"])
    valid = [p for p in choices if p["effective_from"] <= day]
    if not valid:
        raise ValueError(f"cost schedule has no rate at {day}")
    return valid[-1]


def _underlying(symbol: str) -> str:
    return str(symbol).split("@", 1)[0].upper()


def full_cost_r(*, segment_name: str, schedule: Mapping, lot_sizes: Mapping[str, float],
                symbol: str, side: str, entry_price: float, exit_price: float,
                stop_price: float, entry_timestamp: object, exit_timestamp: object) -> CostResult:
    """Compute per-trade full-stack cost and Net-R from two executed legs."""
    segment = schedule["segments"].get(segment_name)
    if segment is None:
        raise ValueError(f"schedule does not define {segment_name}")
    underlying = _underlying(symbol)
    # Paper replay deliberately uses a constant quantity when no reviewed
    # contract specification is supplied. The caller records this mode; this
    # is not represented as broker-exact contract economics.
    qty = float(lot_sizes.get(underlying, PAPER_DEFAULT_QUANTITY))
    if side not in {"BUY", "SELL"}:
        raise ValueError(f"unsupported side {side}")
    risk_per_unit = abs(float(entry_price) - float(stop_price))
    if risk_per_unit <= 0:
        raise ValueError("non-positive initial risk")
    entry_rate, exit_rate = _period(segment, entry_timestamp), _period(segment, exit_timestamp)
    entry_turnover, exit_turnover = float(entry_price) * qty, float(exit_price) * qty
    turnover = entry_turnover + exit_turnover
    brokerage = min(segment["brokerage_cap_inr"], segment["brokerage_pct"] * entry_turnover)
    brokerage += min(segment["brokerage_cap_inr"], segment["brokerage_pct"] * exit_turnover)
    exchange = entry_turnover * entry_rate["exchange_transaction_pct"] + exit_turnover * exit_rate["exchange_transaction_pct"]
    clearing = entry_turnover * entry_rate["clearing_pct"] + exit_turnover * exit_rate["clearing_pct"]
    sebi = turnover * segment["sebi_turnover_pct"]
    ipft = turnover * segment.get("ipft_turnover_pct", 0.0)
    # Tax is always applied to the sale leg: exit for BUY; entry for SELL.
    sell_turnover = exit_turnover if side == "BUY" else entry_turnover
    sell_rate = exit_rate if side == "BUY" else entry_rate
    sell_tax = sell_turnover * sell_rate["sell_tax_pct"]
    # Stamp duty is applied to the purchase leg.
    buy_turnover = entry_turnover if side == "BUY" else exit_turnover
    stamp = buy_turnover * segment["stamp_buy_pct"]
    gst = segment["gst_pct"] * (brokerage + exchange + clearing + sebi + ipft)
    components = {"brokerage": brokerage, "exchange_transaction": exchange, "clearing": clearing,
                  "sebi": sebi, "ipft": ipft, "sell_tax": sell_tax, "stamp": stamp, "gst": gst}
    total = sum(components.values())
    signed = (float(exit_price) - float(entry_price)) * qty if side == "BUY" else (float(entry_price) - float(exit_price)) * qty
    risk = risk_per_unit * qty
    return CostResult(signed, total, signed - total, risk, signed / risk, (signed - total) / risk, components)
