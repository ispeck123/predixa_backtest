"""Shared, audit-only checks for trend-permission attribution.

The wet-run implementation is deliberately imported rather than reimplemented:
``scripts.analyze_entry_regime_permissions.regime_snapshot`` calls
``scripts.setup_engine.process_setup`` at ``purchased_cmp_date``.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import pandas as pd

from scripts.analyze_entry_regime_permissions import regime_snapshot


WET_MASTER = Path("outputs/cash_order_master_engine_rerun_20260901_141530/all_orders_engine_enriched.csv")
WET_ATTRIBUTION = Path("outputs/predixa_entry_regime_permission_analysis_20260917/entry_regime_permission_analysis.csv")


def load_wet_rows() -> pd.DataFrame:
    rows = pd.read_csv(WET_MASTER)
    return rows.loc[rows["status"].isin(["success", "failed"])].copy()


def wet_reconciliation() -> tuple[pd.DataFrame, Counter]:
    """Compare the preserved 22-row run to the stipulated published counts.

    This does not rerun the production engine: rerunning is unnecessary to prove
    the already persisted attribution output, and avoids a needless production
    computation before the entry-time gate is passed.
    """
    old = pd.read_csv(WET_ATTRIBUTION)
    wet = load_wet_rows()[["order_id", "purchased_cmp_date", "entry_timestamp"]]
    out = old.merge(wet, on="order_id", how="left", validate="one_to_one")
    out["scan_timestamp"] = pd.to_datetime(out["purchased_cmp_date"])
    out["actual_entry_timestamp"] = pd.to_datetime(out["entry_timestamp"])
    out["scan_to_entry_hours"] = (out["actual_entry_timestamp"] - out["scan_timestamp"]).dt.total_seconds() / 3600
    out["timestamp_gate"] = out["scan_timestamp"].eq(out["actual_entry_timestamp"])
    counts = Counter(zip(out["regime_E"], out["regime_A"], out["outcome_direction"]))
    return out, counts


def exact_wet_method_documentation() -> str:
    return (
        "scripts/analyze_entry_regime_permissions.py:29-58, regime_snapshot(); "
        "line 33 assigns setup_time = pd.Timestamp(row['purchased_cmp_date']); "
        "line 34 calls scripts.setup_engine.process_setup(symbol, frames, setup_time)."
    )
