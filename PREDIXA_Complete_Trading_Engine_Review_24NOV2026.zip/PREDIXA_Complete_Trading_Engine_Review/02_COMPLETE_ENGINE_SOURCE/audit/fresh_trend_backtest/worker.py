"""Isolated production invocation.  This module has no database access."""
from __future__ import annotations
import contextlib, io, json, os, time, traceback
from functools import lru_cache
from typing import Any
import pandas as pd

from .replay import TF_STACKS, _enum, read_ohlc, resolve_buy, run_current_setup, serialise
from .production_gate import evaluate_gate

@lru_cache(maxsize=16)
def _x_bars(symbol: str, tf: int) -> pd.DataFrame:
    # Process-local immutable source cache. `resolve_buy` never supplies these
    # bars to production; production remains clipped by last_d_time.
    return read_ohlc(symbol, TF_STACKS[tf][-1])

@lru_cache(maxsize=32)
def _bars(symbol: str, frame: str) -> pd.DataFrame:
    return read_ohlc(symbol, frame)

def _reference(symbol: str, tf: int, timestamp: str) -> dict:
    """Independent Phase-1 oracle on a fresh <=T slice; never production zones."""
    from audit.trend_engine.price_action_oracle import diagnostics, label_as_of
    out={}; names=("E","A","X")
    cutoff=pd.Timestamp(timestamp)
    for name,frame in zip(names,TF_STACKS[tf]):
        source=_bars(symbol,frame); clipped=source[source.timestamp<=cutoff]
        if clipped.empty: continue
        d=diagnostics(clipped); out[f"reference_{name}"]=label_as_of(clipped)
        out[f"{name}_ema20"]=d["ema20"];out[f"{name}_ema_slope"]=d["ema20_slope"];out[f"return_20_{name}"]=d["return_n"]
        if name=="X": out["last_confirmed_swing_high"]=d["recent_swing_high"];out["last_confirmed_swing_low"]=d["recent_swing_low"]
    return out

def _value(obj: Any, name: str, default=None):
    return _enum(getattr(obj, name, default)) if obj is not None else default

def _zone(zone: Any, timeframe: str, role: str, cmp: float | None) -> dict | None:
    if zone is None: return None
    prox=_value(zone,"proximal"); dist=_value(zone,"distal")
    distance=None
    try: distance=100*(float(cmp)-float(prox))/float(cmp) if cmp else None
    except (ValueError,TypeError,ZeroDivisionError): pass
    return {"timeframe":timeframe,"zone_role":role,"zone_id":str(_value(zone,"zone_id")) if _value(zone,"zone_id") is not None else None,
      "zone_type":_value(zone,"zone_type"),"proximal":prox,"distal":dist,"created_idx":_value(zone,"created_idx"),
      "created_timestamp":str(_value(zone,"created_timestamp")) if _value(zone,"created_timestamp") else None,
      "age_bars":_value(zone,"age_bars"),"age_class":_value(zone,"age_class"),"retest_count":_value(zone,"retest_count"),
      "penetration_pct":_value(zone,"penetration_pct"),"state":_value(zone,"state"),"invalidated":_value(zone,"invalidated"),
      "violation":_value(zone,"violation"),"final_score":_value(zone,"final_score"),"nesting_tier":_value(zone,"nesting_tier"),
      "session_accepted":_value(zone,"session_accepted"),"removes_structure":_value(zone,"removes_structure"),"distance_from_cmp_pct":distance}

def _context_payload(task: dict, raw: dict, runtime_ms: float, store_raw_json: bool=False, compute_reference_oracle: bool=False) -> dict:
    ctx=raw.get("trend_context")
    if ctx is None: raise RuntimeError("production result lacks trend_context")
    cmp=raw.get("price_cmp")
    best=raw.get("best_setup_long")
    setup_generated=best is not None
    best_s=serialise(best) if best is not None else {}
    allow_long=bool(_value(ctx,"allow_long",False))
    decision=evaluate_gate("NSE_CASH", int(task["strategy_tf"]), _value(ctx,"regime_E"), _value(ctx,"regime_A"))
    rr=float(best_s.get("rr_ratio") or 0) if best else 0.0
    eligible=bool(best and rr >= 2.0 and allow_long and not decision.denied)
    rejection=None
    if not best: rejection="no_best_setup_long"
    elif decision.denied: rejection=decision.reason
    elif rr < 2: rejection="cash_scanner_rr_below_2"
    elif not allow_long: rejection="long_permission_blocked"
    scan={"task_id":task["task_id"],"run_id":task["run_id"],"symbol":task["symbol"],"strategy_tf":task["strategy_tf"],"evaluation_timestamp":task["evaluation_timestamp"],"cmp":cmp,
      "signal_generated":int(setup_generated),"setup_generated":int(setup_generated),"entry_candidate":int(eligible),"rejection_reason":rejection,
      "final_bias":_value(ctx,"bias"),"allow_long":int(allow_long),"allow_short":int(bool(_value(ctx,"allow_short",False))),"permitted_setup":_value(ctx,"permitted_setup"),
      "trade_type_long":_value(ctx,"trade_type_long"),"trade_type_short":_value(ctx,"trade_type_short"),"dbr_required":_value(ctx,"dbr_required"),"rbd_required":_value(ctx,"rbd_required"),
      "htf_veto_longs":_value(ctx,"htf_veto_longs"),"htf_veto_shorts":_value(ctx,"htf_veto_shorts"),"htf_veto_reason":_value(ctx,"htf_veto_reason"),"production_runtime_ms":runtime_ms,
      "gate_tier":decision.tier,"gate_size_multiplier":decision.size_multiplier,"gate_reason":decision.reason,"gate_denied":int(decision.denied),
      "raw_json": json.dumps(serialise(raw),default=str) if store_raw_json else None}
    reg={"E_regime":_value(ctx,"regime_E"),"A_regime":_value(ctx,"regime_A"),"X_regime":_value(ctx,"regime_X"),"E_quadrant":_value(ctx,"quadrant_E"),"A_quadrant":_value(ctx,"quadrant_A"),"X_quadrant":_value(ctx,"quadrant_X"),
      "E_rule_applied":_value(_value(ctx,"result_E"),"rule_applied"),"A_rule_applied":_value(_value(ctx,"result_A"),"rule_applied"),"X_rule_applied":_value(_value(ctx,"result_X"),"rule_applied"),
      "E_diagnosis":_value(_value(ctx,"result_E"),"diagnosis"),"A_diagnosis":_value(_value(ctx,"result_A"),"diagnosis"),"X_diagnosis":_value(_value(ctx,"result_X"),"diagnosis"),
      "E_htf_veto_applied":None,"A_htf_veto_applied":None,"X_htf_veto_applied":None,"E_reinforcers":None,"A_reinforcers":None,"X_reinforcers":None}
    if compute_reference_oracle: reg.update(_reference(task["symbol"],task["strategy_tf"],task["evaluation_timestamp"]))
    zones=[]
    for label,res in (("E",_value(ctx,"result_E")),("A",_value(ctx,"result_A")),("X",_value(ctx,"result_X"))):
        for role,attr in (("NEAREST_BZ","nearest_bz"),("NEAREST_SZ","nearest_sz"),("NEXT_BZ","next_bz"),("NEXT_SZ","next_sz")):
            z=_zone(_value(res,attr),label,role,cmp)
            if z: zones.append(z)
    setups=[]
    if best:
        setup={"symbol":task["symbol"],"strategy_tf":task["strategy_tf"],"direction":"BUY","setup_timestamp":task["evaluation_timestamp"],"pattern":best_s.get("pattern"),"zone_id":str(best_s.get("zone_id")) if best_s.get("zone_id") is not None else None,
         "zone_signature":best_s.get("zone_signature"),
         "proposed_entry":best_s.get("entry_price"),"proposed_stop":best_s.get("stop_price"),"proposed_target":best_s.get("target_price"),"rr":rr,"setup_score":best_s.get("score"),"setup_rank":1,"eligible":int(eligible),"blocked_reason":rejection,"permission_state":"ALLOWED" if allow_long and not decision.denied else "BLOCKED","gate_tier":decision.tier,"gate_size_multiplier":decision.size_multiplier,"gate_reason":decision.reason}
        if eligible:
            candidate={"scan_timestamp":task["evaluation_timestamp"],"entry":best_s.get("entry_price"),"stop":best_s.get("stop_price"),"target":best_s.get("target_price")}
            resolved=resolve_buy(candidate,_x_bars(task["symbol"],task["strategy_tf"]))
            entry=resolved.get("entry_timestamp")
            outcome=str(resolved.get("WIN / LOSS"))
            if entry:
                trade={"symbol":task["symbol"],"strategy_tf":task["strategy_tf"],"side":"BUY","scan_timestamp":task["evaluation_timestamp"],"setup_timestamp":task["evaluation_timestamp"],"entry_timestamp":entry,"exit_timestamp":resolved.get("exit_timestamp"),"entry_price":resolved.get("entry"),"stop_price":resolved.get("stop"),"target_price":resolved.get("target"),"exit_price":resolved.get("exit_price"),"outcome":outcome,"exit_reason":resolved.get("exit_reason"),"target_hit":int(bool(resolved.get("target_hit"))),"stop_hit":int(bool(resolved.get("stop_hit"))),"bars_held":resolved.get("bars_to_exit"),"gross_r":None,"gross_return_pct":None}
                if outcome in {"WIN","LOSS"}: trade["gross_r"]=(float(trade["exit_price"])-float(trade["entry_price"]))/(float(trade["entry_price"])-float(trade["stop_price"])); trade["gross_return_pct"]=100*(float(trade["exit_price"])/float(trade["entry_price"])-1)
                trade["metrics"]={"max_favorable_excursion":resolved.get("max_favorable_excursion"),"max_adverse_excursion":resolved.get("max_adverse_excursion"),"mfe_pct":None,"mae_pct":None,"max_favorable_pct_of_target":resolved.get("max_favorable_pct_of_target"),"bars_to_mfe":resolved.get("bars_to_MFE"),"bars_to_mae":resolved.get("bars_to_MAE"),"bars_to_exit":resolved.get("bars_to_exit"),"first_positive_bar":None,"first_negative_bar":None,"favorable_before_adverse":None,"outcome_direction":resolved.get("outcome_direction")}
                setup["trade"]=trade
        setups.append(setup)
    return {"scan":scan,"regime":reg,"zones":zones,"setups":setups}

def execute_task(task: dict, store_raw_json: bool=False, max_retries: int=2, capture_output: bool=True, compute_reference_oracle: bool=False, engine_overrides: dict | None=None) -> dict:
    """Top-level, picklable process-worker function; production is clipped at T."""
    started=time.perf_counter()
    try:
        # Production logging is intentionally contained in each worker.
        if capture_output:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                raw=run_current_setup(task["symbol"],task["strategy_tf"],pd.Timestamp(task["evaluation_timestamp"]),engine_overrides)
        else:
            # Redirecting sys.stdout is process-global and therefore unsafe in
            # threads. Thread benchmark output may be noisy by design.
            raw=run_current_setup(task["symbol"],task["strategy_tf"],pd.Timestamp(task["evaluation_timestamp"]),engine_overrides)
        return {"task":task,"result":_context_payload(task,raw,(time.perf_counter()-started)*1000,store_raw_json,compute_reference_oracle),"duration_ms":(time.perf_counter()-started)*1000,"worker_id":str(os.getpid()),"max_retries":max_retries}
    except Exception as exc:
        return {"task":task,"error":{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()},"duration_ms":(time.perf_counter()-started)*1000,"worker_id":str(os.getpid()),"max_retries":max_retries}
