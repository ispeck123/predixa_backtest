"""Summarise one audit-only B-W-EMBED/proximity replay from SQLite.

The replay's recorded extrema are sufficient for ``mfe_mae_helper.summarize``:
that helper only consumes max(high) and min(low), so each trade is represented
by an equivalent one-bar extrema pair.  Costs are explicitly labelled as a
round-trip bps sensitivity; this repository has no OI-4 full-cost function.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from scripts.mfe_mae_helper import summarize
from audit.derivatives_tuning.cost_model import PAPER_DEFAULT_QUANTITY, full_cost_r, load_lot_sizes, load_schedule, paper_lot_sizes


def _metric(rows: pd.DataFrame, bps: float, *, segment: str | None = None,
            schedule: dict | None = None, lot_sizes: dict | None = None) -> dict:
    trades=[]; net=[]
    for r in rows.itertuples():
        risk=abs(float(r.entry_price)-float(r.stop_price))
        if risk <= 0 or r.outcome not in ("WIN","LOSS"): continue
        # Equivalent extrema series; summarize() only uses max/min.
        mfe=float(r.max_favorable_excursion or 0.0)
        adverse=float(r.max_adverse_excursion or 0.0)
        if r.side == "BUY": highs=[float(r.entry_price)+mfe]; lows=[float(r.entry_price)+adverse]
        else: highs=[float(r.entry_price)-adverse]; lows=[float(r.entry_price)-mfe]
        trades.append({"entry":r.entry_price,"stop":r.stop_price,"side":r.side,"win":r.outcome=="WIN","bar_highs":highs,"bar_lows":lows})
        # bps-only sensitivity, expressed in R.  It is not labelled a full cost stack.
        net.append(float(r.gross_r) - (2 * bps / 10_000) * float(r.entry_price) / risk)
    gross_values=[float(x.gross_r) for x in rows.itertuples() if pd.notna(x.gross_r)]
    out=summarize(trades); out["gross_R_mean"]=sum(gross_values)/len(gross_values) if gross_values else None
    out["net_R_mean_bps_only"]=sum(net)/len(net) if net else None; out["cost_bps_round_trip"]=bps
    if segment and schedule and lot_sizes is not None:
        costs=[]; failures=[]
        for x in rows.itertuples():
            if x.outcome not in ("WIN", "LOSS") or x.exit_price is None or x.entry_timestamp is None or x.exit_timestamp is None: continue
            try:
                costs.append(full_cost_r(segment_name=segment, schedule=schedule, lot_sizes=lot_sizes,
                    symbol=x.symbol, side=x.side, entry_price=x.entry_price, exit_price=x.exit_price,
                    stop_price=x.stop_price, entry_timestamp=x.entry_timestamp, exit_timestamp=x.exit_timestamp))
            except ValueError as exc: failures.append(str(exc))
        out["full_cost_trade_count"] = len(costs)
        out["full_cost_unavailable_count"] = len(failures)
        out["net_R_mean_full_cost"] = sum(x.net_r for x in costs)/len(costs) if costs else None
        out["full_cost_mean_inr"] = sum(x.total_cost for x in costs)/len(costs) if costs else None
        out["full_cost_schedule_id"] = schedule.get("schedule_id")
        out["full_cost_quantity_mode"] = "PAPER_QTY_10" if not lot_sizes else "REVIEWED_LOT_SIZES_WITH_PAPER_FALLBACK"
        out["full_cost_paper_quantity"] = PAPER_DEFAULT_QUANTITY
        out["full_cost_failure_examples"] = ";".join(sorted(set(failures))[:3]) if failures else None
    return out


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--storage",required=True);p.add_argument("--run",required=True);p.add_argument("--output",required=True)
    p.add_argument("--round-trip-bps",default="0,2,5")
    p.add_argument("--side", choices=("BUY", "SELL"), help="decision cut; the tuning protocol requires BUY")
    p.add_argument("--strategy-tfs", help="comma-separated production TF IDs")
    p.add_argument("--segment", choices=("NSEFO", "MCX"), help="enables statutory full-cost Net-R")
    p.add_argument("--cost-schedule", help="versioned audit-only broker cost schedule JSON")
    p.add_argument("--lot-sizes", help="optional reviewed symbol->lot-size JSON; absent uses paper quantity 10")
    p.add_argument("--require-full-cost", action="store_true", help="fail if any resolved decision-cut trade lacks full cost")
    args=p.parse_args(argv)
    if args.lot_sizes and not args.cost_schedule: p.error("--lot-sizes requires --cost-schedule")
    if args.require_full_cost and not args.segment: p.error("--require-full-cost requires --segment and --cost-schedule")
    schedule = load_schedule(args.cost_schedule) if args.cost_schedule else None
    lot_sizes = load_lot_sizes(args.lot_sizes) if args.lot_sizes else (paper_lot_sizes() if args.cost_schedule else None)
    import sqlite3
    q="""SELECT t.*,p.max_favorable_excursion,p.max_adverse_excursion
    FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id
    LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id WHERE s.run_id=?"""
    rows=pd.read_sql_query(q,sqlite3.connect(args.storage),params=[args.run]); rows["entry_timestamp"]=pd.to_datetime(rows.entry_timestamp,errors="coerce")
    midpoint=rows.entry_timestamp.dropna().sort_values().iloc[len(rows.entry_timestamp.dropna())//2] if rows.entry_timestamp.notna().any() else pd.NaT
    rows["partition"]="OOS"; rows.loc[rows.entry_timestamp<=midpoint,"partition"]="IS"
    bps=[float(x) for x in args.round_trip_bps.split(",")]; out=[]
    q2="""SELECT t.*,p.max_favorable_excursion,p.max_adverse_excursion,r.E_regime,r.A_regime
    FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id JOIN regime_snapshots r ON r.scan_id=s.scan_id
    LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id WHERE s.run_id=?"""
    rows=pd.read_sql_query(q2,sqlite3.connect(args.storage),params=[args.run]); rows["entry_timestamp"]=pd.to_datetime(rows.entry_timestamp,errors="coerce"); rows["exit_timestamp"]=pd.to_datetime(rows.exit_timestamp,errors="coerce"); rows["partition"]="OOS"
    if args.side: rows=rows[rows.side.eq(args.side)].copy()
    if args.strategy_tfs:
        allowed={int(x) for x in args.strategy_tfs.split(",")}; rows=rows[rows.strategy_tf.isin(allowed)].copy()
    if rows.entry_timestamp.notna().any(): rows.loc[rows.entry_timestamp<=rows.entry_timestamp.dropna().sort_values().iloc[len(rows.entry_timestamp.dropna())//2],"partition"]="IS"
    for part, frame in list(rows.groupby("partition"))+[("POOLED",rows)]:
        for cell_name, cell in [("POOLED",frame), *[(f"TF{tf}:{e}/{a}",x) for (tf,e,a),x in frame.groupby(["strategy_tf","E_regime","A_regime"])]]:
            for cost in bps: out.append({"partition":part,"cell":cell_name,**_metric(cell,cost,segment=args.segment,schedule=schedule,lot_sizes=lot_sizes)})
    target=Path(args.output);target.parent.mkdir(parents=True,exist_ok=True);pd.DataFrame(out).to_csv(target,index=False)
    if args.require_full_cost:
        report=pd.DataFrame(out)
        if report.empty or "full_cost_unavailable_count" not in report or (report.full_cost_unavailable_count.fillna(0) > 0).any():
            raise SystemExit("full-cost analysis incomplete: provide complete symbol lot sizes and resolved exit fields")
    print(f"wrote {target} ({len(out)} rows); IS/OOS midpoint={midpoint}")

if __name__ == "__main__": main()
