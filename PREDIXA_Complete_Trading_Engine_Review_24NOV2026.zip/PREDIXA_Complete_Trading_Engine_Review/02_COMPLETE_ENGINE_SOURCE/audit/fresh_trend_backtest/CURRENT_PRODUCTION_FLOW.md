# Current cash production flow replayed

## Platform evolution

Retained: the strict `last_d_time=T` production call, source-OHLC reader, and production-equivalent BUY resolver. The original bounded `run_fresh_backtest.py` pilot remains intact for its existing evidence.

Changed: centralized SQLite task status is the authoritative resume mechanism. TF1, TF5, and TF6 task creation now uses the final completed execute bar per trading day, matching their daily scheduling rather than creating artificial duplicate scans.

Added: process/thread benchmark modes, a single central result writer, retry/resume, structured no-signal scans, regimes, zones, setups, trades, query/export, and analysis tooling. The new command is `python -m audit.fresh_trend_backtest.cli`.

The fresh replay uses source OHLC in `data/indian_stock_data/latest_data_csv`, never an order table.

1. `apps/pipelines/stock_process.py` schedules `SetupScannerOrchestrator` runs. TF1/5/6 are daily at 15:45; TF2 and TF25 are intraday schedules. The task generator preserves one unique completed execute-bar decision, avoiding repeated scans of the same bar.
2. `scripts/cash_wetrun_scanner.py:395-410` invokes `scripts.setup_engine_new.process_setup(symbol, time_list, job.last_d_time)`, then formats the selected setup.
3. `scripts/setup_engine_new.py:1171-1179` creates `SDEnginePipeline` and calls `.run()` using `last_d_time` as the as-of timestamp.
4. `SDEnginePipeline.run` reads E/A/X source CSVs, detects/qualifies zones, calls `MultiTimeframeTrendCalculator.calculate_full_context`, and selects `best_setup_long` at `scripts/setup_engine_new.py:884-892`.
5. The cash wet-run scanner accepts BUY only when `BUY_RRR >= 2.0` (`scripts/cash_wetrun_scanner.py:417-457`). The audit runner applies the same threshold but never persists a signal or order.
6. Production entry is the first execute-timeframe candle whose `[low, high]` contains entry (`scripts/order_update.py:42-56`). Production resolution checks stop first only when target is not hit; a target touch wins, including target+stop in the same OHLC bar (`scripts/order_update.py:94-125`).

The runner invokes step 3 at each selected logical scan timestamp and resolves only after it has frozen a returned setup. `scripts.models.load_preprocess_data` performs the production clipping (`<= last_d_time`, then excludes the active period), so the audit does not substitute a different timestamp/window rule.
