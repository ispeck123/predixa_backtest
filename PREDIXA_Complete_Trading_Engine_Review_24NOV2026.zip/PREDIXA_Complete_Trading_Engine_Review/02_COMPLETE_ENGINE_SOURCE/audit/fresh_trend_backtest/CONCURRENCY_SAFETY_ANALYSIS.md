# Concurrency safety assessment

## Finding

The current production replay entry point is `scripts.setup_engine_new.process_setup()`. It constructs a pipeline per call, reads CSV input through `scripts.models.load_preprocess_data()`, and emits through the shared application logger. The reviewed path does not expose a supported lock or transaction boundary for concurrent in-process callers.

## Risks observed

- Module-level logging is shared (`shared.utils.logger.logger`); parallel stdout/stderr is not reliable evidence output.
- The pipeline builds mutable pandas objects and detector instances. They are per invocation, but no producer contract promises thread safety.
- `load_preprocess_data()` reads source CSVs on each invocation. Thread workers would contend for the same files and Python parsing/GIL time.
- No worker calls an application database session in this audit path; the audit database is deliberately owned by one writer only.

## Control

`process` mode is the default AUTO choice. Each worker has isolated memory, imports, pandas objects, logger stream capture, and source-data cache. Workers never receive the SQLite connection. Thread mode remains available only for measured comparison.

## Required validation

The platform compares the same task universe between one worker and concurrent workers before a full run. A failed equivalence test means process isolation must be retained and the affected result set is not accepted.
