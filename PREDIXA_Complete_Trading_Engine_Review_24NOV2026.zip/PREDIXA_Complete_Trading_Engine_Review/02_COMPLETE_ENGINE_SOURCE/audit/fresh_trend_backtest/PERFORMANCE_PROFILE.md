# Performance profile (baseline platform)

## Existing measured baseline

The retained pilot measured approximately **0.30 seconds per exact production `process_setup()` invocation**. The prior all-execute-bar enumeration was 2,424,989 calls, or approximately 8.4 sequential CPU-days.

## Profiled stages without production changes

The platform records full production-call wall time in `scan_results.production_runtime_ms`. It separately performs only audit-side work: task registration, structured extraction, future-path resolution, and SQLite batch persistence.

Static inspection identifies the likely dominant component: `scripts.models.load_preprocess_data()` reads and parses source CSV history for each production invocation, followed by zone generation and trend/setup calculation in `SDEnginePipeline.run()`.

## Cache policy

Workers cache execute-timeframe OHLC only for post-decision trade resolution. Production source loading remains untouched by default; therefore the production result is still generated through the exact current function and its own clipping. A production-input cache is not enabled until a deterministic cached-vs-uncached equality experiment is implemented and passes.

## Measurement command

```bash
python -m audit.fresh_trend_backtest.cli benchmark --symbols icici_lombard_gic,reliance --tfs 2 --start 2024-01-02 --end 2024-01-31 --benchmark-tasks 20
```

Use the reported throughput—not assumed linear speedup—to choose the full-run executor and worker count.
