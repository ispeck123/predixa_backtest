"""Audit-only fresh replay of the current cash setup pipeline."""
