"""Fresh, strictly as-of replay helpers.

This module deliberately calls the live cash setup function.  It neither
imports an order table nor reimplements zone/trend/set-up selection logic.
"""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

DATA = Path("data/indian_stock_data/latest_data_csv")

TF_STACKS = {
    1: ["monthly", "weekly", "daily"],
    2: ["weekly", "daily", "sixty"],
    5: ["weekly", "daily", "one_twenty_five"],
    6: ["daily", "one_twenty_five", "twenty_five"],
    3: ["daily", "sixty", "fifteen"],
    25: ["weekly", "daily", "seventy_five"],
}


def read_ohlc(symbol: str, frame: str) -> pd.DataFrame:
    """Read source history only; no repair or forward fill is performed."""
    path = DATA / f"{symbol}_{frame}.csv"
    df = pd.read_csv(path)
    column = "tradeDate" if "tradeDate" in df.columns else "timestamp"
    df["timestamp"] = pd.to_datetime(df[column], dayfirst=True)
    return df.sort_values("timestamp", kind="stable").reset_index(drop=True)


def completed_scan_timestamps(symbol: str, trade_tf: int, start: pd.Timestamp,
                              end: pd.Timestamp) -> list[pd.Timestamp]:
    """Return one timestamp for each logical production scan opportunity.

    `process_setup` applies the production current-period exclusion itself;
    passing a timestamp at the end of an X bar therefore preserves the active
    production clipping behaviour rather than replacing it with audit logic.
    """
    x = read_ohlc(symbol, TF_STACKS[trade_tf][-1])
    x = x.loc[(x.timestamp >= start) & (x.timestamp <= end)].copy()
    x = x.drop_duplicates("timestamp").sort_values("timestamp")
    # apps/pipelines/stock_process.py schedules TF1, TF5 and TF6 at the
    # end-of-day cash cycle.  TF2 and TF25 are intraday jobs.  Choosing the
    # last completed X bar for daily jobs avoids artificial duplicate scans;
    # no future bar is used to choose the timestamp.
    if trade_tf in {1, 5, 6}:
        day = x["timestamp"].dt.normalize()
        x = x.groupby(day, sort=False).tail(1)
    return [pd.Timestamp(t) for t in x["timestamp"]]


def serialise(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if hasattr(value, "value"):
        return value.value
    if is_dataclass(value):
        return {key: serialise(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): serialise(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [serialise(item) for item in value]
    return str(value)


def _enum(value: Any) -> Any:
    return getattr(value, "value", value)


def run_current_setup(symbol: str, trade_tf: int, scan_timestamp: pd.Timestamp, engine_overrides: dict | None = None) -> dict:
    """Invoke the actual current cash setup entry point with data as of T."""
    # Intentional local import: importing the production module is part of the
    # tested code path, and makes monkey-patching / alternate classifiers harder.
    from scripts.setup_engine_new import process_setup

    from .tuning import production_config_overrides
    with production_config_overrides(engine_overrides):
        raw = process_setup(symbol, TF_STACKS[trade_tf], scan_timestamp.to_pydatetime())
    if isinstance(raw, str):
        raise RuntimeError(raw)
    return raw


def zone_fields(zone: Any, prefix: str) -> dict[str, Any]:
    attrs = ("zone_id", "age_bars", "retest_count", "penetration_pct", "state", "proximal", "distal")
    return {f"{prefix}_{name}": _enum(getattr(zone, name, None)) if zone else None for name in attrs}


def candidate_from_result(symbol: str, trade_tf: int, scan_timestamp: pd.Timestamp,
                          result: dict) -> dict | None:
    """Extract only a current pipeline-selected BUY satisfying cash scanner RR."""
    setup = result.get("best_setup_long")
    if setup is None:
        return None
    setup = serialise(setup)
    if float(setup.get("rr_ratio") or 0) < 2.0:  # cash_wetrun_scanner threshold
        return None
    ctx = result["trend_context"]
    if not getattr(ctx, "allow_long", False):
        return None
    row = {
        "symbol": symbol, "trade_tf": trade_tf, "side": "BUY",
        "scan_timestamp": scan_timestamp.isoformat(),
        "setup_timestamp": scan_timestamp.isoformat(),
        "cmp_at_scan": result.get("price_cmp"),
        "entry": setup.get("entry_price"), "stop": setup.get("stop_price"),
        "target": setup.get("target_price"),
        "E_regime": _enum(ctx.regime_E), "A_regime": _enum(ctx.regime_A),
        "X_regime": _enum(ctx.regime_X), "final_bias": ctx.bias,
        "quadrant_E": _enum(ctx.quadrant_E), "quadrant_A": _enum(ctx.quadrant_A),
        "quadrant_X": _enum(ctx.quadrant_X), "allow_long": ctx.allow_long,
        "allow_short": ctx.allow_short, "permitted_setup": ctx.permitted_setup,
        "trade_type_long": _enum(ctx.trade_type_long), "dbr_required": ctx.dbr_required,
        "htf_veto_longs": ctx.htf_veto_longs, "htf_veto_shorts": ctx.htf_veto_shorts,
        "E_rule_applied": ctx.result_E.rule_applied, "A_rule_applied": ctx.result_A.rule_applied,
        "X_rule_applied": ctx.result_X.rule_applied, "E_diagnosis": ctx.result_E.diagnosis,
        "A_diagnosis": ctx.result_A.diagnosis, "X_diagnosis": ctx.result_X.diagnosis,
    }
    row.update(zone_fields(ctx.result_E.nearest_bz, "E_BZ"))
    row.update(zone_fields(ctx.result_E.nearest_sz, "E_SZ"))
    row.update(zone_fields(ctx.result_A.nearest_bz, "A_BZ"))
    row.update(zone_fields(ctx.result_A.nearest_sz, "A_SZ"))
    return row


def resolve_buy(candidate: dict, x_bars: pd.DataFrame) -> dict:
    """Mirror `scripts.order_update.evaluate_order_status` on source X bars.

    Entry is first bar at/after scan whose range contains entry.  Once entered,
    a bar with only stop is a loss; any bar touching target is a win, including
    an OHLC-ambiguous stop+target bar.  That target-first condition is the
    active code's ordering (lines 102--125), not an audit preference.
    """
    scan = pd.Timestamp(candidate["scan_timestamp"])
    entry, stop, target = (float(candidate[k]) for k in ("entry", "stop", "target"))
    # Decision candle is fully consumed by the as-of engine.  Entry and outcome
    # evaluation begin strictly after the frozen decision timestamp.
    future = x_bars[x_bars.timestamp > scan].reset_index(drop=True)
    entered_at = None
    mfe, mae = float("-inf"), float("inf")
    mfe_bar = mae_bar = None
    for idx, bar in future.iterrows():
        low, high = float(bar.low), float(bar.high)
        if entered_at is None:
            if low <= entry <= high:
                entered_at = bar.timestamp
            else:
                continue
        mfe = max(mfe, high - entry)
        mae = min(mae, low - entry)
        if mfe == high - entry:
            mfe_bar = idx
        if mae == low - entry:
            mae_bar = idx
        stop_hit, target_hit = low <= stop, high >= target
        if stop_hit and not target_hit:
            return {**candidate, "entry_timestamp": entered_at.isoformat(), "exit_timestamp": bar.timestamp.isoformat(),
                    "exit_price": stop, "WIN / LOSS": "LOSS", "target_hit": False, "stop_hit": True,
                    "exit_reason": "Stoploss hit", "outcome_direction": "AGAINST_TRADE_DIRECTION",
                    "max_favorable_excursion": mfe, "max_adverse_excursion": mae,
                    "max_favorable_pct_of_target": 100*mfe/(target-entry), "bars_to_exit": idx,
                    "bars_to_MFE": mfe_bar, "bars_to_MAE": mae_bar}
        if target_hit:
            return {**candidate, "entry_timestamp": entered_at.isoformat(), "exit_timestamp": bar.timestamp.isoformat(),
                    "exit_price": target, "WIN / LOSS": "WIN", "target_hit": True, "stop_hit": stop_hit,
                    "exit_reason": "Target hit" if not stop_hit else "Target hit (same-bar ambiguity: production target-first)",
                    "outcome_direction": "PERMITTED_DIRECTION", "max_favorable_excursion": mfe,
                    "max_adverse_excursion": mae, "max_favorable_pct_of_target": 100*mfe/(target-entry),
                    "bars_to_exit": idx, "bars_to_MFE": mfe_bar, "bars_to_MAE": mae_bar}
    return {**candidate, "entry_timestamp": entered_at.isoformat() if entered_at is not None else None,
            "exit_timestamp": None, "exit_price": None, "WIN / LOSS": "UNRESOLVED" if entered_at else "UNFILLED",
            "target_hit": False, "stop_hit": False, "exit_reason": "end_of_source_history",
            "outcome_direction": None, "max_favorable_excursion": None, "max_adverse_excursion": None,
            "max_favorable_pct_of_target": None, "bars_to_exit": None, "bars_to_MFE": None, "bars_to_MAE": None}
