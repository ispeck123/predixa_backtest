# Fresh Trend Backtest Engine — Operations Handover

## 1. Purpose and non-negotiable boundary

This is an **audit-only, fresh historical replay platform**. It generates decisions from historical OHLC and the current production setup pipeline. It is not an order-table attribution tool and it does not modify production trading logic.

At a historical decision time `T`:

1. The current production `process_setup()` path is called with `last_d_time=T`.
2. Production preprocessing clips inputs as of `T`.
3. The returned trend / permission / setup state is persisted.
4. Only after that frozen decision, audit code may inspect later execute-timeframe bars to simulate entry and TP/SL resolution.

Never alter Trend Engine rules, zone rules, permission matrices, RR thresholds, veto behaviour, or source history in order to improve results.

## 2. Production path reproduced

```text
latest_data_csv OHLC
  -> apps/pipelines/stock_process.py schedule
  -> scripts/cash_wetrun_scanner.py
  -> scripts.setup_engine_new.process_setup(symbol, time_stack, last_d_time)
  -> SDEnginePipeline.run()
  -> zones / trend context / permission / best_setup_long
  -> audit-only entry and TP/SL resolution
  -> central SQLite evidence database
```

The entry check mirrors `scripts/order_update.py`: entry is reached when `low <= entry <= high`. A bar touching both stop and target is recorded as target-first, because that is the active production ordering.

## 3. Repository locations

| Purpose | Path |
|---|---|
| CLI | `audit/fresh_trend_backtest/cli.py` |
| Coordinator | `audit/fresh_trend_backtest/coordinator.py` |
| Production replay worker | `audit/fresh_trend_backtest/worker.py` |
| As-of / resolver helpers | `audit/fresh_trend_backtest/replay.py` |
| Task generator | `audit/fresh_trend_backtest/task_generator.py` |
| SQLite storage | `audit/fresh_trend_backtest/storage/backtest.sqlite` |
| Query/export | `audit/fresh_trend_backtest/query_results.py` |
| Analysis | `audit/fresh_trend_backtest/analyze_baseline.py` |
| Report renderer | `audit/fresh_trend_backtest/report_baseline.py` |
| Production-flow evidence | `audit/fresh_trend_backtest/CURRENT_PRODUCTION_FLOW.md` |
| Concurrency assessment | `audit/fresh_trend_backtest/CONCURRENCY_SAFETY_ANALYSIS.md` |
| Runtime profile | `audit/fresh_trend_backtest/PERFORMANCE_PROFILE.md` |
| Long-run tmux guide | `audit/fresh_trend_backtest/RUN_LONG_BACKTEST.md` |

## 4. Historical input data

Default source root:

```text
data/indian_stock_data/latest_data_csv/
```

Expected naming convention:

```text
<symbol>_<timeframe_name>.csv
```

Examples:

```text
icici_lombard_gic_daily.csv
icici_lombard_gic_weekly.csv
icici_lombard_gic_sixty.csv
```

Expected OHLC columns include `open`, `high`, `low`, and `close`, plus either `tradeDate` or `timestamp`. The source reader sorts timestamps but does not repair OHLC, forward-fill values, or invent missing bars.

### Junior data-preprocessing responsibilities

Before a material run:

1. Preserve raw source files; do not overwrite them.
2. Confirm every requested symbol has all timeframe files required by its selected strategy TF.
3. Check timestamp parsing, duplicate rows, monotonic ordering, null OHLC, and `high >= low`.
4. Record source-file dates and checksums in the run notes.
5. Use a new SQLite file for materially changed market data. Do not mix task results produced from different source-data revisions in one run.
6. Run a small one-symbol pilot before a broad run after any data refresh.

## 5. Supported universe and strategy timeframes

The built-in allowlist contains the approved 52 cash-equity symbols in `audit/fresh_trend_backtest/universe.py`.

Only these strategy timeframe IDs are in scope:

| Strategy TF | E / A / X time stack | Live logical cadence |
|---:|---|---|
| 1 | monthly / weekly / daily | Daily |
| 2 | weekly / daily / sixty | Intraday completed 60-minute bars |
| 5 | weekly / daily / one_twenty_five | Daily |
| 6 | daily / one_twenty_five / twenty_five | Daily |
| 25 | weekly / daily / seventy_five | Intraday completed 75-minute bars |

TF3 is explicitly excluded.

For TF1, TF5, and TF6, task generation selects the final completed execute bar each day. This prevents accidental repetition of a production job that is scheduled once per day.

## 6. Architecture

```text
BacktestCoordinator
  -> SQLite task registration / durable status
  -> bounded worker executor (thread or process)
  -> result events
  -> one ResultWriter thread
  -> SQLite WAL database
  -> query, analysis, and report scripts
```

Workers never write to SQLite. The central writer batches events into transactions. Task uniqueness is enforced by:

```text
(run_id, symbol, strategy_tf, evaluation_timestamp)
```

This makes restart/resume idempotent for completed tasks.

## 7. Database content

| Table | Purpose |
|---|---|
| `backtest_runs` | Run configuration, source context, lifecycle status |
| `scan_tasks` | One historical scanner evaluation per task |
| `scan_results` | Every evaluation, including no-signal scans |
| `regime_snapshots` | E/A/X regimes, quadrants, rules, diagnoses, optional oracle fields |
| `zone_snapshots` | Nearest/next BZ and SZ context where exposed by production results |
| `setup_results` | Production-selected BUY setup / eligibility state |
| `simulated_trades` | Entered trades and resolution state |
| `trade_path_metrics` | MFE/MAE and direction-path fields |
| `worker_metrics` | Worker runtime summaries |
| `errors` | Isolated task failures and tracebacks |

Useful views:

```text
v_trade_context
v_ea_performance
v_rule_performance
v_symbol_performance
v_timeframe_performance
v_yearly_performance
```

## 8. Command-line interface

The main command is:

```bash
python -m audit.fresh_trend_backtest.cli <command> [arguments]
```

Commands:

| Command | Use |
|---|---|
| `dry-run` | Count tasks and validate requested scope without production calls |
| `benchmark` | Compare thread/process throughput for the same representative task set |
| `run` | Create and execute a new centralized run |
| `status` | Inspect a persisted run |
| `resume` | Continue incomplete / stale tasks from a persisted run |

### `run`, `dry-run`, and `benchmark` arguments

| Argument | Default | Meaning |
|---|---|---|
| `--run-name` | `baseline_current_engine` | Human-readable run name |
| `--symbols` | `all` | `all`, comma-separated symbols, or path to a newline-separated symbol file |
| `--tfs` | `1,2,5,6,25` | Comma-separated strategy TF IDs |
| `--start` | `2020-01-01` | Inclusive calendar start, or `auto` |
| `--end` | `auto` | Inclusive calendar end, or `auto` |
| `--executor` | `auto` | `thread`, `process`, or `auto` |
| `--workers` | `auto` | Positive integer or `auto` |
| `--storage` | `audit/fresh_trend_backtest/storage/backtest.sqlite` | SQLite database path |
| `--max-retries` | `2` | Retries after a worker error |
| `--write-batch-size` | `100` | Result events per central SQLite transaction |
| `--write-flush-seconds` | `2` | Maximum writer batch wait |
| `--progress-seconds` | `10` | Progress-print interval |
| `--compute-reference-oracle` | off | Persist independent Phase-1/2 pivot-oracle evidence; adds runtime |
| `--store-raw-json` | off | Persist full raw production response; use only for focused forensic runs |
| `--raw-json-sample-rate` | `0.0` | Reserved audit configuration field; do not rely on it as a raw-response sampling control yet |
| `--limit-tasks` | none | Development / pilot limit only |
| `--sample-every` | `1` | Development-only sparse sampling; never use for a final baseline |
| `--benchmark-tasks` | `20` | Benchmark-only representative task count |

### `status` arguments

```bash
python -m audit.fresh_trend_backtest.cli status RUN_ID \
  --storage path/to/database.sqlite \
  --status-json
```

`--status-json` emits structured output suitable for logs or monitoring.

### `resume` arguments

```bash
python -m audit.fresh_trend_backtest.cli resume RUN_ID \
  --storage path/to/database.sqlite
```

Resume reloads the saved run configuration. It never reruns completed task rows. Any stale `RUNNING` row from a terminated worker is moved to `RETRY`.

## 9. Standard operating procedure

### A. Validate the codebase

```bash
cd /home/ispeck/STOCK_PROJECT/STP_LATEST
pytest -q tests/fresh_trend_backtest
```

Expected current result: all tests pass.

### B. Dry-run the exact production universe

```bash
python -m audit.fresh_trend_backtest.cli dry-run \
  --symbols all \
  --tfs 1,2,5,6,25 \
  --start 2024-09-17 \
  --end 2026-09-16 \
  --executor process \
  --workers 4 \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite
```

Record its task count. It is the authoritative workload estimate for that exact source-data state and scope.

### C. Benchmark

```bash
python -u -m audit.fresh_trend_backtest.cli benchmark \
  --symbols icici_lombard_gic,reliance \
  --tfs 2 \
  --start 2024-09-17 \
  --end 2024-10-31 \
  --benchmark-tasks 100 \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  > audit/fresh_trend_backtest/results/benchmark_2y.log 2>&1
```

Use process workers unless a repeat benchmark proves otherwise. Thread mode is not the normal baseline choice because production logging is process-global and production code has no thread-safety contract.

### D. Small real-pipeline pilot

```bash
python -u -m audit.fresh_trend_backtest.cli run \
  --run-name pilot_icici_tf2 \
  --symbols icici_lombard_gic \
  --tfs 2 \
  --start 2024-09-17 \
  --end 2024-12-31 \
  --executor process \
  --workers 4 \
  --limit-tasks 500 \
  --storage audit/fresh_trend_backtest/storage/pilot_2y.sqlite \
  --progress-seconds 10 \
  --compute-reference-oracle \
  2>&1 | tee audit/fresh_trend_backtest/results/pilot_2y.log
```

Confirm task counts, scan rows, no-signal rows, setup rows, errors, and trades before launching the broad baseline.

### E. Start the long run in tmux

```bash
tmux new -s trend-backtest-2y
```

```bash
cd /home/ispeck/STOCK_PROJECT/STP_LATEST

python -u -m audit.fresh_trend_backtest.cli run \
  --run-name current_engine_2y_baseline \
  --symbols all \
  --tfs 1,2,5,6,25 \
  --start 2024-09-17 \
  --end 2026-09-16 \
  --executor process \
  --workers 4 \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --max-retries 2 \
  --progress-seconds 10 \
  --compute-reference-oracle \
  2>&1 | tee audit/fresh_trend_backtest/results/current_engine_2y_baseline.log
```

The first lines include:

```text
run_id=<actual identifier>
```

Record that ID in the run register. Detach with `Ctrl+B`, then `D`.

### F. Monitor

```bash
python -m audit.fresh_trend_backtest.cli status RUN_ID \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --status-json
```

Retrieve a missed run ID from the log:

```bash
grep -m1 '^run_id=' audit/fresh_trend_backtest/results/current_engine_2y_baseline.log
```

### G. Resume

```bash
python -m audit.fresh_trend_backtest.cli resume RUN_ID \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite
```

### H. Produce the report after `COMPLETED`

```bash
python -m audit.fresh_trend_backtest.analyze_baseline \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID \
  --output audit/fresh_trend_backtest/results/current_engine_2y_analysis
```

```bash
python -m audit.fresh_trend_backtest.report_baseline \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID \
  --analysis-dir audit/fresh_trend_backtest/results/current_engine_2y_analysis \
  --output reports/FRESH_TREND_ENGINE_2Y_BASELINE_REPORT.md
```

## 10. Result exports

Export all entered trades:

```bash
python -m audit.fresh_trend_backtest.query_results \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID --table trades \
  --output audit/fresh_trend_backtest/results/current_engine_2y_trades.csv
```

Export all evaluations, including no-signal observations:

```bash
python -m audit.fresh_trend_backtest.query_results \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID --table scans \
  --output audit/fresh_trend_backtest/results/current_engine_2y_scans.csv
```

Export UP/UP entered trades:

```bash
python -m audit.fresh_trend_backtest.query_results \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID --table trades \
  --where "E_regime='UP' AND A_regime='UP'" \
  --output audit/fresh_trend_backtest/results/current_engine_2y_up_up_trades.csv
```

Export Rule B cases from the trade-context view:

```bash
python -m audit.fresh_trend_backtest.query_results \
  --storage audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  --run RUN_ID --table trades --rule "Rule B" \
  --output audit/fresh_trend_backtest/results/current_engine_2y_rule_b_trades.csv
```

## 11. Expected duration and capacity planning

The exact duration must be based on the dry-run task count and benchmark/pilot throughput. Do not use a fixed calendar estimate after source data changes.

Existing evidence:

- Earlier full 2020–2026 all-execute-bar enumeration: about 2.42 million calls; not the corrected daily task cadence.
- Corrected logical-cadence full 2020–2026 dry-run: 1,093,741 tasks.
- Real 500-task ICICI Lombard TF2 process/4 pilot: 82.8 seconds, approximately 6.0 tasks/second end-to-end.
- That older broad-scope rate implies roughly 50 hours for 1.09 million tasks at process/4, subject to historical-window size, disk contention, host load, and error/retry volume.

The two-year task count should be materially smaller; use its dry-run output and a two-year pilot for the current estimate.

## 12. Progress interpretation

Progress messages contain:

```text
Run <id>: completed / total (%), active=<futures>, queued=<writer queue>, executor=process/<workers>
```

Healthy signs:

- `COMPLETED` rises steadily.
- Writer queue remains bounded.
- Errors remain low and explained in `errors`.
- Repeated symbols/TFs progress in order, preserving worker cache locality.

Investigate immediately if:

- errors rise persistently;
- the same task repeatedly transitions to `RETRY`;
- host memory starts swapping;
- output task count is unexpectedly zero;
- results show no `scan_results` rows despite tasks completing.

## 13. Troubleshooting

### No run ID visible

The command may have redirected output to a file. Retrieve it:

```bash
grep -m1 '^run_id=' audit/fresh_trend_backtest/results/current_engine_2y_baseline.log
```

### Terminal disconnect or reboot

Use `resume`; do not create a second run for the same intended baseline unless source data or configuration changed.

### A task fails

Inspect:

```bash
sqlite3 audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  "SELECT symbol,timeframe,evaluation_timestamp,exception_type,exception_message FROM errors ORDER BY error_id DESC LIMIT 20;"
```

The task retries up to `--max-retries`. A terminally failed task remains visible; do not silently delete it.

### Storage is large

Keep raw JSON off for broad baselines. Structured scalar evidence is the default. Archive completed SQLite files together with exported CSVs and checksums.

### Process/8 appears faster

It did on a short benchmark, but memory was not measured in this environment. Start with process/4; test process/8 in a controlled pilot and watch RAM/swap before changing the baseline worker count.

## 14. Final integrity steps

After analysis and reporting:

```bash
sha256sum \
  audit/fresh_trend_backtest/storage/backtest_2y.sqlite \
  reports/FRESH_TREND_ENGINE_2Y_BASELINE_REPORT.md \
  audit/fresh_trend_backtest/results/current_engine_2y_trades.csv \
  audit/fresh_trend_backtest/results/current_engine_2y_scans.csv \
  > audit/fresh_trend_backtest/results/current_engine_2y_SHA256SUMS.txt
```

Record:

- run ID;
- Git commit / branch in `backtest_runs`;
- source-data date range and checksums;
- exact command line;
- executor and worker count;
- task, completed, failed, scan, setup, and trade counts;
- report and export paths.

## 15. Handover acceptance checklist

- [ ] Tests pass.
- [ ] Data files validated and source revision recorded.
- [ ] Dry-run scope recorded.
- [ ] Benchmark completed and executor rationale recorded.
- [ ] Pilot completed with scans, no-signals, setups, and trades in SQLite.
- [ ] Full run uses tmux and a recorded run ID.
- [ ] Status remains monitored until `COMPLETED`.
- [ ] Errors are reviewed, not discarded.
- [ ] Analysis script runs only after completion.
- [ ] Markdown report and CSV exports generated from SQLite.
- [ ] Checksums saved.
- [ ] No production Trend Engine files were modified.
