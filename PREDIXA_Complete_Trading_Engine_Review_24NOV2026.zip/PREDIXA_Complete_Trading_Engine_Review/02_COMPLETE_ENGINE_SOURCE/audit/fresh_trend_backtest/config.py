"""Immutable configuration for the audit-only fresh replay platform."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from hashlib import sha256
import json
import os
from pathlib import Path
from typing import Literal

from .universe import SYMBOLS


ExecutorType = Literal["thread", "process", "auto"]


@dataclass(frozen=True)
class ReplayConfig:
    run_name: str
    symbols: tuple[str, ...] = field(default_factory=lambda: tuple(SYMBOLS))
    tfs: tuple[int, ...] = (1, 2, 5, 6, 25)
    start: str = "2020-01-01"
    end: str = "auto"
    executor: ExecutorType = "auto"
    workers: int | str = "auto"
    max_retries: int = 2
    storage_path: str = "audit/fresh_trend_backtest/storage/backtest.sqlite"
    write_batch_size: int = 100
    flush_seconds: float = 2.0
    compute_reference_oracle: bool = False
    store_raw_json: bool = False
    raw_json_sample_rate: float = 0.0
    progress_seconds: float = 10.0
    random_seed: int = 20260917
    limit_tasks: int | None = None
    sample_every: int = 1
    variant_name: str = "CURRENT_PRODUCTION"
    engine_overrides: dict = field(default_factory=dict)

    def canonical(self) -> dict:
        return asdict(self)

    @property
    def config_hash(self) -> str:
        payload = json.dumps(self.canonical(), sort_keys=True, separators=(",", ":"))
        return sha256(payload.encode()).hexdigest()

    def resolved_workers(self) -> int:
        if self.workers != "auto":
            return max(1, int(self.workers))
        # Conservative default.  The benchmark command is the authority for a
        # final run recommendation; this merely prevents accidental oversubscription.
        return max(1, min(4, (os.cpu_count() or 2) // 2))

    @property
    def storage(self) -> Path:
        return Path(self.storage_path)
