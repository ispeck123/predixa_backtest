"""Task-universe creation without invoking production setup logic."""
from __future__ import annotations
import pandas as pd
from .replay import completed_scan_timestamps, TF_STACKS

def generate_tasks(config):
    for symbol in config.symbols:
        for tf in config.tfs:
            try:
                end=pd.Timestamp.now() if config.end == "auto" else pd.Timestamp(config.end)
                # CLI calendar dates denote the inclusive trading day, not
                # midnight only. Explicit timestamps retain their exact bound.
                if isinstance(config.end, str) and len(config.end) == 10:
                    end = end + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1)
                start=pd.Timestamp("1900-01-01") if config.start == "auto" else pd.Timestamp(config.start)
                times=completed_scan_timestamps(symbol,tf,start,end)
                for n, timestamp in enumerate(times):
                    if n % config.sample_every:
                        continue
                    yield {"symbol":symbol,"strategy_tf":tf,"strategy_tf_name":TF_STACKS[tf][-1],"evaluation_timestamp":timestamp.isoformat()}
            except FileNotFoundError:
                # Missing source is registered by the coordinator as an error-free skipped universe item in the run log.
                continue
