# Running a durable baseline

Start a `tmux` session:

```bash
tmux new -s trend-backtest
python -m audit.fresh_trend_backtest.cli run --run-name current_engine_full_baseline --symbols all --tfs 1,2,5,6,25 --start 2020-01-01 --end auto --executor process --workers 4 --storage audit/fresh_trend_backtest/storage/backtest.sqlite --max-retries 2 --progress-seconds 10
```

Detach with `Ctrl+B`, then `D`; reconnect with:

```bash
tmux attach -t trend-backtest
```

Check progress from another terminal:

```bash
python -m audit.fresh_trend_backtest.cli status RUN_ID --storage audit/fresh_trend_backtest/storage/backtest.sqlite --status-json
```

After interruption or reboot, resume the exact persisted configuration:

```bash
python -m audit.fresh_trend_backtest.cli resume RUN_ID --storage audit/fresh_trend_backtest/storage/backtest.sqlite
```

Completed task rows are unique by run, symbol, strategy timeframe, and timestamp; resume reclaims only stale `RUNNING` work and runs `PENDING`/`RETRY` tasks.
