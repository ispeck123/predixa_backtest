#!/usr/bin/env python3
"""Restartable fresh baseline replay; audit-only, never writes database state."""
from __future__ import annotations
import argparse
import contextlib
import io
import json
import time
from pathlib import Path
import sys
import csv
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from replay import TF_STACKS, candidate_from_result, completed_scan_timestamps, read_ohlc, resolve_buy, run_current_setup

SYMBOLS = [
 "abb_india","adani_ports","apollo_hospitals","bajaj_auto","bajaj_finance","bank_of_baroda","bharat_electronics","bharti_airtel","britannia_industries","cg_power_inds","cholamandalam_investment","divis_laboratories","dlf","eicher_motors","eternal","godrej_consumer","grasim_industries","hindustan_aeronautics","hcl_technologies","hdfcbank","hero_motocorp","hindalco_industries","hindunilvr","icicibank","icici_lombard_gic","indian_hotels","indigo","infy","jindal_steel_power","jsw_steel","larsen_toubro","ltimindtree","mahindra_mahindra","maruti_suzuki","info_edge","ntpc","power_finance_corporation","pidilite_industries","reliance","shree_cement","shriram_finance","siemens","sun_pharma","tatamotors","tata_steel","titan","torrent_pharmaceuticals","trent","tvs_motor","ultratech_cement","varun_beverages","vedanta"
]

ROOT = Path("audit/fresh_trend_backtest/results")

def append_rows(path: Path, rows: list[dict]) -> None:
    """Durable append used for interruption-safe audit checkpoints."""
    if not rows:
        return
    fieldnames = sorted({key for row in rows for key in row})
    if path.exists() and path.stat().st_size:
        # Checkpoint rows always have a fixed schema; trade rows are written in
        # the final consolidation because candidate payloads may gain fields.
        with path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writerows(rows)
    else:
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader(); writer.writerows(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2020-01-01")
    ap.add_argument("--end", default="2026-08-01")
    ap.add_argument("--symbols", default=",")
    ap.add_argument("--tfs", default="1,2,5,6,25")
    ap.add_argument("--max-scans", type=int, default=None, help="bounded pilot only; never represents full baseline")
    ap.add_argument("--quiet-production-output", action="store_true")
    args = ap.parse_args()
    ROOT.mkdir(parents=True, exist_ok=True)
    requested_symbols = SYMBOLS if args.symbols == "," else args.symbols.split(",")
    tfs = [int(x) for x in args.tfs.split(",")]
    existing_path = ROOT / "fresh_backtest_trades.csv"
    try:
        existing = pd.read_csv(existing_path) if existing_path.exists() and existing_path.stat().st_size else pd.DataFrame()
    except pd.errors.EmptyDataError:
        existing = pd.DataFrame()
    checkpoint_path = ROOT / "processed_scans.csv"
    try:
        checkpoint = pd.read_csv(checkpoint_path) if checkpoint_path.exists() and checkpoint_path.stat().st_size else pd.DataFrame()
    except pd.errors.EmptyDataError:
        checkpoint = pd.DataFrame()
    completed = set(checkpoint.get("scan_key", pd.Series(dtype=str)).dropna())
    trades, scans, errors, processed = [], 0, [], []
    started = time.time()
    for symbol in requested_symbols:
        for trade_tf in tfs:
            try:
                timestamps = completed_scan_timestamps(symbol, trade_tf, pd.Timestamp(args.start), pd.Timestamp(args.end))
                x_bars = read_ohlc(symbol, TF_STACKS[trade_tf][-1])
            except Exception as exc:
                errors.append({"symbol":symbol,"trade_tf":trade_tf,"error":str(exc)})
                continue
            for ts in timestamps:
                key = f"{symbol}|{trade_tf}|{ts.isoformat()}"
                if key in completed:
                    continue
                if args.max_scans is not None and scans >= args.max_scans:
                    break
                scans += 1
                try:
                    sink = io.StringIO()
                    with contextlib.redirect_stdout(sink) if args.quiet_production_output else contextlib.nullcontext():
                        result = run_current_setup(symbol, trade_tf, ts)
                    candidate = candidate_from_result(symbol, trade_tf, ts, result)
                    processed.append({"scan_key": key, "symbol": symbol, "trade_tf": trade_tf,
                                      "scan_timestamp": ts.isoformat(), "candidate_generated": bool(candidate)})
                    append_rows(checkpoint_path, processed[-1:])
                    if candidate:
                        candidate["scan_key"] = key
                        trades.append(resolve_buy(candidate, x_bars))
                except Exception as exc:
                    errors.append({"symbol":symbol,"trade_tf":trade_tf,"timestamp":ts.isoformat(),"error":repr(exc)})
            print(f"{symbol} TF{trade_tf}: processed; scans this run={scans}; elapsed={time.time()-started:.1f}s", flush=True)
            if args.max_scans is not None and scans >= args.max_scans:
                break
        if args.max_scans is not None and scans >= args.max_scans:
            break
    combined = pd.concat([existing, pd.DataFrame(trades)], ignore_index=True)
    combined.to_csv(existing_path, index=False)
    pd.DataFrame(errors).to_csv(ROOT / "replay_errors.csv", index=False)
    manifest = {"baseline_type":"CURRENT_PRODUCTION_FRESH_REPLAY", "symbols_requested":requested_symbols,
                "tfs":tfs,"start":args.start,"end":args.end,"scans_processed_this_run":scans,
                "entered_trades_this_run":len(trades),"errors":len(errors),"max_scans":args.max_scans,
                "total_successfully_checkpointed_scans": len(completed) + len(processed),
                "production_entry_point":"scripts.setup_engine_new.process_setup"}
    (ROOT / "run_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    # Legacy pilot entry point retained for old checkpoint evidence.  The
    # centralized platform is intentionally invoked as `python -m ...cli`.
    main()
