"""Approved cash-universe constants shared by audit-only tooling."""

SYMBOLS = (
    "abb_india", "adani_ports", "apollo_hospitals", "bajaj_auto", "bajaj_finance", "bank_of_baroda", "bharat_electronics", "bharti_airtel", "britannia_industries", "cg_power_inds", "cholamandalam_investment", "divis_laboratories", "dlf", "eicher_motors", "eternal", "godrej_consumer", "grasim_industries", "hindustan_aeronautics", "hcl_technologies", "hdfcbank", "hero_motocorp", "hindalco_industries", "hindunilvr", "icicibank", "icici_lombard_gic", "indian_hotels", "indigo", "infy", "jindal_steel_power", "jsw_steel", "larsen_toubro", "ltimindtree", "mahindra_mahindra", "maruti_suzuki", "info_edge", "ntpc", "power_finance_corporation", "pidilite_industries", "reliance", "shree_cement", "shriram_finance", "siemens", "sun_pharma", "tatamotors", "tata_steel", "titan", "torrent_pharmaceuticals", "trent", "tvs_motor", "ultratech_cement", "varun_beverages", "vedanta"
)
