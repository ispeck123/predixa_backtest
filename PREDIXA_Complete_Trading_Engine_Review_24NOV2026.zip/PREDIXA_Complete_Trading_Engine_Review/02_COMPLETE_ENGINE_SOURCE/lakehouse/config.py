from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _path_from_env(name: str, default: Path) -> Path:
    value = os.getenv(name)
    path = Path(value).expanduser() if value else default
    return path.resolve()


@dataclass(frozen=True)
class LakehouseConfig:
    """Filesystem and Spark settings for the local NSE Cash lakehouse."""

    source_dir: Path
    warehouse_dir: Path
    rejected_dir: Path
    reports_dir: Path
    checkpoint_dir: Path
    catalog: str = "local"
    namespace: str = "nse_cash"
    table: str = "bars"
    rejected_table: str = "bars_rejected"
    spark_master: str = "local[4]"
    spark_driver_memory: str = "12g"
    spark_shuffle_partitions: int = 128
    spark_timezone: str = "UTC"
    source_timezone: str = "Asia/Kolkata"
    iceberg_package: str = "org.apache.iceberg:iceberg-spark-runtime-4.1_2.13:1.11.0"

    @property
    def table_name(self) -> str:
        return f"{self.catalog}.{self.namespace}.{self.table}"

    @property
    def rejected_table_name(self) -> str:
        return f"{self.catalog}.{self.namespace}.{self.rejected_table}"

    @classmethod
    def from_env(cls) -> "LakehouseConfig":
        lake_root = _path_from_env("NSE_CASH_LAKE_ROOT", PROJECT_ROOT / "lake")
        return cls(
            source_dir=_path_from_env(
                "NSE_CASH_CSV_DIR",
                PROJECT_ROOT / "data" / "indian_stock_data" / "latest_data_csv",
            ),
            warehouse_dir=_path_from_env("NSE_CASH_WAREHOUSE_DIR", lake_root / "warehouse"),
            rejected_dir=_path_from_env("NSE_CASH_REJECTED_DIR", lake_root / "rejected"),
            reports_dir=_path_from_env("NSE_CASH_REPORTS_DIR", lake_root / "reports"),
            checkpoint_dir=_path_from_env("NSE_CASH_CHECKPOINT_DIR", lake_root / "checkpoints"),
            spark_master=os.getenv("NSE_CASH_SPARK_MASTER", "local[4]"),
            spark_driver_memory=os.getenv("NSE_CASH_SPARK_DRIVER_MEMORY", "12g"),
            spark_shuffle_partitions=int(
                os.getenv("NSE_CASH_SPARK_SHUFFLE_PARTITIONS", "128")
            ),
            iceberg_package=os.getenv(
                "ICEBERG_SPARK_PACKAGE",
                "org.apache.iceberg:iceberg-spark-runtime-4.1_2.13:1.11.0",
            ),
        )

    def create_runtime_directories(self) -> None:
        for path in (
            self.warehouse_dir,
            self.rejected_dir,
            self.reports_dir,
            self.checkpoint_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)

