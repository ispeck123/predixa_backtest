"""Local Spark/Iceberg market-data lakehouse."""

