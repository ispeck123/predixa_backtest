from __future__ import annotations

from lakehouse.config import LakehouseConfig


def create_spark_session(config: LakehouseConfig, app_name: str = "nse-cash-lakehouse"):
    """Create a local Spark session with a filesystem-backed Iceberg catalog."""
    try:
        from pyspark.sql import SparkSession
    except ImportError as exc:  # pragma: no cover - depends on optional runtime
        raise RuntimeError(
            "PySpark is not installed. Install lakehouse/requirements.txt and Java 17+."
        ) from exc

    config.create_runtime_directories()
    warehouse_uri = config.warehouse_dir.as_uri()
    spark = (
        SparkSession.builder.appName(app_name)
        .master(config.spark_master)
        .config("spark.driver.memory", config.spark_driver_memory)
        .config("spark.sql.shuffle.partitions", str(config.spark_shuffle_partitions))
        .config("spark.default.parallelism", str(config.spark_shuffle_partitions))
        .config("spark.jars.packages", config.iceberg_package)
        .config(
            "spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        )
        .config(
            f"spark.sql.catalog.{config.catalog}",
            "org.apache.iceberg.spark.SparkCatalog",
        )
        .config(f"spark.sql.catalog.{config.catalog}.type", "hadoop")
        .config(f"spark.sql.catalog.{config.catalog}.warehouse", warehouse_uri)
        .config("spark.sql.session.timeZone", config.spark_timezone)
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
        .getOrCreate()
    )
    spark.sparkContext.setCheckpointDir(str(config.checkpoint_dir))
    return spark

