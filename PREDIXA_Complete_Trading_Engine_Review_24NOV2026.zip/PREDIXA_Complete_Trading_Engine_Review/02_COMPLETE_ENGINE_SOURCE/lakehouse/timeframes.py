from __future__ import annotations


LEGACY_TO_CANONICAL: dict[str, str] = {
    "five": "5m",
    "fifteen": "15m",
    "twenty_five": "25m",
    "sixty": "60m",
    "seventy_five": "75m",
    "one_twenty_five": "125m",
    "daily": "1d",
    "weekly": "1w",
    "monthly": "1M",
}
CANONICAL_TO_LEGACY = {value: key for key, value in LEGACY_TO_CANONICAL.items()}

# Longest first is essential because symbols and timeframe names contain underscores.
LEGACY_SUFFIXES = tuple(sorted(LEGACY_TO_CANONICAL, key=len, reverse=True))


def normalize_timeframe(value: str) -> str:
    normalized = value.strip()
    if normalized in LEGACY_TO_CANONICAL:
        return LEGACY_TO_CANONICAL[normalized]
    if normalized in CANONICAL_TO_LEGACY:
        return normalized
    raise ValueError(f"Unsupported NSE Cash timeframe: {value!r}")


def legacy_timeframe(value: str) -> str:
    canonical = normalize_timeframe(value)
    return CANONICAL_TO_LEGACY[canonical]

