# FYERS Futures and Commodity market data

The existing `scripts/ingestor_service.py` process remains the only upstream
FYERS DataSocket process.  It now reads active Cash symbols from
`ind_stock_master` and exact derivative contracts from `ticker_tape`:

- Cash: active `ind_stock_master.fyers_symbol`.
- Futures: active, unexpired `ticker_tape` rows where `exchange = NSEFO`.
- Commodity: active, unexpired `ticker_tape` rows where `exchange = MCX`.

`ticker_tape.fyers_symbol` and `expiry_date` must be copied from the FYERS
instrument master. An undated or expired derivative row is fail-closed and is
not subscribed. For rollover, add/activate the new ticker-tape row and disable
the expiring row. The ingestor refreshes this map every 30 seconds by default
(`FYERS_SYMBOL_REFRESH_SECONDS`) and also reloads it after a socket reconnect.

## Redis contract

Cash remains unchanged: hash `price:<FYERS symbol>` and channel
`prices:<FYERS symbol>`.  Futures use hash
`market:futures:latest:<FYERS symbol>` and channel
`market:futures:ticks:<FYERS symbol>`; commodities replace `futures` with
`commodity`.  Hashes contain the current normalized tick only (no per-tick
keys and no TTL); `received_at` and `exchange_timestamp` make staleness
visible without erasing the last good price during an outage.

## Dashboard downstream WebSocket

The dashboard service exposes one single-contract endpoint, independent of the
Cash `/ws/stock_live_prices` endpoint:

```text
ws://<host>:9000/ws/futures_commodity_live_price?symbol=<symbol>&expiry=YYYY-MM-DD&timeframe=<timeframe>
```

For manual validation in a browser, open
`http://<host>:9000/futures_commodity_live_price`. It has a small form for
these same three inputs and renders the acknowledgement, snapshot, and ticks.

The only client inputs are `symbol`, `expiry`, and `timeframe`. Timeframe is a
descriptive project name, not a numeric ID: `monthly`, `weekly`, `daily`,
`two_forty`, `one_twenty`, `sixty`, `fifteen`, `seventy_five`, `five`,
`twenty_five`, or `one_twenty_five`. `symbol` may
be an exact FYERS `NSE:...FUT`/`MCX:...FUT` contract, or a base symbol found in
the existing futures/commodity masters. Base symbols are resolved using the
project's established `NSE:<SYMBOL><YYMON>FUT` or `MCX:<SYMBOL><YYMON>FUT`
format. Invalid or expired input receives an `INVALID_CONTRACT` error; invalid
timeframes receive `INVALID_TIMEFRAME`.

On connect the dashboard writes a 90-second Redis lease and signals the shared
ingestor. The ingestor dynamically adds the resolved contract to its existing
DataSocket subscription; it removes it once the final lease expires. The
endpoint sends `subscription_ack`, an optional `market_snapshot`, then
`market_tick` messages. `timeframe` is echoed on every response for chart
association; it does not create another FYERS subscription.

## Deployment

No PM2 ecosystem file is present in this repository, so preserve the existing
PM2 process name and point it at the same entry point:

```bash
pm2 reload <existing-ingestor-process> --update-env
pm2 reload <dashboard-process> --update-env
```

Set `FYERS_DATA_SOCKET_MAX_SYMBOLS` to the account's confirmed FYERS plan
limit (50 for Standard, 5000 for Prime).  The ingestor prioritizes Cash and
logs rejected derivative symbols rather than exceed that cap.  To run MCX
through its evening session, also set `INGESTOR_CLOSE_TIME=23:30` on the
existing runner process.  Do not start `fyers_ingestor_fc.py`; it is an old
duplicate and would create an unintended second subscription source.

Rollback: stop clients from opening the derivative endpoint and reload the
existing ingestor. Active dashboard leases expire within
`DERIVATIVE_WS_LEASE_SECONDS` (90 seconds by default). Remove the derivative
router import if an endpoint rollback is required; Cash keys, channels, and
websocket endpoints are unaffected.
