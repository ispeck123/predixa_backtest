"""Simulated contract-level integration: tick -> monitor -> Discord outbox.

This is deliberately brokerless and DB/network-free.  It models the durable
event-key and delivery uniqueness constraints used by the MySQL worker while
exercising the same StatefulDetector and exact-contract matching rules.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from apps.backend.services.mcx_zone_alerts import CanonicalZone, StatefulDetector, signature

class SimulatedPipeline:
    def __init__(self, zone):
        self.zone = zone
        self.detector, self.events, self.outbox, self.last_received = StatefulDetector(), {}, set(), 0
    def tick(self, ltp, received_at, *, stale=False):
        if stale or received_at <= self.last_received:
            return
        self.last_received = received_at
        for transition in self.detector.evaluate(self.zone, ltp, approach_ticks=4):
            key = signature({"zone": self.zone.logical_id, "revision": self.zone.revision,
                             "type": transition.event_type, "received": received_at, "ltp": str(transition.ltp)})
            if key in self.events: continue  # MySQL uq_mcx_zone_event equivalent
            self.events[key] = transition
            # Shared Discord delivery: canonical event plus destination, never
            # one row per platform user.
            self.outbox.add((key, "discord-default", "DISCORD"))

def test_simulated_redis_monitor_mysql_outbox_discord_flow():
    near = CanonicalZone.make(instrument="GOLDM", expiry="2026-11-30", timeframe="daily", side="BUY", lower=100, upper=110, tick_size=1, origin="bar-1")
    p = SimulatedPipeline(near)
    p.tick(96, 1000); p.tick(100, 2000); p.tick(100, 2000)  # duplicate Redis delivery
    p.tick(105, 3000); p.tick(98, 4000); p.tick(100, 5000)
    p.tick(105, 6000, stale=True)  # stale cache must not create a market event
    assert [event.event_type for event in p.events.values()] == ["APPROACHING_ZONE", "ZONE_ENTERED", "ZONE_EXITED", "ZONE_ENTERED"]
    assert len(p.outbox) == 4
    assert {channel for _, _, channel in p.outbox} == {"DISCORD"}

def test_simulated_restart_restores_state_without_duplicate_entry():
    zone = CanonicalZone.make(instrument="SILVERM", expiry="2026-11-30", timeframe="weekly", side="SELL", lower=200, upper=210, tick_size=1, origin="bar-2")
    before = StatefulDetector(); before.evaluate(zone, 205)
    after = StatefulDetector(before.state)  # persisted mcx_zone_event_state restoration
    assert after.evaluate(zone, 206) == []
