from datetime import datetime

import pandas as pd

from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler


def test_empty_mcx_archive_bootstraps_from_2020_in_provider_safe_chunks(tmp_path):
    """Deleting local CSVs must not silently revert to a one-year download."""
    handler = MCXFutureDataHandler.__new__(MCXFutureDataHandler)
    handler.commodities = ["CRUDEOILM"]
    handler.download_path = str(tmp_path)
    handler.name_interval_dict = {"60": "sixty"}
    handler.full_history_start = datetime(2020, 1, 1)
    handler.bootstrap_full_history = True
    handler.get_latest_fyers_commodity_symbol_expiry = lambda _symbol: [{
        "symbol": "MCX:CRUDEOILM26NOVFUT", "expiry": "19-11-2026"
    }]
    requests = []

    def fetch(symbol, start, end, interval, **_kwargs):
        requests.append((symbol, start, end, interval))
        return pd.DataFrame(columns=["open", "high", "low", "close", "qty", "tradeDate"])

    handler.fetch_candle_data = fetch
    result = handler.download_all(intervals=["60"])

    assert result == []
    assert len(requests) == 1
    assert requests[0][0] == "MCX:CRUDEOILM26NOVFUT"
    assert requests[0][1] == datetime(2020, 1, 1)
    assert requests[0][3] == "60"


def test_compatibility_history_window_uses_the_configured_anchor():
    handler = MCXFutureDataHandler.__new__(MCXFutureDataHandler)
    handler.full_history_start = datetime(2020, 1, 1)
    handler.bootstrap_full_history = True

    now, start = handler.return_now_and_previous_date("60")

    assert start == datetime(2020, 1, 1)
    assert now >= start
