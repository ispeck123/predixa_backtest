import json
from pathlib import Path

import pytest

from audit.derivatives_tuning.cost_model import full_cost_r, load_schedule
from audit.derivatives_tuning.sweep_plan import plan
from audit.derivatives_tuning.analyze_sweep import _pass_table


SCHEDULE = Path("audit/derivatives_tuning/cost_schedules/fyers_derivatives_2023_2026.json")


def test_full_cost_includes_required_components_and_reduces_r():
    result = full_cost_r(segment_name="NSEFO", schedule=load_schedule(SCHEDULE),
        lot_sizes={"ITC": 1000}, symbol="ITC@30102026", side="BUY",
        entry_price=100, exit_price=110, stop_price=95,
        entry_timestamp="2025-01-01", exit_timestamp="2025-01-02")
    assert {"brokerage", "exchange_transaction", "clearing", "sebi", "ipft", "sell_tax", "stamp", "gst"} == set(result.components)
    assert result.total_cost > 0
    assert result.net_r < result.gross_r


def test_cost_uses_paper_quantity_ten_without_lot_size():
    result=full_cost_r(segment_name="NSEFO", schedule=load_schedule(SCHEDULE), lot_sizes={}, symbol="ITC@30102026", side="BUY",
        entry_price=100, exit_price=110, stop_price=95, entry_timestamp="2025-01-01", exit_timestamp="2025-01-02")
    assert result.risk_inr == 50.0


def test_protocol_plan_has_control_30_embed_and_5_proximity_runs():
    rows = plan("MCX")
    assert len(rows) == 36
    assert sum(x["sweep"] == "EMBED" for x in rows) == 30
    assert sum(x["sweep"] == "PROXIMITY" for x in rows) == 5
    assert rows[0]["overrides"]["embed_sits_on_top_target_pct"] == .5
    assert any(x["overrides"].get("proximity_atr_mult") == 2.5 for x in rows)


def test_pass_arithmetic_requires_all_is_and_oos_clauses():
    rows=[]
    for combo, m1, m2, net in (("CONTROL", .20, .20, .10), ("GOOD", .16, .16, .12)):
        for part in ("IS", "OOS"):
            rows.append({"combo_id":combo,"cost_bps_round_trip":0,"partition":part,"cell":"POOLED","M1_give_back_rate":m1,"M2_wick_out_rate":m2,"net_R_mean_full_cost":net})
            rows.append({"combo_id":combo,"cost_bps_round_trip":0,"partition":part,"cell":"TF4:UP/UP","M1_give_back_rate":m1,"M2_wick_out_rate":m2,"net_R_mean_full_cost":net})
    decision=_pass_table(__import__("pandas").DataFrame(rows)).set_index("combo_id")
    assert bool(decision.loc["GOOD", "pass_all_clauses"])
