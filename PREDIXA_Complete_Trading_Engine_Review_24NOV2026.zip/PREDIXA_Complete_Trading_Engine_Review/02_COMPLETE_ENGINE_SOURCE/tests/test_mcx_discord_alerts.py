"""Offline tests for the MCX Discord delivery adapter; no live webhook is used."""
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from apps.backend.services.mcx_discord_alerts import (
    DiscordSettings, classify_response, discord_payload, matches,
)


def settings(**overrides):
    values = dict(enabled=True, webhook_url="https://discord.invalid/api/webhooks/secret", instruments={"SILVERM", "GOLDM"},
                  timeframes={"DAILY", "WEEKLY"}, event_types={"APPROACHING_ZONE", "ZONE_ENTERED", "NEW_ZONE", "ZONE_MODIFIED"},
                  zone_types={"BUY", "SELL"}, contracts=set(), contract_classifications=set(), min_priority=1, username="REVIEW_REDACTED",
                  thread_id="", chart_url="https://predixa.markets/mcx")
    values.update(overrides)
    return DiscordSettings(**values)


def event(**overrides):
    value = dict(id=7, event_key="event-7", zone_id="zone-7", instrument="SILVERM", contract_expiry="2026-11-30",
                 timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED", ltp="149250", detected_at=datetime(2026, 11, 5, 9, 30, tzinfo=timezone.utc),
                 payload={"lower": "148800", "upper": "149100", "tick_size": "1"})
    value.update(overrides)
    return value


def test_buy_embed_is_mention_safe_and_has_exact_chart_link():
    payload = discord_payload(event(), settings())
    embed = payload["embeds"][0]
    assert payload["allowed_mentions"] == {"parse": []}
    assert "SILVERM" in embed["title"] and "BUY" in embed["title"]
    assert embed["color"] == 0x22C55E
    assert "symbol=SILVERM" in embed["fields"][-1]["value"]
    assert "expiry=2026-11-30" in embed["fields"][-1]["value"]


def test_sell_embed_is_red_and_approaching_is_amber():
    sell = discord_payload(event(zone_type="SELL"), settings())["embeds"][0]
    approach = discord_payload(event(event_type="APPROACHING_ZONE"), settings())["embeds"][0]
    assert sell["color"] == 0xEF4444
    assert approach["color"] == 0xF59E0B


def test_zone_modified_embed_describes_authoritative_refresh():
    embed = discord_payload(event(event_type="ZONE_MODIFIED", ltp=None), settings())["embeds"][0]
    assert embed["color"] == 0x3B82F6
    assert "authoritative CSV refresh" in embed["description"]


def test_filter_is_independent_of_user_subscribers_and_requires_explicit_filters():
    assert matches(settings(), instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED")
    assert not matches(settings(instruments=set()), instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED")


def test_filter_rejects_excluded_instrument_timeframe_and_event():
    s = settings()
    assert not matches(s, instrument="CRUDEOILM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED")
    assert not matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="sixty", zone_type="BUY", event_type="ZONE_ENTERED")
    assert not matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_EXITED")


def test_optional_exact_contract_and_priority_filters():
    s = settings(contracts={"SILVERM@2026-11-30"}, contract_classifications={"NEAR", "NEXT"}, min_priority=3)
    assert matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED", contract_classification="NEAR")
    assert not matches(s, instrument="SILVERM", expiry="2026-12-31", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED")
    assert not matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="NEW_ZONE")
    assert not matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED", contract_classification="FAR")


def test_numeric_timeframe_aliases_match_existing_zone_timeframes():
    s = settings(timeframes={"WEEKLY", "DAILY", "TWO_FORTY", "ONE_TWENTY", "SIXTY"})
    for timeframe in ("weekly", "daily", "two_forty", "one_twenty", "sixty"):
        assert matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe=timeframe, zone_type="BUY", event_type="ZONE_ENTERED")


def test_disabled_or_missing_webhook_never_queues():
    for s in (settings(enabled=False), settings(webhook_url="")):
        assert not matches(s, instrument="SILVERM", expiry="2026-11-30", timeframe="daily", zone_type="BUY", event_type="ZONE_ENTERED")


def test_success_records_discord_message_id():
    result = classify_response(200, body={"id": "discord-message-1"})
    assert result.status == "DELIVERED" and result.message_id == "discord-message-1"


def test_repeated_event_has_one_destination_identity():
    # This is the exact tuple protected by uq_mcx_discord_delivery in MySQL.
    sent = set(); key = (7, settings().destination_hash, "DISCORD")
    sent.add(key); sent.add(key)
    assert len(sent) == 1


def test_rate_limit_honours_retry_after():
    result = classify_response(429, {"Retry-After": "2.7"}, {"retry_after": 1}, attempts=1)
    assert result.status == "PENDING" and result.retry_seconds == 3


def test_temporary_failure_has_bounded_backoff_and_eventual_dead_letter():
    retry = classify_response(502, attempts=3)
    dead = classify_response(500, attempts=8)
    assert retry.status == "PENDING" and retry.retry_seconds == 8
    assert dead.status == "FAILED"


def test_revoked_webhook_is_permanent_failure():
    for status in (401, 403, 404):
        assert classify_response(status, attempts=1).status == "FAILED"


def test_timeout_is_explicitly_uncertain_not_automatically_retried():
    result = classify_response(None, timeout=True, attempts=1)
    assert result.status == "UNCERTAIN" and "unknown" in result.error


def test_configured_thread_and_destination_hash_do_not_expose_webhook_in_embed():
    s = settings(thread_id="123")
    serialized = str(discord_payload(event(), s))
    assert "discord.invalid" not in serialized
    assert len(s.destination_hash) == 64
