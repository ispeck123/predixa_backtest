from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from apps.backend.api import fyers_order_management as order_api
from shared.db.db_model import OMSOrderBucket, Order
from shared.db.fyers_req_model import UpdateLiveOrderRequest


def _request(**identifiers):
    return UpdateLiveOrderRequest(
        orderId=identifiers.get("orderId", ""),
        bucket_id=identifiers.get("bucket_id"),
        status="Pending",
        marketSection="Stocks",
        originalEntry=179.869,
        originalTarget=193.31,
        originalStoploss=177.013,
        entry=179.87,
        target=193.31,
        stoploss=175.2,
        entryChanged=False,
        targetChanged=False,
        stoplossChanged=True,
        hasChanges=True,
    )


def _session():
    engine = create_engine("sqlite:///:memory:")
    OMSOrderBucket.__table__.create(engine)
    Order.__table__.create(engine)
    return sessionmaker(bind=engine)()


def test_bucket_only_update_does_not_require_an_order(monkeypatch):
    session = _session()
    bucket = OMSOrderBucket(
        bucket_id=276,
        order_id=None,
        order_type="BUY",
        entry_price=179.869,
        target_price=193.31,
        stoploss_price=177.013,
        is_trade_started=0,
    )
    session.add(bucket)
    session.commit()

    monkeypatch.setattr(order_api.db, "get_session", lambda: session)
    monkeypatch.setattr(order_api, "get_pending_gtt_by_id", lambda *_: None)

    response = order_api.update_live_order(_request(bucket_id=276), fyers=object())

    assert response["msg"] == "success"
    assert session.get(OMSOrderBucket, 276).stoploss_price == 175.2


def test_order_only_update_does_not_require_a_bucket(monkeypatch):
    session = _session()
    order = Order(
        order_id=901,
        order_type="BUY",
        entry_price=179.869,
        target_price=193.31,
        stoploss_price=177.013,
    )
    session.add(order)
    session.commit()

    monkeypatch.setattr(order_api.db, "get_session", lambda: session)

    response = order_api.update_live_order(_request(orderId="901"), fyers=object())

    assert response["msg"] == "success"
    assert session.get(Order, 901).stoploss_price == 175.2
