import pandas as pd

from audit.derivatives_backtest_common.export_labeled import evaluate_path


def test_path_populates_ordered_excursion_fields_and_breakeven_variant():
    bars = pd.DataFrame([
        {"timestamp": pd.Timestamp("2026-01-01 10:00"), "high": 105.5, "low": 99.5},
        {"timestamp": pd.Timestamp("2026-01-01 11:00"), "high": 105.0, "low": 100.0},
    ])
    metrics, path = evaluate_path("BUY", 100.0, 90.0, 120.0, bars)
    assert metrics["first_positive_bar"] == 0
    assert metrics["first_negative_bar"] == 0
    assert metrics["be05_outcome"] == "BREAKEVEN"
    assert metrics["be05_r"] == 0.0
    assert len(path) == 2


def test_path_uses_target_first_for_ambiguous_baseline_bar():
    bars = pd.DataFrame([{"timestamp": pd.Timestamp("2026-01-01 10:00"), "high": 121.0, "low": 89.0}])
    metrics, _ = evaluate_path("BUY", 100.0, 90.0, 120.0, bars)
    assert metrics["baseline_path_outcome"] == "WIN"
