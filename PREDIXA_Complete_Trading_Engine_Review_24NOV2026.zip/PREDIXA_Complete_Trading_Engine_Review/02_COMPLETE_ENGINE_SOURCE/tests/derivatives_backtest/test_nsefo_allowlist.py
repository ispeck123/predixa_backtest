from audit.nsefo_futures_backtest.preflight import (
    NSEFO_ACTIVE_EXPIRIES,
    NSEFO_ALLOWED_SYMBOLS,
    NSEFO_COMPLETED_SYMBOLS,
    NSEFO_EXPIRY_SCHEDULE,
    NSEFO_FULL_UNIVERSE,
    NSEFO_SYMBOL_METADATA,
)
from audit.nsefo_futures_backtest.run_phase_a import _symbols


EXPECTED = {
    "BANKNIFTY", "FINNIFTY", "NIFTY", "HDFCBANK", "ICICIBANK", "RELIANCE",
    "AXISBANK", "INFY", "BHARTIARTL", "TCS", "BSE", "SBIN", "KOTAKBANK",
    "BAJFINANCE", "BHEL", "PAYTM", "ETERNAL", "TECHM", "HCLTECH", "LAURUSLABS",
    "MIDCPNIFTY", "ITC", "WIPRO", "ADANIENT", "LT", "TATASTEEL", "POLYCAB",
    "HINDALCO", "FEDERALBNK", "PERSISTENT",
}


def test_nsefo_allowlist_matches_approved_universe():
    assert EXPECTED <= NSEFO_FULL_UNIVERSE
    assert len(NSEFO_FULL_UNIVERSE) == 188
    assert len(NSEFO_COMPLETED_SYMBOLS) == 30
    assert len(NSEFO_ALLOWED_SYMBOLS) == 158
    assert not (NSEFO_ALLOWED_SYMBOLS & NSEFO_COMPLETED_SYMBOLS)
    assert set(NSEFO_SYMBOL_METADATA) == NSEFO_FULL_UNIVERSE
    assert set(NSEFO_EXPIRY_SCHEDULE) == NSEFO_FULL_UNIVERSE
    assert set(NSEFO_EXPIRY_SCHEDULE["NIFTY"]) == {"27102026", "23112026", "29122026"}
    assert NSEFO_ACTIVE_EXPIRIES["NIFTY"] == ("27102026",)
    assert "23112026" not in NSEFO_ACTIVE_EXPIRIES["NIFTY"]
    assert "29122026" not in NSEFO_ACTIVE_EXPIRIES["NIFTY"]


def test_nsefo_rejects_symbol_outside_allowlist():
    try:
        _symbols("BANKNIFTY")
    except SystemExit as exc:
        assert "BANKNIFTY" in str(exc)
    else:
        raise AssertionError("disallowed NSEFO symbol was accepted")
