import csv

from audit.derivatives_backtest_common.build_expiry_map_from_filenames import (
    PENDING_STATUS,
    build_candidate_expiry_map,
)


def test_candidate_expiry_map_extracts_multitoken_timeframes_without_official_stamp(tmp_path):
    (tmp_path / "M&M_29092026_one_twenty_five.csv").touch()
    (tmp_path / "M&M_29092026_daily.csv").touch()
    (tmp_path / "NOT_A_CONTRACT.csv").touch()
    output = tmp_path / "candidate.csv"

    result = build_candidate_expiry_map(tmp_path, "NSEFO", output)

    assert result["rows"] == 1
    with output.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows == [{
        "symbol": "M&M",
        "roll_date": "2026-09-29",
        "verification_status": PENDING_STATUS,
        "source_filenames": "M&M_29092026_daily.csv|M&M_29092026_one_twenty_five.csv",
        "extraction_rule": "SYMBOL_DDMMYYYY_TIMEFRAME.csv filename date; expiry equals roll boundary per locked 10-Nov-2026 specification",
    }]
