from pathlib import Path

from audit.derivatives_backtest_common.contract_inventory import parse_contract_filename
from audit.nsefo_futures_backtest.run_phase_a import Config, generate_tasks


FRAMES = ("daily", "one_twenty_five", "seventy_five", "twenty_five")


def test_parse_multitoken_timeframe_suffixes():
    item = parse_contract_filename(Path("ITC_29092026_one_twenty_five.csv"), FRAMES)
    assert item is not None
    assert (item.symbol, item.expiry, item.timeframe) == ("ITC", "29092026", "one_twenty_five")


def test_parse_contract_symbol_with_internal_separator():
    item = parse_contract_filename(Path("M&M_29092026_seventy_five.csv"), FRAMES)
    assert item is not None
    assert item.symbol == "M&M"
    assert item.timeframe == "seventy_five"


def test_phase_a_uses_one_canonical_source_per_symbol_timeframe():
    cfg = Config("test", ("ITC",), (2,), "2026-09-01", "2026-09-01")
    sources = {task["symbol"] for task in generate_tasks(cfg)}
    assert len(sources) == 1
