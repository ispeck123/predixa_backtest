import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts import mcx_zone_refresh as refresh
from scripts.models import TF


def _csv(tmp_path):
    path = tmp_path / "zones.csv"
    path.write_text("tradeDate,open,high,low,close\n")
    return path


def test_weekly_daily_and_240_use_the_existing_optimized_zone_roles(tmp_path, monkeypatch):
    path = _csv(tmp_path)
    calls = []
    monkeypatch.setattr(refresh, "_file", lambda *_: path)
    monkeypatch.setattr(refresh, "_max_retests", lambda: 1)

    def zones(_path, role, _now, *, max_retests):
        calls.append((role, max_retests))
        return {"Buy": [], "Sell": []}

    monkeypatch.setattr(refresh, "process_zones", zones)
    for timeframe in ("weekly", "daily", "two_forty"):
        refresh._bands("GOLDM", date(2027, 1, 29), timeframe, 1)

    assert calls == [(TF.E, 1), (TF.A, 1), (TF.X, 1)]


def test_lower_intraday_alerts_use_existing_qualified_zone_source(tmp_path, monkeypatch):
    path = _csv(tmp_path)
    calls = []
    monkeypatch.setattr(refresh, "_file", lambda *_: path)
    monkeypatch.setattr(refresh, "_max_retests", lambda: 1)

    def qualified(_path, role, _now, time_list, symbol, *, max_retests):
        calls.append((role, time_list, symbol, max_retests))
        return {"Buy": [], "Sell": []}

    monkeypatch.setattr(refresh, "process_qualified_zones", qualified)
    for timeframe in ("one_twenty", "sixty"):
        refresh._bands("SILVERM", date(2027, 1, 29), timeframe, 1)

    assert calls == [(TF.X, ["one_twenty"], "SILVERM", 1), (TF.X, ["sixty"], "SILVERM", 1)]

