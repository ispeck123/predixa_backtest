import queue
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data_fetchers.fyers.fyers_ingestor import FyersIngestor, redis_channel, redis_key
from shared import market_data_symbols
from shared.market_data_symbols import resolve_derivative_contract
from apps.dashboard.derivatives_market import apply_timeframe_candle, configured_timeframes, load_latest_candle


def _ingestor_for_tick():
    ingestor = FyersIngestor.__new__(FyersIngestor)
    ingestor.symbol_info = {
        "NSE:ABC26OCTFUT": {"segment": "futures", "display_name": "ABC"},
        "MCX:GOLD26OCTFUT": {"segment": "commodity", "display_name": "GOLD"},
    }
    ingestor.symbol_lock = threading.Lock()
    ingestor.last_seen = {}
    ingestor.last_tick_by_segment = {}
    ingestor.queue = queue.Queue()
    return ingestor


def test_derivative_keys_are_segment_isolated_and_cash_is_compatible():
    assert redis_key("cash", "NSE:SBIN-EQ") == "price:NSE:SBIN-EQ"
    assert redis_channel("cash", "NSE:SBIN-EQ") == "prices:NSE:SBIN-EQ"
    assert redis_key("futures", "NSE:ABC26OCTFUT") == "market:futures:latest:NSE:ABC26OCTFUT"
    assert redis_channel("commodity", "MCX:GOLD26OCTFUT") == "market:commodity:ticks:MCX:GOLD26OCTFUT"


def test_derivative_tick_is_segmented_and_out_of_order_tick_is_ignored():
    ingestor = _ingestor_for_tick()
    ingestor.on_message({"symbol": "NSE:ABC26OCTFUT", "ltp": 101.5, "open_price": 100,
                         "vol_traded_today": 20, "open_interest": 7, "exch_feed_time": 200})
    tick = ingestor.queue.get_nowait()
    assert tick["segment"] == "futures"
    assert tick["ltp"] == 101.5
    assert tick["open_interest"] == 7

    ingestor.on_message({"symbol": "NSE:ABC26OCTFUT", "ltp": 99, "exch_feed_time": 199})
    assert ingestor.queue.empty()


def test_unknown_symbols_are_not_written():
    ingestor = _ingestor_for_tick()
    ingestor.on_message({"symbol": "NSE:NOT-CONFIGURED-EQ", "ltp": 1, "exch_feed_time": 200})
    assert ingestor.queue.empty()


def test_exact_contract_uses_only_symbol_expiry_and_does_not_need_a_mapping():
    contract = resolve_derivative_contract(None, "MCX:GOLD26OCTFUT", "2026-10-30")
    assert contract["symbol"] == "MCX:GOLD26OCTFUT"
    assert contract["segment"] == "commodity"


def test_mcx_base_symbol_uses_exact_instrument_master_contract(monkeypatch):
    class Query:
        def filter(self, *args): return self
        def first(self): return None

    class Session:
        def query(self, *_): return Query()
        def close(self): pass

    class DB:
        def get_session(self): return Session()

    class Commodity:
        full_name = "Gold Petal 1 g Futures"

    original_first = Query.first
    calls = 0
    def first(self):
        nonlocal calls
        calls += 1
        return None if calls == 1 else Commodity()
    monkeypatch.setattr(Query, "first", first)
    monkeypatch.setattr(market_data_symbols, "_exact_mcx_futures_symbol", lambda *_: "MCX:GOLDPETAL26OCTFUT")
    contract = resolve_derivative_contract(DB(), "GOLDPETAL", "2026-10-30")
    assert contract["symbol"] == "MCX:GOLDPETAL26OCTFUT"


def test_derivative_websocket_uses_descriptive_timeframe_names():
    timeframes = configured_timeframes()
    assert {"daily", "weekly", "monthly", "sixty", "one_twenty", "two_forty"} <= set(timeframes)
    assert "5" not in timeframes


def test_dashboard_socket_uses_timeframe_candle_not_fyers_session_open(tmp_path, monkeypatch):
    candle_dir = tmp_path / "latest_data_csv"
    candle_dir.mkdir()
    (candle_dir / "GOLDPETAL_30102026_sixty.csv").write_text(
        "open,high,low,close,qty,tradeDate\n"
        "14932,14940,14918,14935,353,13/10/2026 14:00:00\n"
    )
    from apps.dashboard import derivatives_market
    monkeypatch.setattr(derivatives_market.stock_data_dir_config, "indian_commodity_data", str(tmp_path))
    candle = load_latest_candle({"segment": "commodity", "symbol": "MCX:GOLDPETAL26OCTFUT",
                                 "base_symbol": "GOLDPETAL", "expiry_date": "2026-10-30"}, "sixty")
    message = apply_timeframe_candle({"open": "14980", "high": "14990", "low": "14900", "ltp": "14936"}, candle)
    assert message["open"] == 14932
    assert message["high"] == 14940
    assert message["low"] == 14918
    assert message["close"] == 14936
    assert message["day_open"] == "14980"
