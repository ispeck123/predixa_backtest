import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from apps.backend.services.mcx_zone_alerts import CanonicalZone, StatefulDetector, ZoneState, diff_snapshots

def zone(lo=100, hi=110, *, expiry="2026-11-30", origin="bar-1"):
    return CanonicalZone.make(instrument="GOLDM", expiry=expiry, timeframe="daily", side="BUY", lower=lo, upper=hi, tick_size=1, origin=origin)

def kinds(detector, z, prices):
    return [event.event_type for price in prices for event in detector.evaluate(z, price, approach_ticks=5)]

def test_approach_enter_no_duplicate_inside_ticks():
    d = StatefulDetector(); assert kinds(d, zone(), [94, 95, 100] + [105] * 200) == ["APPROACHING_ZONE", "ZONE_ENTERED"]

def test_exit_and_real_reentry():
    d = StatefulDetector(); assert kinds(d, zone(), [100, 112, 100]) == ["ZONE_ENTERED", "ZONE_EXITED", "ZONE_ENTERED"]

def test_hysteresis_prevents_boundary_spam():
    d = StatefulDetector(); assert kinds(d, zone(), [100, 99, 100, 99, 98]) == ["ZONE_ENTERED", "ZONE_EXITED"]

def test_gap_crossing_is_single_entry():
    d = StatefulDetector(); assert kinds(d, zone(), [90, 105]) == ["ZONE_ENTERED"]

def test_identical_snapshot_is_noop(): assert diff_snapshots([zone()], [zone()]) == []
def test_new_zone(): assert [x[0] for x in diff_snapshots([], [zone()])] == ["NEW_ZONE"]
def test_material_zone_change_is_modified(): assert [x[0] for x in diff_snapshots([zone()], [zone(101, 110)])] == ["ZONE_MODIFIED"]
def test_removed_zone(): assert [x[0] for x in diff_snapshots([zone()], [])] == ["ZONE_REMOVED"]
def test_contracts_never_match(): assert [x[0] for x in diff_snapshots([zone()], [zone(expiry="2026-12-31")])] == ["NEW_ZONE", "ZONE_REMOVED"]
def test_outside_to_approaching_to_inside_state():
    d = StatefulDetector(); kinds(d, zone(), [95,100]); assert d.state == ZoneState.INSIDE
