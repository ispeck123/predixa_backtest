from datetime import date, timedelta

import pytest

from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler


def test_history_ranges_are_descending_non_overlapping_and_cover_requested_window():
    start = date(2026, 1, 1)
    end = date(2026, 4, 15)
    ranges = Indian_future_data_handler._build_descending_history_ranges(start, end, 30)

    assert ranges[0][1] == end
    assert ranges[-1][0] == start
    assert all(range_from <= range_to for range_from, range_to in ranges)
    for older, newer in zip(ranges[1:], ranges[:-1]):
        assert older[1] + timedelta(days=1) == newer[0]


def test_history_ranges_support_same_day_and_partial_first_chunk():
    single_day = date(2026, 11, 23)
    assert Indian_future_data_handler._build_descending_history_ranges(
        single_day, single_day, 100
    ) == [(single_day, single_day)]

    ranges = Indian_future_data_handler._build_descending_history_ranges(
        date(2026, 11, 1), date(2026, 11, 23), 100
    )
    assert ranges == [(date(2026, 11, 1), date(2026, 11, 23))]


def test_two_hundred_day_window_does_not_create_a_third_inverted_chunk():
    end = date(2026, 7, 20)
    start = end - timedelta(days=200)
    ranges = Indian_future_data_handler._build_descending_history_ranges(start, end, 100)

    assert len(ranges) == 2
    assert all(range_from <= range_to for range_from, range_to in ranges)
    assert ranges[0][1] == end
    assert ranges[-1][0] == start


def test_history_range_builder_rejects_inverted_or_invalid_ranges():
    with pytest.raises(ValueError, match="after end date"):
        Indian_future_data_handler._build_descending_history_ranges(
            date(2026, 11, 24), date(2026, 11, 23), 100
        )
    with pytest.raises(ValueError, match="chunk_days"):
        Indian_future_data_handler._build_descending_history_ranges(
            date(2026, 11, 1), date(2026, 11, 23), 0
        )


def test_fetch_future_candles_rejects_inverted_range_before_api_call():
    handler = object.__new__(Indian_future_data_handler)
    with pytest.raises(ValueError, match="Invalid NSEFO history range"):
        handler.fetch_future_candles(
            "NSE:NIFTY27JANFUT",
            date(2026, 11, 24),
            date(2026, 11, 23),
            "D",
        )
