import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from fyers_apiv3 import fyersModel
from datetime import datetime, timedelta
import pandas as pd
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
from shared.config.settings import stock_data_dir_config
from data_fetchers.interval_stitching import aggregate_daily_periods, stitch_nse_intraday
import time
import csv


# Match the production cash updater's downloaded base intervals. The custom
# intervals below are derived from these source files after the download pass.
BASE_RESOLUTIONS = ("D", "60", "15", "5")
HISTORICAL_START_DATE = "2020-01-01"


class CandleDateFetcher:

    def __init__(self):
        fyers_access_token = fyers_access_token_handler().get_access_token()
        self.client_id = fyers_access_token.split(':')[0]
        self.access_token = fyers_access_token.split(':')[1]
        self.output_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
        self.name_interval_dict = {
            "D": "daily",
            "60": "sixty", 
            "15": "fifteen",
            "5": "five"
        }
        self.dbc = DBConnection()

    def get_all_symbols(self):
        session = self.dbc.get_session()
        stock_master = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1,
                                                             Ind_StockMaster.fyers_symbol != None).order_by(Ind_StockMaster.id.desc()).all()
        session.close()
        return [(stock.stock_tick, stock.fyers_symbol) for stock in stock_master]

    def fetch_candle_data_custom_resolution(self,
                                        symbol: str,
                                        file_name: str,
                                        start_date: str = "2020-01-01",
                                        end_date: str = None,
                                        resolution: str = "60"):
        if resolution not in self.name_interval_dict:
            raise ValueError(f"Unsupported FYERS resolution: {resolution}")
        if end_date is None:
            end_date = datetime.now().strftime("%Y-%m-%d")
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        if start_dt > end_dt:
            raise ValueError(f"start_date {start_date} is after end_date {end_date}")
        
        fyers = fyersModel.FyersModel(
            client_id=self.client_id,
            is_async=False,
            token=self.access_token,
            log_path=""
        )
        out_file_name = os.path.join(self.output_path, f"{file_name}_{self.name_interval_dict[resolution]}.csv")
        if not os.path.exists(out_file_name):
            print("File does not exist:", out_file_name, symbol)
        all_candles = []
        current_from = end_dt

        while current_from > start_dt:
            current_to = current_from
            current_from = current_to - timedelta(days=99)

            # Clamp range_from to not go before start_dt
            if current_from < start_dt:
                current_from = start_dt

            range_from_str = current_from.strftime("%Y-%m-%d")
            range_to_str = current_to.strftime("%Y-%m-%d")
            print(f"Fetching: {range_from_str} → {range_to_str}")

            data = {
                "symbol": symbol,
                "resolution": resolution,
                "date_format": "1",
                "range_from": range_from_str,
                "range_to": range_to_str,
                "cont_flag": "1"
            }

            success = False
            for attempt in range(10):
                response = fyers.history(data=data)
                if 'candles' in response and response['candles']:
                    all_candles = response['candles'] + all_candles  # Prepend to maintain chronological order
                    success = True
                    break
                else:
                    print(response)
                    print(f"Retry {attempt + 1}: No candle data for {symbol} between {range_from_str} and {range_to_str}")
                    if response.get('s') == 'no_data':
                        break
                    elif response.get('message') == 'request limit reached':
                        time.sleep(5)
                    time.sleep(5)


            if not success:
                print(f"⚠️ Skipped chunk: {range_from_str} to {range_to_str}")

        if not all_candles:
            print("❌ No candles fetched. Skipping save.")
            return

        # Normalize provider output before persisting so subsequent stitching
        # never depends on response ordering or overlapping request ranges.
        df = pd.DataFrame(all_candles, columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
        df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata')
        df = df.sort_values('tradeDate', kind='mergesort')
        df = df.drop_duplicates(subset=['tradeDate'], keep='last').reset_index(drop=True)
        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
        df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]

        out_file_name = os.path.join(self.output_path, f"{file_name}_{self.name_interval_dict[resolution]}.csv")
        df.to_csv(out_file_name, index=False)
        print("✅ Saved:", out_file_name)


    def process_all_symbols(self, symbols=None):
        """Download every configured base timeframe for each active cash symbol."""
        symbols = self.get_all_symbols() if symbols is None else symbols
        for stock_tick, fyers_symbol in symbols:
            for resolution in BASE_RESOLUTIONS:
                self.fetch_candle_data_custom_resolution(
                    symbol=fyers_symbol,
                    file_name=stock_tick,
                    start_date=HISTORICAL_START_DATE,
                    resolution=resolution,
                )


    def process_all_data(self, symbols=None):
        """Build the same derived intervals as the production cash updater."""
        symbols = self.get_all_symbols() if symbols is None else symbols
        for stock_tick, fyers_symbol in symbols:
            daily_file = f"{stock_tick}_daily.csv"
            fifteen_file = f"{stock_tick}_fifteen.csv"
            five_file = f"{stock_tick}_five.csv"
            if os.path.exists(os.path.join(self.output_path, daily_file)):
                self.create_weekly_and_monthly_from_daily(daily_file)
            if os.path.exists(os.path.join(self.output_path, fifteen_file)):
                self.create_75munite_from_15munite(file_name=fifteen_file)
            if os.path.exists(os.path.join(self.output_path, five_file)):
                self.create_25_munite_from_5_munite(file_name=five_file)
                self.create_125_munite_from_5_munite(file_name=five_file)


    def create_weekly_and_monthly_from_daily(self, file_name: str):
        """Create weekly and monthly bars from the downloaded daily history."""
        file_path = os.path.join(self.output_path, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        for sample, output_interval in (("W", "weekly"), ("ME", "monthly")):
            output = aggregate_daily_periods(df, sample)
            output_file = os.path.join(
                self.output_path,
                file_name.replace("daily", output_interval),
            )
            output.to_csv(output_file, index=False)
            print("Saved:", output_file)
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_nse_intraday(df, 125).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "one_twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 125-minute chunks to save.")

    def create_25_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_nse_intraday(df, 25).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 25-minute chunks to save.")
    

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        output = stitch_nse_intraday(df, 75).to_dict('records')

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")
    

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')
    

if __name__ == "__main__":
    cls = CandleDateFetcher()
    active_symbols = cls.get_all_symbols()
    cls.process_all_symbols(active_symbols)
    cls.process_all_data(active_symbols)
