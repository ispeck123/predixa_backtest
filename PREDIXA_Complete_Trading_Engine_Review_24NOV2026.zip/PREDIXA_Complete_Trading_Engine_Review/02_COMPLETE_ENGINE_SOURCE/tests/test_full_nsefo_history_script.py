from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.download_full_nsefo_futures_history import (
    main,
    preflight_contracts,
    validate_universe,
)


def test_universe_guard_requires_exact_count_and_no_duplicates():
    assert validate_universe(["NIFTY", " BANKNIFTY "], 2) == ["NIFTY", "BANKNIFTY"]
    with pytest.raises(ValueError, match="Expected 2"):
        validate_universe(["NIFTY"], 2)
    with pytest.raises(ValueError, match="duplicate"):
        validate_universe(["NIFTY", "NIFTY"], 2)


def test_contract_preflight_fails_before_download_when_a_symbol_is_unresolved():
    class Handler:
        def _contracts_for(self, symbol, refresh=False):
            assert refresh is True
            return [] if symbol == "BANKNIFTY" else [{"symbol": "NSE:NIFTY26NOVFUT"}]

    with pytest.raises(RuntimeError, match="BANKNIFTY"):
        preflight_contracts(Handler(), ["NIFTY", "BANKNIFTY"])


def test_cli_defaults_to_preflight_and_does_not_start_download():
    class Handler:
        def __init__(self):
            self.download_started = False

        def get_all_stock_symbols(self):
            return ["NIFTY", "BANKNIFTY"]

        def process(self, **_kwargs):
            self.download_started = True

    handler = Handler()
    assert main(["--expected-symbols", "2"], handler_factory=lambda: handler) == 0
    assert handler.download_started is False


def test_cli_run_uses_full_refresh_and_processes_derived_data():
    class Handler:
        def __init__(self):
            self.calls = []

        def get_all_stock_symbols(self):
            return ["NIFTY", "BANKNIFTY"]

        def _contracts_for(self, symbol, refresh=False):
            self.calls.append(("resolve", symbol, refresh))
            return [{"symbol": f"NSE:{symbol}26NOVFUT", "expiry": "26-11-2026"}]

        def process(self, **kwargs):
            self.calls.append(("download", kwargs))
            return ["/tmp/NIFTY_26112026_daily.csv"]

    class Processor:
        def __init__(self, handler=None):
            self.handler = handler
            self.calls = []

        def process_all_files(self, **kwargs):
            self.calls.append(kwargs)

    handler = Handler()
    processor = Processor()
    assert main(
        ["--run", "--expected-symbols", "2", "--batch-delay", "0"],
        handler_factory=lambda: handler,
        processor_factory=lambda handler=None: processor,
    ) == 0

    download_call = next(call[1] for call in handler.calls if call[0] == "download")
    assert download_call["force_full_refresh"] is True
    assert download_call["underlyings"] == ["NIFTY", "BANKNIFTY"]
    assert download_call["configured_symbols"] == ["NIFTY", "BANKNIFTY"]
    assert processor.calls == [{
        "symbols": ["NIFTY", "BANKNIFTY"],
        "source_files": ["/tmp/NIFTY_26112026_daily.csv"],
    }]
