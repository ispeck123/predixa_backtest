import pandas as pd

from audit.mcx_futures_backtest.provisional_roll_diagnostic import build_provisional_diagnostic


def _frame(symbol, rows):
    return pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).assign(
        underlying="CRUDEOILM", contract_symbol=symbol
    )


def test_provisional_diagnostic_uses_observed_raw_roll_prices_and_remains_unverified():
    august = _frame("MCX:CRUDEOILM26AUGFUT", [
        ["2026-08-14 23:00:00+05:30", 100, 102, 99, 100, 1],
        ["2026-08-17 08:00:00+05:30", 101, 102, 100, 101, 1],
    ])
    october = _frame("MCX:CRUDEOILM26OCTFUT", [
        ["2026-08-17 09:00:00+05:30", 110, 112, 109, 111, 1],
        ["2026-08-17 10:00:00+05:30", 111, 113, 110, 112, 1],
    ])
    result = build_provisional_diagnostic(august, october, effective_at="2026-08-17 09:00:00+05:30")
    # The builder uses the final observed outgoing close before the switch
    # (101) and the first incoming open at the switch (110).
    assert result.roll_metadata[0]["outgoing_adjustment"] == 9
    assert result.validation_summary["status"] == "UNVERIFIED"
    outgoing = result.series[result.series.contract_symbol == "MCX:CRUDEOILM26AUGFUT"].iloc[0]
    assert outgoing.raw_close == 100
    assert outgoing.research_close == 109
    assert result.series.e1_session_id.notna().all()
