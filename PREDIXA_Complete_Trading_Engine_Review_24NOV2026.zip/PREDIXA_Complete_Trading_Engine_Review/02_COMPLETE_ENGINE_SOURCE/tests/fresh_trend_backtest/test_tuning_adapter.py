from audit.fresh_trend_backtest.tuning import production_config_overrides


def test_overrides_apply_to_both_active_config_paths_and_restore():
    import scripts.models as models
    import scripts.trend_engine as trend
    import scripts.setup_engine_new as setup
    before = (models.Config().embed_overlap_threshold, trend.Config().embed_overlap_threshold)
    with production_config_overrides({"embed_overlap_threshold": 0.6, "embed_strict_stop": True}):
        assert setup.trade_config().embed_overlap_threshold == 0.6
        assert setup.trend_config().embed_overlap_threshold == 0.6
        assert setup.trade_config().embed_strict_stop is True
        assert setup.trend_config().embed_strict_stop is True
    assert (models.Config().embed_overlap_threshold, trend.Config().embed_overlap_threshold) == before


def test_cash_tf3_is_the_production_daily_sixty_fifteen_stack():
    from audit.fresh_trend_backtest.replay import TF_STACKS
    assert TF_STACKS[3] == ["daily", "sixty", "fifteen"]
