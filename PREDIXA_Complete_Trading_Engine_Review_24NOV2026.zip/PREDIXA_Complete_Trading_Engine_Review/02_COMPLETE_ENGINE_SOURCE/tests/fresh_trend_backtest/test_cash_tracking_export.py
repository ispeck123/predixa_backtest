from __future__ import annotations

import sqlite3
from pathlib import Path

from audit.fresh_trend_backtest.export_cash_tracking_cells import export_cash_tracking_cells
from audit.fresh_trend_backtest.storage.schema import SCHEMA


def test_export_uses_persisted_pipeline_regime_and_selected_x_zone(tmp_path: Path):
    database = tmp_path / "cash.sqlite"
    with sqlite3.connect(database) as db:
        db.executescript(SCHEMA)
        db.execute("""INSERT INTO backtest_runs
                      (run_id,run_name,created_at,engine_version,config_hash,config_json,status,variant_name)
                      VALUES (?,?,?,?,?,?,?,?)""",
                   ("run", "cash", "now", "CURRENT_PRODUCTION", "hash", "{}", "COMPLETED",
                    "CURRENT_PRODUCTION"))
        db.execute("INSERT INTO scan_tasks(run_id,symbol,strategy_tf,strategy_tf_name,evaluation_timestamp) VALUES (?,?,?,?,?)",
                   ("run", "infy", 2, "sixty", "2026-01-02T10:00:00"))
        task_id = db.execute("SELECT task_id FROM scan_tasks").fetchone()[0]
        db.execute("INSERT INTO scan_results(task_id,run_id,symbol,strategy_tf,evaluation_timestamp,cmp,signal_generated,setup_generated,entry_candidate) VALUES (?,?,?,?,?,?,?,?,?)",
                   (task_id, "run", "infy", 2, "2026-01-02T10:00:00", 100, 1, 1, 1))
        scan_id = db.execute("SELECT scan_id FROM scan_results").fetchone()[0]
        db.execute("INSERT INTO regime_snapshots(scan_id,E_regime,A_regime,X_regime) VALUES (?,?,?,?)",
                   (scan_id, "UP", "SW", "DN"))
        db.execute("INSERT INTO setup_results(scan_id,symbol,strategy_tf,direction,zone_id,eligible) VALUES (?,?,?,?,?,?)",
                   (scan_id, "infy", 2, "BUY", "zone-7", 1))
        setup_id = db.execute("SELECT setup_id FROM setup_results").fetchone()[0]
        db.execute("INSERT INTO zone_snapshots(scan_id,timeframe,zone_role,zone_id,proximal,distal) VALUES (?,?,?,?,?,?)",
                   (scan_id, "X", "NEAREST_BZ", "zone-7", 101.234, 98.765))
        db.execute("INSERT INTO simulated_trades(setup_id,scan_id,symbol,strategy_tf,side,scan_timestamp,entry_price,stop_price,target_price,outcome,gross_r) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                   (setup_id, scan_id, "infy", 2, "BUY", "2026-01-02T10:00:00", 100, 95, 110, "WIN", 2.0))

    output = tmp_path / "cash_tracking.csv"
    frame = export_cash_tracking_cells(database, "run", output)

    row = frame.iloc[0]
    assert row.e_regime == "UP" and row.a_regime == "SW"  # persisted, not recomputed
    assert row.strategy_tf == 2 and row.time_frame == "sixty"
    assert row.result == "SUCCESS" and row.gross_r == 2.0
    assert row.zone_signature == "infy:X:101.23:98.77"
    assert row.zone_signature_source == "RECONSTRUCTED_FROM_PERSISTED_SELECTED_X_ZONE"
    assert output.exists()


def test_export_prefers_literal_pipeline_signature_when_available(tmp_path: Path):
    database = tmp_path / "cash_literal.sqlite"
    with sqlite3.connect(database) as db:
        db.executescript(SCHEMA)
        db.execute("""INSERT INTO backtest_runs
                      (run_id,run_name,created_at,engine_version,config_hash,config_json,status,variant_name)
                      VALUES (?,?,?,?,?,?,?,?)""",
                   ("run", "cash", "now", "CURRENT_PRODUCTION", "hash", "{}", "COMPLETED", "CURRENT_PRODUCTION"))
        db.execute("INSERT INTO scan_tasks(run_id,symbol,strategy_tf,strategy_tf_name,evaluation_timestamp) VALUES (?,?,?,?,?)", ("run", "infy", 2, "sixty", "t"))
        task = db.execute("SELECT task_id FROM scan_tasks").fetchone()[0]
        db.execute("INSERT INTO scan_results(task_id,run_id,symbol,strategy_tf,evaluation_timestamp,cmp,signal_generated,setup_generated,entry_candidate) VALUES (?,?,?,?,?,?,?,?,?)", (task, "run", "infy", 2, "t", 1, 1, 1, 1))
        scan = db.execute("SELECT scan_id FROM scan_results").fetchone()[0]
        db.execute("INSERT INTO regime_snapshots(scan_id,E_regime,A_regime) VALUES (?,?,?)", (scan, "UP", "UP"))
        db.execute("INSERT INTO setup_results(scan_id,symbol,strategy_tf,direction,zone_id,zone_signature,eligible) VALUES (?,?,?,?,?,?,?)", (scan, "infy", 2, "BUY", "different-zone", "infy:X:11.0:10.0", 1))
        setup = db.execute("SELECT setup_id FROM setup_results").fetchone()[0]
        db.execute("INSERT INTO simulated_trades(setup_id,scan_id,symbol,strategy_tf,side,scan_timestamp,outcome) VALUES (?,?,?,?,?,?,?)", (setup, scan, "infy", 2, "BUY", "t", "LOSS"))
    row = export_cash_tracking_cells(database, "run", tmp_path / "out.csv").iloc[0]
    assert row.zone_signature == "infy:X:11.0:10.0"
    assert row.zone_signature_source == "EMITTED_BY_PIPELINE_AT_SETUP_TIME"


def test_export_uses_only_matched_backfill_signature(tmp_path: Path):
    database = tmp_path / "cash_backfill.sqlite"
    with sqlite3.connect(database) as db:
        db.executescript(SCHEMA)
        db.execute("""INSERT INTO backtest_runs
                      (run_id,run_name,created_at,engine_version,config_hash,config_json,status,variant_name)
                      VALUES (?,?,?,?,?,?,?,?)""", ("run", "cash", "now", "CURRENT_PRODUCTION", "hash", "{}", "COMPLETED", "CURRENT_PRODUCTION"))
        db.execute("INSERT INTO scan_tasks(run_id,symbol,strategy_tf,strategy_tf_name,evaluation_timestamp) VALUES (?,?,?,?,?)", ("run", "infy", 2, "sixty", "t"))
        task = db.execute("SELECT task_id FROM scan_tasks").fetchone()[0]
        db.execute("INSERT INTO scan_results(task_id,run_id,symbol,strategy_tf,evaluation_timestamp,cmp,signal_generated,setup_generated,entry_candidate) VALUES (?,?,?,?,?,?,?,?,?)", (task, "run", "infy", 2, "t", 1, 1, 1, 1))
        scan = db.execute("SELECT scan_id FROM scan_results").fetchone()[0]
        db.execute("INSERT INTO regime_snapshots(scan_id,E_regime,A_regime) VALUES (?,?,?)", (scan, "UP", "UP"))
        db.execute("INSERT INTO setup_results(scan_id,symbol,strategy_tf,direction,zone_id,eligible) VALUES (?,?,?,?,?,?)", (scan, "infy", 2, "BUY", "zone", 1))
        setup = db.execute("SELECT setup_id FROM setup_results").fetchone()[0]
        db.execute("INSERT INTO simulated_trades(setup_id,scan_id,symbol,strategy_tf,side,scan_timestamp,outcome) VALUES (?,?,?,?,?,?,?)", (setup, scan, "infy", 2, "BUY", "t", "WIN"))
    backfill = tmp_path / "backfill.sqlite"
    with sqlite3.connect(backfill) as db:
        db.execute("CREATE TABLE backfill_tasks (trade_id INTEGER, status TEXT, signature TEXT)")
        db.execute("INSERT INTO backfill_tasks VALUES (1,'MATCHED','infy:X:12.0:11.0')")
        db.execute("INSERT INTO backfill_tasks VALUES (999,'MISMATCH','do-not-use')")
    row = export_cash_tracking_cells(database, "run", tmp_path / "out.csv", backfill).iloc[0]
    assert row.zone_signature == "infy:X:12.0:11.0"
    assert row.zone_signature_source == "EMITTED_BY_PINNED_PIPELINE_BACKFILL"
