from types import SimpleNamespace

import pytest

from scripts import futures_graduated_live_scanner as scanner


def job(symbol="RELIANCE", exp_num="26092026", timeframe_id=25, exchange_id=11, is_future=True):
    return scanner.FuturesScanJob(
        symbol=symbol,
        expiry=exp_num,
        exp_num=exp_num,
        timeframe_id=timeframe_id,
        time_list=["weekly", "daily", "seventy_five"],
        exchange_id=exchange_id,
        is_future=is_future,
        contract=f"NSE:{symbol}26SEPFUT",
        lot_size=100,
        execution_mode="PAPER",
        tick_size=0.05,
    )


def formatted_buy(rrr=2.2):
    return {
        "STOCK_NAME": "RELIANCE",
        "PRICE_CMP": 2490.0,
        "BUY": {
            "entry_price": 2500.0,
            "stop_loss": 2450.0,
            "target_price": 2610.0,
            "zone_signature": "RELIANCE:X:1:2",
            "is_execute_tf": True,
            "retest_count": 1,
        },
        "BUY_RRR": rrr,
        "BUY_TIMESTAMPS": {"entry_price_timestamp": 1810000000},
        "e_regime": "SW",
        "a_regime": "SW",
    }


def formatted_sell_only():
    return {
        "STOCK_NAME": "RELIANCE",
        "PRICE_CMP": 2490.0,
        "SELL": {
            "entry_price": 2480.0,
            "stop_loss": 2520.0,
            "target_price": 2390.0,
        },
        "SELL_RRR": 2.5,
        "e_regime": "SW",
        "a_regime": "SW",
    }


def run_with(formatted_results, jobs):
    formatted_iter = iter(formatted_results)
    inserted = []

    def insert(trade, country_id, exchange_id, timeframe_id):
        inserted.append((trade, country_id, exchange_id, timeframe_id))
        return True, len(inserted)

    def provider(timeframe_ids, max_symbols, last_d_time, min_expiry_days):
        assert timeframe_ids == [25]
        assert max_symbols is None
        assert min_expiry_days == scanner.DEFAULT_MIN_EXPIRY_DAYS
        return jobs

    def setup_runner(scan_job):
        return {"raw": scan_job.symbol}

    def formatter(raw, scan_job):
        return next(formatted_iter)

    sut = scanner.FuturesGraduatedLiveReadonlyScanner(
        job_provider=provider,
        setup_runner=setup_runner,
        formatter=formatter,
        signal_inserter=insert,
        candidate_persister=lambda candidate, scan_job, signal_result: None,
    )
    return sut.run(timeframe_ids=[25], write_files=False), inserted


def test_buy_candidate_is_accepted():
    outputs, inserted = run_with([formatted_buy(2.2)], [job()])

    assert len(outputs.candidates) == 1
    candidate = outputs.candidates[0]
    assert candidate["side"] == "BUY"
    assert candidate["exchange_id"] == 11
    assert candidate["is_future"] is True
    assert candidate["entry"] == 2500.0
    assert candidate["stop_loss"] == 2450.0
    assert candidate["target"] == 2610.0
    # G9 evaluated the far target (BUY_RRR=2.2); the brokerless PAPER
    # candidate itself uses the separately recorded full-position TP@50 exit.
    assert candidate["paper_target_price"] == 2555.0
    assert candidate["tp50_overlay"]["original_target"] == 2610.0
    assert candidate["tp50_overlay"]["candidate_tp50_executable"] == 2555.0
    assert candidate["BUY_RRR"] == 2.2
    assert outputs.diagnostics[0]["scan_status"] == "ACCEPTED"
    assert len(inserted) == 1
    trade, country_id, exchange_id, timeframe_id = inserted[0]
    assert trade["TRADE_TYPE"] == "BUY"
    assert trade["PREDICTION"] == "NA"
    assert trade["PROBABILITY"] == 0.0
    assert trade["EXP_NUM"] == "26092026"
    shadow = trade["PAPER_TP50_SHADOW_EXITS"]
    assert shadow["control"]["target_price"] == 2610.0
    assert shadow["candidate"]["target_price"] == 2555.0
    assert shadow["control"]["tracking_error"] is None
    assert shadow["candidate"]["tracking_error"] is None
    assert country_id == 1
    assert exchange_id == 11
    assert timeframe_id == 25


def test_low_rr_paper_setup_is_rejected_by_original_target_g9():
    outputs, inserted = run_with([formatted_buy(2.09)], [job()])

    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] == "BUY_RRR_TOO_LOW"
    assert inserted == []


def test_low_rr_real_setup_remains_rejected():
    real_job = scanner.FuturesScanJob(**(job().__dict__ | {"execution_mode": "REAL"}))
    outputs, inserted = run_with([formatted_buy(2.09)], [real_job])

    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] == "BUY_RRR_TOO_LOW"
    assert inserted == []


def test_sell_only_never_becomes_candidate():
    outputs, inserted = run_with([formatted_sell_only()], [job()])

    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] == "NO_SETUP"
    assert outputs.diagnostics[0]["rejection_reason"] == "NO_BUY_SETUP"
    assert inserted == []


@pytest.mark.parametrize("formatted", [{}, {"BUY": None}, None])
def test_no_setup_produces_no_candidate(formatted):
    outputs, inserted = run_with([formatted], [job()])

    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] in {"NO_SETUP", "INVALID_RESULT"}
    assert inserted == []


def test_multiple_futures_scan_without_db_or_broker_mutation():
    jobs = [job("RELIANCE"), job("TCS")]
    outputs, inserted = run_with([formatted_buy(2.2), formatted_buy(2.3)], jobs)

    assert outputs.total_jobs == 2
    assert outputs.processed == 2
    assert outputs.errors == 0
    assert [candidate["symbol"] for candidate in outputs.candidates] == ["RELIANCE", "TCS"]
    assert len(inserted) == 2


def test_declined_trade_signal_is_reported_without_candidate_persistence():
    sut = scanner.FuturesGraduatedLiveReadonlyScanner(
        job_provider=lambda *_args: [job()],
        setup_runner=lambda _job: {"raw": "RELIANCE"},
        formatter=lambda _raw, _job: formatted_buy(2.2),
        signal_inserter=lambda *_args: (False, None),
        candidate_persister=lambda *_args: pytest.fail("declined signal reached persistence"),
    )
    outputs = sut.run(timeframe_ids=[25], write_files=False)
    assert outputs.errors == 0
    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] == "SIGNAL_NOT_PERSISTED"
    assert outputs.diagnostics[0]["rejection_reason"] == "TRADE_SIGNAL_INSERT_DECLINED"


def test_default_jobs_use_full_configured_universe_and_dynamic_expiries(monkeypatch):
    import scripts.scanner_fc as scanner_fc

    monkeypatch.setattr(
        scanner_fc,
        "build_futures_expiry_map",
        lambda min_days, time_fr: [
            {"symbol": "CANBK", "expiry": ["29092026", "27102026"]},
            {"symbol": "HDFCBANK", "expiry": ["29092026"]},
            {"symbol": "RELIANCE", "expiry": ["29092026"]},
        ],
    )
    monkeypatch.setattr(scanner, "resolve_nsefo_contract_metadata", lambda symbol, expiry: {
        "fyers_symbol": f"NSE:{symbol}26SEPFUT", "lot_size": 75, "tick_size": 0.05})

    jobs = list(scanner.default_futures_jobs([1], max_symbols=None, last_d_time=None))

    assert [item.symbol for item in jobs] == ["CANBK", "CANBK", "HDFCBANK", "RELIANCE"]
    assert [item.expiry for item in jobs] == ["29092026", "27102026", "29092026", "29092026"]
    assert [item.exp_num for item in jobs] == ["29092026", "27102026", "29092026", "29092026"]
    assert [item.contract for item in jobs] == ["NSE:CANBK26SEPFUT", "NSE:CANBK26SEPFUT", "NSE:HDFCBANK26SEPFUT", "NSE:RELIANCE26SEPFUT"]
    assert all(item.exchange_id == 11 for item in jobs)
    assert all(item.is_future is True for item in jobs)
    assert all(item.execution_mode == "PAPER" for item in jobs)


def test_artificial_max_symbols_is_rejected():
    with pytest.raises(ValueError, match="UNIVERSE_TRUNCATION_DISABLED"):
        list(scanner.default_futures_jobs([1], max_symbols=1, last_d_time=None))


def test_default_jobs_passes_five_day_expiry_filter_to_scanner_fc(monkeypatch):
    calls = []

    import scripts.scanner_fc as scanner_fc

    def fake_build_futures_expiry_map(min_days, time_fr):
        calls.append((min_days, time_fr))
        return [{"symbol": "CANBK", "expiry": ["27102026"]}]

    monkeypatch.setattr(scanner_fc, "build_futures_expiry_map", fake_build_futures_expiry_map)
    monkeypatch.setattr(scanner, "resolve_nsefo_contract_metadata", lambda symbol, expiry: {
        "fyers_symbol": f"NSE:{symbol}26OCTFUT", "lot_size": 75, "tick_size": 0.05})

    jobs = list(scanner.default_futures_jobs([1], max_symbols=None, last_d_time=None, min_expiry_days=5))

    assert calls == [(5, 1)]
    assert [item.exp_num for item in jobs] == ["27102026"]


def test_broker_mutation_methods_are_not_called(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("broker mutation called")

    from shared.db import fyers_req_model

    for name in (
        "place_order",
        "place_cash_gtt",
        "place_futures_entry_gtt",
        "cancel_gtt_order",
    ):
        monkeypatch.setattr(fyers_req_model.FyersClient, name, forbidden, raising=False)

    fake_client = SimpleNamespace(
        place_gtt_order=forbidden,
        modify_gtt_order=forbidden,
        cancel_gtt_order=forbidden,
        exit_positions=forbidden,
    )
    monkeypatch.setattr(fyers_req_model.FyersClient, "_client", fake_client, raising=False)

    outputs, inserted = run_with([formatted_buy(2.2)], [job()])

    assert len(outputs.candidates) == 1
    assert len(inserted) == 1


def test_trade_insert_function_is_called_for_accepted_candidate():
    def forbidden(*args, **kwargs):
        raise AssertionError("unused")

    outputs, inserted = run_with([formatted_buy(2.2)], [job()])

    assert len(outputs.candidates) == 1
    assert len(inserted) == 1


def test_futures_only_rejects_non_nsefo_path():
    outputs, inserted = run_with([formatted_buy(2.2)], [job(exchange_id=10, is_future=False)])

    assert outputs.candidates == []
    assert outputs.diagnostics[0]["scan_status"] == "INVALID_RESULT"
    assert outputs.diagnostics[0]["rejection_reason"] == "NOT_NSE_FUTURES"
    assert inserted == []


def test_buy_only_rejects_sell_result_even_when_sell_rrr_qualifies():
    outputs, inserted = run_with([formatted_sell_only()], [job()])

    assert outputs.candidates == []
    assert all(candidate["side"] == "BUY" for candidate in outputs.candidates)
    assert inserted == []
