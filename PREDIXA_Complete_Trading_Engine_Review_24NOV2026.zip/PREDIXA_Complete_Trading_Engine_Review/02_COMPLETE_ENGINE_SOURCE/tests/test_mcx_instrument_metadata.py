import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts import mcx_instrument_metadata as metadata

class Response:
    text = "123,Silver Mini 30 NOV 27 FUT,x,5,0.05,x,x,x,x,MCX:SILVERM27NOVFUT\n"
    def raise_for_status(self): pass

def test_fyers_mcx_master_supplies_exact_contract_tick_and_identity(monkeypatch):
    metadata._master.cache_clear()
    monkeypatch.setattr(metadata.requests, "get", lambda *args, **kwargs: Response())
    record = metadata.resolve_mcx_contract_metadata("silver mini", "30-11-2027", now=1)
    assert record["fyers_symbol"] == "MCX:SILVERM27NOVFUT"
    assert record["provider_token"] == "123"
    assert record["tick_size"] == .05
    assert record["trading_status"] == "ACTIVE"

    assert metadata.resolve_mcx_contract_metadata("silver mini", "2027-11-30", now=1)["tick_size"] == .05

def test_no_tick_is_never_inferred(monkeypatch):
    metadata._master.cache_clear()
    class BadResponse(Response):
        text = "123,Silver Mini 30 NOV 27 FUT,x,5,0,x,x,x,x,MCX:SILVERM27NOVFUT\n"
    monkeypatch.setattr(metadata.requests, "get", lambda *args, **kwargs: BadResponse())
    try:
        metadata.resolve_mcx_contract_metadata("silver mini", "30-11-2027", now=1)
    except ValueError as exc:
        assert "METADATA_MISSING" in str(exc)
    else:
        raise AssertionError("invalid master tick was accepted")
