import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from scripts.nsefo_paper_governor import (PAPER_ACTIVE, PAPER_AUTO_APPROVED, PAPER_PENDING, PAPER_SOURCE,
                                          approve_paper_candidate, auto_approve_tier0_paper_candidate,
                                          promote_next_auto_approved_paper_candidate)
from scripts.nsefo_tp_overlay import (build_overlay, is_eligible, realized_r,
                                      resolve_long_exit, shadow_exit_log, tracking_summary)
from scripts.nsefo_real_mechanical_rails import evaluate
from shared.db.db_model import Base, Future_Order, OMSOrderBucketFuture


def test_tp50_is_exact_scope_tick_rounded_and_original_target_preserved():
    assert is_eligible(segment="NSEFO", e_regime="SW", a_regime="SW", strategy_tf=25, side="BUY")
    assert not is_eligible(segment="MCX", e_regime="SW", a_regime="SW", strategy_tf=25, side="BUY")
    assert not is_eligible(segment="NSEFO", e_regime="SW", a_regime="SW", strategy_tf=25, side="SELL")
    overlay = build_overlay(entry=100, stop=90, original_target=121.03, tick_size=.05)
    assert overlay["original_target"] == 121.03
    assert overlay["candidate_tp50_requested"] == pytest.approx(110.515)
    assert overlay["candidate_tp50_executable"] == pytest.approx(110.5)


def test_tp50_exit_is_full_position_and_ambiguous_ohlc_is_not_favorably_filled():
    assert resolve_long_exit(entry=100, stop=90, target=110, candle_low=95, candle_high=111) == {"status": "TARGET", "exit_price": 110.0}
    assert resolve_long_exit(entry=100, stop=90, target=110, candle_low=89, candle_high=111)["status"] == "UNRESOLVED_AMBIGUOUS_OHLC"
    assert realized_r(entry=100, stop=90, exit_price=110) == pytest.approx(1.0)


def test_tracking_summary_is_per_variant_and_never_promotes_automatically():
    candidate = tracking_summary([{"tracking_error": 0.0}] * 20)
    control = tracking_summary([{"tracking_error": -0.2}] * 20)
    assert candidate["gross_divergence_review"] is True
    assert control["gross_divergence_review"] is False
    assert candidate["promotion"] == "BLOCKED_PENDING_CRITERION_RECONCILIATION"


def test_shadow_exit_log_has_separate_control_and_candidate_tracking_books():
    overlay = build_overlay(entry=100, stop=90, original_target=121, tick_size=.05)
    logged = shadow_exit_log(setup_id="tier0-1", overlay=overlay)
    assert logged["control"]["target_price"] == 121.0
    assert logged["candidate"]["target_price"] == 110.5
    assert logged["control"]["tracking_error"] is None
    assert logged["candidate"]["tracking_error"] is None


def _factory():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)


def _pending(factory, signal_id):
    session = factory()
    order = Future_Order(trade_signal_id=signal_id, order_status=PAPER_PENDING,
                         execution_mode="PAPER", candidate_source=PAPER_SOURCE)
    session.add(order); session.flush()
    bucket = OMSOrderBucketFuture(order_id=order.order_id, trade_signal_id=signal_id,
                                  order_status=PAPER_PENDING, approval_status="pending",
                                  execution_mode="PAPER", candidate_source=PAPER_SOURCE)
    session.add(bucket); session.commit(); result = bucket.bucket_id; session.close()
    return result


def test_per_order_approval_enforces_serial_paper_position_without_broker():
    factory = _factory(); first, second = _pending(factory, 1), _pending(factory, 2)
    assert approve_paper_candidate(bucket_id=first, approved_by=9, session_factory=factory)["status"] == "PAPER_APPROVED"
    with pytest.raises(ValueError, match="OPTION3_SERIAL_LOCKED"):
        approve_paper_candidate(bucket_id=second, approved_by=9, session_factory=factory)
    session = factory(); row = session.get(OMSOrderBucketFuture, first)
    assert row.order_status == PAPER_ACTIVE and row.approved_by == 9
    session.close()


def test_auto_approval_is_exact_tier0_paper_only_and_serial_safe():
    factory = _factory(); first, second = _pending(factory, 1), _pending(factory, 2)
    session = factory()
    bucket = session.get(OMSOrderBucketFuture, first); order = session.get(Future_Order, bucket.order_id)
    assert auto_approve_tier0_paper_candidate(session=session, bucket=bucket, order=order)["status"] == "PAPER_AUTO_APPROVED_MONITORING"
    session.commit(); session.close()
    session = factory(); bucket = session.get(OMSOrderBucketFuture, second); order = session.get(Future_Order, bucket.order_id)
    assert auto_approve_tier0_paper_candidate(session=session, bucket=bucket, order=order)["status"] == "PAPER_AUTO_APPROVED_QUEUED"
    assert bucket.approval_status == PAPER_AUTO_APPROVED and bucket.order_status == PAPER_PENDING
    session.commit(); session.close()
    session = factory(); active = session.get(OMSOrderBucketFuture, first)
    active.order_status = "closed"
    active_order = session.get(Future_Order, active.order_id); active_order.order_status = "closed"
    assert promote_next_auto_approved_paper_candidate(session=session)["status"] == "PAPER_AUTO_APPROVED_PROMOTED"
    session.commit(); session.close()
    session = factory(); promoted = session.get(OMSOrderBucketFuture, second)
    assert promoted.order_status == PAPER_ACTIVE
    session.close()
    session = factory(); bucket = session.get(OMSOrderBucketFuture, first); order = session.get(Future_Order, bucket.order_id)
    bucket.candidate_source = "GRADUATED_LIVE"
    with pytest.raises(ValueError, match="PROVENANCE_REJECTED"):
        auto_approve_tier0_paper_candidate(session=session, bucket=bucket, order=order)
    session.close()


def test_real_mechanical_rails_are_dormant_until_tracking_error_graduation():
    result = evaluate(serialization_clear=True, trade_risk_inr=17_999,
                      margin_clear=True, liquidity_clear=True,
                      tracking_error_graduated=True)
    assert result["approved"] is False
    assert "NSEFO_REAL_MECHANICAL_RAILS_NOT_ACTIVATED" in result["reasons"]
