from datetime import datetime, timedelta
from pathlib import Path
import sys

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data_fetchers.fyers.expiry_refresh import (
    ExchangeCalendar,
    ExpiryRefreshCoordinator,
    IST,
    normalize_fyers_ohlc,
    safe_replace_csv,
)


def at(value):
    return datetime.fromisoformat(value).replace(tzinfo=IST)


def coordinator(tmp_path, exchange="NSE", calendar=None):
    return ExpiryRefreshCoordinator(tmp_path / f"{exchange}.json", exchange, calendar=calendar)


def test_normal_day_only_records_active_contracts(tmp_path):
    state = coordinator(tmp_path)
    state.observe([{"symbol": "NSE:ABC26OCTFUT", "expiry": "29-10-2026"}], at("2026-10-12T10:00:00"))
    assert state.pending_and_eligible(at("2026-10-12T10:00:00")) == []


def test_expiry_waits_until_final_session_close_and_then_becomes_pending(tmp_path):
    state = coordinator(tmp_path)
    contracts = [{"symbol": "NSE:ABC26OCTFUT", "expiry": "29-10-2026"}]
    state.observe(contracts, at("2026-10-29T15:29:00"))
    assert not state.state["events"]
    state.observe(contracts, at("2026-10-29T15:31:00"))
    assert not state.state["events"]
    assert not state.pending_and_eligible(at("2026-10-29T15:31:00"))
    state.observe(contracts, at("2026-10-30T09:15:00"))
    assert state.pending_and_eligible(at("2026-10-30T09:15:00"))


def test_weekend_defers_refresh_to_next_market_opening(tmp_path):
    state = coordinator(tmp_path)
    state.observe([{"symbol": "NSE:ABC26OCTFUT", "expiry": "30-10-2026"}], at("2026-10-30T15:31:00"))
    assert not state.pending_and_eligible(at("2026-10-31T10:00:00"))
    state.observe([], at("2026-11-02T09:15:00"))
    assert state.pending_and_eligible(at("2026-11-02T09:15:00"))


def test_nse_holiday_and_mcx_evening_partial_session_are_respected(tmp_path):
    calendar_file = tmp_path / "calendar.json"
    calendar_file.write_text('{"NSE":{"2026-10-20":[]},"MCX":{"2026-10-20":[["17:00","23:30"]]}}')
    calendar = ExchangeCalendar(calendar_file)
    nse = coordinator(tmp_path, "NSE", calendar)
    nse.observe([{"symbol": "NSE:ABC26OCTFUT", "expiry": "19-10-2026"}], at("2026-10-19T15:31:00"))
    nse.observe([], at("2026-10-20T10:00:00"))
    assert not nse.pending_and_eligible(at("2026-10-20T10:00:00"))
    mcx = coordinator(tmp_path, "MCX", calendar)
    mcx.observe([{"symbol": "MCX:CRUDEOILM26OCTFUT", "expiry": "19-10-2026"}], at("2026-10-19T23:31:00"))
    mcx.observe([], at("2026-10-20T10:00:00"))
    assert not mcx.pending_and_eligible(at("2026-10-20T10:00:00"))
    assert mcx.pending_and_eligible(at("2026-10-20T17:00:00"))


def test_same_expiry_is_consolidated_and_different_expiry_is_independent(tmp_path):
    state = coordinator(tmp_path)
    state.observe([
        {"symbol": "NSE:A26OCTFUT", "expiry": "29-10-2026"},
        {"symbol": "NSE:B26OCTFUT", "expiry": "29-10-2026"},
        {"symbol": "NSE:C26NOVFUT", "expiry": "26-11-2026"},
    ], at("2026-10-29T15:31:00"))
    state.observe([], at("2026-10-30T10:00:00"))
    assert len(state.state["events"]) == 1
    event = next(iter(state.state["events"].values()))
    assert len(event["expired_contracts"]) == 2
    state.observe([], at("2026-11-27T09:15:00"))
    assert len(state.state["events"]) == 2


def test_pending_event_maps_expired_contracts_to_only_rolled_underlyings(tmp_path):
    state = coordinator(tmp_path, "MCX")
    state.observe([
        {"symbol": "MCX:CRUDEOILM26OCTFUT", "expiry": "19-10-2026", "underlying": "CRUDEOILM"},
        {"symbol": "MCX:GOLDM26OCTFUT", "expiry": "19-10-2026", "underlying": "GOLDM"},
        {"symbol": "MCX:SILVER26NOVFUT", "expiry": "26-11-2026", "underlying": "SILVER"},
    ], at("2026-10-20T09:00:00"))
    events = state.pending_and_eligible(at("2026-10-20T09:00:00"))
    assert state.affected_underlyings(events) == {"CRUDEOILM", "GOLDM"}
    assert state.blocks_engine(at("2026-10-20T09:00:00")) is True
    state.complete(events, at("2026-10-20T10:00:00"))
    assert state.blocks_engine(at("2026-10-20T10:00:00")) is False


def test_restart_recovers_in_progress_and_completed_event_never_repeats(tmp_path):
    path = tmp_path / "NSE.json"
    state = ExpiryRefreshCoordinator(path, "NSE")
    state.observe([{"symbol": "NSE:A26OCTFUT", "expiry": "29-10-2026"}], at("2026-10-29T15:31:00"))
    state.observe([], at("2026-10-30T10:00:00"))
    event = state.pending_and_eligible(at("2026-10-30T10:00:00"))[0]
    state.start([event], at("2026-10-30T10:00:00"))
    recovered = ExpiryRefreshCoordinator(path, "NSE")
    event = recovered.pending_and_eligible(at("2026-10-30T10:00:00"))[0]
    recovered.complete([event], at("2026-10-30T10:00:00"))
    restarted = ExpiryRefreshCoordinator(path, "NSE")
    assert restarted.pending_and_eligible(at("2026-10-30T10:30:00")) == []


def test_invalid_history_never_replaces_existing_csv(tmp_path):
    destination = tmp_path / "history.csv"
    original = "open,high,low,close,qty,tradeDate\n1,2,0,1,1,01/10/2026 09:15:00\n"
    destination.write_text(original)
    invalid = pd.DataFrame([[1, 0, 2, 1, 1, "01/10/2026 09:15:00"]],
                           columns=["open", "high", "low", "close", "qty", "tradeDate"])
    with pytest.raises(ValueError):
        safe_replace_csv(invalid, destination)
    assert destination.read_text() == original


def test_legacy_bootstrap_can_stage_fyers_ohlc_anomaly_without_disabling_refresh_validation(tmp_path):
    destination = tmp_path / "history.csv"
    anomalous = pd.DataFrame([[1, 0, 2, 1, 1, "01/10/2026 09:15:00"]],
                             columns=["open", "high", "low", "close", "qty", "tradeDate"])
    safe_replace_csv(anomalous, destination, validate_ohlc=False)
    assert destination.exists()


def test_rare_stitched_ohlc_envelope_anomaly_is_repaired_before_refresh_swap():
    rows = [[100, 99, 95, 98, 1, "01/10/2026 09:15:00"]]
    rows.extend([[100, 105, 95, 102, 1, "01/10/2026 09:30:00"]] * 100)
    frame = pd.DataFrame(rows, columns=["open", "high", "low", "close", "qty", "tradeDate"])
    repaired = normalize_fyers_ohlc(frame)
    assert repaired.loc[0, "high"] == 100
    assert repaired.loc[0, "low"] == 95


def test_material_ohlc_corruption_is_still_rejected():
    frame = pd.DataFrame([[100, 99, 95, 98, 1, "01/10/2026 09:15:00"]],
                         columns=["open", "high", "low", "close", "qty", "tradeDate"])
    with pytest.raises(ValueError, match="inconsistent OHLC"):
        normalize_fyers_ohlc(frame)


def test_mcx_continuous_refresh_repairs_the_observed_sparse_anomaly_rate():
    rows = [[100, 105, 95, 102, 1, "01/10/2026 09:15:00"]] * 1758
    for index in range(18):
        rows[index] = [100, 99, 95, 98, 1, "01/10/2026 09:15:00"]
    frame = pd.DataFrame(rows, columns=["open", "high", "low", "close", "qty", "tradeDate"])
    repaired = normalize_fyers_ohlc(frame, max_invalid_fraction=0.02)
    assert (repaired["high"] >= repaired[["open", "low", "close"]].max(axis=1)).all()


def test_mcx_derived_writer_repairs_a_stitched_source_envelope(monkeypatch, tmp_path):
    from data_fetchers.fyers import indian_commodity_data_updater as mcx_updater

    monkeypatch.setattr(mcx_updater.sddcfg, "indian_commodity_data", str(tmp_path))
    handler = mcx_updater.MCXFutureDataHandler.__new__(mcx_updater.MCXFutureDataHandler)
    header = ["open", "high", "low", "close", "qty", "tradeDate"]
    start = datetime(2026, 7, 3, 9)
    rows = [{"open": 6564, "high": 6644, "low": 6570, "close": 6611,
             "qty": 1, "tradeDate": start.strftime("%d/%m/%Y %H:%M:%S")}]
    rows.extend([{"open": 6564, "high": 6650, "low": 6560, "close": 6611,
                  "qty": 1,
                  "tradeDate": (start + timedelta(minutes=75 * index)).strftime("%d/%m/%Y %H:%M:%S")}
                 for index in range(1, 101)])
    handler.dump_csv(header, "CRUDEOILM_19112026_seventy_five.csv", rows)
    saved = pd.read_csv(tmp_path / "latest_data_csv" / "CRUDEOILM_19112026_seventy_five.csv")
    assert saved.loc[0, "low"] == 6564


@pytest.mark.parametrize("code, payload, message", [
    (-50, {"range_from": "outside the available historical data for intraday resolutions"}, "Invalid input"),
    (-99, None, "Bad request"),
])
def test_mcx_intraday_pre_availability_response_is_skipped_without_retry(monkeypatch, code, payload, message):
    """FYERS -50/-99 availability boundaries are not transient outages."""
    from data_fetchers.fyers import indian_commodity_data_updater as mcx_updater

    class FyersBoundary:
        calls = 0

        def history(self, **_kwargs):
            self.calls += 1
            response = {"code": code, "message": message, "s": "error"}
            if payload is not None:
                response["data"] = payload
            return response

    handler = mcx_updater.MCXFutureDataHandler.__new__(mcx_updater.MCXFutureDataHandler)
    handler.fyers = FyersBoundary()
    monkeypatch.setattr(mcx_updater.time, "sleep", lambda *_: pytest.fail("boundary response retried"))
    result = handler._fetch_candle_data_once(
        "MCX:GOLDM26DECFUT", datetime(2017, 1, 1), datetime(2017, 4, 10), "60"
    )
    assert result.empty
    assert handler.fyers.calls == 1


def test_mcx_rate_limit_uses_long_cooldown_before_retry(monkeypatch):
    from data_fetchers.fyers import indian_commodity_data_updater as mcx_updater

    class FyersRateLimited:
        def history(self, **_kwargs):
            return {"code": -360, "message": "rate limited", "s": "error"}

    handler = mcx_updater.MCXFutureDataHandler.__new__(mcx_updater.MCXFutureDataHandler)
    handler.fyers = FyersRateLimited()
    waits = []
    monkeypatch.setattr(mcx_updater.time, "sleep", waits.append)
    result = handler._fetch_candle_data_once(
        "MCX:SILVER26DECFUT", datetime(2018, 10, 1), datetime(2019, 1, 9), "240", max_retries=1
    )
    assert result is None
    assert waits == [60.0]


def test_missing_metadata_creates_no_refresh_event(tmp_path):
    state = coordinator(tmp_path)
    state.observe(None, at("2026-10-30T10:00:00"))
    assert state.state["events"] == {}
