import pandas as pd
import importlib.util
from pathlib import Path

from data_fetchers.interval_stitching import (
    aggregate_daily_periods,
    stitch_mcx_intraday,
    stitch_nse_intraday,
)


def _candles(stamps):
    rows = []
    for index, stamp in enumerate(stamps, start=1):
        rows.append({
            "open": index * 10,
            "high": index * 10 + 3,
            "low": index * 10 - 2,
            "close": index * 10 + 1,
            "qty": index,
            "tradeDate": pd.Timestamp(stamp).strftime("%d/%m/%Y %H:%M:%S"),
        })
    return pd.DataFrame(rows)


def test_nse_stitch_uses_time_buckets_and_sorts_unsorted_input():
    source = _candles([
        "2026-11-23 10:05", "2026-11-23 09:15", "2026-11-23 09:25",
        "2026-11-23 10:10", "2026-11-23 10:15", "2026-11-23 09:30",
        "2026-11-23 10:20", "2026-11-23 09:35", "2026-11-23 10:25",
    ])
    result = stitch_nse_intraday(source, 25)

    assert result["tradeDate"].tolist() == [
        "23/11/2026 09:15:00", "23/11/2026 10:05:00"
    ]
    # The missing 09:20 bar does not slide later bars into a different bucket.
    assert result.iloc[0]["open"] == 20
    assert result.iloc[0]["close"] == 81
    assert result.iloc[1]["open"] == 10
    assert result.iloc[1]["close"] == 91


def test_nse_stitch_does_not_mix_days_or_include_out_of_session_rows():
    source = _candles([
        "2026-11-23 15:30", "2026-11-24 09:15", "2026-11-23 15:35"
    ])
    result = stitch_nse_intraday(source, 75)
    assert result["tradeDate"].tolist() == ["24/11/2026 09:15:00"]


def test_nse_75_and_125_minute_grids_use_session_open_anchors():
    stamps = pd.date_range("2026-11-23 09:15", "2026-11-23 15:25", freq="5min")
    source = _candles(stamps)
    seventy_five = stitch_nse_intraday(source, 75)
    one_twenty_five = stitch_nse_intraday(source, 125)
    assert seventy_five["tradeDate"].tolist() == [
        "23/11/2026 09:15:00", "23/11/2026 10:30:00", "23/11/2026 11:45:00",
        "23/11/2026 13:00:00", "23/11/2026 14:15:00",
    ]
    assert one_twenty_five["tradeDate"].tolist() == [
        "23/11/2026 09:15:00", "23/11/2026 11:20:00", "23/11/2026 13:25:00"
    ]


def test_mcx_stitch_is_session_anchored_and_does_not_bridge_e1_seam():
    source = _candles([
        "2026-11-23 23:00", "2026-11-23 09:15", "2026-11-23 09:30",
        "2026-11-24 09:00", "2026-11-24 09:15",
    ])
    result = stitch_mcx_intraday(source, 75)
    assert result["tradeDate"].tolist() == [
        "23/11/2026 09:00:00", "23/11/2026 22:45:00", "24/11/2026 09:00:00"
    ]


def test_mcx_evening_only_session_anchors_at_1700_and_drops_incomplete_bucket():
    stamps = [
        "2026-11-23 17:00", "2026-11-23 17:15", "2026-11-23 17:30",
        "2026-11-23 17:45", "2026-11-23 18:00", "2026-11-23 18:15",
    ]
    result = stitch_mcx_intraday(_candles(stamps), 75, base_minutes=15)
    assert result["tradeDate"].tolist() == ["23/11/2026 17:00:00"]


def test_daily_weekly_rollup_sorts_before_open_close_selection():
    source = pd.DataFrame([
        {"open": 30, "high": 35, "low": 29, "close": 33, "qty": 3, "tradeDate": "03/11/2026"},
        {"open": 10, "high": 15, "low": 9, "close": 13, "qty": 1, "tradeDate": "02/11/2026"},
        {"open": 20, "high": 25, "low": 19, "close": 23, "qty": 2, "tradeDate": "04/11/2026"},
    ])
    result = aggregate_daily_periods(source, "W")
    assert result.iloc[0]["open"] == 10
    assert result.iloc[0]["close"] == 23
    assert result.iloc[0]["qty"] == 6
    assert result.columns.tolist() == ["open", "high", "low", "close", "qty", "tradeDate"]


def test_t17_downloader_does_not_start_when_imported():
    script_path = Path(__file__).resolve().parents[1] / "tests" / "t17.py"
    spec = importlib.util.spec_from_file_location("predixa_t17_import_check", script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert hasattr(module, "CandleDateFetcher")
    assert not hasattr(module, "cls")


def test_t17_downloads_every_base_resolution_without_network_calls():
    script_path = Path(__file__).resolve().parents[1] / "tests" / "t17.py"
    spec = importlib.util.spec_from_file_location("predixa_t17_resolution_check", script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    fetcher = module.CandleDateFetcher.__new__(module.CandleDateFetcher)
    requests = []
    fetcher.fetch_candle_data_custom_resolution = lambda **kwargs: requests.append(kwargs)
    fetcher.process_all_symbols([("ABC", "NSE:ABC-EQ")])

    assert [request["resolution"] for request in requests] == ["D", "60", "15", "5"]
    assert all(request["start_date"] == "2020-01-01" for request in requests)


def test_t17_builds_all_configured_derived_timeframes(tmp_path):
    script_path = Path(__file__).resolve().parents[1] / "tests" / "t17.py"
    spec = importlib.util.spec_from_file_location("predixa_t17_derived_check", script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    fetcher = module.CandleDateFetcher.__new__(module.CandleDateFetcher)
    fetcher.output_path = str(tmp_path)
    for interval in ("daily", "fifteen", "five"):
        (tmp_path / f"ABC_{interval}.csv").touch()

    calls = []
    fetcher.create_weekly_and_monthly_from_daily = lambda name: calls.append(("weekly_monthly", name))
    fetcher.create_75munite_from_15munite = lambda file_name: calls.append(("75m", file_name))
    fetcher.create_25_munite_from_5_munite = lambda file_name: calls.append(("25m", file_name))
    fetcher.create_125_munite_from_5_munite = lambda file_name: calls.append(("125m", file_name))
    fetcher.process_all_data([("ABC", "NSE:ABC-EQ")])

    assert calls == [
        ("weekly_monthly", "ABC_daily.csv"),
        ("75m", "ABC_fifteen.csv"),
        ("25m", "ABC_five.csv"),
        ("125m", "ABC_five.csv"),
    ]
