# MCX Institutional Zone Alerts

## Audited integration points

- API: `apps/backend/main.py`; FastAPI with SQLAlchemy/MySQL (`shared/db/dbconn.py`).
- Live market source: `data_fetchers/fyers/fyers_ingestor.py` publishes de-duplicated exact-provider contract ticks to Redis `market:commodity:ticks:<symbol>`; `apps/dashboard/derivatives_market.py` is the browser relay.
- Contract selection: `shared/market_data_symbols.py` resolves the exact MCX provider contract; `futures_category_map` supplies NEAR/NEXT/FAR for futures.  No contract aliases are merged by this feature.
- CSV/zone pipeline: MCX candles are in `data/indian_commodity_data/latest_data_csv`; chart API `apps/backend/api/indian_commodity_futures.py` calls `scripts.trade_engine.process_zones` / `process_qualified_zones`.
- Existing updater: `data_fetchers/kiteconnect/indian_commodity_data_updater.py`. It writes CSV files directly and exposes no success event, therefore invoke the post-success hook below from its owning batch/orchestrator after all files are complete.

## Deploy

1. Apply `scripts/db_migrations/20261105_mcx_zone_alerts.sql`, then the additive `scripts/db_migrations/20261105_mcx_zone_discord_alerts.sql`, to the existing MySQL schema.
2. Install `pywebpush` in the current backend environment, generate VAPID keys, and set `VAPID_PRIVATE_KEY`, `VAPID_PUBLIC_KEY`, `VAPID_SUBJECT=mailto:REVIEW_USER@example.invalid`; optional `MCX_PUSH_TTL_SECONDS=120`, `MCX_ALERT_STALE_MS=30000`, `MCX_ZONE_APPROACH_TICKS=4`.
3. `scripts/mcx_instrument_metadata.py` reads and schema-validates FYERS `MCX_COM.csv` hourly: exact provider symbol/token, expiry, lot size, tick size and active state. The snapshot publisher rejects a mismatch with the updater's exact provider contract. `MCX_ZONE_TICK_SIZES_JSON` is a validated emergency fallback only; there is no implicit tick-size default.
4. Start exactly the normal FYERS ingestor, then run `python scripts/mcx_zone_alert_worker.py` and `python scripts/mcx_zone_delivery_worker.py` under the platform supervisor. Multiple workers are safe through row locking and unique keys.
5. The Dagster `update_indian_commodity_job` automatically invokes `publish_completed_contracts` after `MCXFutureDataHandler.download_all()` has atomically replaced every source/derived CSV in a completed contract batch. It then evaluates Redis's cached fresh LTP. The CLI remains available for recovery operations; normal 30-minute processing needs no manual invocation.

Zone selection remains on the established trade-engine implementation. Weekly,
Daily and 240-minute CSVs use `process_zones`; 120-minute and 60-minute CSVs
use the existing `process_qualified_zones` validation path before a snapshot is
published. Snapshot provenance records the selected `zone_method`.

MCX zone alerts are configured centrally and delivered only to Discord. There
are no user subscriptions, browser-push records, notification inboxes, or
frontend alert APIs in this deployment. Instrument, event, timeframe and
NEAR/NEXT filtering are entirely server-side in `.env.mcx-alerts`.

## Compose operation

`docker-compose.yml` defines `mcx_zone_monitor` and `mcx_zone_delivery` with `restart: always`. Copy `.env.mcx-alerts.example` to an ignored `.env.mcx-alerts` on the host, provide the VAPID/Redis values, and make the worker image include `pywebpush` and `redis` packages. Run `docker compose up -d mcx_zone_monitor mcx_zone_delivery` after applying the migration. Both workers restore from MySQL and unique constraints prevent restart duplicates.

## Discord webhook delivery

Discord is an optional shared delivery channel. The monitor and CSV refresh do
not call Discord: they first persist a canonical `mcx_zone_alert_events` row,
then atomically add one `mcx_zone_discord_deliveries` outbox row when the
central Discord filter matches. The existing `mcx_zone_delivery` service sends
that row, so there is no additional FYERS subscription, CSV scheduler, or
zone-calculation implementation.

Set `DISCORD_ALERTS_ENABLED=false` by default. To enable a controlled rollout,
set it to `true`, configure `DISCORD_WEBHOOK_URL` only in the ignored runtime
environment file, and explicitly configure `DISCORD_ALERT_INSTRUMENTS` and
`DISCORD_ALERT_EVENT_TYPES`. Default Discord timeframes are `Weekly,Daily,240,120,60`
(aliases for the internal `weekly,daily,two_forty,one_twenty,sixty`). Default
contract classifications are `NEAR,NEXT`, so FAR contracts are excluded.
Optional filters are `DISCORD_ALERT_TIMEFRAMES`, `DISCORD_ALERT_ZONE_TYPES`,
`DISCORD_ALERT_CONTRACTS` (`SYMBOL@YYYY-MM-DD`), `DISCORD_ALERT_CONTRACT_CLASSIFICATIONS`,
and `DISCORD_ALERT_MIN_PRIORITY` (`INFO`, `IMPORTANT`, `HIGH`). `DISCORD_ALERT_THREAD_ID`
supports a forum/media thread. `PREDIXA_MCX_CHART_URL` controls the deep-link
base. The raw webhook URL is never exposed through an API, browser, database,
or logs.

The worker uses Discord embeds with `allowed_mentions: {parse: []}`. A unique
key on `(event_id, destination_hash, channel)` prevents repeated ticks or a
worker restart from reposting the same canonical event. HTTP 429 honors
`Retry-After`; 5xx responses use bounded exponential backoff; 401/403/404 are
permanent failures. A socket timeout is marked `UNCERTAIN` rather than retried
automatically, because Discord may already have created the message. Operators
can inspect that state before manual retry, avoiding an unsupported exactly-once
claim for an external HTTP API.

For local PM2 operation, source the ignored `.env.mcx-alerts` in each worker's
shell command. `mcx_zone_delivery_worker.py` runs Discord-only when VAPID keys
or `pywebpush` are absent; existing Web Push delivery activates automatically
when its VAPID settings are present. Set `MCX_ZONE_TIMEFRAMES=Weekly,Daily,240,120,60`
to publish the existing Daily/Weekly/240/120/60 chart zones after each complete
CSV batch.

Before enabling production fanout, run the mocked tests and use an authorized
test webhook with a synthetic event in an isolated database/Redis environment.
Confirm one returned Discord message ID and verify a replay does not create a
second row. If a webhook is compromised, delete/rotate it in Discord, update
only the runtime `DISCORD_WEBHOOK_URL`, leave the old destination's pending
rows failed for audit, and restart `mcx_zone_delivery`.

## Manual verification

Create a subscription for an exact MCX expiry, run the post-refresh hook, and confirm `NEW_ZONE` events/delivery records. Publish a synthetic fresh tick to the contract Redis channel outside then inside a persisted zone: exactly one `ZONE_ENTERED` and one in-app delivery must appear. Re-publish it repeatedly (no duplicates), publish outside beyond hysteresis then inside (one new entry), and inspect the browser click URL for the same expiry/timeframe.
