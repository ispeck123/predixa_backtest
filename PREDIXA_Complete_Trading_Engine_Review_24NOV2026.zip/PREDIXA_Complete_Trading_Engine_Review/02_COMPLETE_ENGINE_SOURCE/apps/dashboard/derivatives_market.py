"""Single-contract Futures/Commodity live-price WebSocket for Dashboard :9000."""
import asyncio
import contextlib
import csv
import json
import logging
import os
import uuid
from datetime import datetime
from html import escape
from pathlib import Path

import redis.asyncio as redis
from fastapi import APIRouter, WebSocket
from fastapi.responses import HTMLResponse
from starlette.websockets import WebSocketDisconnect

from shared.db.dbconn import DBConnection
from shared.config.settings import stock_data_dir_config, stock_logic_config
from shared.market_data_symbols import (
    DYNAMIC_CONTROL_CHANNEL,
    DYNAMIC_REQUEST_PREFIX,
    resolve_derivative_contract,
)

router = APIRouter()
log = logging.getLogger("ws.derivatives")
db = DBConnection()
r = redis.from_url(
    os.getenv("REDIS_URL", "redis://localhost:6379/0"),
    encoding="utf-8",
    decode_responses=True,
    health_check_interval=30,
    socket_connect_timeout=5,
    socket_timeout=5,
)
LEASE_SECONDS = max(30, int(os.getenv("DERIVATIVE_WS_LEASE_SECONDS", "90")))

def configured_timeframes() -> tuple[str, ...]:
    """Read the currently configured derivative timeframe names from settings."""
    frames = set()
    for name, value in vars(stock_logic_config).items():
        if name.startswith(("FUTURE_TIME_FRAME_", "COMMODITY_TIME_FRAME_")) and isinstance(value, (list, tuple, set)):
            frames.update(str(frame).strip().lower() for frame in value if str(frame).strip())
    return tuple(sorted(frames))


def redis_key(segment, symbol):
    return f"market:{segment}:latest:{symbol}"


def redis_channel(segment, symbol):
    return f"market:{segment}:ticks:{symbol}"


def _number(value):
    """Return a numeric CSV/tick value, or ``None`` for absent/malformed data."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def load_latest_candle(contract: dict, timeframe: str) -> dict | None:
    """Load the latest persisted OHLC candle for the requested derivative.

    FYERS' DataSocket ``open_price`` is the *trading-session* open, not the
    caller's selected chart timeframe.  The dashboard's established derivative
    CSVs are the source of truth for timeframe-specific candle opens.
    """
    base_symbol = contract.get("base_symbol")
    if not base_symbol:
        # An exact FYERS identifier has no reliable reversible base-symbol
        # format.  It can still stream live data, just without a local candle.
        return None
    try:
        expiry = datetime.strptime(contract["expiry_date"], "%Y-%m-%d")
    except (KeyError, TypeError, ValueError):
        return None
    root = (stock_data_dir_config.indian_commodity_data
            if contract["segment"] == "commodity"
            else stock_data_dir_config.indian_stock_future_data_dir)
    path = Path(root) / "latest_data_csv" / f"{base_symbol}_{expiry:%d%m%Y}_{timeframe}.csv"
    try:
        with path.open(newline="", encoding="utf-8") as source:
            rows = csv.DictReader(source)
            latest = None
            for row in rows:
                values = {name: _number(row.get(name)) for name in ("open", "high", "low", "close")}
                if all(value is not None for value in values.values()):
                    latest = {**values, "candle_timestamp": row.get("tradeDate")}
            return latest
    except OSError:
        log.info("No local %s candle file for %s (%s)", timeframe, contract["symbol"], path)
        return None


def apply_timeframe_candle(tick: dict, candle: dict | None) -> dict:
    """Expose timeframe OHLC and retain FYERS' session fields without mixing them."""
    result = dict(tick)
    if not candle:
        return result
    # Preserve the upstream session values explicitly.  Consumers asking for a
    # timeframe must never mistake these for candle values again.
    result["day_open"] = result.get("open")
    result["day_high"] = result.get("high")
    result["day_low"] = result.get("low")
    ltp = _number(result.get("ltp"))
    if ltp is not None:
        candle["high"] = max(candle["high"], ltp)
        candle["low"] = min(candle["low"], ltp)
        candle["close"] = ltp
    result.update(candle)
    return result


@router.get("/futures_commodity_live_price", response_class=HTMLResponse)
async def futures_commodity_live_price_page():
    """Small manual test page for the Dashboard derivative WebSocket."""
    timeframe_options = "".join(
        f'<option value="{escape(frame)}">{escape(frame)}</option>' for frame in configured_timeframes())
    return HTMLResponse("""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>MCX / Futures Live Price</title>
  <style>
    body { max-width: 900px; margin: 32px auto; padding: 0 18px; font: 15px system-ui, sans-serif; color: #172033; }
    form { display: flex; flex-wrap: wrap; align-items: end; gap: 12px; padding: 18px; background: #f3f6fa; border-radius: 10px; }
    label { display: grid; gap: 5px; font-weight: 600; } input, button { padding: 9px; font: inherit; } button { cursor: pointer; background: #1463d9; color: white; border: 0; border-radius: 5px; }
    #status { margin: 18px 0; font-weight: 600; } .connected { color: #117a36; } .error { color: #b42318; }
    table { width: 100%; border-collapse: collapse; } th, td { border-bottom: 1px solid #dce2ea; padding: 10px; text-align: left; } th { width: 35%; color: #566275; }
    pre { background: #101828; color: #d0d5dd; padding: 14px; border-radius: 8px; overflow: auto; }
  </style>
</head>
<body>
  <h1>Futures / Commodity Live Price</h1>
  <p>Use a base product (for example <code>GOLDPETAL</code>) or an exact FYERS contract. This page connects to the Dashboard WebSocket on this same host.</p>
  <form id="market-form">
    <label>Symbol<input id="symbol" required value="GOLDPETAL" autocomplete="off"></label>
    <label>Expiry<input id="expiry" required type="date" value="2026-10-30"></label>
    <label>Timeframe<select id="timeframe" required>__TIMEFRAME_OPTIONS__</select></label>
    <button type="submit">Connect</button><button type="button" id="disconnect">Disconnect</button>
  </form>
  <div id="status">Disconnected</div>
  <table><tbody id="price"><tr><th>Waiting for live data</th><td>—</td></tr></tbody></table>
  <h2>Last message</h2><pre id="message">No message received.</pre>
  <script>
    let socket;
    const status = document.getElementById('status');
    const message = document.getElementById('message');
    const price = document.getElementById('price');
    const setStatus = (text, kind = '') => { status.textContent = text; status.className = kind; };
    const render = (data) => {
      const tick = data.data || data;
      const fields = ['symbol', 'segment', 'ltp', 'previous_close', 'change', 'change_percent', 'open', 'high', 'low', 'close', 'candle_timestamp', 'day_open', 'day_high', 'day_low', 'volume', 'open_interest', 'exchange_timestamp', 'received_at'];
      price.replaceChildren(...fields.filter(key => tick[key] !== undefined).map(key => {
        const row = document.createElement('tr'), heading = document.createElement('th'), value = document.createElement('td');
        heading.textContent = key; value.textContent = tick[key] ?? '—'; row.append(heading, value); return row;
      }));
    };
    document.getElementById('market-form').addEventListener('submit', (event) => {
      event.preventDefault();
      if (socket) socket.close();
      const params = new URLSearchParams({ symbol: symbol.value.trim(), expiry: expiry.value, timeframe: timeframe.value.trim() });
      const protocol = location.protocol === 'https:' ? 'wss' : 'ws';
      socket = new WebSocket(`${protocol}://${location.host}/ws/futures_commodity_live_price?${params}`);
      setStatus('Connecting…');
      socket.onopen = () => setStatus('Connected — waiting for subscription acknowledgement', 'connected');
      socket.onmessage = (event) => {
        const data = JSON.parse(event.data); message.textContent = JSON.stringify(data, null, 2);
        if (data.type === 'error') setStatus(`${data.code}: ${data.message}`, 'error');
        else { setStatus(`Connected — ${data.type}`, 'connected'); if (data.type !== 'subscription_ack') render(data); }
      };
      socket.onerror = () => setStatus('WebSocket connection error', 'error');
      socket.onclose = () => { if (!status.classList.contains('error')) setStatus('Disconnected'); };
    });
    document.getElementById('disconnect').onclick = () => socket?.close();
  </script>
</body>
</html>""".replace("__TIMEFRAME_OPTIONS__", timeframe_options))


@router.websocket("/ws/futures_commodity_live_price")
async def futures_commodity_live_price(websocket: WebSocket, symbol: str, expiry: str, timeframe: str):
    """Stream one contract requested as symbol, expiry, and timeframe only.

    ``timeframe`` associates the tick to its caller's active chart timeframe;
    it never creates a separate FYERS upstream subscription.
    """
    timeframe = (timeframe or "").strip().lower()
    await websocket.accept()
    available_timeframes = configured_timeframes()
    if timeframe not in available_timeframes:
        await websocket.send_json({"type": "error", "code": "INVALID_TIMEFRAME",
                                   "message": f"timeframe must be one of {list(available_timeframes)}"})
        await websocket.close(code=1008)
        return
    try:
        contract = resolve_derivative_contract(db, symbol, expiry)
    except ValueError as exc:
        await websocket.send_json({"type": "error", "code": "INVALID_CONTRACT", "message": str(exc)})
        await websocket.close(code=1008)
        return

    lease_key = f"{DYNAMIC_REQUEST_PREFIX}{uuid.uuid4().hex}"
    pubsub = None
    try:
        await r.hset(lease_key, mapping={**contract, "timeframe": timeframe})
        await r.expire(lease_key, LEASE_SECONDS)
        await r.publish(DYNAMIC_CONTROL_CHANNEL, "refresh")
        pubsub = r.pubsub()
        await pubsub.subscribe(redis_channel(contract["segment"], contract["symbol"]))
        snapshot = await r.hgetall(redis_key(contract["segment"], contract["symbol"]))
        await websocket.send_json({"type": "subscription_ack", "symbol": contract["symbol"],
                                   "segment": contract["segment"], "expiry": contract["expiry_date"],
                                   "timeframe": timeframe})
        candle = load_latest_candle(contract, timeframe)
        if snapshot:
            await websocket.send_json({"type": "market_snapshot", "symbol": contract["symbol"],
                                       "segment": contract["segment"], "timeframe": timeframe,
                                       "data": apply_timeframe_candle(snapshot, candle)})

        async def renew_lease():
            while True:
                await asyncio.sleep(LEASE_SECONDS // 2)
                await r.expire(lease_key, LEASE_SECONDS)

        async def relay_ticks():
            async for message in pubsub.listen():
                if message.get("type") != "message":
                    continue
                try:
                    tick = json.loads(message["data"])
                    await websocket.send_json({"type": "market_tick", "timeframe": timeframe,
                                               **apply_timeframe_candle(tick, candle)})
                except (TypeError, ValueError):
                    log.warning("Ignoring malformed derivative tick")

        async def wait_for_disconnect():
            while True:
                message = await websocket.receive()
                if message.get("type") == "websocket.disconnect":
                    return

        renewal = asyncio.create_task(renew_lease())
        relay = asyncio.create_task(relay_ticks())
        disconnect = asyncio.create_task(wait_for_disconnect())
        try:
            await asyncio.wait((relay, disconnect), return_when=asyncio.FIRST_COMPLETED)
        finally:
            for task in (renewal, relay, disconnect):
                task.cancel()
            for task in (renewal, relay, disconnect):
                with contextlib.suppress(asyncio.CancelledError, WebSocketDisconnect):
                    await task
    except redis.RedisError:
        log.exception("Derivative WebSocket Redis operation failed")
        with contextlib.suppress(Exception):
            await websocket.send_json({"type": "error", "code": "MARKET_DATA_UNAVAILABLE",
                                       "message": "live market data is temporarily unavailable"})
            await websocket.close(code=1013)
    except WebSocketDisconnect:
        pass
    finally:
        if pubsub is not None:
            with contextlib.suppress(Exception):
                await pubsub.unsubscribe()
            with contextlib.suppress(Exception):
                await pubsub.aclose()
        with contextlib.suppress(Exception):
            await r.delete(lease_key)
            await r.publish(DYNAMIC_CONTROL_CHANNEL, "refresh")
