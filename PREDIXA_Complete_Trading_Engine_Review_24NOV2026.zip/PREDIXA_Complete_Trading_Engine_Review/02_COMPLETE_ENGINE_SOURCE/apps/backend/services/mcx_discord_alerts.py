"""Discord adapter for canonical MCX zone-alert events.

This module deliberately has no Redis, database, or Discord bot dependency.
The monitor calls :func:`matches` before atomically writing a shared outbox
record; the delivery worker uses the formatter and response classification.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from urllib.parse import urlencode
from zoneinfo import ZoneInfo


def _csv(name: str) -> set[str]:
    return {part.strip().upper() for part in os.getenv(name, "").split(",") if part.strip()}


def _timeframes(name: str) -> set[str]:
    aliases = {"WEEKLY": "WEEKLY", "DAILY": "DAILY", "240": "TWO_FORTY", "TWO_FORTY": "TWO_FORTY",
               "4H": "TWO_FORTY", "120": "ONE_TWENTY", "ONE_TWENTY": "ONE_TWENTY",
               "60": "SIXTY", "SIXTY": "SIXTY"}
    return {aliases.get(part, part) for part in _csv(name)}


def _enabled(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


_PRIORITY = {
    "NEW_ZONE": 1, "ZONE_MODIFIED": 1, "ZONE_REMOVED": 1,
    "APPROACHING_ZONE": 2,
    "ZONE_ENTERED": 3, "ZONE_BROKEN": 3, "MULTI_TIMEFRAME_CONFLUENCE": 3,
}


@dataclass(frozen=True)
class DiscordSettings:
    enabled: bool
    webhook_url: str
    instruments: set[str]
    timeframes: set[str]
    event_types: set[str]
    zone_types: set[str]
    contracts: set[str]
    contract_classifications: set[str]
    min_priority: int
    username: str
    thread_id: str
    chart_url: str

    @property
    def destination_hash(self) -> str:
        # Never persist or log the webhook itself; its hash differentiates a
        # rotated destination and participates in the uniqueness fence.
        return hashlib.sha256(f"{self.webhook_url}|{self.thread_id}".encode()).hexdigest()

    @classmethod
    def from_env(cls) -> "DiscordSettings":
        priority = {"INFO": 1, "INFORMATIONAL": 1, "IMPORTANT": 2, "HIGH": 3}
        return cls(
            enabled=_enabled(os.getenv("DISCORD_ALERTS_ENABLED")),
            webhook_url=os.getenv("DISCORD_WEBHOOK_URL", "").strip(),
            instruments=_csv("DISCORD_ALERT_INSTRUMENTS"),
            timeframes=_timeframes("DISCORD_ALERT_TIMEFRAMES"),
            event_types=_csv("DISCORD_ALERT_EVENT_TYPES"),
            zone_types=_csv("DISCORD_ALERT_ZONE_TYPES"),
            contracts=_csv("DISCORD_ALERT_CONTRACTS"),
            contract_classifications=_csv("DISCORD_ALERT_CONTRACT_CLASSIFICATIONS"),
            min_priority=priority.get(os.getenv("DISCORD_ALERT_MIN_PRIORITY", "INFO").strip().upper(), 1),
            username=os.getenv("DISCORD_WEBHOOK_USERNAME", "REVIEW_REDACTED").strip()[:80] or "REVIEW_REDACTED",
            thread_id=os.getenv("DISCORD_ALERT_THREAD_ID", "").strip(),
            chart_url=os.getenv("PREDIXA_MCX_CHART_URL", "https://predixa.markets/mcx").strip(),
        )


def matches(settings: DiscordSettings, *, instrument: str, expiry: str, timeframe: str, zone_type: str, event_type: str,
            contract_classification: str | None = None) -> bool:
    """Return whether one canonical event should be broadcast once.

    An enabled webhook still fails closed unless a URL and explicit event types
    are configured.  This prevents an accidental all-contract broadcast.
    """
    instrument, timeframe, zone_type, event_type = instrument.upper(), timeframe.upper(), zone_type.upper(), event_type.upper()
    contract = f"{instrument}@{expiry}".upper()
    return bool(
        settings.enabled and settings.webhook_url and settings.instruments and settings.event_types
        and instrument in settings.instruments
        and event_type in settings.event_types
        and (not settings.timeframes or timeframe in settings.timeframes)
        and (not settings.zone_types or zone_type in settings.zone_types)
        and (not settings.contracts or contract in settings.contracts)
        and (not settings.contract_classifications or str(contract_classification or "").upper() in settings.contract_classifications)
        and _PRIORITY.get(event_type, 1) >= settings.min_priority
    )


def _price(value: Any, tick_size: Any = None) -> str:
    value = Decimal(str(value))
    try:
        tick = Decimal(str(tick_size))
        places = max(0, -tick.as_tuple().exponent)
    except Exception:
        places = max(0, -value.as_tuple().exponent)
    return f"₹{value:,.{places}f}"


def _as_payload(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else json.loads(value or "{}")


def discord_payload(event: dict[str, Any], settings: DiscordSettings) -> dict[str, Any]:
    """Build a mention-safe Discord webhook payload from one persisted event."""
    extra = _as_payload(event.get("payload"))
    side = str(event["zone_type"]).upper()
    kind = str(event["event_type"]).upper()
    timeframe = str(event["timeframe"]).upper()
    tick = extra.get("tick_size")
    lower, upper, ltp = extra.get("lower"), extra.get("upper"), event.get("ltp")
    detected = event.get("detected_at") or datetime.now(timezone.utc)
    if isinstance(detected, str):
        detected = datetime.fromisoformat(detected.replace("Z", "+00:00"))
    if detected.tzinfo is None:
        detected = detected.replace(tzinfo=timezone.utc)
    ist = detected.astimezone(ZoneInfo("Asia/Kolkata"))
    query = urlencode({"symbol": event["instrument"], "expiry": event["contract_expiry"], "timeframe": str(event["timeframe"]),
                       "zone": event["zone_id"], "event": event.get("event_key", event.get("id", ""))})
    chart = f"{settings.chart_url}?{query}"
    if kind == "APPROACHING_ZONE": explanation = "Live price has entered the configured approach distance outside this institutional zone."
    elif kind == "ZONE_ENTERED": explanation = "Live price has entered this institutional zone."
    elif kind == "ZONE_MODIFIED": explanation = "The authoritative CSV refresh materially changed this zone."
    elif kind in {"NEW_ZONE", "ZONE_REMOVED"}: explanation = "The authoritative CSV refresh updated the institutional-zone snapshot."
    else: explanation = "A canonical MCX institutional-zone event was confirmed."
    color = 0xF59E0B if kind == "APPROACHING_ZONE" else (0x22C55E if side == "BUY" else 0xEF4444)
    if kind in {"NEW_ZONE", "ZONE_MODIFIED", "ZONE_REMOVED"}: color = 0x3B82F6
    classification = str(extra.get("contract_classification") or "").upper()
    contract_label = f"{event['instrument']} · {event['contract_expiry']}" + (f" · {classification}" if classification else "")
    fields = [
        {"name": "Instrument", "value": contract_label, "inline": True},
        {"name": "Timeframe", "value": timeframe.title(), "inline": True},
        {"name": "Event", "value": kind, "inline": True},
        {"name": f"{side.title()} Zone", "value": f"{_price(lower, tick)} – {_price(upper, tick)}", "inline": True},
        {"name": "Live Price", "value": _price(ltp, tick) if ltp is not None else "Not applicable", "inline": True},
        {"name": "Time", "value": ist.strftime("%d-%m-%Y %H:%M:%S IST"), "inline": True},
        {"name": "Chart", "value": f"[Open MCX chart]({chart})", "inline": False},
    ]
    return {"username": settings.username, "allowed_mentions": {"parse": []}, "embeds": [{
        "title": f"{event['instrument']} — {timeframe} {side} ZONE {kind}", "description": explanation,
        "color": color, "fields": fields, "timestamp": detected.astimezone(timezone.utc).isoformat(),
        "footer": {"text": "REVIEW_REDACTED · Informational, not a trade recommendation"},
    }]}


@dataclass(frozen=True)
class DispatchDecision:
    status: str
    retry_seconds: int | None = None
    message_id: str | None = None
    error: str | None = None


def classify_response(status: int | None, headers: dict[str, str] | None = None, body: Any = None, *, timeout: bool = False, attempts: int = 1) -> DispatchDecision:
    """Classify Discord outcomes without leaking a webhook URL or response body."""
    if timeout:
        # The webhook may have accepted the body before TCP timed out.  Do not
        # blindly retry an uncertain send and create a duplicate external post.
        return DispatchDecision("UNCERTAIN", error="network timeout; delivery outcome is unknown")
    headers = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    if status is not None and 200 <= status < 300:
        message_id = body.get("id") if isinstance(body, dict) else None
        return DispatchDecision("DELIVERED", message_id=str(message_id) if message_id else None)
    if status == 429:
        retry = headers.get("retry-after")
        if retry is None and isinstance(body, dict): retry = body.get("retry_after")
        try: delay = max(1, min(3600, math.ceil(float(retry))))
        except (TypeError, ValueError): delay = min(3600, 2 ** min(attempts, 10))
        return DispatchDecision("PENDING", delay, error="Discord rate limit")
    if status in {401, 403, 404}:
        return DispatchDecision("FAILED", error=f"Discord permanent HTTP {status}")
    if status is None or status >= 500:
        delay = min(3600, 2 ** min(attempts, 10))
        return DispatchDecision("FAILED" if attempts >= 8 else "PENDING", delay, error=f"Discord temporary HTTP {status or 'network'}")
    return DispatchDecision("FAILED", error=f"Discord HTTP {status}")
