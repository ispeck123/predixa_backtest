"""MCX institutional-zone alert domain service.

This module deliberately has no browser dependency.  It is used by the Redis
consumer and by the CSV post-refresh hook, so the same canonical zones that
the chart API produces are monitored when no user has a chart open.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable


class ZoneState(str, Enum):
    OUTSIDE = "OUTSIDE"
    APPROACHING = "APPROACHING"
    INSIDE = "INSIDE"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def price(value: float | Decimal, tick_size: float) -> Decimal:
    """Canonicalise a boundary to the verified contract tick, never binary float."""
    tick = Decimal(str(tick_size or 0.01))
    return (Decimal(str(value)) / tick).quantize(Decimal("1"), ROUND_HALF_UP) * tick


def signature(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class CanonicalZone:
    instrument: str
    expiry: str
    timeframe: str
    side: str
    lower: Decimal
    upper: Decimal
    provenance: str = "institutional-zone"
    origin: str = ""
    tick_size: Decimal = Decimal("0.01")

    @property
    def logical_id(self) -> str:
        # Origin is supplied by the existing Zone object's zone_id / creation
        # timestamp when available; boundaries are intentionally excluded.
        return signature({"exchange": "MCX", "instrument": self.instrument, "expiry": self.expiry,
                          "timeframe": self.timeframe, "side": self.side, "origin": self.origin or self.provenance})[:40]

    @property
    def revision(self) -> str:
        return signature({"logical_id": self.logical_id, "lower": str(self.lower), "upper": str(self.upper),
                          "provenance": self.provenance})

    @classmethod
    def make(cls, *, instrument: str, expiry: str, timeframe: str, side: str,
             lower: float, upper: float, tick_size: float = .01, provenance: str = "institutional-zone", origin: str = ""):
        lo, hi = price(lower, tick_size), price(upper, tick_size)
        return cls(instrument.upper(), expiry, timeframe.lower(), side.upper(), min(lo, hi), max(lo, hi), provenance, origin, Decimal(str(tick_size)))


@dataclass
class AlertTransition:
    event_type: str
    zone: CanonicalZone
    ltp: Decimal
    state: ZoneState


class StatefulDetector:
    """Pure, persistable OUTSIDE -> APPROACHING -> INSIDE transition machine."""
    def __init__(self, state: ZoneState = ZoneState.OUTSIDE, *, hysteresis_ticks: int = 1):
        self.state = state
        self.hysteresis_ticks = hysteresis_ticks

    def evaluate(self, zone: CanonicalZone, ltp: float, approach_ticks: int = 4) -> list[AlertTransition]:
        ltp_d = price(ltp, float(zone.tick_size))
        hysteresis = zone.tick_size * self.hysteresis_ticks
        proximity = zone.tick_size * max(0, approach_ticks)
        inside = zone.lower <= ltp_d <= zone.upper
        approaching = (zone.lower - proximity <= ltp_d < zone.lower or zone.upper < ltp_d <= zone.upper + proximity)
        events: list[AlertTransition] = []
        old = self.state
        if inside:
            if old != ZoneState.INSIDE:
                # Direct outside -> inside (including a gap) is an entry, not
                # two synthetic events.
                events.append(AlertTransition("ZONE_ENTERED", zone, ltp_d, ZoneState.INSIDE))
            self.state = ZoneState.INSIDE
        elif old == ZoneState.INSIDE:
            # Require the price to clear a tick outside to prevent edge spam.
            if ltp_d < zone.lower - hysteresis or ltp_d > zone.upper + hysteresis:
                self.state = ZoneState.APPROACHING if approaching else ZoneState.OUTSIDE
                events.append(AlertTransition("ZONE_EXITED", zone, ltp_d, self.state))
        elif approaching:
            if old == ZoneState.OUTSIDE:
                events.append(AlertTransition("APPROACHING_ZONE", zone, ltp_d, ZoneState.APPROACHING))
            self.state = ZoneState.APPROACHING
        elif old == ZoneState.APPROACHING:
            # Reset only once it clears the wider approach band plus hysteresis.
            if ltp_d < zone.lower - proximity - hysteresis or ltp_d > zone.upper + proximity + hysteresis:
                self.state = ZoneState.OUTSIDE
        return events


def diff_snapshots(previous: Iterable[CanonicalZone], current: Iterable[CanonicalZone]) -> list[tuple[str, CanonicalZone]]:
    """Return NEW/MODIFIED/REMOVED without cross-contract/timeframe matching."""
    before = {z.logical_id: z for z in previous}
    after = {z.logical_id: z for z in current}
    result = []
    for key, zone in after.items():
        if key not in before:
            result.append(("NEW_ZONE", zone))
        elif before[key].revision != zone.revision:
            result.append(("ZONE_MODIFIED", zone))
    for key, zone in before.items():
        if key not in after:
            result.append(("ZONE_REMOVED", zone))
    return result


def confluences(zones: Iterable[CanonicalZone]) -> list[CanonicalZone]:
    """Daily/weekly overlap only; callers may emit a dedicated event from this."""
    zones = list(zones)
    return [a for a in zones for b in zones if a is not b and {a.timeframe, b.timeframe} == {"daily", "weekly"}
            and a.side == b.side and max(a.lower, b.lower) <= min(a.upper, b.upper)]
