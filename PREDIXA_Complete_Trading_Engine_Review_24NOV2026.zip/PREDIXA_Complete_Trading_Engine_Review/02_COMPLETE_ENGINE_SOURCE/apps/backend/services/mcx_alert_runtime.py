"""Runtime configuration support shared by locally supervised MCX workers."""
from __future__ import annotations

import os
from pathlib import Path


def load_mcx_alert_env() -> None:
    """Load the ignored local alert environment without overriding supervisor env.

    Docker Compose already injects these settings.  PM2 does not, so local
    workers load `.env.mcx-alerts` from the repository root by default.  This
    intentionally implements only `KEY=value` lines and never logs values.
    """
    configured = os.getenv("MCX_ALERT_ENV_FILE")
    path = Path(configured) if configured else Path(__file__).resolve().parents[3] / ".env.mcx-alerts"
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            if key:
                os.environ.setdefault(key, value.strip())
    except FileNotFoundError:
        pass
