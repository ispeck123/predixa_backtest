/* Kept separate from existing PWA workers; register this explicit scope only. */
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  event.waitUntil(self.registration.showNotification(data.title || 'MCX zone alert', {
    body: data.body || '', data: {url: data.url || '/'}, tag: data.eventId || undefined,
    renotify: false, requireInteraction: data.priority === 'high'
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.openWindow(event.notification.data.url));
});
