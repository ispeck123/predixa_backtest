# MCX Phase-1 status

- Task 1 E1: COMPLETE and regression-tested.
- Task 2: PARTIALLY_COMPLETED — provenance auditor and partial dated-source registry produced; no verified roll pairs.
- Task 3: BLOCKED — no roll-correct authoritative source bundle.
- Task 4: BLOCKED — no authoritative realized-R export or approved complete split/policy.

MCX PAPER and REAL remain OFF.
