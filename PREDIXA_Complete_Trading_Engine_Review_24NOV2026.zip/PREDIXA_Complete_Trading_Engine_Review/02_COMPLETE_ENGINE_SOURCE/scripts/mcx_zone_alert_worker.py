#!/usr/bin/env python3
"""Single logical MCX monitor worker; run one or more instances safely.

It consumes the *already shared* FYERS Redis stream.  MySQL's unique event key
is the concurrency fence, therefore duplicate Pub/Sub delivery or two workers
cannot create two market events.  Refreshes are invoked by the updater after a
successful atomic CSV batch via ``mcx_zone_refresh.py``.
"""
from __future__ import annotations
import json, logging, os, time
from datetime import datetime, timezone
from decimal import Decimal
import redis
from sqlalchemy import text
from apps.backend.services.mcx_alert_runtime import load_mcx_alert_env
from apps.backend.services.mcx_zone_alerts import CanonicalZone, StatefulDetector, ZoneState, signature
from apps.backend.services.mcx_discord_alerts import DiscordSettings, matches as discord_matches
from shared.db.dbconn import DBConnection

log = logging.getLogger("mcx.zone-alert-worker")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
load_mcx_alert_env()

class Worker:
    def __init__(self, client=None, database=None):
        self.redis = client or redis.Redis.from_url(os.getenv("REDIS_URL", "redis://localhost:6379/0"), decode_responses=True)
        self.db = database or DBConnection()
        # A restarted subscriber can briefly receive ticks which were already
        # waiting in its socket buffer.  Those are deliberately ignored by
        # the freshness fence below.  Keep a small per-symbol diagnostic gate
        # so expected old-cache traffic never turns into an error-log storm.
        self._stale_log_at = {}

    def _zones(self, provider_symbol: str):
        # provenance.provider_symbol is written by refresh.  Exact provider
        # symbol means GOLDM near/next never share a price/state.  Only
        # snapshots emitted by the active-zone adapter are eligible: legacy
        # broad/all-zone snapshots must never produce a false alert.
        sql = text("""SELECT * FROM mcx_zone_snapshots WHERE status='ACTIVE'
          AND JSON_UNQUOTE(JSON_EXTRACT(provenance,'$.provider_symbol'))=:symbol
          AND JSON_UNQUOTE(JSON_EXTRACT(provenance,'$.alert_eligible'))='true'
          AND version=(SELECT MAX(s2.version) FROM mcx_zone_snapshots s2 WHERE s2.instrument=mcx_zone_snapshots.instrument AND s2.contract_expiry=mcx_zone_snapshots.contract_expiry)""")
        with self.db.engine.connect() as c: return [dict(r._mapping) for r in c.execute(sql, {"symbol":provider_symbol})]

    def process(self, tick: dict):
        ltp, symbol = tick.get("ltp"), tick.get("symbol")
        if ltp is None or not symbol: return
        received = int(tick.get("received_at") or 0)
        if received and (datetime.now(timezone.utc).timestamp()*1000 - received) > int(os.getenv("MCX_ALERT_STALE_MS", "30000")):
            now_monotonic = time.monotonic()
            previous = self._stale_log_at.get(symbol, 0.0)
            if now_monotonic - previous >= 300:
                self._stale_log_at[symbol] = now_monotonic
                log.debug("stale tick ignored symbol=%s", symbol)
            return
        for row in self._zones(symbol):
            provenance = row.get("provenance") or {}
            if isinstance(provenance, str): provenance = json.loads(provenance)
            zone = CanonicalZone.make(instrument=row["instrument"], expiry=str(row["contract_expiry"]), timeframe=row["timeframe"],
                side=row["zone_type"], lower=float(row["lower_boundary"]), upper=float(row["upper_boundary"]),
                tick_size=float(provenance.get("tick_size") or .01), provenance=json.dumps(provenance, sort_keys=True), origin=provenance.get("origin", row["zone_id"]))
            self._process_zone(zone, row, float(ltp), tick)

    def reevaluate_latest(self, contracts: list[dict]):
        """Evaluate the cached fresh LTP immediately after snapshot publish.

        Pub/Sub does not replay a tick merely because zones changed.  Reading
        the existing shared latest hash closes that gap without adding a market
        data subscription.  ``process`` retains the stale-data fence.
        """
        for contract in contracts or []:
            symbol = contract.get("provider_symbol")
            if not symbol:
                continue
            try:
                tick = self.redis.hgetall(f"market:commodity:latest:{symbol}")
                if tick:
                    self.process(tick)
            except Exception:
                log.exception("post-refresh latest-LTP evaluation failed symbol=%s", symbol)

    def _process_zone(self, zone, row, ltp, tick):
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        with self.db.engine.begin() as c:
            state_row = c.execute(text("SELECT * FROM mcx_zone_event_state WHERE zone_id=:z AND revision_signature=:r AND contract_expiry=:e FOR UPDATE"),
                                  {"z":zone.logical_id,"r":zone.revision,"e":zone.expiry}).mappings().first()
            detector = StatefulDetector(ZoneState(state_row["state"]) if state_row else ZoneState.OUTSIDE)
            transitions = detector.evaluate(zone, ltp, int(os.getenv("MCX_ZONE_APPROACH_TICKS", "4")))
            c.execute(text("""INSERT INTO mcx_zone_event_state(zone_id,revision_signature,contract_expiry,state,last_ltp,last_tick_at,updated_at)
              VALUES(:z,:r,:e,:s,:p,:n,:n) ON DUPLICATE KEY UPDATE state=VALUES(state),last_ltp=VALUES(last_ltp),last_tick_at=VALUES(last_tick_at),updated_at=VALUES(updated_at)"""),
              {"z":zone.logical_id,"r":zone.revision,"e":zone.expiry,"s":detector.state.value,"p":str(ltp),"n":now})
            for transition in transitions:
                # Tick timestamp and state-cycle event type form an idempotency key.
                event_key = signature({"zone":zone.logical_id,"revision":zone.revision,"type":transition.event_type,"received":tick.get("received_at"),"ltp":str(transition.ltp)})
                result = c.execute(text("""INSERT IGNORE INTO mcx_zone_alert_events(event_key,zone_id,revision_signature,instrument,contract_expiry,timeframe,zone_type,event_type,ltp,detected_at,payload)
                  VALUES(:k,:z,:r,:i,:e,:t,:side,:kind,:p,:n,:payload)"""), {"k":event_key,"z":zone.logical_id,"r":zone.revision,"i":zone.instrument,"e":zone.expiry,"t":zone.timeframe,"side":zone.side,"kind":transition.event_type,"p":str(transition.ltp),"n":now,"payload":json.dumps({"lower":str(zone.lower),"upper":str(zone.upper),"tick_size":str(zone.tick_size),"provider_symbol":tick.get("symbol")})})
                if result.rowcount: self._fanout(c, event_key, zone, transition.event_type, now)

    def _fanout(self, c, event_key, zone, event_type, now):
        event_id = c.execute(text("SELECT id FROM mcx_zone_alert_events WHERE event_key=:k"), {"k":event_key}).scalar_one()
        # Discord is the sole shared destination; no per-user fanout exists.
        settings = DiscordSettings.from_env()
        classification = self._contract_classification(zone.instrument, str(zone.expiry))
        if classification:
            c.execute(text("""UPDATE mcx_zone_alert_events
                SET payload=JSON_SET(payload, '$.contract_classification', :classification)
                WHERE id=:event_id"""), {"classification": classification, "event_id": event_id})
        if discord_matches(settings, instrument=zone.instrument, expiry=str(zone.expiry), timeframe=zone.timeframe, zone_type=zone.side, event_type=event_type, contract_classification=classification):
            c.execute(text("""INSERT IGNORE INTO mcx_zone_discord_deliveries
                (event_id,destination_hash,channel,status,attempts,available_at)
                VALUES(:event_id,:destination,'DISCORD','PENDING',0,:now)"""),
                {"event_id": event_id, "destination": settings.destination_hash, "now": now})

    @staticmethod
    def _contract_classification(instrument, expiry):
        """Resolve official NEAR/NEXT/FAR only for the optional Discord filter.

        If authoritative metadata is unavailable, a configured classification
        filter fails closed rather than broadcasting an ambiguous contract.
        """
        try:
            from scripts.mcx_instrument_metadata import active_mcx_contracts
            for index, contract in enumerate(active_mcx_contracts(instrument)[:3]):
                if str(contract["expiry"]) == str(expiry):
                    return ("NEAR", "NEXT", "FAR")[index]
        except Exception:
            log.exception("Discord contract classification unavailable instrument=%s", instrument)
        return None

    def record_snapshot_events(self, changes):
        """Persist authoritative CSV snapshot changes as canonical events.

        Snapshot events use a revision-derived key, so retried Dagster refreshes
        cannot create another Discord delivery.  It intentionally does
        not consume Redis or calculate zones.
        """
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        with self.db.engine.begin() as c:
            for event_type, zone in changes or []:
                event_key = signature({"zone": zone.logical_id, "revision": zone.revision,
                                       "type": event_type, "source": "CSV_REFRESH"})
                result = c.execute(text("""INSERT IGNORE INTO mcx_zone_alert_events
                    (event_key,zone_id,revision_signature,instrument,contract_expiry,timeframe,zone_type,event_type,ltp,detected_at,payload)
                    VALUES(:k,:z,:r,:i,:e,:t,:side,:kind,NULL,:n,:payload)"""), {
                    "k": event_key, "z": zone.logical_id, "r": zone.revision, "i": zone.instrument,
                    "e": zone.expiry, "t": zone.timeframe, "side": zone.side, "kind": event_type, "n": now,
                    "payload": json.dumps({"lower": str(zone.lower), "upper": str(zone.upper),
                                           "tick_size": str(zone.tick_size), "source": "CSV_REFRESH"})})
                if result.rowcount:
                    self._fanout(c, event_key, zone, event_type, now)

    def run(self):
        ps = self.redis.pubsub(ignore_subscribe_messages=True); ps.psubscribe("market:commodity:ticks:*")
        for message in ps.listen():
            try: self.process(json.loads(message["data"]))
            except Exception: log.exception("tick processing failed")

if __name__ == "__main__": Worker().run()
