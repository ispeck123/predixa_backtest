"""Brokerless Option-3 serial governor for approved NSEFO PAPER candidates."""
from __future__ import annotations

from datetime import datetime
from shared.db.db_model import Future_Order, OMSOrderBucketFuture

PAPER_SOURCE = "NSEFO_TIER0_PAPER"
PAPER_PENDING = "paper_pending_approval"
PAPER_ACTIVE = "paper_monitoring"
PAPER_AUTO_APPROVED = "auto_approved"
PAPER_AUTO_QUEUED = "auto_approved_waiting_serial"
TERMINAL = frozenset({"cancelled", "expired", "closed", "rejected", "success", "failed"})


def has_active_paper_position(session) -> bool:
    rows = session.query(OMSOrderBucketFuture).filter(
        OMSOrderBucketFuture.execution_mode == "PAPER",
        OMSOrderBucketFuture.candidate_source == PAPER_SOURCE,
    ).all()
    # Unapproved rows are a review queue, not simulated exposure.  Only an
    # approved/resting/open PAPER record owns the Option-3 serial slot.
    return any(str(row.order_status or "").lower() not in TERMINAL | {PAPER_PENDING}
               for row in rows)


def is_tier0_paper_provenance(*, execution_mode, candidate_source) -> bool:
    """The sole provenance allowed to bypass manual PAPER approval."""
    return (str(execution_mode or "").upper() == "PAPER"
            and str(candidate_source or "") == PAPER_SOURCE)


def auto_approve_tier0_paper_candidate(*, session, bucket, order, now_factory=datetime.now) -> dict:
    """Auto-approve only Tier-0 PAPER, preserving one-at-a-time simulation.

    A second qualifying signal is automatically approved for the serial queue,
    never converted into an active/resting simulated position until the slot is
    released. It cannot call broker code because this function only mutates
    ORM records supplied by its caller.
    """
    if not is_tier0_paper_provenance(execution_mode=bucket.execution_mode,
                                     candidate_source=bucket.candidate_source):
        raise ValueError("NSEFO_PAPER_AUTO_APPROVAL_PROVENANCE_REJECTED")
    if not is_tier0_paper_provenance(execution_mode=order.execution_mode,
                                     candidate_source=order.candidate_source):
        raise ValueError("NSEFO_PAPER_AUTO_APPROVAL_ORDER_PROVENANCE_REJECTED")
    if bucket.approval_status not in {"pending", PAPER_AUTO_QUEUED, PAPER_AUTO_APPROVED}:
        raise ValueError("NSEFO_PAPER_AUTO_APPROVAL_INVALID_STATE")
    if (bucket.approval_status == PAPER_AUTO_APPROVED
            and bucket.order_status == PAPER_ACTIVE
            and order.order_status == PAPER_ACTIVE):
        # Keep scanner retries observationally idempotent as well as
        # database-idempotent: callers always see the same active result.
        return {"status": "PAPER_AUTO_APPROVED_MONITORING", "bucket_id": bucket.bucket_id}
    active = has_active_paper_position(session)
    bucket.approval_status = PAPER_AUTO_APPROVED
    bucket.approved_by = None
    bucket.approved_at = now_factory()
    if active:
        bucket.order_status = PAPER_PENDING
        order.order_status = PAPER_PENDING
        return {"status": "PAPER_AUTO_APPROVED_QUEUED", "bucket_id": bucket.bucket_id}
    bucket.order_status = PAPER_ACTIVE
    order.order_status = PAPER_ACTIVE
    return {"status": "PAPER_AUTO_APPROVED_MONITORING", "bucket_id": bucket.bucket_id}


def promote_next_auto_approved_paper_candidate(*, session) -> dict:
    """Promote the oldest auto-approved Tier-0 record after the serial slot frees.

    This is deliberately a persistence-only reconciliation hook: it never
    creates, modifies, or cancels a broker order.  Calling it while an active
    simulated record remains is a safe no-op.
    """
    if has_active_paper_position(session):
        return {"status": "PAPER_SERIAL_SLOT_BUSY"}
    bucket = session.query(OMSOrderBucketFuture).filter(
        OMSOrderBucketFuture.execution_mode == "PAPER",
        OMSOrderBucketFuture.candidate_source == PAPER_SOURCE,
        OMSOrderBucketFuture.approval_status == PAPER_AUTO_APPROVED,
        OMSOrderBucketFuture.order_status == PAPER_PENDING,
    ).order_by(OMSOrderBucketFuture.bucket_id.asc()).first()
    if bucket is None:
        return {"status": "PAPER_AUTO_QUEUE_EMPTY"}
    order = session.query(Future_Order).filter(
        Future_Order.order_id == bucket.order_id,
        Future_Order.execution_mode == "PAPER",
        Future_Order.candidate_source == PAPER_SOURCE,
    ).first()
    if order is None:
        raise ValueError("NSEFO_PAPER_AUTO_QUEUE_ORDER_NOT_FOUND")
    bucket.order_status = PAPER_ACTIVE
    order.order_status = PAPER_ACTIVE
    return {"status": "PAPER_AUTO_APPROVED_PROMOTED", "bucket_id": bucket.bucket_id}


def approve_paper_candidate(*, bucket_id: int, approved_by: int, session_factory,
                            now_factory=datetime.now) -> dict:
    """Approve exactly one pending candidate without contacting FYERS.

    Pending candidates are intentionally not simulated resting orders.  This
    transition is the explicit per-order owner approval boundary.
    """
    session = session_factory()
    try:
        bucket = session.query(OMSOrderBucketFuture).filter(
            OMSOrderBucketFuture.bucket_id == bucket_id).first()
        if bucket is None:
            raise ValueError("NSEFO_PAPER_BUCKET_NOT_FOUND")
        if bucket.execution_mode != "PAPER" or bucket.candidate_source != PAPER_SOURCE:
            raise ValueError("NSEFO_PAPER_PROVENANCE_REJECTED")
        if bucket.approval_status != "pending" or bucket.order_status != PAPER_PENDING:
            raise ValueError("NSEFO_PAPER_NOT_PENDING_APPROVAL")
        if has_active_paper_position(session):
            raise ValueError("NSEFO_PAPER_OPTION3_SERIAL_LOCKED")
        bucket.approval_status = "approved"
        bucket.approved_by = int(approved_by)
        bucket.approved_at = now_factory()
        bucket.order_status = PAPER_ACTIVE
        order = session.query(Future_Order).filter(
            Future_Order.trade_signal_id == bucket.trade_signal_id).first()
        if order is None:
            raise ValueError("NSEFO_PAPER_ORDER_NOT_FOUND")
        order.order_status = PAPER_ACTIVE
        session.commit()
        return {"status": "PAPER_APPROVED", "bucket_id": bucket_id,
                "trade_signal_id": bucket.trade_signal_id}
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
