"""Dormant NSEFO REAL mechanical rails; no selector and no broker call.

This becomes callable only after a separately recorded tracking-error
graduation. It is deliberately disabled in configuration today.
"""
from __future__ import annotations

from scripts.graduated_live_config import NSEFO_REAL_MECHANICAL_RAILS_ACTIVE, OPTION3_SINGLE_TRADE_RISK_CAP_INR


def evaluate(*, serialization_clear: bool, trade_risk_inr: float, margin_clear: bool,
             liquidity_clear: bool, tracking_error_graduated: bool) -> dict:
    """Approve every rail-clearing candidate; never rank or pick setups."""
    reasons = []
    if not NSEFO_REAL_MECHANICAL_RAILS_ACTIVE:
        reasons.append("NSEFO_REAL_MECHANICAL_RAILS_NOT_ACTIVATED")
    if not tracking_error_graduated:
        reasons.append("NSEFO_TRACKING_ERROR_GRADUATION_REQUIRED")
    if not serialization_clear:
        reasons.append("OPTION3_SERIALIZATION_LOCKED")
    if float(trade_risk_inr) > float(OPTION3_SINGLE_TRADE_RISK_CAP_INR):
        reasons.append("OPTION3_RISK_CAP_18000")
    if not margin_clear:
        reasons.append("OPTION3_MARGIN_RAIL")
    if not liquidity_clear:
        reasons.append("OPTION3_LIQUIDITY_RAIL")
    return {"approved": not reasons, "reasons": reasons,
            "selection": "MECHANICAL_RAILS_NO_DISCRETION"}
