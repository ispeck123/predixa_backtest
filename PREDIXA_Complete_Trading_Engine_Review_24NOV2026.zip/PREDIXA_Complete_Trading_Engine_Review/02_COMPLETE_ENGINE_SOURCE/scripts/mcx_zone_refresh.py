#!/usr/bin/env python3
"""Authoritative post-CSV-refresh hook for MCX zone snapshots.

Call once *after* the existing updater has finished a complete successful batch:
``python scripts/mcx_zone_refresh.py GOLDM 30-11-2026 daily``.
The CSV hash makes retries harmless; this intentionally does not watch files or
run its own 30-minute scheduler.
"""
from __future__ import annotations
import hashlib, json, os, re, sys
from datetime import datetime
from pathlib import Path
from sqlalchemy import text
from shared.config.settings import stock_data_dir_config
from shared.db.dbconn import DBConnection
from apps.backend.services.mcx_alert_runtime import load_mcx_alert_env
from scripts.models import TF
from scripts.trade_engine import process_zones, process_qualified_zones
from apps.backend.services.mcx_zone_alerts import CanonicalZone, diff_snapshots

load_mcx_alert_env()

def _expiry(value): return datetime.strptime(value, "%d-%m-%Y").date()
def _file(symbol, expiry, timeframe): return Path(stock_data_dir_config.indian_commodity_data) / "latest_data_csv" / f"{symbol}_{expiry:%d%m%Y}_{timeframe}.csv"
_QUALIFIED_ZONE_TIMEFRAMES = {"one_twenty", "sixty"}
# These are the exact roles used by the existing commodity optimized-zone
# endpoint for the Weekly/Daily/240 chart profile.  E/A applies the platform's
# nearest-active BUY/SELL selection; X is the execute-timeframe calculation.
_OPTIMIZED_ZONE_ROLES = {
    "weekly": TF.E,
    "daily": TF.A,
    "two_forty": TF.X,
}


def _zone_method(timeframe: str):
    """Return the existing endpoint calculation used for alert candidates."""
    return "qualified" if timeframe.lower() in _QUALIFIED_ZONE_TIMEFRAMES else "standard"


def _active_zone_source(timeframe: str) -> tuple[str, TF]:
    """Map an alert timeframe to its established chart-zone calculation.

    ``get_commodities_opt_zones`` assigns Weekly/Daily/240 the E/A/X roles in
    the commodity profile.  The E/A formatter deliberately returns only the
    closest valid BUY below CMP and SELL above CMP.  Lower execution frames
    use ``get_qualified_zones_commodity`` and retain only qualified levels.
    """
    normalized = timeframe.lower()
    if normalized in _QUALIFIED_ZONE_TIMEFRAMES:
        return "get_qualified_zones_commodity", TF.X
    try:
        return "get_commodities_opt_zones", _OPTIMIZED_ZONE_ROLES[normalized]
    except KeyError as exc:
        raise RuntimeError(f"unsupported MCX alert timeframe: {timeframe}") from exc


def _max_retests() -> int:
    try:
        value = int(os.getenv("MCX_ZONE_MAX_RETESTS", "1"))
    except ValueError as exc:
        raise RuntimeError("MCX_ZONE_MAX_RETESTS must be a non-negative integer") from exc
    if value < 0:
        raise RuntimeError("MCX_ZONE_MAX_RETESTS must be a non-negative integer")
    return value


def _bands(symbol, expiry, timeframe, tick_size):
    path = _file(symbol, expiry, timeframe)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    # Existing chart calculations are called directly; no shadow strategy
    # exists.  The source below is also persisted as provenance so the monitor
    # can fail closed if a legacy all-zone snapshot is still in the database.
    method = _zone_method(timeframe)
    source, role = _active_zone_source(timeframe)
    max_retests = _max_retests()
    zones = (process_qualified_zones(str(path), role, datetime.now(), [timeframe], symbol, max_retests=max_retests)
             if method == "qualified" else process_zones(str(path), role, datetime.now(), max_retests=max_retests))
    result = []
    for side, bands in zones.items():
        for band in bands:
            if len(band) != 2: continue
            origin = str(band[0].get("time", ""))
            result.append(CanonicalZone.make(instrument=symbol, expiry=expiry.isoformat(), timeframe=timeframe,
                side=side, lower=band[0]["price"], upper=band[1]["price"], tick_size=tick_size,
                provenance=f"existing-process_{method}_zones", origin=origin))
    return digest, result, method, max_retests, source, role.name

def refresh(symbol, expiry_text, timeframe, *, tick_size=None, provider_symbol=None, instrument_metadata=None, db=None):
    if tick_size is None or float(tick_size) <= 0:
        raise ValueError("verified MCX tick_size is required")
    expiry = _expiry(expiry_text); path = _file(symbol, expiry, timeframe)
    if not path.is_file() or path.with_suffix(path.suffix + ".tmp").exists(): raise RuntimeError("CSV batch is not atomically ready")
    digest, current, method, max_retests, source, role = _bands(symbol.upper(), expiry, timeframe, tick_size); dbc = db or DBConnection()
    now = datetime.utcnow()
    with dbc.engine.begin() as c:
        old_rows = c.execute(text("SELECT * FROM mcx_zone_snapshots WHERE instrument=:i AND contract_expiry=:e AND timeframe=:t AND status='ACTIVE' AND version=(SELECT MAX(s.version) FROM mcx_zone_snapshots s WHERE s.instrument=:i AND s.contract_expiry=:e AND s.timeframe=:t)"), {"i":symbol.upper(),"e":expiry,"t":timeframe}).mappings().all()
        # Same content hash means an updater retry cannot produce events/version churn.
        if old_rows and all(
            (lambda p: p.get("csv_sha256") == digest and p.get("zone_method") == method and p.get("max_retests") == max_retests
             and p.get("alert_eligible") is True and p.get("alert_source") == source and p.get("alert_role") == role)
            (json.loads(r["provenance"]) if isinstance(r["provenance"], str) else r["provenance"])
            for r in old_rows
        ): return []
        previous = [CanonicalZone.make(instrument=r["instrument"],expiry=str(r["contract_expiry"]),timeframe=r["timeframe"],side=r["zone_type"],lower=float(r["lower_boundary"]),upper=float(r["upper_boundary"]),tick_size=tick_size,origin=(json.loads(r["provenance"]) if isinstance(r["provenance"],str) else r["provenance"]).get("origin",r["zone_id"])) for r in old_rows]
        version = (c.execute(text("SELECT COALESCE(MAX(version),0)+1 FROM mcx_zone_snapshots WHERE instrument=:i AND contract_expiry=:e AND timeframe=:t"), {"i":symbol.upper(),"e":expiry,"t":timeframe}).scalar_one())
        for old in old_rows: c.execute(text("UPDATE mcx_zone_snapshots SET status='REMOVED',updated_at=:n WHERE id=:id"), {"n":now,"id":old["id"]})
        for z in current:
            provenance = {"origin":z.origin,"csv_sha256":digest,"provider_symbol":provider_symbol,"tick_size":str(z.tick_size),"zone_method":method,"max_retests":max_retests,
                          "alert_eligible": True, "alert_source": source, "alert_role": role,
                          "instrument_metadata": instrument_metadata or {}}
            # A zone can reappear with an identical logical/revision identity
            # after a later CSV batch.  The schema keeps that identity unique
            # forever, so reactivate the existing row instead of failing the
            # refresh.  This also makes retries and overlapping refresh runs
            # harmless without weakening the database uniqueness constraint.
            c.execute(text("""INSERT INTO mcx_zone_snapshots(snapshot_key,instrument,contract_expiry,timeframe,zone_id,revision_signature,zone_type,lower_boundary,upper_boundary,provenance,status,version,created_at,updated_at)
              VALUES(:key,:i,:e,:t,:z,:r,:side,:lo,:hi,:p,'ACTIVE',:v,:n,:n)
              ON DUPLICATE KEY UPDATE
                snapshot_key=VALUES(snapshot_key), zone_type=VALUES(zone_type),
                lower_boundary=VALUES(lower_boundary), upper_boundary=VALUES(upper_boundary),
                provenance=VALUES(provenance), status='ACTIVE', version=VALUES(version),
                updated_at=VALUES(updated_at)"""), {"key":digest,"i":z.instrument,"e":expiry,"t":z.timeframe,"z":z.logical_id,"r":z.revision,"side":z.side,"lo":str(z.lower),"hi":str(z.upper),"p":json.dumps(provenance),"v":version,"n":now})
    return diff_snapshots(previous, current)

def _tick_sizes() -> dict[str, float]:
    """Read an operator-maintained per-instrument MCX tick-size mapping.

    CommoditiesMaster has no tick-size field in this repository.  We do not
    invent exchange specifications: missing entries are logged and skipped.
    """
    raw = os.getenv("MCX_ZONE_TICK_SIZES_JSON", "{}")
    try:
        return {str(k).upper(): float(v) for k, v in json.loads(raw).items() if float(v) > 0}
    except (TypeError, ValueError, json.JSONDecodeError):
        raise RuntimeError("MCX_ZONE_TICK_SIZES_JSON must be a JSON object of positive tick sizes")

def _timeframes() -> tuple[str, ...]:
    """Configured existing chart timeframes to publish after a complete batch."""
    aliases = {"weekly": "weekly", "daily": "daily", "240": "two_forty", "two_forty": "two_forty",
               "120": "one_twenty", "one_twenty": "one_twenty", "60": "sixty", "sixty": "sixty"}
    requested = [item.strip().lower() for item in os.getenv("MCX_ZONE_TIMEFRAMES", "weekly,daily,240,120,60").split(",") if item.strip()]
    unknown = [item for item in requested if item not in aliases]
    if unknown:
        raise RuntimeError(f"MCX_ZONE_TIMEFRAMES has unsupported values: {','.join(unknown)}")
    return tuple(dict.fromkeys(aliases[item] for item in requested))

def publish_completed_contracts(contracts: list[dict], *, db=None):
    """Publish Daily/Weekly snapshots for an atomically completed CSV batch."""
    sizes, published = _tick_sizes(), []
    from scripts.mcx_instrument_metadata import resolve_mcx_contract_metadata
    for contract in contracts or []:
        symbol = str(contract["underlying"]).upper()
        try:
            metadata = resolve_mcx_contract_metadata(symbol, contract["expiry"])
            # The updater's discovery and the master lookup must identify the
            # same exact dated contract.  Never attach zones to a lookalike.
            if metadata["fyers_symbol"] != contract["provider_symbol"]:
                raise RuntimeError("FYERS provider symbol mismatch")
            tick = metadata["tick_size"]
        except Exception as exc:
            # Preserve an explicitly configured per-product value only as a
            # validated availability fallback; it is never a default of 1.
            tick = sizes.get(symbol)
            if tick is None:
                import logging
                logging.getLogger(__name__).error("MCX zone snapshot skipped for %s: verified metadata unavailable (%s)", symbol, exc)
                continue
            metadata = {"source": "MCX_ZONE_TICK_SIZES_JSON_FALLBACK", "tick_size": tick,
                        "fyers_symbol": contract["provider_symbol"]}
        if not tick or float(tick) <= 0:
            continue
        for timeframe in _timeframes():
            try:
                events = refresh(symbol, contract["expiry"], timeframe, tick_size=tick,
                                 provider_symbol=contract["provider_symbol"], instrument_metadata=metadata, db=db)
                published.append({"contract": contract, "timeframe": timeframe, "events": events})
            except Exception:
                # Do not let one snapshot make the successful market-data batch
                # fail, and do not publish a partial replacement.
                import logging
                logging.getLogger(__name__).exception("MCX zone snapshot failed for %s %s", symbol, timeframe)
    # Snapshot changes are canonical market events too.  Record them through
    # the existing monitor fanout path after the successful atomic snapshot
    # transaction, so Discord can receive updates with zero user subscribers.
    changes = [event for item in published for event in item["events"]]
    if changes:
        from scripts.mcx_zone_alert_worker import Worker
        Worker(database=(db or DBConnection())).record_snapshot_events(changes)
    return published

if __name__ == "__main__":
    if len(sys.argv) != 4: raise SystemExit("usage: mcx_zone_refresh.py SYMBOL DD-MM-YYYY timeframe")
    from scripts.mcx_instrument_metadata import resolve_mcx_contract_metadata
    metadata = resolve_mcx_contract_metadata(sys.argv[1], sys.argv[2])
    print([(kind, z.logical_id) for kind, z in refresh(*sys.argv[1:], tick_size=metadata["tick_size"], provider_symbol=metadata["fyers_symbol"], instrument_metadata=metadata)])
