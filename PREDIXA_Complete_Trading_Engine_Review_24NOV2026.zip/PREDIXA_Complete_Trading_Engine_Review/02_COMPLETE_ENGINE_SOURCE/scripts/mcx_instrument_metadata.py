"""Verified MCX futures metadata from FYERS' public MCX Symbol Master.

The public master is the authoritative source for provider identity and tick
size.  Values are rejected rather than inferred: a zone alert with an unknown
tick is unsafe for both canonicalisation and proximity distance.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import time
from datetime import date, datetime
from decimal import Decimal
from functools import lru_cache

import requests

from shared.market_data_symbols import FYERS_MCX_MASTER_URL


def _expiry(value: object) -> date:
    raw = str(value)
    for fmt in ("%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"invalid MCX expiry: {raw}")


@lru_cache(maxsize=2)
def _master(hour_bucket: int) -> dict[tuple[str, date], dict]:
    """Load only schema-valid, unexpired MCX FUT rows; cache for one hour."""
    try:
        response = requests.get(FYERS_MCX_MASTER_URL, timeout=30)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise RuntimeError("MCX_FYERS_MASTER_UNAVAILABLE") from exc
    result: dict[tuple[str, date], dict] = {}
    for row in csv.reader(io.StringIO(response.text)):
        # FYERS derivative-master shape is description[1], lot[3], tick[4],
        # exact provider symbol[9].  Retain token[0] as opaque provider data;
        # never manufacture it from the display symbol.
        if len(row) < 10 or not row[9].startswith("MCX:") or not row[9].endswith("FUT"):
            continue
        match = re.fullmatch(r"(.+?)\s+(\d{2}\s+[A-Za-z]{3}\s+\d{2})\s+FUT", row[1].strip())
        if not match:
            continue
        try:
            expiry = datetime.strptime(match.group(2), "%d %b %y").date()
            lot, tick = int(Decimal(row[3])), Decimal(row[4])
            if lot <= 0 or tick <= 0:
                continue
        except (ArithmeticError, ValueError):
            continue
        underlying = match.group(1).upper()
        result[(underlying, expiry)] = {
            "symbol": underlying, "expiry": expiry.isoformat(), "fyers_symbol": row[9],
            "provider_token": row[0] or None, "lot_size": lot, "tick_size": float(tick),
            "trading_status": "ACTIVE" if expiry >= date.today() else "INACTIVE",
            "source": "FYERS_MCX_PUBLIC_MASTER", "master_hour": hour_bucket,
        }
    return result


def _fallback(symbol: str, expiry: date) -> dict | None:
    """Validated emergency cache, supplied only by operations configuration."""
    try:
        configured = json.loads(os.getenv("MCX_ZONE_CONTRACT_METADATA_JSON", "{}"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("MCX_ZONE_CONTRACT_METADATA_JSON is invalid JSON") from exc
    record = configured.get(f"{symbol}:{expiry.isoformat()}")
    if not isinstance(record, dict):
        return None
    try:
        tick = float(record["tick_size"])
        provider = str(record["fyers_symbol"])
        if tick <= 0 or not provider.startswith("MCX:") or not provider.endswith("FUT"):
            raise ValueError
    except (KeyError, TypeError, ValueError) as exc:
        raise RuntimeError(f"invalid MCX fallback metadata for {symbol}:{expiry.isoformat()}") from exc
    return {"symbol": symbol, "expiry": expiry.isoformat(), "fyers_symbol": provider,
            "provider_token": record.get("provider_token"), "lot_size": record.get("lot_size"),
            "tick_size": tick, "trading_status": record.get("trading_status", "ACTIVE"),
            "source": "MCX_ZONE_CONTRACT_METADATA_JSON"}


def resolve_mcx_contract_metadata(symbol: object, expiry: object, *, now=None) -> dict:
    normalized, expiry_date = str(symbol or "").strip().upper(), _expiry(expiry)
    try:
        record = _master(int((now or time.time()) // 3600)).get((normalized, expiry_date))
    except RuntimeError:
        record = _fallback(normalized, expiry_date)
        if record is None:
            raise
    if record is None:
        raise ValueError(f"MCX_FYERS_CONTRACT_METADATA_MISSING:{normalized}:{expiry_date.isoformat()}")
    if record["trading_status"] != "ACTIVE":
        raise ValueError(f"MCX_FYERS_CONTRACT_INACTIVE:{normalized}:{expiry_date.isoformat()}")
    return dict(record)


def active_mcx_contracts(symbol: object, *, now=None) -> list[dict]:
    """Current official NEAR/NEXT/FAR order for one underlying."""
    normalized = str(symbol or "").strip().upper()
    records = [dict(record) for (underlying, _), record in _master(int((now or time.time()) // 3600)).items()
               if underlying == normalized and record["trading_status"] == "ACTIVE"]
    return sorted(records, key=lambda record: record["expiry"])
