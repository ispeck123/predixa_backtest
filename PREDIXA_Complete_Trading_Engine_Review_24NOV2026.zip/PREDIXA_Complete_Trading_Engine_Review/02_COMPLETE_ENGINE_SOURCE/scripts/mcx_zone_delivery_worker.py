#!/usr/bin/env python3
"""Durable Discord outbox dispatcher for shared MCX zone alerts."""
import json, logging, os, socket, time
from datetime import datetime, timedelta
from sqlalchemy import text
from shared.db.dbconn import DBConnection
from apps.backend.services.mcx_alert_runtime import load_mcx_alert_env
from apps.backend.services.mcx_discord_alerts import DiscordSettings, classify_response, discord_payload
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

log = logging.getLogger("mcx.zone-push")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
load_mcx_alert_env()
def _discord_url(settings: DiscordSettings) -> str:
    """Append Discord's wait/thread query without ever logging the URL."""
    parts = urlsplit(settings.webhook_url)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["wait"] = "true"
    if settings.thread_id:
        query["thread_id"] = settings.thread_id
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _post_discord(settings: DiscordSettings, payload: dict):
    request = Request(_discord_url(settings), data=json.dumps(payload).encode("utf-8"),
                      headers={"Content-Type": "application/json", "User-Agent": "Predixa-MCX-Alerts/1.0"}, method="POST")
    try:
        with urlopen(request, timeout=float(os.getenv("DISCORD_ALERT_TIMEOUT_SECONDS", "10"))) as response:
            raw = response.read().decode("utf-8")
            try: body = json.loads(raw) if raw else {}
            except json.JSONDecodeError: body = {}
            return response.status, dict(response.headers.items()), body, False
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try: body = json.loads(raw) if raw else {}
        except json.JSONDecodeError: body = {}
        return exc.code, dict(exc.headers.items()) if exc.headers else {}, body, False
    except (socket.timeout, TimeoutError):
        return None, {}, {}, True
    except URLError:
        return None, {}, {}, False


def _claim_discord(db):
    now = datetime.utcnow()
    with db.engine.begin() as c:
        # A killed worker leaves a lease, not a permanently invisible delivery.
        c.execute(text("""UPDATE mcx_zone_discord_deliveries SET status='PENDING', processing_at=NULL,
            available_at=:now WHERE status='PROCESSING' AND processing_at < :stale"""),
                  {"now": now, "stale": now - timedelta(minutes=5)})
        row = c.execute(text("""SELECT d.*,e.event_key,e.zone_id,e.instrument,e.contract_expiry,e.timeframe,
            e.zone_type,e.event_type,e.ltp,e.detected_at,e.payload
            FROM mcx_zone_discord_deliveries d JOIN mcx_zone_alert_events e ON e.id=d.event_id
            WHERE d.channel='DISCORD' AND d.status='PENDING' AND d.available_at<=:now
            ORDER BY d.id LIMIT 1 FOR UPDATE SKIP LOCKED"""), {"now": now}).mappings().first()
        if not row:
            return None
        c.execute(text("""UPDATE mcx_zone_discord_deliveries SET status='PROCESSING',attempts=attempts+1,
            processing_at=:now WHERE id=:id"""), {"now": now, "id": row["id"]})
        data = dict(row)
        data["attempts"] = int(data["attempts"]) + 1
        return data


def _finish_discord(db, row, decision):
    now = datetime.utcnow()
    values = {"id": row["id"], "status": decision.status, "error": decision.error,
              "message_id": decision.message_id, "now": now,
              "available": now + timedelta(seconds=decision.retry_seconds or 0)}
    with db.engine.begin() as c:
        c.execute(text("""UPDATE mcx_zone_discord_deliveries SET status=:status,error=:error,
            discord_message_id=COALESCE(:message_id,discord_message_id),
            delivered_at=CASE WHEN :status='DELIVERED' THEN :now ELSE delivered_at END,
            available_at=:available,processing_at=NULL WHERE id=:id"""), values)


def dispatch_discord_once(db, *, settings: DiscordSettings | None = None, sender=_post_discord) -> bool:
    """Dispatch one shared Discord outbox item.  Kept injectable for tests."""
    row = _claim_discord(db)
    if not row:
        return False
    settings = settings or DiscordSettings.from_env()
    if not settings.enabled or not settings.webhook_url or settings.destination_hash != row["destination_hash"]:
        _finish_discord(db, row, classify_response(403, attempts=row["attempts"]))
        return True
    try:
        status, headers, body, timed_out = sender(settings, discord_payload(row, settings))
        decision = classify_response(status, headers, body, timeout=timed_out, attempts=row["attempts"])
    except Exception:
        log.exception("discord delivery failed id=%s", row["id"])
        decision = classify_response(None, attempts=row["attempts"])
    _finish_discord(db, row, decision)
    return True

def main():
    db = DBConnection()
    while True:
        if DiscordSettings.from_env().enabled:
            try:
                dispatch_discord_once(db)
            except Exception:
                # An unapplied optional Discord migration or transient DB
                # error must never stop the established Web Push pipeline.
                log.exception("discord outbox poll failed")
        time.sleep(1)

if __name__ == "__main__": main()
