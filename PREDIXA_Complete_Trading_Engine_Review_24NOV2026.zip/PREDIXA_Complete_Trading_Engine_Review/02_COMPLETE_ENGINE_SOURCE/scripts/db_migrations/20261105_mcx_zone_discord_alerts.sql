-- Additive only. Apply after 20261105_mcx_zone_alerts.sql on MySQL 8+.
-- One row is a shared webhook delivery, never one row per platform user.
CREATE TABLE IF NOT EXISTS mcx_zone_discord_deliveries (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  event_id BIGINT NOT NULL,
  destination_hash CHAR(64) NOT NULL,
  channel VARCHAR(16) NOT NULL DEFAULT 'DISCORD',
  status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
  attempts INT NOT NULL DEFAULT 0,
  available_at DATETIME(6) NOT NULL,
  processing_at DATETIME(6) NULL,
  delivered_at DATETIME(6) NULL,
  discord_message_id VARCHAR(64) NULL,
  error TEXT NULL,
  UNIQUE KEY uq_mcx_discord_delivery (event_id, destination_hash, channel),
  KEY ix_mcx_discord_pending (status, available_at),
  CONSTRAINT fk_mcx_discord_event FOREIGN KEY (event_id)
    REFERENCES mcx_zone_alert_events(id) ON DELETE CASCADE
);
