-- MySQL 8+ migration.  Timestamps are UTC; application converts for display.
CREATE TABLE IF NOT EXISTS mcx_zone_snapshots (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, snapshot_key CHAR(64) NOT NULL, instrument VARCHAR(50) NOT NULL,
  contract_expiry DATE NOT NULL, contract_classification VARCHAR(8) NULL, timeframe VARCHAR(32) NOT NULL,
  zone_id VARCHAR(64) NOT NULL, revision_signature CHAR(64) NOT NULL, zone_type VARCHAR(8) NOT NULL,
  lower_boundary DECIMAL(20,8) NOT NULL, upper_boundary DECIMAL(20,8) NOT NULL, provenance JSON NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE', version BIGINT NOT NULL, created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL, UNIQUE KEY uq_mcx_zone_revision (contract_expiry, zone_id, revision_signature),
  KEY ix_mcx_zone_active (instrument, contract_expiry, timeframe, status, version)
);
CREATE TABLE IF NOT EXISTS mcx_zone_event_state (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, zone_id VARCHAR(64) NOT NULL, revision_signature CHAR(64) NOT NULL,
  contract_expiry DATE NOT NULL, state VARCHAR(16) NOT NULL, last_ltp DECIMAL(20,8) NULL,
  last_tick_at DATETIME(6) NULL, entry_cycle INT NOT NULL DEFAULT 0, updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_mcx_zone_state (zone_id, revision_signature, contract_expiry)
);
CREATE TABLE IF NOT EXISTS mcx_zone_alert_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, event_key CHAR(64) NOT NULL, zone_id VARCHAR(64) NOT NULL,
  revision_signature CHAR(64) NOT NULL, instrument VARCHAR(50) NOT NULL, contract_expiry DATE NOT NULL,
  timeframe VARCHAR(32) NOT NULL, zone_type VARCHAR(8) NOT NULL, event_type VARCHAR(40) NOT NULL,
  ltp DECIMAL(20,8) NULL, detected_at DATETIME(6) NOT NULL, payload JSON NOT NULL,
  UNIQUE KEY uq_mcx_zone_event (event_key), KEY ix_mcx_zone_event_contract (instrument, contract_expiry, detected_at)
);
