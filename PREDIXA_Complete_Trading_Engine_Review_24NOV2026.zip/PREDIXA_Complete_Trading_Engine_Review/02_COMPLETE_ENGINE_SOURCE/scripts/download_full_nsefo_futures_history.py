"""Explicit full-history bootstrap for the configured NSEFO futures universe.

By default this command performs read-only preflight and prints the verified
symbol scope. Pass ``--run`` to download. Example:

    python scripts/download_full_nsefo_futures_history.py --run

The downloader uses the existing FYERS history path and writes per-contract
CSV files under the configured NSEFO futures data directory. The historical
endpoint is requested with ``cont_flag=1``; this is FYERS continuous history
for each currently listed contract symbol, not an archive of every expired
dated contract.
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import argparse
import logging
from datetime import datetime
from typing import Iterable


DEFAULT_START_DATE = "2020-01-01"
DEFAULT_EXPECTED_SYMBOLS = 59


def validate_universe(symbols: Iterable[str], expected_count: int = DEFAULT_EXPECTED_SYMBOLS) -> list[str]:
    """Validate and preserve the configured universe order without duplicates."""
    normalized = [str(symbol).strip() for symbol in symbols if str(symbol).strip()]
    duplicates = sorted({symbol for symbol in normalized if normalized.count(symbol) > 1})
    if duplicates:
        raise ValueError(f"Configured futures list contains duplicate symbols: {duplicates}")
    if len(normalized) != expected_count:
        raise ValueError(
            f"Expected {expected_count} configured futures symbols, found {len(normalized)}"
        )
    return normalized


def preflight_contracts(handler, symbols: Iterable[str]) -> dict[str, list[dict]]:
    """Resolve all configured symbols before allowing any full-refresh writes."""
    resolved = {}
    missing = []
    for symbol in symbols:
        contracts = handler._contracts_for(symbol, refresh=True) or []
        if not contracts:
            missing.append(symbol)
            continue
        resolved[symbol] = contracts
    if missing:
        raise RuntimeError(
            "No current FYERS futures contract metadata for: " + ", ".join(missing)
        )
    return resolved


def main(argv=None, *, handler_factory=None, processor_factory=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true", help="perform the full-history download")
    parser.add_argument("--start-date", default=DEFAULT_START_DATE,
                        help="history start date (default: 2020-01-01)")
    parser.add_argument("--expected-symbols", type=int, default=DEFAULT_EXPECTED_SYMBOLS,
                        help="fail unless the configured sheet has exactly this many symbols")
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=10)
    parser.add_argument("--batch-delay", type=int, default=10)
    args = parser.parse_args(argv)

    try:
        datetime.strptime(args.start_date, "%Y-%m-%d")
    except ValueError as exc:
        parser.error(f"--start-date must be YYYY-MM-DD: {exc}")
    if args.expected_symbols <= 0 or args.workers <= 0 or args.batch_size <= 0 or args.batch_delay < 0:
        parser.error("expected symbols, workers, and batch size must be positive; delay cannot be negative")

    if handler_factory is None:
        from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
        handler_factory = Indian_future_data_handler
    if processor_factory is None:
        from data_fetchers.fyers.indian_futures_data_updater import future_data_processer
        processor_factory = future_data_processer

    handler = handler_factory()
    symbols = validate_universe(handler.get_all_stock_symbols(), args.expected_symbols)
    print(f"Configured NSEFO underlyings verified: {len(symbols)}")
    print(f"Full history window: {args.start_date} through the run date")
    print("Base intervals: D, 60, 15, 5; derived: weekly, monthly, 75, 25, 125")
    print("Universe: " + ", ".join(symbols))

    if not args.run:
        print("Preflight only; no market-data download performed. Rerun with --run to start.")
        return 0

    handler.full_history_start = datetime.strptime(args.start_date, "%Y-%m-%d")
    resolved = preflight_contracts(handler, symbols)
    contract_count = sum(len(contracts) for contracts in resolved.values())
    print(f"FYERS contract metadata preflight passed: {contract_count} contracts across {len(symbols)} underlyings")

    changed_files = handler.process(
        max_workers=args.workers,
        batch_size=args.batch_size,
        delay_between_batches=args.batch_delay,
        force_full_refresh=True,
        underlyings=symbols,
        configured_symbols=symbols,
    )
    if not changed_files:
        raise RuntimeError("Full-history refresh completed without producing source CSV files")

    processor = processor_factory(handler=handler)
    processor.process_all_files(symbols=symbols, source_files=changed_files)
    print(f"Full-history refresh and derived timeframe processing complete: {len(changed_files)} source files")
    return 0


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    raise SystemExit(main())
