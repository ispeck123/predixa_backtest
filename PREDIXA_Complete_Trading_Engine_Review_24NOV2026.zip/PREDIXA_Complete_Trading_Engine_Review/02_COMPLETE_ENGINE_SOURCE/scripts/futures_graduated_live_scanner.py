import argparse
import csv
import json
import time
from dataclasses import dataclass, field, replace
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional
import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


from shared.db import db_utils
from shared.db.db_model import Future_Order, FuturesMaster, OMSOrderBucketFuture, TradeSignal
from shared.config.settings import stock_logic_config
from scripts.graduated_live_config import (FUTURES_LOT_SIZES, FUTURES_TIER0_LOTS,
                                           PAPER, REAL, execution_mode_for)
from scripts.nsefo_tp_overlay import overlay_for_setup, shadow_exit_log
from scripts.nsefo_paper_governor import PAPER_PENDING, PAPER_SOURCE, auto_approve_tier0_paper_candidate
from scripts.nsefo_instrument_metadata import resolve_nsefo_contract_metadata
from scripts.setup_engine_new import format_calculate_setup_response, process_setup_fc
from scripts.tf_regime_gate_by_exchange import gate
import time
import logging
logger = logging.getLogger(__name__)


EXCHANGE_ID_NSEFO = 11
BUY_RRR_THRESHOLD = 2.1
DEFAULT_OUTPUT_DIR = Path("outputs/graduated_live_validation")
# DEFAULT_TIMEFRAME_IDS = [1, 25, 2, 3, 4, 5]
DEFAULT_TIMEFRAME_IDS = [1, 25]
DEFAULT_MIN_EXPIRY_DAYS = 5
CANDIDATE_SOURCE = "GRADUATED_LIVE"


SAFETY_BANNER = """============================================================
PREDIXA FUTURES GRADUATED-LIVE SCANNER
MODE: DB CANDIDATE INSERT
SEGMENT: NSE FUTURES
SIDE: BUY ONLY
BROKER MUTATIONS: DISABLED
OMS FUTURES CANDIDATES: ENABLED
================================"""


@dataclass(frozen=True)
class FuturesScanJob:
    symbol: str
    expiry: Any
    exp_num: Any
    timeframe_id: int
    time_list: List[str]
    last_d_time: Any = None
    exchange_id: int = EXCHANGE_ID_NSEFO
    is_future: bool = True
    contract: Optional[str] = None
    lot_size: Optional[int] = None
    stock_id: Optional[int] = None
    execution_mode: Optional[str] = None
    tick_size: Optional[float] = None


@dataclass
class ScanOutputs:
    run_id: str
    scan_timestamp: str
    candidates: List[Dict[str, Any]] = field(default_factory=list)
    diagnostics: List[Dict[str, Any]] = field(default_factory=list)
    total_jobs: int = 0
    processed: int = 0
    errors: int = 0
    csv_path: Optional[Path] = None
    jsonl_path: Optional[Path] = None


SetupRunner = Callable[[FuturesScanJob], Any]
Formatter = Callable[[Any, FuturesScanJob], Dict[str, Any]]
JobProvider = Callable[[List[int], Optional[int], Any, int], Iterable[FuturesScanJob]]
SignalInserter = Callable[[Dict[str, Any], int, int, int], Any]
CandidatePersister = Callable[[Dict[str, Any], FuturesScanJob, Any], Any]


def _one_lot(value: Any) -> int:
    if isinstance(value, bool) or value is None:
        raise ValueError("FUT_REJECT_LOT_SIZE_UNAVAILABLE")
    try:
        quantity = int(value)
    except (TypeError, ValueError):
        raise ValueError("FUT_REJECT_INVALID_LOT_SIZE") from None
    try:
        is_integral = quantity == value
    except Exception:
        is_integral = False
    if quantity <= 0 or not is_integral:
        raise ValueError("FUT_REJECT_INVALID_LOT_SIZE")
    return quantity


def _order_expiry(value: Any) -> str:
    from scripts.scanner_fc import parse_expiry_date
    return parse_expiry_date(value).strftime("%d-%m-%Y")


def persist_futures_candidate(candidate: Dict[str, Any], job: FuturesScanJob,
                              signal_result: Any) -> Dict[str, Any]:
    """Create/reuse the DB-side futures approval candidate only.

    ``signal_result`` is the return value of ``insert_trade_signals`` and may
    be ``(inserted, id)`` or a test-specific ID.  No broker or reservation
    code is reachable from this helper.
    """
    mode = str(job.execution_mode or "").strip().upper()
    if mode not in {PAPER, REAL}:
        raise ValueError("FUT_REJECT_INVALID_EXECUTION_MODE")
    # PAPER is exactly one verified simulated futures lot.  The exact Tier-0
    # provenance is auto-approved into its brokerless serial queue; every
    # other provenance remains outside this shortcut and nothing reaches a
    # broker or real-risk reservation.
    quantity = _one_lot(job.lot_size)
    source = PAPER_SOURCE if mode == PAPER else CANDIDATE_SOURCE
    trade_signal_id = signal_result[1] if isinstance(signal_result, tuple) and len(signal_result) > 1 else signal_result
    trade = candidate.get("setup_result") or {}
    buy = trade.get("BUY") if isinstance(trade, dict) else None
    if not isinstance(buy, dict):
        raise ValueError("FUT_REJECT_BUY_SETUP_MISSING")
    session = db_utils.dbc.get_session()
    try:
        if trade_signal_id:
            signal = session.query(TradeSignal).filter(TradeSignal.id == trade_signal_id).first()
        else:
            signal = session.query(TradeSignal).filter(
                TradeSignal.stock_name == job.symbol,
                TradeSignal.time_fr == job.timeframe_id,
                TradeSignal.trade_type == "BUY",
                TradeSignal.exp_date == str(job.exp_num),
                TradeSignal.price_cmp == candidate.get("PRICE_CMP"),
            ).order_by(TradeSignal.id.desc()).first()
        if signal is None:
            raise ValueError("FUT_REJECT_TRADE_SIGNAL_NOT_PERSISTED")
        trade_signal_id = signal.id

        stock_id = job.stock_id
        if stock_id is None:
            stock = session.query(FuturesMaster).filter(
                FuturesMaster.symbol == job.symbol,
                FuturesMaster.expiry_date == datetime.strptime(
                    _order_expiry(job.expiry), "%d-%m-%Y").date(),
            ).order_by(FuturesMaster.expiry_date).first()
            stock_id = stock.id if stock else None

        future_order = session.query(Future_Order).filter(
            Future_Order.trade_signal_id == trade_signal_id
        ).first()
        now = datetime.now()
        if future_order is not None and (
                future_order.execution_mode != mode
                or future_order.candidate_source != source):
            raise ValueError("FUT_REJECT_EXISTING_ORDER_PROVENANCE_MISMATCH")
        if future_order is None:
            future_order = Future_Order(
                stock_tick=job.symbol, stock_id=stock_id, country_id=1,
                time_frame=job.timeframe_id, order_type="BUY",
                entry_price=buy["entry_price"], stoploss_price=buy["stop_loss"],
                target_price=candidate["paper_target_price"], stock_quantity=quantity,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"),
                purchased_on=now,
                order_status=PAPER_PENDING if mode == PAPER else "pending",
                is_trade_started=False,
                is_evaluated=False, entry_timestamp=None, completed_on=None,
                arima_ab_model_prediction="NA", arima_ab_model_prob=0.0,
                expiry_date=_order_expiry(job.expiry), trade_signal_id=trade_signal_id,
                execution_mode=mode,
                candidate_source=source,
            )
            session.add(future_order)
            session.flush()

        oms = session.query(OMSOrderBucketFuture).filter(
            OMSOrderBucketFuture.trade_signal_id == trade_signal_id
        ).first()
        if oms is not None and (
                oms.execution_mode != mode or oms.candidate_source != source):
            raise ValueError("FUT_REJECT_EXISTING_BUCKET_PROVENANCE_MISMATCH")
        if oms is None:
            oms = OMSOrderBucketFuture(
                order_id=future_order.order_id, trade_signal_id=trade_signal_id,
                stock_tick=job.symbol, stock_id=stock_id, country_id=1,
                time_frame=job.timeframe_id, order_type="BUY",
                entry_price=buy["entry_price"], stoploss_price=buy["stop_loss"],
                target_price=candidate["paper_target_price"], stock_quantity=quantity,
                purchased_cmp_date=now.strftime("%Y-%m-%dT%H:%M"),
                purchased_on=now,
                order_status=PAPER_PENDING if mode == PAPER else "pending",
                is_trade_started=0,
                is_evaluated=0, entry_timestamp=None, completed_on=None,
                expiry_date=_order_expiry(job.expiry),
                approval_status="pending",
                approved_by=None, approved_at=None,
                id_fyers=None, gtt_id=None,
                execution_mode=mode,
                candidate_source=source,
            )
            session.add(oms)
        auto_result = None
        if mode == PAPER:
            # This exact provenance is the owner-authorized unbiased Tier-0
            # paper cohort. GRADUATED_LIVE, LEGACY_PAPER and every REAL row
            # remain on their existing paths.
            auto_result = auto_approve_tier0_paper_candidate(
                session=session, bucket=oms, order=future_order)
        session.commit()
        return {"success": True, "trade_signal_id": trade_signal_id,
                "future_order_id": future_order.order_id, "bucket_id": oms.bucket_id,
                "status": (auto_result or {}).get("status", "PAPER_PENDING_APPROVAL" if mode == PAPER else "CANDIDATE_PENDING"),
                "execution_mode": mode}
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def default_time_list(timeframe_id: int) -> List[str]:
    return list(getattr(stock_logic_config, f"FUTURE_TIME_FRAME_{timeframe_id}"))


def execute_timeframe(time_list: List[str]) -> Optional[str]:
    return time_list[-1] if time_list else None


def default_futures_jobs(
    timeframe_ids: List[int],
    max_symbols: Optional[int],
    last_d_time: Any,
    min_expiry_days: int = DEFAULT_MIN_EXPIRY_DAYS,
) -> Iterable[FuturesScanJob]:
    from scripts.scanner_fc import build_futures_expiry_map

    if max_symbols is not None:
        raise ValueError("FUTURES_UNIVERSE_TRUNCATION_DISABLED")
    emitted = set()
    mode = execution_mode_for("NSEFO")

    for timeframe_id in timeframe_ids:
        futures_map = build_futures_expiry_map(
            min_days=min_expiry_days,
            time_fr=timeframe_id,
        )
        for item in futures_map:
            try:
                symbol = str(item.get("symbol") or "").strip().upper()
                for exp_num in item.get("expiry", []):
                    key = (symbol, str(exp_num), timeframe_id)
                    if key in emitted:
                        continue
                    emitted.add(key)
                    metadata = resolve_nsefo_contract_metadata(symbol, exp_num)
                    yield FuturesScanJob(
                        symbol=symbol,
                        expiry=exp_num,
                        exp_num=exp_num,
                        timeframe_id=timeframe_id,
                        time_list=default_time_list(timeframe_id),
                        last_d_time=last_d_time,
                        # PAPER and REAL both require dated FYERS metadata.  No
                        # static fallback can stand in for an executable lot/tick.
                        lot_size=metadata["lot_size"],
                        contract=metadata["fyers_symbol"],
                        tick_size=metadata["tick_size"],
                        execution_mode=mode,
                    )
            except Exception as ex:
                logger.exception(ex)



def run_setup_engine(job: FuturesScanJob) -> Any:
    return process_setup_fc(job.symbol, job.time_list, job.exp_num, normalize_last_d_time(job.last_d_time), True)


def format_setup_result(raw: Any, job: FuturesScanJob) -> Dict[str, Any]:
    return format_calculate_setup_response(
        raw,
        stock_name=job.symbol,
        time_fr=job.timeframe_id,
        exp_num=job.exp_num,
        last_d_time=normalize_last_d_time(job.last_d_time),
        is_future=True,
        is_cash=False,
    )


def normalize_last_d_time(value: Any) -> Any:
    """Return the datetime shape expected by the pandas setup-data loader."""
    import pandas as pd

    if value is None or value == "":
        return pd.Timestamp.now().to_pydatetime()
    if isinstance(value, (datetime, pd.Timestamp)):
        return pd.Timestamp(value).to_pydatetime()
    return pd.to_datetime(value, dayfirst=True, errors="raise").to_pydatetime()


def _base_record(run_id: str, scan_timestamp: str, job: FuturesScanJob) -> Dict[str, Any]:
    return {
        "run_id": run_id,
        "scan_timestamp": scan_timestamp,
        "symbol": job.symbol,
        "expiry": job.expiry,
        "EXP_NUM": job.exp_num,
        "timeframe_id": job.timeframe_id,
        "time_list": job.time_list,
        "execute_timeframe": execute_timeframe(job.time_list),
        "exchange_id": job.exchange_id,
        "is_future": job.is_future,
        "contract": job.contract,
        "execution_mode": job.execution_mode,
    }


def classify_formatted_result(
    formatted: Any,
    job: FuturesScanJob,
    *,
    run_id: str,
    scan_timestamp: str,
    buy_rrr_threshold: float = BUY_RRR_THRESHOLD,
) -> tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    record = _base_record(run_id, scan_timestamp, job)
    record["setup_result"] = formatted

    if str(job.execution_mode or "").strip().upper() not in {PAPER, REAL}:
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "INVALID_EXECUTION_MODE"
        return record, None

    if job.exchange_id != EXCHANGE_ID_NSEFO or job.is_future is not True:
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "NOT_NSE_FUTURES"
        return record, None

    if job.exp_num in (None, ""):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "INVALID_EXPIRY"
        return record, None

    if not isinstance(formatted, dict):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "FORMATTED_RESULT_NOT_DICT"
        return record, None

    buy = formatted.get("BUY")
    if not buy:
        record["scan_status"] = "NO_SETUP"
        record["rejection_reason"] = "NO_BUY_SETUP"
        return record, None

    mode = str(job.execution_mode or "").strip().upper()
    tier, size_mult, gate_reason = gate(
        "NSEFO", job.timeframe_id, formatted.get("e_regime"), formatted.get("a_regime"), job.symbol)
    record.update(gate_tier=tier, gate_size_multiplier=size_mult, gate_reason=gate_reason)
    if size_mult == 0:
        record["scan_status"] = "GATE_DENIED"
        record["rejection_reason"] = gate_reason
        return record, None

    try:
        buy_rrr = float(formatted.get("BUY_RRR", 0.0))
    except (TypeError, ValueError):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "INVALID_BUY_RRR"
        return record, None

    # G9/selection remains based on the original far target in every mode.
    if buy_rrr < buy_rrr_threshold:
        record["scan_status"] = "BUY_RRR_TOO_LOW"
        record["rejection_reason"] = f"BUY_RRR_LT_{buy_rrr_threshold}"
        return record, None

    if not isinstance(buy, dict):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "BUY_NOT_DICT"
        return record, None

    required = ("entry_price", "stop_loss", "target_price")
    if any(buy.get(key) is None for key in required):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "BUY_PRICE_FIELD_MISSING"
        return record, None

    try:
        entry, stop, target = (float(buy[key]) for key in required)
        if not (stop < entry < target):
            raise ValueError
    except (TypeError, ValueError):
        record["scan_status"] = "INVALID_RESULT"
        record["rejection_reason"] = "INVALID_BUY_PRICE_ORDERING"
        return record, None

    record["scan_status"] = "ACCEPTED"
    record["rejection_reason"] = None

    timestamps = formatted.get("BUY_TIMESTAMPS") if isinstance(formatted.get("BUY_TIMESTAMPS"), dict) else {}
    candidate = {
        **_base_record(run_id, scan_timestamp, job),
        "side": "BUY",
        "entry": buy.get("entry_price"),
        "stop_loss": buy.get("stop_loss"),
        "target": buy.get("target_price"),
        "BUY_RRR": buy_rrr,
        "zone_type": buy.get("zone_type"),
        "zone_signature": buy.get("zone_signature"),
        "zone_metadata": {
            key: buy.get(key)
            for key in (
                "is_execute_tf",
                "consumption_dead_after",
                "base_start_idx",
                "legout_end_idx",
                "retest_count",
                "overlap_ratio",
                "htf_target_price",
                "struct_stop_A",
                "struct_stop_E",
            )
            if key in buy
        },
        "signal_timestamp": timestamps.get("entry_price_timestamp"),
        "PRICE_CMP": formatted.get("PRICE_CMP"),
        "gate_tier": tier,
        "gate_size_multiplier": size_mult,
        "gate_reason": gate_reason,
        "setup_result": formatted,
    }
    if mode == PAPER:
        try:
            overlay = overlay_for_setup({
                "segment": "NSEFO", "e_regime": formatted.get("e_regime"),
                "a_regime": formatted.get("a_regime"), "strategy_tf": job.timeframe_id,
                "side": "BUY", "entry": entry, "stop_loss": stop, "target": target,
            }, tick_size=job.tick_size)
        except ValueError as exc:
            record["scan_status"] = "INVALID_RESULT"
            record["rejection_reason"] = str(exc)
            return record, None
        if overlay is None:
            record["scan_status"] = "GATE_DENIED"
            record["rejection_reason"] = "NSEFO_TIER0_PAPER_CELL_REQUIRED"
            return record, None
        candidate["tp50_overlay"] = overlay
        candidate["paper_target_price"] = overlay["candidate_tp50_executable"]
    else:
        candidate["paper_target_price"] = target
    return record, candidate


class FuturesGraduatedLiveReadonlyScanner:
    def __init__(
        self,
        *,
        job_provider: JobProvider = default_futures_jobs,
        setup_runner: SetupRunner = run_setup_engine,
        formatter: Formatter = format_setup_result,
        signal_inserter: SignalInserter = db_utils.insert_trade_signals,
        candidate_persister: CandidatePersister = persist_futures_candidate,
        buy_rrr_threshold: float = BUY_RRR_THRESHOLD,
    ) -> None:
        self.job_provider = job_provider
        self.setup_runner = setup_runner
        self.formatter = formatter
        self.signal_inserter = signal_inserter
        self.candidate_persister = candidate_persister
        self.buy_rrr_threshold = buy_rrr_threshold

    def run(
        self,
        *,
        timeframe_ids: List[int],
        max_symbols: Optional[int] = None,
        last_d_time: Any = None,
        min_expiry_days: int = DEFAULT_MIN_EXPIRY_DAYS,
        output_dir: Path = DEFAULT_OUTPUT_DIR,
        write_files: bool = True,
    ) -> ScanOutputs:
        run_id = f"FGLS_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        scan_timestamp = datetime.now().isoformat()
        outputs = ScanOutputs(run_id=run_id, scan_timestamp=scan_timestamp)
        for job in self.job_provider(timeframe_ids, max_symbols, last_d_time, min_expiry_days):
            job = replace(job, last_d_time=normalize_last_d_time(job.last_d_time))
            outputs.total_jobs += 1
            record = _base_record(run_id, scan_timestamp, job)
            # print("########################################################################")
            try:
                print("*********************************************")
                print(f"Processing job: {job}")
                print("*********************************************")
                raw = self.setup_runner(job)
                if isinstance(raw, str):
                    raise RuntimeError(raw)
                formatted = self.formatter(raw, job)
                record, candidate = classify_formatted_result(
                    formatted,
                    job,
                    run_id=run_id,
                    scan_timestamp=scan_timestamp,
                    buy_rrr_threshold=self.buy_rrr_threshold,
                )
                outputs.processed += 1

                print("BUY_RRR", candidate.get("BUY_RRR") if candidate else None)
                # print(time.sleep(2))

                mode = str(job.execution_mode or "").strip().upper()
                if candidate:
                    trade_signal = dict(formatted)
                    trade_signal["TRADE_TYPE"] = "BUY"
                    trade_signal["PREDICTION"] = "NA"
                    trade_signal["PROBABILITY"] = 0.0
                    trade_signal["EXP_NUM"] = job.exp_num
                    if candidate.get("tp50_overlay"):
                        # TradeSignal JSON is the existing durable setup audit
                        # envelope.  db_utils persists the BUY object as
                        # trade_data, so retain both shadow exits there too.
                        # This avoids a schema change while ensuring the
                        # control/candidate ledgers survive insertion.
                        trade_signal["BUY"] = dict(trade_signal["BUY"])
                        trade_signal["PAPER_TP50_OVERLAY"] = candidate["tp50_overlay"]
                        trade_signal["PAPER_TP50_SHADOW_EXITS"] = shadow_exit_log(
                            setup_id=f"{job.symbol}:{job.exp_num}:{job.timeframe_id}:{candidate.get('signal_timestamp')}",
                            overlay=candidate["tp50_overlay"],
                        )
                        trade_signal["BUY"]["PAPER_TP50_OVERLAY"] = trade_signal["PAPER_TP50_OVERLAY"]
                        trade_signal["BUY"]["PAPER_TP50_SHADOW_EXITS"] = trade_signal["PAPER_TP50_SHADOW_EXITS"]
                    signal_result = self.signal_inserter(
                        trade_signal, 1, EXCHANGE_ID_NSEFO, job.timeframe_id
                    )
                    signal_id = (
                        signal_result[1]
                        if isinstance(signal_result, tuple) and len(signal_result) > 1
                        else None
                    )
                    if not signal_id:
                        # Upstream insertion can legitimately decline a signal
                        # (for example unavailable circuit data).  Do not turn
                        # that into a misleading persistence exception or try a
                        # fallback DB lookup with a different CMP.
                        record["scan_status"] = "SIGNAL_NOT_PERSISTED"
                        record["rejection_reason"] = "TRADE_SIGNAL_INSERT_DECLINED"
                    else:
                        self.candidate_persister(candidate, job, signal_result)
                        outputs.candidates.append(candidate)
                #     print("inserted")
                #     time.sleep(2)
                # else:
                #     print("skipped")
                #     time.sleep(2)
            except Exception as exc:
                outputs.errors += 1
                record["scan_status"] = "PROCESSING_ERROR"
                record["rejection_reason"] = str(exc)
                record["setup_result"] = None
            outputs.diagnostics.append(record)

        if write_files:
            write_outputs(outputs, output_dir)
        return outputs


def run_graduated_futures_scan(*, timeframe_ids=None, last_d_time=None,
                               min_expiry_days=DEFAULT_MIN_EXPIRY_DAYS,
                               output_dir=DEFAULT_OUTPUT_DIR, write_files=True):
    """Programmatic entry point used by orchestration; no CLI parsing."""
    scanner = FuturesGraduatedLiveReadonlyScanner()
    return scanner.run(
        timeframe_ids=timeframe_ids or DEFAULT_TIMEFRAME_IDS,
        max_symbols=None,
        last_d_time=last_d_time,
        min_expiry_days=min_expiry_days,
        output_dir=output_dir,
        write_files=write_files,
    )


def write_outputs(outputs: ScanOutputs, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outputs.csv_path = output_dir / f"futures_readonly_candidates_{timestamp}.csv"
    outputs.jsonl_path = output_dir / f"futures_readonly_scan_{timestamp}.jsonl"

    candidate_fields = [
        "run_id",
        "scan_timestamp",
        "symbol",
        "expiry",
        "EXP_NUM",
        "timeframe_id",
        "time_list",
        "execute_timeframe",
        "exchange_id",
        "is_future",
        "contract",
        "side",
        "entry",
        "stop_loss",
        "target",
        "BUY_RRR",
        "zone_type",
        "zone_signature",
        "zone_metadata",
        "signal_timestamp",
        "PRICE_CMP",
    ]
    with outputs.csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=candidate_fields, extrasaction="ignore")
        writer.writeheader()
        for candidate in outputs.candidates:
            row = dict(candidate)
            row["time_list"] = json.dumps(row.get("time_list"), default=str)
            row["zone_metadata"] = json.dumps(row.get("zone_metadata"), default=str)
            writer.writerow(row)

    with outputs.jsonl_path.open("w", encoding="utf-8") as fh:
        for record in outputs.diagnostics:
            fh.write(json.dumps(record, default=str))
            fh.write("\n")


def print_candidate_table(outputs: ScanOutputs) -> None:
    print("\nPREDIXA FUTURES BUY CANDIDATES\n")
    if not outputs.candidates:
        print("NO QUALIFYING FUTURES BUY SETUPS FOUND")
    else:
        print(f"{'Symbol':<14} {'Expiry':<12} {'TF':<12} {'Entry':>10} {'Stop':>10} {'Target':>10} {'RRR':>7}")
        for candidate in outputs.candidates:
            print(
                f"{str(candidate.get('symbol', '')):<14} "
                f"{str(candidate.get('expiry', '')):<12} "
                f"{str(candidate.get('execute_timeframe', '')):<12} "
                f"{candidate.get('entry', ''):>10} "
                f"{candidate.get('stop_loss', ''):>10} "
                f"{candidate.get('target', ''):>10} "
                f"{candidate.get('BUY_RRR', ''):>7}"
            )

    print("")
    print(f"Total jobs: {outputs.total_jobs}")
    print(f"Processed: {outputs.processed}")
    print(f"Errors: {outputs.errors}")
    print(f"BUY candidates: {len(outputs.candidates)}")
    print(f"Output CSV: {outputs.csv_path}")
    print(f"Diagnostic JSONL: {outputs.jsonl_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read-only NSE futures graduated-live BUY scanner.")
    parser.add_argument("--timeframe", type=int, action="append", dest="timeframes", help="Futures timeframe id. Repeat to scan multiple ids.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--min-expiry-days", type=int, default=DEFAULT_MIN_EXPIRY_DAYS)
    parser.add_argument("--last-d-time", default=None)
    return parser.parse_args()


def futureScanner() -> int:
    print(SAFETY_BANNER)
    args = parse_args()
    started = time.time()
    outputs = run_graduated_futures_scan(
        timeframe_ids=args.timeframes,
        last_d_time=args.last_d_time,
        min_expiry_days=args.min_expiry_days,
        output_dir=args.output_dir,
        write_files=True,
    )
    print_candidate_table(outputs)
    print(f"Elapsed seconds: {round(time.time() - started, 2)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(futureScanner())
