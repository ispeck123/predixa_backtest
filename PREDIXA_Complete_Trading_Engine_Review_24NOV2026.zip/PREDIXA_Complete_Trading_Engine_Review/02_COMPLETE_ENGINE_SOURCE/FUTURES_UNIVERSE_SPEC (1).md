# PREDIXA — Futures Universe Definition (Phase A backtest + live)

**Date:** 30 Sep 2026 · Extends `FUTURES_ENABLEMENT_PROGRAM.md` (Phase A) and
`FUT_REGIME_TF_BACKTEST_EXPORT_SPEC.md`. Settles the H2 call: index + liquid stock futures for NSEFO;
bullion + energy for MCX.

## Core principle — two universes, never conflated
- **BACKTEST/validation universe = BROAD.** Breadth is what gives statistical validity. Narrowing it
  reproduces the core-8 failure (thin per-cell n, unstable winners, overfit). Run broad.
- **LIVE-trading universe = the liquid subset.** Execution quality (spread, OI depth, market impact)
  governs here. This is where a liquidity shortlist applies — AFTER the backtest identifies edge.
- **Live pick = liquidity ∩ Phase-B edge.** Never liquidity alone (liquidity ≠ trendiness).

---

## NSEFO — BACKTEST universe (for the Phase A clean re-run)
Base = the **validated cash 99-symbol universe** (our existing liquidity+quality screen; the 52-name
cash allowlist is its shipping subset), PLUS liquid F&O names not in it, PLUS index futures.

- **Add (liquid, currently absent from our screened set):** SBIN, TCS, AXISBANK, ADANIENT, COALINDIA
  (+ any other NSE F&O name with durable turnover/OI — BE to sweep the full F&O list).
- **Index futures (NEW class, priority):** NIFTY, BANKNIFTY, FINNIFTY. Tag `instrument_class=index`.
- **Tag every row** `instrument_class` ∈ {stock, index} so Phase B can cut by class.
- **Do NOT** scope the backtest to 8–20 names. Target ≥ ~80–100 liquid underlyings + index.
- Note: core-8 included ITC, ONGC, WIPRO — never in our screened cash set (ad-hoc pick). The new
  universe supersedes that selection.

## NSEFO — LIVE universe (post-Phase-B, for go-live execution)
Restrict to names that are BOTH: (a) liquid on current NSE data — BE/Apratim verify turnover + OI +
quantity-freeze; Perplexity's practical rules apply (bid-ask ≤1–2 ticks, OI across near+next, small
market impact, liquid outside first/last 30 min, no imminent event); AND (b) show a robust Phase-B
edge in their instrument_class.
- **Index first.** NIFTY/BANKNIFTY/FINNIFTY: most liquid, best trend-capture fit, least gap risk.
  Confirm current lot sizes + per-lot margin (SEBI changes these) — margin per lot vs the ₹50k
  ceiling drives the Option-3 single-lot check.
- **Stock futures:** start from the 10 Perplexity∩cash-validated names (RELIANCE, HDFCBANK, ICICIBANK,
  BHARTIARTL, INFY, LT, TATAMOTORS, ADANIPORTS, TATASTEEL, BAJFINANCE), filtered by Phase-B edge.
  Flag gap risk on single-stock (esp. Adani names): a 1% structural stop can be gapped through on
  results/news → realized loss > 1R. Prefer index where the strategy allows.

## MCX — bullion + energy (on plan, unchanged)
MCX is all futures (no cash). Stay on the existing plan: **bullion + energy only.**
- **Bullion:** GOLD / GOLDM, SILVER / SILVERM.
- **Energy:** CRUDEOIL / CRUDEOILM, NATURALGAS / NATGASMINI.
- Prefer the **mini contracts** (GOLDM, SILVERM, CRUDEOILM, NATGASMINI) for live — lower per-lot
  margin fits the ₹50k ceiling and the single-lot mechanism better.
- MCX requires the continuity fix + **E1 session-gap** fix before any assessment (already specced).

---

## Live-liquidity feed — how to rank (from the dashboard "Most Liquid Stock" export, 30 Sep)
The dashboard provides a real-time API feed: Symbol, **Avg Volume (contracts, near = Oct)**, and
near/next/far expiries. 27 stocks + NIFTY/BANKNIFTY/FINNIFTY. Useful, with one correction:

- **"Avg Volume (contracts)" is price-biased — do NOT rank the live universe by it.** Contract count
  is inflated for low-priced names, so the top of the list tilts to cheap PSU/high-share-count names
  (CANBK, PNB, UNIONBANK, IOC, BHEL, IREDA, JIOFIN, LTF, BANDHANBNK, FEDERALBNK, RBLBANK — mostly
  ₹100–250). Perplexity's quality names (LT, TCS, BHARTIARTL, TATAMOTORS, BAJFINANCE) are ABSENT from
  the top-30 only because higher price → fewer contracts, not because they're illiquid. Ranking by
  this metric reproduces the very bias we're avoiding, tilted to gap-prone PSU banks — the worst fit
  for a tight-stop trend-capture.
- **To rank for LIVE, use rupee turnover (price × volume) AND open interest** — neither is in the
  current feed. Ask the dashboard to add a `value_traded` (price×vol) and `open_interest` column
  (near + next). Then rank on those, not contract count.
- **Right use of this feed = BREADTH input for the BACKTEST universe.** Every name on it has real
  futures activity, so all 27 are valid backtest inclusions (alongside cash-99 + the 5 Perplexity
  adds + index). Breadth for backtest; turnover+OI+edge for live.
- **Index caveat:** contract-volume understates index (large lots) — NIFTY 2.87M / BANKNIFTY 478k are
  NOT "less liquid than HDFCBANK 38M"; in rupee/OI terms index leads. But **FINNIFTY futures at 9,766
  is genuinely thin** (FINNIFTY activity is in options) — drop FINNIFTY futures unless its OI says
  otherwise. Index live picks: **NIFTY + BANKNIFTY.**

## Independent-verification caveats (honest)
- Current NSE/MCX OI, spreads and lot sizes remain live-market data to confirm from the dashboard/NSE
  before the live universe is fixed. The contract-volume feed alone is insufficient to rank — it needs
  turnover + OI added (above).
- The backtest universe does not need that live check — it needs breadth. Include a name in the
  backtest if it has *any* durable F&O liquidity; prune to the liquid+edge subset only for live.
