# Cross-segment comparison

| Dimension | CASH | NSEFO | MCX |
|---|---|---|---|
| Primary scheduled path | Wet-run scanner | Graduated futures scanner | Graduated commodity scanner |
| Schedule source default | RUNNING, weekdays 16:00 IST | STOPPED, every 30 minutes 09–15 weekdays | STOPPED, every 30 minutes 09–23 weekdays |
| Instrument identity | NSE equity symbol, fixed wet-run universe | NSE underlying plus exact expiry with FYERS contract ID | MCX commodity source underlying plus expiry, distinct conditional execution mapping |
| Bars | Symbol/TF CSV | Expiry/TF CSV with NSE stitching | Expiry/TF CSV with MCX session-based stitching and E1 |
| Cell permission | Six explicit cells and TF1 exclusion | SW/SW/25 only | Operational hold and empty permit table |
| Candidate path | BUY signal, cash order/bucket | BUY signal, futures order/bucket, conditional isolated TP50 PAPER governor | Held before engine; commodity order/bucket available under conditional code |
| Research | CASH tracking-cell export | Futures Phase-A and expiry-aware replay | E1-aware, contract roll, clean realized-R research |

All three share E/A/X pipeline structure, zone/trend/risk scoring classes, formatter, side policy, exchange gate implementation and parts of storage. CASH and NSEFO use the NSE cash-open alignment in the applicable upstream resampler; MCX alone supplies E1 labels to the shared core. The scope of proof differs for scheduled execution, standalone HTTP results and research replay.
