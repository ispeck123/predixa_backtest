# NSEFO engine execution map

The graduated entrypoint is `apps/pipelines/stock_process.py::future_graduated_scanner_job → future_graduated_scanner_op → scripts/futures_graduated_live_scanner.py::run_graduated_futures_scan`. Its 30-minute, 09–15 weekday IST schedule defaults to STOPPED. `futureScanner` is its CLI handler. The general scheduled scanner is `scripts/scanner_fc.py::SetupScannerOrchestrator_FC.run` with `is_future=True`. The FastAPI path is `apps/backend/api/indian_stock_futures.py::calculate_setup_futures`.

```mermaid
flowchart LR
  U["FuturesMaster, FYERS contract metadata"] --> Exp["build_futures_expiry_map → default_futures_jobs"]
  H["GraduatedPaperFuturesDataHandler / ExpiryRefreshCoordinator"] --> CSV["dated contract OHLC CSVs"]
  J["future_graduated_scanner_job"] --> S["FuturesGraduatedLiveReadonlyScanner.run"]
  Exp --> S
  CSV --> R["run_setup_engine → process_setup_fc with is_future=True"]
  S --> R
  R --> F["format_setup_result → shared cell gate"]
  F --> C["classify_formatted_result → TP50 when PAPER"]
  C --> DB["signal and order/bucket persistence → PAPER governor"]
  C --> Logs["diagnostic and candidate outputs"]
```

- **Contracts and history.** `default_futures_jobs` asks `build_futures_expiry_map` for each strategy stack, deduplicates symbol/expiry/TF, and calls `nsefo_instrument_metadata.resolve_nsefo_contract_metadata` for the dated FYERS symbol, lot size and tick. `scanner_fc` normalizes expiries, accepts strictly more than the minimum days (default 5) and selects up to two eligible contracts. Do not assume calendar or month-end conventions over the provider/master records. Arbitrary `max_symbols` truncation is explicitly rejected by the graduated caller.
- **Preparation.** `future_data_india` drives `GraduatedPaperFuturesDataHandler` from the futures updater base, using `ExpiryRefreshCoordinator` and forced full re-anchor versus incremental work. Dated contract CSVs follow `<underlying>_<DDMMYYYY>_<frame>.csv`, with NSE stitching and weekly/monthly derivation where invoked. In the general scanner, a pending expiry refresh can block before iteration. The updater and general scanner reference different state filenames for the graduated liquid updater versus the general scanner. The selected setup wrapper loads dated series. It does not pass the optional segment or days_to_expiry inputs to SDEnginePipeline.run, so that pipeline’s expiry-distance branch is not engaged by this wrapper. Continuous/stitch helpers in audit paths are evidence for replay and research.
- **Eligibility.** Defaults scan TF1 and 25, while the live NSEFO policy permits only SW/SW/25. The classifier requires NSE futures identity and a valid PAPER/REAL mode, expiry, BUY object and directional price ordering. It evaluates minimum RR on the original far target before the PAPER overlay. The PAPER route additionally requires the Tier-0 cell and uses dated lot/tick metadata. Option-chain utilities exist for market/API features. The traced setup job is a futures contract path.
- **Persistence.** The graduated scanner has injection points for read-only fixtures, but its default flow can persist. `persist_futures_candidate` records `trade_signals`, `future_order_master` and `oms_order_bucket_future`; the Tier-0 PAPER governor can approve an isolated one-lot candidate. TP50 overlay and exit provenance are in `nsefo_tp_overlay.py` and `nsefo_paper_governor.py`. REAL approval and broker execution are downstream and guarded by the mechanical rails. Diagnostic records include invalid inputs, gate/RR rejects, no BUY, unsuccessful signal insertion and processing errors. General `scanner_fc` writes JSONL and qualifying signals, without the graduated order creation path.
- **External prerequisites.** MySQL futures master and execution schemas, approved isolated PAPER connection, dated FYERS symbol master/history and CSV mount. The synthetic engine case exercised the dated CSV route, and the scanner test substitutes provider/engine/writer boundaries.

### Offline observation

The selected fixture ran strategy TF 25 for synthetic `RELIANCE` candles, returned E/A SW/SW, gate CORE and 0 E1 boundaries. The scanner fixture returned `NO_SETUP`. It emitted no actionable side. The shared scoring, ranking and G9 cascade are detailed in [Setup generation flow](../01_ENGINE_ARCHITECTURE/SETUP_GENERATION_FLOW.md); this result alone does not exercise every candidate branch.
