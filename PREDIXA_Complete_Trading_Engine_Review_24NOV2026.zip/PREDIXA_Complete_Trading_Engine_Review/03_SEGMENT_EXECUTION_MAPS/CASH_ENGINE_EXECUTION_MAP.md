# CASH engine execution map

The scheduled entrypoint is `apps/pipelines/stock_process.py::cash_wetrun_scanner_job → cash_wetrun_scanner_op`. The definition at 16:00 weekdays IST defaults to RUNNING in source. The alternate general scanner is `scripts/scanner.py::SetupScannerOrchestrator.run`, wired to stopped-by-default general CASH schedules, and the HTTP setup entrypoint is `apps/backend/api/cash.py::calculate_setup` via `apps.backend.main:app`.

```mermaid
flowchart LR
  Feed["FYERS history and equity master"] --> Up["INDIAN_STOCK_DATA_UPDATER.process_all"]
  Up --> CSV["latest_data_csv by equity and TF"]
  Job["cash_wetrun_scanner_job"] --> Scan["run_cash_wetrun_scanner → SetupScannerOrchestrator.run"]
  CSV --> Engine["process_setup → SDEnginePipeline.run"]
  Scan --> Engine
  Engine --> Format["format_calculate_setup_response → NSE_CASH gate"]
  Format --> Dedup["consumed_zone_suppression → size_for_order"]
  Dedup --> DB["insert_trade_signals → insert_order_and_oms_bucket"]
  Scan --> Log["cash_wetrun_scan_results.jsonl"]
```

- **Inputs and aggregation.** The Dagster `fetch_india_stock_data` op drives `data_fetchers/fyers/indian_stock_data_updater.py::INDIAN_STOCK_DATA_UPDATER.process_all`. `get_stock_details`/history pulls feed per-symbol CSV delta updates and `_build_timeframes_for_tick`. Daily rolls to weekly/monthly, 15-minute to 75-minute and 5-minute to 25/125-minute grids. The stitched NSE grid starts at 09:15 IST. Filenames are `<symbol>_<frame>.csv`. The stock-split checker is separate from setup gap detection.
- **Universe and TF.** `run_cash_wetrun_scanner` iterates its frozen 24-symbol list and stacks 1/2/5/25/6. `shared/config/settings.py::stock_logic_config` holds the stacks. The general scanner has `load_cash_fno_allowlist` and `_apply_cash_fno_gate`, which can use the configured allowlist or stock master F&O metadata. The universe and signal scope differ from the wet-run. See the timeframe and gate reports.
- **Acceptance.** Formatted BUY needs numeric `BUY_RRR >= 2.1` and passes the CASH cell gate, the executed-zone consumption checks and sizing. The consumed-zone path reads prior filled orders and uses canonical signature, overlap/age and tightly conditioned reactivation. `CASH_WETRUN_MODE` leaves the wet-run scoped to a one-share floor for permitted cells. Its active insertion branch is BUY-only. The general scanner has a conditional SELL branch, so its output scope must be read independently of the wet-run.
- **Persistence and revalidation.** Wet-run inserts `trade_signals`; on successful insert it creates an `order_master` candidate and `oms_order_bucket` row through `shared/db/db_utils.py`. Denials/exceptions and suppression details flow into JSONL/logging as applicable. `revalidate_active_trades`, `scripts/scanner.py::revalidate_resting_setups`, `scripts/order_update.py::evaluate_order_status` and `apps/pipelines/miscellaneous_jobs.py::update_order_status_functions` cover adjacent lifecycle. CASH status evaluation consumes processed execution TF candles.
- **External prerequisites.** Stock CSV history, MySQL instrument/signal/order schemas and FYERS auth/history for the production updater. Isolated fixture used local synthetic CSVs, and the CASH policy/dedup unit tests use substitutes. External service and live schedule state are unknown.

### Offline observation

The selected fixture ran strategy TF 25 for synthetic `RELIANCE` candles, returned E/A SW/SW, gate CORE and 0 E1 boundaries. The scanner fixture returned `OK`. It emitted no actionable side. The shared scoring, ranking and G9 cascade are detailed in [Setup generation flow](../01_ENGINE_ARCHITECTURE/SETUP_GENERATION_FLOW.md); this result alone does not exercise every candidate branch.
