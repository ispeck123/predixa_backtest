# MCX engine execution map

The graduated entrypoint is `apps/pipelines/stock_process.py::mcx_graduated_scanner_job → mcx_graduated_scanner_op → scripts/mcx_graduated_live_scanner.py::run_graduated_mcx_scan`. Its 30-minute, 09–23 weekday IST schedule defaults to STOPPED. The general Dagster commodity jobs use `scripts/scanner_fc.py::SetupScannerOrchestrator_FC.run` with `is_future=False` and also default to STOPPED. `scripts/mcx_graduated_live_scanner.py::main` is the CLI handler. The HTTP calculation path is `apps/backend/api/indian_commodity_futures.py::calculate_setup_commodities`.

```mermaid
flowchart LR
  Master["CommoditiesMaster and FYERS metadata"] --> Exp["build_commodity_expiry_map → default_mcx_jobs"]
  Data["MCXFutureDataHandler and ExpiryRefreshCoordinator"] --> CSV["expiry-specific CSV and session-anchored candles"]
  Job["mcx_graduated_scanner_job"] --> Scan["MCXGraduatedLiveScanner.run"]
  Exp --> Scan
  Scan --> Hold["execution permission"]
  Hold -->|snapshot hold| Block["MCX_EXECUTION_BLOCKED / diagnostic JSONL"]
  Hold -->|conditional path| Engine["process_setup_fc with is_future=False → E1 labels"]
  CSV --> Engine
  HTTP["HTTP setup preview"] --> Engine
  Engine --> Format["formatter → MCX gate"]
  Format --> Candidate["classify_mcx_setup → persist_mcx_candidate when allowed"]
  CSV --> Alert["separate mcx_zone_refresh → alert workers"]
```

- **Selection and market data.** `build_commodity_expiry_map` uses commodity master rows and provider metadata, expiry minimum and optional existing-contract paths. `default_mcx_jobs` scopes source underlyings to the MCX gate universe and resolves stack 3/4 by default. `MCXFutureDataHandler.download_all` fetches dated OHLC; normalization and atomic replace guard the refresh. Live setup uses the dated CSV series. Ratio-adjusted stitching and verified roll boundaries are replay inputs. GOLDM/CRUDEOILM source identities and GOLDGUINEA execution routing appear in the conditional proving policy. `mcx_instrument_metadata` resolves provider symbol, exact expiry, lot and tick, including environment-based metadata fallback when configured.
- **Session handling.** E1 normalizes timestamps to IST and splits a close-side bar at or after 21:00 followed on a later day by an open-side bar at or before 09:00. Nonmonotonic timestamps also break continuity. `ZoneDetector`, gap and qualification steps use labeled sessions to avoid crossing the seam. `interval_stitching.stitch_mcx_intraday` anchors at 09:00 or 17:00 for an evening-only session and prevents partial buckets from bridging E1. The `ExchangeCalendar` may use operator-supplied overrides for expiry refresh.
- **Acceptance and hold.** Both scanners deny production setup scanning before engine invocation under `MCX_EXECUTION_SUSPENDED=True`. The shared permission table has empty MCX permits and `gate` has an early DENY return with an operational-hold reason. `MCX_PAPER_OBSERVATION_AUTHORIZED=False` independently holds observation. The conditional classifier checks BUY schema, numeric directional prices, and consistency of calculated versus reported RR. REAL adds minimum RR and proving size/metadata constraints. The latent writer uses `trade_signals`, `commodity_order_master` and `oms_order_bucket_commodity`, with mode/source isolation and preexisting-candidate checks.
- **Observation and alerts.** `paper_observation_runtime` and `paper_observation` are adjacent to the held scanner. The separate `mcx_zone_refresh` path can compute qualified zone bands and publish MySQL snapshots, then tick/Discord workers match, enqueue and deliver alerts. Their existence does not grant trade permission. Alert refresh is operated independently in this snapshot. Live worker configuration and databases were outside the verification.
- **External prerequisites.** FYERS commodity metadata/history, operator calendar if configured, dedicated CSV mount and MySQL. Alert paths additionally use provider ticks, Web Push and Discord delivery configuration. The synthetic MCX case deliberately invoked the offline core via the preview-style path and observed the source hold in the formatter.

### Offline observation

The selected fixture ran strategy TF 4 for synthetic `GOLDM` candles, returned E/A SW/SW, gate DENY and 64 E1 boundaries. The scanner fixture returned `MCX_EXECUTION_BLOCKED`. It emitted no actionable side. The shared scoring, ranking and G9 cascade are detailed in [Setup generation flow](../01_ENGINE_ARCHITECTURE/SETUP_GENERATION_FLOW.md); this result alone does not exercise every candidate branch.
