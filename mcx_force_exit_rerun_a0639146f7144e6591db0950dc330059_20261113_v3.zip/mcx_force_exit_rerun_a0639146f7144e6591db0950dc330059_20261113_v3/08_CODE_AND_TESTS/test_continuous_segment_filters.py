from __future__ import annotations

import csv

import pandas as pd

from audit.derivatives_backtest_common.continuous_segment_filters import (
    LEDGER_COLUMNS,
    export_continuous_segment_filtered,
)
from audit.derivatives_backtest_common.fixed_trade_export import FIXED_TRADE_EXPORT_COLUMNS
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.nsefo_futures_backtest.run_phase_a import Config


def _event(task, timestamp: str, *, entry: str | None = None, exit_: str | None = None, zone_index: int = 2,
           outcome: str = "WIN", exit_reason: str = "Target hit", gross_r: float = 2.0):
    setup = {
        "symbol": "TEST@27102026", "strategy_tf": 2, "direction": "BUY", "setup_timestamp": timestamp,
        "pattern": "test", "zone_id": "Z1", "zone_signature": "test", "proposed_entry": 100.0,
        "proposed_stop": 95.0, "proposed_target": 110.0, "rr": 2.0, "setup_score": 1.0,
        "setup_rank": 1, "eligible": 1, "blocked_reason": None, "permission_state": "ALLOWED",
        "gate_tier": "RESEARCH_BYPASS", "gate_size_multiplier": 1.0, "gate_reason": "research-only",
    }
    if entry:
        setup["trade"] = {
            "symbol": "TEST@27102026", "strategy_tf": 2, "side": "BUY", "scan_timestamp": timestamp,
            "setup_timestamp": timestamp, "entry_timestamp": entry, "exit_timestamp": exit_,
            "entry_price": 100.0, "stop_price": 95.0, "target_price": 110.0, "exit_price": 110.0,
            "outcome": outcome, "exit_reason": exit_reason, "target_hit": int(outcome == "WIN"), "stop_hit": int(outcome == "LOSS"),
            "bars_held": 3, "gross_r": gross_r, "gross_return_pct": 10.0,
            "metrics": {"max_favorable_excursion": 12.0, "max_adverse_excursion": -1.0,
                        "mfe_pct": None, "mae_pct": None, "max_favorable_pct_of_target": 120.0,
                        "bars_to_mfe": 2, "bars_to_mae": 1, "bars_to_exit": 3,
                        "first_positive_bar": 0, "first_negative_bar": 1,
                        "favorable_before_adverse": 1, "outcome_direction": "PERMITTED_DIRECTION"},
        }
    scan = {
        "task_id": task["task_id"], "run_id": task["run_id"], "symbol": "TEST@27102026", "strategy_tf": 2,
        "evaluation_timestamp": timestamp, "cmp": 100.0, "signal_generated": 1, "setup_generated": 1,
        "entry_candidate": 1, "rejection_reason": None, "final_bias": "UP", "allow_long": 1,
        "allow_short": 0, "permitted_setup": "BUY", "trade_type_long": "BUY", "trade_type_short": None,
        "dbr_required": 0, "rbd_required": 0, "htf_veto_longs": 0, "htf_veto_shorts": 0,
        "htf_veto_reason": None, "production_runtime_ms": 1.0, "gate_tier": "RESEARCH_BYPASS",
        "gate_size_multiplier": 1.0, "gate_reason": "research-only", "gate_denied": 0, "raw_json": None,
    }
    zone = {"timeframe": "X", "zone_role": "NEAREST_BZ", "zone_id": "Z1", "zone_type": "BZ",
            "proximal": 95.0, "distal": 90.0, "created_idx": zone_index, "created_timestamp": None,
            "age_bars": 1, "age_class": "FRESH", "retest_count": 0, "penetration_pct": 0.0,
            "state": "GREEN", "invalidated": 0, "violation": 0, "final_score": 1.0,
            "nesting_tier": "X", "session_accepted": 1, "removes_structure": 0,
            "distance_from_cmp_pct": 5.0}
    return {"task": task, "duration_ms": 1.0, "worker_id": "test", "max_retries": 0,
            "result": {"scan": scan, "regime": {"E_regime": "UP", "A_regime": "SW", "X_regime": "UP"},
                       "zones": [zone], "setups": [setup]}}


def test_continuous_filter_is_read_only_and_retains_excluded_ledger(tmp_path):
    storage = SQLiteBacktestStorage(tmp_path / "run.sqlite")
    cfg = Config(run_name="continuous-filter", symbols=("TEST",), tfs=(2,), start="2026-01-01", end="2026-01-10",
                 research_gate_bypass=True, random_seed=20260930)
    run_id = storage.create_run(cfg)
    storage.register_tasks(run_id, [
        {"symbol": "TEST@27102026", "strategy_tf": 2, "strategy_tf_name": "sixty", "evaluation_timestamp": "2026-01-05T22:00:00"},
        {"symbol": "TEST@27102026", "strategy_tf": 2, "strategy_tf_name": "sixty", "evaluation_timestamp": "2026-01-08T12:00:00"},
        {"symbol": "TEST@27102026", "strategy_tf": 2, "strategy_tf_name": "sixty", "evaluation_timestamp": "2026-01-08T22:00:00"},
    ])
    tasks = storage.claim_tasks(run_id, 3)
    storage.save_events([
        _event(tasks[0], "2026-01-05T22:00:00", entry="2026-01-05T22:00:00", exit_="2026-01-06T10:00:00", zone_index=0),
        _event(tasks[1], "2026-01-08T12:00:00", zone_index=2),
        _event(tasks[2], "2026-01-08T22:00:00", entry="2026-01-08T22:00:00", exit_="2026-01-09T10:00:00", zone_index=2,
               outcome="TIME_EXIT", exit_reason="expiry_minus_3_time_exit", gross_r=0.75),
    ])
    before = storage.conn.execute("SELECT COUNT(*) FROM setup_results").fetchone()[0]

    root = tmp_path / "data" / "latest_data_csv"
    root.mkdir(parents=True)
    for frame in ("weekly", "daily", "sixty"):
        pd.DataFrame({"tradeDate": ["02-01-2026", "05-01-2026", "07-01-2026", "08-01-2026", "09-01-2026"]}).to_csv(
            root / f"TEST_27102026_{frame}.csv", index=False
        )
    rolls = tmp_path / "official_rolls.csv"
    with rolls.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["symbol", "roll_date", "verification_status"])
        writer.writeheader()
        writer.writerows([
            {"symbol": "TEST", "roll_date": "2026-01-06", "verification_status": "OFFICIAL_VERIFIED"},
            {"symbol": "TEST", "roll_date": "2026-02-01", "verification_status": "OFFICIAL_VERIFIED"},
        ])
    sessions = tmp_path / "official_sessions.csv"
    with sessions.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["exchange_date", "verification_status"])
        writer.writeheader()
        writer.writerows([
            {"exchange_date": "2026-01-05", "verification_status": "OFFICIAL_VERIFIED"},
            {"exchange_date": "2026-01-06", "verification_status": "OFFICIAL_VERIFIED"},
            {"exchange_date": "2026-01-08", "verification_status": "OFFICIAL_VERIFIED"},
            {"exchange_date": "2026-01-09", "verification_status": "OFFICIAL_VERIFIED"},
        ])
    output = tmp_path / "filtered.csv"
    result = export_continuous_segment_filtered(
        storage.path, run_id, "MCX", output, rolls, data_root=tmp_path / "data", session_calendar=sessions,
    )

    assert result["included_rows"] == 2
    included = pd.read_csv(output)
    ledger = pd.read_csv(output.with_suffix(".csv.filter_ledger.csv"))
    assert list(included.columns) == FIXED_TRADE_EXPORT_COLUMNS
    assert list(ledger.columns) == LEDGER_COLUMNS
    assert len(ledger) == 3
    assert "roll_span" in ledger.loc[0, "exclusion_reason"]
    assert "e1_gap" in ledger.loc[0, "exclusion_reason"]
    assert ledger.loc[1, "filter_status"] == "INCLUDED"
    assert ledger.loc[2, "filter_status"] == "INCLUDED"
    assert "e1_gap" not in str(ledger.loc[2, "exclusion_reason"])
    assert result["force_exit_violation_count"] == 0
    assert result["force_exit_violation_alarm"] is False
    assert storage.conn.execute("SELECT COUNT(*) FROM setup_results").fetchone()[0] == before
