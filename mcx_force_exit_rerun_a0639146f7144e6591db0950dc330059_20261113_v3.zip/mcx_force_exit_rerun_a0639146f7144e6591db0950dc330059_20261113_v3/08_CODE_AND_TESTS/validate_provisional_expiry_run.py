"""Read-only validator for MCX provisional-expiry research replays."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

import pandas as pd

from audit.mcx_futures_backtest.run_provisional_expiry_aware import ProvisionalExpiryMap
from audit.futures_trend_backtest.run_futures_backtest import _crosses_mcx_e1


def validate(storage: Path, run_id: str, expiry_map_path: Path) -> dict:
    uri = f"file:{storage.resolve()}?mode=ro"
    with sqlite3.connect(uri, uri=True) as db:
        db.row_factory = sqlite3.Row
        run = dict(db.execute("SELECT * FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone() or {})
        if not run:
            raise ValueError(f"unknown run: {run_id}")
        symbols = tuple(json.loads(run["config_json"])["symbols"])
        expiry_map = ProvisionalExpiryMap(expiry_map_path, symbols)
        task_counts = dict(db.execute("SELECT status,count(*) n FROM scan_tasks WHERE run_id=? GROUP BY status", (run_id,)).fetchall())
        errors = [dict(row) for row in db.execute("SELECT exception_type,exception_message,count(*) n FROM errors WHERE run_id=? GROUP BY 1,2 ORDER BY n DESC", (run_id,))]
        setups = [dict(row) for row in db.execute("""SELECT su.symbol,su.setup_timestamp,su.eligible,su.blocked_reason
          FROM setup_results su JOIN scan_results s ON s.scan_id=su.scan_id WHERE s.run_id=?""", (run_id,))]
        trades = [dict(row) for row in db.execute("""SELECT t.entry_timestamp,t.exit_timestamp,t.outcome,t.gross_r,s.symbol
          FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?""", (run_id,))]
        duplicate_setups = db.execute("""SELECT count(*) FROM (SELECT t.setup_id,count(*) n FROM simulated_trades t
          JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=? GROUP BY t.setup_id HAVING n>1)""", (run_id,)).fetchone()[0]
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    cutoff_violations, e1_crossings, forced_exit_e1_crossings = [], [], []
    for setup in setups:
        symbol = setup["symbol"].split("@", 1)[0]
        control = expiry_map.control(symbol, setup["setup_timestamp"])
        if setup["eligible"] and pd.Timestamp(setup["setup_timestamp"]).normalize() >= pd.Timestamp(control["entry_cutoff_date"]):
            cutoff_violations.append(setup)
    for trade in trades:
        symbol = trade["symbol"].split("@", 1)[0]
        control = expiry_map.control(symbol, trade["entry_timestamp"])
        if pd.Timestamp(trade["entry_timestamp"]).normalize() >= pd.Timestamp(control["entry_cutoff_date"]):
            cutoff_violations.append({"trade_entry_after_cutoff": trade})
        if _crosses_mcx_e1(trade["entry_timestamp"], trade["exit_timestamp"]):
            # Mandatory expiry-minus-three closes are retained as realized
            # TIME_EXITs; their overnight span is not an E1 violation.
            (forced_exit_e1_crossings if trade["outcome"] == "TIME_EXIT" else e1_crossings).append(trade)
    allowed_warmup = all(item["exception_type"] == "RuntimeError" and "minimum 7 required" in item["exception_message"] for item in errors)
    outcome_counts: dict[str, int] = {}
    for trade in trades:
        outcome_counts[trade["outcome"]] = outcome_counts.get(trade["outcome"], 0) + 1
    blocked_counts: dict[str, int] = {}
    for setup in setups:
        name = setup["blocked_reason"] or "ALLOWED"
        blocked_counts[name] = blocked_counts.get(name, 0) + 1
    passed = run["status"] == "COMPLETED" and integrity == "ok" and not duplicate_setups and not cutoff_violations and not e1_crossings and allowed_warmup
    return {"run_id": run_id, "status": run["status"], "task_counts": task_counts, "integrity_check": integrity,
            "expiry_map": str(expiry_map.path), "expiry_map_sha256": expiry_map.sha256,
            "research_mode": json.loads(run["config_json"])["research_mode"],
            "contract_slot_assumption": json.loads(run["config_json"])["contract_slot_assumption"],
            "setups_by_disposition": blocked_counts, "trades_by_outcome": outcome_counts,
            "time_exit_count": outcome_counts.get("TIME_EXIT", 0), "duplicate_setup_trades": duplicate_setups,
            "cutoff_violations": len(cutoff_violations), "e1_crossing_trades": len(e1_crossings),
            "time_exit_e1_crossings_retained": len(forced_exit_e1_crossings),
            "error_groups": errors, "only_known_warmup_errors": allowed_warmup, "passed": passed}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("run_id"); p.add_argument("--storage", required=True, type=Path); p.add_argument("--expiry-map", required=True, type=Path); p.add_argument("--output", required=True, type=Path)
    a = p.parse_args(argv)
    result = validate(a.storage, a.run_id, a.expiry_map)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    md = a.output.with_suffix(".md")
    md.write_text("\n".join(["# MCX provisional expiry-aware sample validation", "", f"- Run: `{result['run_id']}`", f"- Status: `{result['status']}`", f"- Pass: `{result['passed']}`", f"- SQLite integrity: `{result['integrity_check']}`", f"- Entry-cutoff violations: {result['cutoff_violations']}", f"- E1-crossing discretionary trades: {result['e1_crossing_trades']}", f"- TIME_EXIT trades: {result['time_exit_count']}", f"- TIME_EXIT records retained despite an overnight seam: {result['time_exit_e1_crossings_retained']}", f"- Known warm-up errors only: `{result['only_known_warmup_errors']}`", "", "This is provisional research: the FYERS continuous container is explicitly treated as the observed MCX NEAR slot; the bhavcopy mirror remains pending official validation.", "" ]), encoding="utf-8")
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["passed"] else 2)


if __name__ == "__main__":
    main()
