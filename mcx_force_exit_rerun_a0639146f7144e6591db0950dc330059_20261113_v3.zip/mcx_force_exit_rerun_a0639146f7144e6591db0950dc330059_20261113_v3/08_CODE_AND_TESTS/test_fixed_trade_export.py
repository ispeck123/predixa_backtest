from __future__ import annotations

import json

import pandas as pd

from audit.derivatives_backtest_common.fixed_trade_export import (
    FIXED_TRADE_EXPORT_COLUMNS,
    export_fixed_trade_schema,
)
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.nsefo_futures_backtest.run_phase_a import Config


def _event(task, *, timestamp: str, trade: bool):
    setup = {
        "symbol": "TEST@27102026", "strategy_tf": 2, "direction": "BUY",
        "setup_timestamp": timestamp, "pattern": "test", "zone_id": "z1",
        "zone_signature": "test", "proposed_entry": 100.0, "proposed_stop": 95.0,
        "proposed_target": 110.0, "rr": 2.0, "setup_score": 1.0,
        "setup_rank": 1, "eligible": 1, "blocked_reason": None,
        "permission_state": "ALLOWED", "gate_tier": "RESEARCH_BYPASS",
        "gate_size_multiplier": 1.0, "gate_reason": "research-only",
    }
    if trade:
        setup["trade"] = {
            "symbol": "TEST@27102026", "strategy_tf": 2, "side": "BUY",
            "scan_timestamp": timestamp, "setup_timestamp": timestamp,
            "entry_timestamp": timestamp, "exit_timestamp": timestamp,
            "entry_price": 100.0, "stop_price": 95.0, "target_price": 110.0,
            "exit_price": 110.0, "outcome": "WIN", "exit_reason": "Target hit",
            "target_hit": 1, "stop_hit": 0, "bars_held": 3, "gross_r": 2.0,
            "gross_return_pct": 10.0,
            "metrics": {"max_favorable_excursion": 12.0, "max_adverse_excursion": -1.0,
                        "mfe_pct": None, "mae_pct": None,
                        "max_favorable_pct_of_target": 120.0, "bars_to_mfe": 2,
                        "bars_to_mae": 1, "bars_to_exit": 3,
                        "first_positive_bar": 0, "first_negative_bar": 1,
                        "favorable_before_adverse": 1, "outcome_direction": "PERMITTED_DIRECTION"},
        }
    scan = {
        "task_id": task["task_id"], "run_id": task["run_id"], "symbol": "TEST@27102026",
        "strategy_tf": 2, "evaluation_timestamp": timestamp, "cmp": 100.0,
        "signal_generated": 1, "setup_generated": 1, "entry_candidate": 1,
        "rejection_reason": None, "final_bias": "UP", "allow_long": 1,
        "allow_short": 0, "permitted_setup": "BUY", "trade_type_long": "BUY",
        "trade_type_short": None, "dbr_required": 0, "rbd_required": 0,
        "htf_veto_longs": 0, "htf_veto_shorts": 0, "htf_veto_reason": None,
        "production_runtime_ms": 1.0, "gate_tier": "RESEARCH_BYPASS",
        "gate_size_multiplier": 1.0, "gate_reason": "research-only", "gate_denied": 0,
        "raw_json": None,
    }
    return {"task": task, "duration_ms": 1.0, "worker_id": "test", "max_retries": 0,
            "result": {"scan": scan, "regime": {"E_regime": "UP", "A_regime": "SW", "X_regime": "UP"},
                       "zones": [], "setups": [setup]}}


def test_fixed_export_has_exact_schema_and_is_deterministic(tmp_path):
    storage = SQLiteBacktestStorage(tmp_path / "run.sqlite")
    cfg = Config(run_name="fixed-export", symbols=("TEST",), tfs=(2,), start="2026-01-01", end="2026-01-10",
                 research_gate_bypass=True, random_seed=20260930)
    run_id = storage.create_run(cfg)
    storage.register_tasks(run_id, [
        {"symbol": "TEST@27102026", "strategy_tf": 2, "strategy_tf_name": "sixty", "evaluation_timestamp": "2026-01-02T09:15:00"},
        {"symbol": "TEST@27102026", "strategy_tf": 2, "strategy_tf_name": "sixty", "evaluation_timestamp": "2026-01-08T09:15:00"},
    ])
    tasks = storage.claim_tasks(run_id, 2)
    storage.save_events([
        _event(tasks[0], timestamp="2026-01-02T09:15:00", trade=True),
        _event(tasks[1], timestamp="2026-01-08T09:15:00", trade=False),
    ])
    first, second = tmp_path / "first.csv", tmp_path / "second.csv"
    export_fixed_trade_schema(storage.path, run_id, "NSEFO", first)
    export_fixed_trade_schema(storage.path, run_id, "NSEFO", second)
    one, two = pd.read_csv(first), pd.read_csv(second)
    assert list(one.columns) == FIXED_TRADE_EXPORT_COLUMNS
    assert one.equals(two)
    assert list(one.outcome) == ["WIN", "UNFILLED"]
    assert one.loc[0, "gross_r"] == 2.0
    assert pd.isna(one.loc[1, "gross_r"])
    assert list(one.partition) == ["IS", "OOS"]
    manifest = json.loads(first.with_suffix(".csv.manifest.json").read_text())
    assert manifest["random_seed"] == 20260930
    assert manifest["historical_start"] == "2026-01-01"
    assert manifest["historical_end"] == "2026-01-10"
    mcx = tmp_path / "mcx.csv"
    export_fixed_trade_schema(storage.path, run_id, "MCX", mcx)
    assert list(pd.read_csv(mcx).overnight_dir.unique()) == ["UNKNOWN"]
