"""Deterministic, fixed-schema BUY setup export for audit research runs.

This reader opens replay SQLite evidence read-only. It is intentionally
separate from live/paper order paths and does not change a stored outcome.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

import pandas as pd


FIXED_TRADE_EXPORT_COLUMNS = [
    "symbol", "E_regime", "A_regime", "strategy_tf", "entry", "stop",
    "target", "exit", "outcome", "gross_r", "mfe",
    "max_favorable_pct_of_target", "bars_held", "entry_timestamp",
    "partition", "overnight_dir",
]

NSEFO_STACKS = {
    1: "M-W-D", 2: "W-D-60", 3: "D-75-60-15", 4: "W-D-125",
    5: "D-125-25", 25: "W-D-75",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def midpoint(start: str, end: str) -> pd.Timestamp:
    """Return the deterministic midpoint of the pinned historical window."""
    left = pd.Timestamp(start)
    right = pd.Timestamp(end) + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1)
    if pd.isna(left) or pd.isna(right) or right < left:
        raise ValueError("run config has an invalid historical start/end window")
    return left + (right - left) / 2


def _stack(segment: str, strategy_tf: int, stored: str | None) -> str:
    label = stored or (NSEFO_STACKS.get(int(strategy_tf), f"TF{strategy_tf}"))
    if segment == "NSEFO" and label in {"sixty", "one_twenty_five"}:
        label = NSEFO_STACKS.get(int(strategy_tf), label)
    return f"TF{int(strategy_tf)}:{label}"


def _partition(timestamp: str | None, split: pd.Timestamp) -> str:
    parsed = pd.Timestamp(timestamp)
    if pd.isna(parsed):
        return "UNASSIGNED"
    return "IS" if parsed < split else "OOS"


def export_fixed_trade_schema(storage: Path, run_id: str, segment: str, output: Path) -> dict:
    """Export one stable-schema row per persisted BUY setup.

    `WIN`/`LOSS`/`TIME_EXIT` values and `gross_r` are only copied from resolved persisted
    simulated trades. `UNFILLED`, `UNRESOLVED`, and `BLOCKED` rows are retained
    with a blank realized R so a screen never silently loses its denominator.
    """
    segment = segment.strip().upper()
    if segment not in {"NSEFO", "MCX"}:
        raise ValueError("segment must be NSEFO or MCX")
    if output.exists():
        raise FileExistsError(f"refusing to overwrite export: {output}")
    manifest_path = output.with_suffix(output.suffix + ".manifest.json")
    hash_path = output.with_suffix(output.suffix + ".sha256")
    if manifest_path.exists() or hash_path.exists():
        raise FileExistsError("refusing to overwrite an existing export manifest or checksum")

    db_uri = f"file:{storage.resolve()}?mode=ro"
    with sqlite3.connect(db_uri, uri=True) as db:
        db.row_factory = sqlite3.Row
        run = db.execute("SELECT config_json,historical_start,historical_end,status FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone()
        if run is None:
            raise ValueError(f"unknown run_id: {run_id}")
        config = json.loads(run["config_json"])
        rows = pd.read_sql_query(
            """SELECT su.setup_id, su.symbol, su.strategy_tf, su.setup_timestamp,
                      su.proposed_entry, su.proposed_stop, su.proposed_target,
                      su.eligible, su.blocked_reason, task.strategy_tf_name,
                      r.E_regime, r.A_regime, t.entry_timestamp, t.exit_price,
                      t.outcome AS trade_outcome, t.gross_r, t.bars_held,
                      p.max_favorable_excursion, p.max_favorable_pct_of_target
               FROM setup_results su
               JOIN scan_results s ON s.scan_id=su.scan_id
               JOIN scan_tasks task ON task.task_id=s.task_id
               LEFT JOIN regime_snapshots r ON r.scan_id=s.scan_id
               LEFT JOIN simulated_trades t ON t.setup_id=su.setup_id
               LEFT JOIN trade_path_metrics p ON p.trade_id=t.trade_id
               WHERE s.run_id=? AND su.direction='BUY'
               ORDER BY su.setup_id""",
            db, params=(run_id,))
        persisted_gate_reasons = [
            row[0] for row in db.execute(
                "SELECT DISTINCT gate_reason FROM scan_results WHERE run_id=? AND gate_reason IS NOT NULL ORDER BY gate_reason",
                (run_id,),
            )
        ]

    split = midpoint(run["historical_start"], run["historical_end"])
    exported = []
    for row in rows.itertuples(index=False):
        outcome = row.trade_outcome
        if not outcome:
            outcome = "UNFILLED" if int(row.eligible) else "BLOCKED"
        resolved = outcome in {"WIN", "LOSS", "TIME_EXIT"}
        exported.append({
            "symbol": str(row.symbol).split("@", 1)[0],
            "E_regime": row.E_regime,
            "A_regime": row.A_regime,
            "strategy_tf": _stack(segment, int(row.strategy_tf), row.strategy_tf_name),
            "entry": row.proposed_entry,
            "stop": row.proposed_stop,
            "target": row.proposed_target,
            "exit": row.exit_price,
            "outcome": outcome,
            "gross_r": row.gross_r if resolved else None,
            "mfe": row.max_favorable_excursion,
            "max_favorable_pct_of_target": row.max_favorable_pct_of_target,
            "bars_held": row.bars_held,
            "entry_timestamp": row.entry_timestamp,
            "partition": _partition(row.setup_timestamp, split),
            "overnight_dir": "UNKNOWN" if segment == "MCX" else "NOT_APPLICABLE",
        })
    frame = pd.DataFrame(exported, columns=FIXED_TRADE_EXPORT_COLUMNS)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    manifest = {
        "schema": "PREDIXA_FIXED_BUY_SETUP_EXPORT_V1",
        "columns": FIXED_TRADE_EXPORT_COLUMNS,
        "segment": segment,
        "run_id": run_id,
        "run_status_at_export": run["status"],
        "random_seed": config.get("random_seed"),
        "historical_start": run["historical_start"],
        "historical_end": run["historical_end"],
        "partition_split_timestamp": split.isoformat(),
        "partition_rule": "IS when setup_timestamp is before the pinned midpoint; OOS otherwise",
        "row_order": "setup_id ascending",
        "outcome_rule": "gross_r is populated only for persisted WIN/LOSS/TIME_EXIT outcomes",
        "overnight_dir_rule": "MCX defaults to UNKNOWN without separately approved as-of overlay evidence; NSEFO is NOT_APPLICABLE",
        "research_gate_bypass_config": bool(config.get("research_gate_bypass", False)),
        "research_gate_bypass_evidence": persisted_gate_reasons,
        "row_count": len(frame),
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    digest = sha256(output)
    hash_path.write_text(f"{digest}  {output.name}\n", encoding="utf-8")
    return {"rows": len(frame), "output": str(output), "sha256": digest, "manifest": str(manifest_path)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--run", required=True)
    parser.add_argument("--segment", required=True, choices=("NSEFO", "MCX"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    print(json.dumps(export_fixed_trade_schema(args.storage, args.run, args.segment, args.output), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
