# MCX force-exit rerun — submission summary

## Status: conditional research result, not final signoff

Run `a0639146f7144e6591db0950dc330059` completed with SQLite integrity and quick checks `ok`. The force-exit correction succeeded: `1,343` realized `TIME_EXIT` trades were retained, representing `17.51%` of resolved trades.

| Metric | Corrected MCX rerun | Immutable unfiltered baseline |
|---|---:|---:|
| Resolved trades | 7,671 | 37,482 |
| Gross realized R | -3,021.192332 | -754.045300 |
| Profit factor | 0.489135 | 0.973497 |
| Sequential maximum drawdown R | -3,020.192332 | -3,415.788449 |

The corrected result improves gross R by `-2,267.147032R`, exactly the realized contribution of retained mandatory expiry exits. It supersedes the prior zero-TIME_EXIT expiry-aware run for diagnostic comparison.

### Remaining blocker

`28` SILVERM trades entered on Sunday `2026-02-01`, a date without a same-day MCX bhavcopy observation. They are listed in `04_RULE_COMPLIANCE/invalid_or_unmapped_entry_sessions.csv`. A session-bar guard is required before this can be called final MCX research output. The package deliberately preserves rather than deletes those source-run rows.
