# MCX expiry−3 force-exit correction — validation record

Date: 2026-11-12  
Scope: audit/research MCX expiry-aware runner only. NSEFO is unchanged.

## Disposition

The completed MCX expiry-aware run `fb7f4c2bef4743cb91b278fcb4c7b7a0` is retained as immutable, superseded diagnostic evidence. It must not be used as a performance result because it has zero `TIME_EXIT` rows.

## Evidence-led root cause

The MCX runner already attached a populated `expiry_control` to the shared resolver. A direct dispatch probe confirmed `entry_cutoff_date=2026-10-29`, `force_exit_date=2026-11-02`, and `exclude_e1_gap=true` for the GOLDM November-2026 near segment.

The actual defect was priority, not loss of the date in the MCX runner: the resolver reached expiry−3, then returned `UNFILLED/e1_gap` before it could persist the mandatory close. Any MCX position that survives from a permitted pre-cutoff entry through expiry−3 necessarily crosses the E1 overnight seam, so the old precedence made a nonzero MCX `TIME_EXIT` count impossible.

## Correction

- `audit/futures_trend_backtest/run_futures_backtest.py`: the locked expiry−3 mandatory close is authoritative and books `TIME_EXIT` at the first executable force-exit bar. MCX E1 remains applied to discretionary target/stop outcomes.
- `audit/derivatives_backtest_common/continuous_segment_filters.py`: a post-force exit is now exposed by `force_exit_violation_count` and `force_exit_violation_alarm` in the read-only export manifest and command result. It is no longer silent.
- No live/paper gate, production trading path, SQLite database, or OHLC source file was modified.

## End-to-end affected-case probe

The probe used an existing historical MCX task without writing to its SQLite database:

- Prior run/task: `fb7f4c2bef4743cb91b278fcb4c7b7a0` / `4450`
- Symbol/TF: `GOLDM@04122026`, TF2 (W-D-60)
- Setup timestamp: `2024-05-23T22:00:00`
- Historical near: `FUTCOM:GOLDM:05JUN2024`
- Entry cutoff: `2024-05-29`; force exit: `2024-05-31`
- Replayed entry: `2024-05-23T23:00:00`
- Replayed forced exit: `2024-05-31T09:00:00`
- Outcome: `TIME_EXIT`; reason `expiry_minus_3_time_exit`; realized `gross_r=0.7338595167007881`

## Automated checks

```text
PYTHONPATH=. pytest -q \
  tests/derivatives_backtest/test_expiry_session_controls.py \
  tests/derivatives_backtest/test_continuous_segment_filters.py \
  tests/derivatives_backtest/test_fixed_trade_export.py

5 passed
```

The targeted unit test proves that a force-exit remains a realized `TIME_EXIT` even when the MCX E1 flag is enabled. The read-only filter test proves a zero post-force alarm is surfaced in its return data.

## Required acceptance for the fresh MCX run

Run a new MCX expiry-aware SQLite database and fixed-schema export with the same seed/map. Accept only if:

1. `TIME_EXIT > 0` (the prior zero result is invalid);
2. its resolved-trade share is assessed against the expected roughly 14% NSEFO reference, with any material difference reported rather than concealed;
3. `force_exit_violation_alarm=false` / count `0` in the final export manifest;
4. entry-cutoff and E1 reporting remain explicit; and
5. the fresh database passes `PRAGMA integrity_check`.

