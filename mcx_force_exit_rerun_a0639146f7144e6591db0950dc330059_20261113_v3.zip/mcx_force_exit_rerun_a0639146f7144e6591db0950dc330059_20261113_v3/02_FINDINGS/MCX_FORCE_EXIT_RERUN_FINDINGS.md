# Findings, controls, and limitations

## Corrected control behavior

- Entry cut-off: no entry on/after expiry minus five observed trading sessions; violations `0`.
- Mandatory force exit: expiry minus three; trades exiting after it `0`.
- MCX E1: discretionary seam crossings `0`. Mandatory TIME_EXIT records crossing the seam are retained (`1343`), because expiry flatten is authoritative.
- Post-filter force-exit alarm: `False`; count `0`.
- Duplicate persisted trade setups: `0`.

## Failures retained, not hidden

The run has `957` failed tasks. `failure_summary.csv` separates expected E-timeframe warm-up insufficiency from `85` source-cell `single positional indexer is out-of-bounds` failures. No failure was converted to a trade.

## Market-data and expiry-evidence limits

- Existing FYERS continuous OHLC remains unchanged. Current filename dates were not treated as historical expiry dates.
- The FYERS continuous container is treated as the observed NEAR slot; this is a persisted research assumption, not individual-contract proof.
- The MCX map is a bhavcopy mirror with status `MIRROR_OF_MCX_BHAVCOPY_PENDING_OFFICIAL_VALIDATION`, not official-owner verified evidence.
- The Sunday SILVERM entries show that resolution bars also require a same-day session guard. Therefore this package is for transparent research submission and corrective follow-up, not live/paper promotion or final performance certification.
