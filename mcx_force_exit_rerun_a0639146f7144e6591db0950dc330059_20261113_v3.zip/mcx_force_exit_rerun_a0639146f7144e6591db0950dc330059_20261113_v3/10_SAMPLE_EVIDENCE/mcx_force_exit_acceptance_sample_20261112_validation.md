# MCX provisional expiry-aware sample validation

- Run: `be278d36670f4f5c98f7c761a2c7cbfd`
- Status: `COMPLETED`
- Pass: `True`
- SQLite integrity: `ok`
- Entry-cutoff violations: 0
- E1-crossing discretionary trades: 0
- TIME_EXIT trades: 6
- TIME_EXIT records retained despite an overnight seam: 6
- Known warm-up errors only: `True`

This is provisional research: the FYERS continuous container is explicitly treated as the observed MCX NEAR slot; the bhavcopy mirror remains pending official validation.
