# Entry Regime / Permission Analysis

Completed trades analyzed: 22

## (E, A) state summary

| E regime | A regime | Trades | Permitted-direction outcomes | Against-direction outcomes |
|---|---:|---:|---:|---:|
| SW | UP | 5 | 0 | 5 |
| UP | SW | 7 | 1 | 6 |
| UP | UP | 10 | 3 | 7 |

## Interpretation

The `outcome_direction` column uses the fresh evaluator result: target hit = permitted direction; stop hit = against trade direction. `first_unambiguous_move` and `dominant_excursion_direction` are path-based controls, because a stop-loss outcome alone does not prove the price never first moved favorably.

A state should only be called systematic if it has repeated observations and a consistently high against-direction rate. This dataset is small; states with one or very few trades are descriptive, not statistically conclusive.
