# Verified API references

- Official Sharekhan API FAQ: https://www.sharekhan.com/faq/API — advertises continuous F&O data and notes EOD scrip-wise data since inception/intraday availability wording.
- Official Sharekhan technical documentation: https://www.sharekhan.com/trading-api/documentation — Historical Chart Data topic.
- Installed Sharekhan Python SDK source (see `07_REPRODUCIBILITY/SOURCE_PROVENANCE.md`): `historicaldata(exchange, scripcode, interval)` to `/skapi/services/historical/{exchange}/{scripcode}/{interval}`; no verified continuous selector or date-range parameters.
- Official FYERS History API support: https://support.fyers.in/portal/en/kb/fyers-api-integrations/fyers-api/api-v3/data-api — timestamp start semantics and supported history API.
