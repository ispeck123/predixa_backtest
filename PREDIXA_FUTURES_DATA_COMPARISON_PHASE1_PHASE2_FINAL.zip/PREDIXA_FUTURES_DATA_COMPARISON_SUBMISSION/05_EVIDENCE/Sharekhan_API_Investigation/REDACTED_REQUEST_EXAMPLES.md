# Redacted request examples (observed parameters only)

## FYERS history

```json
{"symbol":"MCX:CRUDEOILM26OCTFUT","resolution":"60","date_format":"1","range_from":"2025-10-09","range_to":"2025-12-30","cont_flag":"1"}
```

Raw mode used the same verified dated symbol with `cont_flag=0`. Other retrieved intervals used `resolution=240` or `resolution=D`. Auth headers and credentials are intentionally omitted.

## Sharekhan history

Documented/read-only call: `historicaldata("MX", 569901, "60minute")` for the verified CRUDEOILM 19-Oct-2026 dated contract; `historicaldata("MX", 495213, "daily")` for the verified GOLD 04-Dec-2026 scrip. The SDK exposes no date range or continuous flag. No authorization header, token, customer/client identifier, or account data is included.
