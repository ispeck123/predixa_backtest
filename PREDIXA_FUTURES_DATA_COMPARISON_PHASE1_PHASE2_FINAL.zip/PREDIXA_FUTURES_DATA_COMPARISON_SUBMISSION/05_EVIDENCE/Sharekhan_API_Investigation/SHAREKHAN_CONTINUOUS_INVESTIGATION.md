# Sharekhan continuous futures history investigation

Investigation date: 2026-10-09 (Asia/Kolkata)

## Finding

Sharekhan's official [API FAQ](https://www.sharekhan.com/faq/API) does claim that its API provides continuous data for F&O contracts. It separately says F&O EOD data is available since inception and intraday history for the last 7 days. The FAQ does not define the continuous request syntax, instrument identifier, supported instruments, adjustment method, or whether the seven-day statement applies to continuous intraday data.

The official [Historical Chart Data documentation](https://www.sharekhan.com/trading-api/documentation) and installed Python SDK do not expose a continuous selector or a dedicated continuous endpoint. The documented GET request is:

```text
https://api.sharekhan.com/skapi/services/historical/{exchange}/{scripcode}/{interval}
```

The documented request fields are only `exchange`, broker `scripcode`, and `interval`. Supported intervals include `60minute` and go up to `90minute`. There are no documented start/end date, continuous flag, adjustment flag, or roll-rule parameters. The Python SDK is `historicaldata(exchange, scripcode, interval)` and resolves to this endpoint. The rendered documentation's public topic is `TopicId=13, SubTopicId=27, CodeTypeId=2`.

## CRUDEOILM-specific verification

The authenticated `master("MX")` response contained 25,413 instruments. Exact `tradingSymbol=CRUDEOILM` records were options and individual dated futures. The future records carried expiry dates and scrip codes, including:

| Scrip code | Contract expiry | Master type |
|---:|---|---|
| 569901 | 19-Oct-2026 | `FS`, `FUT` |
| 573423 | 19-Nov-2026 | `FS`, `FUT` |

No exact-symbol non-expiring futures row or record explicitly named continuous was found. The broader FAQ claim may mean the feature exists in some F&O use cases, but its identifier and applicability to MCX CRUDEOILM cannot be established from the master or documented historical request.

Read-only history calls to both verified dated codes using `historicaldata("MX", code, "60minute")` returned 397 rows apiece for 2026-09-01 through 2026-10-08. Their same-time prices differ, consistent with separate dated expiries. This verifies that passing those contract codes fetches expiry-specific histories; it does not identify a continuous-series code.

No separate official continuous-history endpoint or continuous instrument identifier for CRUDEOILM was found in the official docs, SDK routes, or MCX master response.

## Seven-day history statement

The FAQ wording says "Intraday data for last 7 days is available as well." The authenticated 60-minute request for scrip code `569901`, made 2026-10-09, returned 397 candles across 27 distinct trading dates from 2026-09-01 to 2026-10-08 (38 calendar days). Thus the observed dated-contract 60-minute response exceeds seven calendar days. This contradicts or qualifies the FAQ's broad seven-day wording for this specific call. Because the endpoint has no date inputs, this observation describes its returned default window; it does not prove that older ranges can be requested or that continuous intraday data has the same retention.

## Roll and adjustment methodology

The FAQ says Sharekhan historical data is not adjusted for corporate actions. That statement does not document futures back-adjustment. Neither the FAQ nor the historical chart specification describes the continuous-series roll rule, whether it is adjusted or unadjusted, or the timestamp at which a contract switch occurs. Since no CRUDEOILM continuous series could be identified or returned, these behaviors remain unknown.

## Phase 1 impact and exact blocker

No Sharekhan continuous 60-minute OHLCV file was created. The previously retrieved Sharekhan October dated-contract file is valid as a raw expiry comparison only. The exact unresolved requirement is a Sharekhan-provided continuous-contract mapping/request instruction for MCX CRUDEOILM, including its identifier and confirmation of timeframe/history availability. Without that documented mapping, trying codes or query parameters by guess would not be a verified API pull.

Even if the continuous identifier is supplied, the documented endpoint has no date-range arguments. The observed default history reaches only 2026-09-01, short of the Fyers comparison sample's 2026-07-01 start and far short of the requested 2025-10-09 start. Sharekhan must clarify the supported retrieval mechanism and available archive range for the required period.

## Evidence and reproduction

- FAQ: [sharekhan.com/faq/API](https://www.sharekhan.com/faq/API)
- Official API documentation page: [sharekhan.com/trading-api/documentation](https://www.sharekhan.com/trading-api/documentation)
- SDK source installed in this environment: `SharekhanApi/sharekhanConnect.py`; `historicaldata()` delegates to `api.historical.data`, mapped to `/skapi/services/historical/{exchange}/{scripcode}/{interval}`.
- Live MCX master results: [sharekhan_master_probe.json](metadata/sharekhan_master_probe.json)
- Dated October response and metadata: [SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.csv](data/SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.csv), [metadata](metadata/SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.json)

No credentials or complete raw master response are included in the research artifacts. No application code was changed.
