# Deliverable checklist

- [x] Verified broker-native OHLCV exports and metadata included
- [x] Phase 1 raw-vs-continuous analysis, same-expiry broker check, calendar and limitation evidence included
- [x] Phase 2 CRUDEOILM/GOLD 60m/240m/daily FYERS comparisons included where valid data exists
- [x] Sharekhan continuous and native 240m explicitly unavailable through verified path
- [x] Markdown and PDF reports generated
- [x] Data-quality, coverage, comparison and integrity manifests included
- [x] Credential scan and ZIP integrity checks recorded in final QA report
