# Limitations and exceptions

- Sharekhan continuous history is advertised generically but no verified MCX continuous identifier/request convention was exposed through the documented SDK/master path.
- Sharekhan native 240m is absent from documented intervals (max 90m); no native 240m claims.
- Sharekhan daily calls for dated scrip codes include dates years before expiry, leaving historical contract mapping unresolved.
- FYERS continuous roll and any back-adjustment method are undocumented.
- FYERS raw histories begin at their returned earliest valid candles; missing earlier periods are not filled.
- Sharekhan intraday timestamps are inferred to represent interval end; hourly cross-broker pairing is inferred.
- Volume units across brokers and across continuous/raw series are not proven comparable.
- Predixa zone output was not run or recreated; findings concern potential absolute-price displacement.
