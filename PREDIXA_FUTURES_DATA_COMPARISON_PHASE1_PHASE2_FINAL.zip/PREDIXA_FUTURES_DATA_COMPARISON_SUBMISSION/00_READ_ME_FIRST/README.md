# Predixa futures comparison submission

Start with `EXECUTIVE_SUMMARY.pdf`, then `../01_FINAL_REPORTS/CONSOLIDATED_FINAL_REPORT.pdf`. Raw broker CSVs and sidecar metadata are organized by instrument/timeframe. `05_EVIDENCE/` documents Sharekhan continuous limitation and symbol mapping; `06_VALIDATION/` contains row-level analysis and quality checks; `07_REPRODUCIBILITY/` contains scripts and methods. Missing Sharekhan continuous data is documented, never fabricated.
