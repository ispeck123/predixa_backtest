# Predixa futures data comparison — executive summary

# Predixa — Final Historical Futures Data Comparison & Zone-Series Assessment

## Executive decision summary

Observed FYERS CRUDEOILM raw-vs-continuous divergence over 1302 identical 60m timestamps is mean absolute ₹208.61, p95 ₹531.95, max ₹1,280.00; raw-minus-continuous mean is ₹-199.20. These offsets are large enough to be a credible material risk for absolute historical zone coordinates. The evidence supports continuous-series input for further offline zone testing, but not a production change.

The complete requested Sharekhan continuous comparison remains unexecuted. FYERS provides more complete continuous coverage; dated raw availability begins later. Sharekhan’s same-expiry intraday raw feeds corroborate prices on a short recent overlap, but Sharekhan daily histories expose pre-expiry dates and cannot safely be classified as raw. No actual Predixa zone output changes were tested.

