# Source provenance

- FYERS official API support: https://support.fyers.in/portal/en/kb/fyers-api-integrations/fyers-api/api-v3/data-api (history timestamps are candle starts; symbol master is linked there).
- Sharekhan official FAQ: https://www.sharekhan.com/faq/API (continuous F&O claim; intraday-history wording).
- Sharekhan technical docs: https://www.sharekhan.com/trading-api/documentation.
- MCX Gold product/circulars: https://www.mcxindia.com/products/bullion/gold.
- CRUDEOILM expiry dates retained in the existing sourced calendar and dated broker master.

No screenshot was created. Redacted request parameters, actual returned-data manifests, master excerpts and metadata are the evidence.
