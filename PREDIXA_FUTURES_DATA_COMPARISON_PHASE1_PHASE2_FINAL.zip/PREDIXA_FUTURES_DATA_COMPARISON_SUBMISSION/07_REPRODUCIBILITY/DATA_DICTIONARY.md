# Data dictionary

`timestamp_ist`: broker timestamp converted/preserved as Asia/Kolkata ISO-8601 offset; `open`, `high`, `low`, `close`: source prices; `volume`: source quantity, unit comparability not assumed. Comparison CSV fields suffix `_a`/`_b` identify pair sides and `close_diff` is A−B. Sharekhan derived 240m, if present, is never a broker-native file and contains a source-row count and partial-bin flag.
