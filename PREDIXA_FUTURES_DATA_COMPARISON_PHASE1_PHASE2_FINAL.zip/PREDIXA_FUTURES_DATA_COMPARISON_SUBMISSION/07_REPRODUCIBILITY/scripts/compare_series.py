#!/usr/bin/env python3
"""Offline, non-trading validation for the CRUDEOILM research exports."""
from __future__ import annotations

import csv
import json
import math
import argparse
from datetime import datetime
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "research" / "zone_series_comparison"
DATA, COMP, CHARTS = BASE / "data", BASE / "comparisons", BASE / "charts"

def read(name: str) -> pd.DataFrame | None:
    path = DATA / name
    if not path.exists(): return None
    frame = pd.read_csv(path)
    if frame.empty: return frame
    frame["timestamp_ist"] = pd.to_datetime(frame["timestamp_ist"], utc=True).dt.tz_convert("Asia/Kolkata")
    for col in ("open", "high", "low", "close", "volume"): frame[col] = pd.to_numeric(frame[col], errors="coerce")
    return frame.sort_values("timestamp_ist").drop_duplicates("timestamp_ist", keep="last")

def compare(left: pd.DataFrame, right: pd.DataFrame, left_name: str, right_name: str) -> tuple[pd.DataFrame, dict]:
    merged = left.merge(right, on="timestamp_ist", how="inner", suffixes=("_left", "_right"))
    for field in ("open", "high", "low", "close"):
        merged[f"{field}_difference"] = merged[f"{field}_left"] - merged[f"{field}_right"]
    merged["absolute_close_difference"] = merged["close_difference"].abs()
    merged["percentage_close_difference"] = np.where(merged["close_right"] != 0, merged["close_difference"] / merged["close_right"] * 100, np.nan)
    d = merged["close_difference"].dropna()
    a = d.abs()
    stats = {"left_series": left_name, "right_series": right_name, "signed_difference_convention": f"{left_name} minus {right_name}",
             "left_candle_count": len(left), "right_candle_count": len(right), "common_timestamps": len(merged),
             "left_non_overlapping_timestamps": len(left) - len(merged), "right_non_overlapping_timestamps": len(right) - len(merged),
             "percentage_left_bars_matched": (len(merged) / len(left) * 100) if len(left) else None,
             "average_signed_close_difference": d.mean(), "median_signed_close_difference": d.median(),
             "maximum_absolute_close_difference": a.max(), "p95_absolute_close_difference": a.quantile(.95),
             "mean_absolute_error": a.mean(), "rmse": math.sqrt((d ** 2).mean()) if len(d) else None,
             "close_correlation": merged["close_left"].corr(merged["close_right"]),
             "mean_percentage_close_difference": merged["percentage_close_difference"].mean()}
    stats["ohlc_signed_difference_summary"] = {
        field: {"mean": merged[f"{field}_difference"].mean(), "median": merged[f"{field}_difference"].median(),
                "maximum_absolute": merged[f"{field}_difference"].abs().max()}
        for field in ("open", "high", "low", "close")}
    if "volume_left" in merged and "volume_right" in merged:
        v = merged[["volume_left", "volume_right"]].dropna()
        if not v.empty:
            delta = v["volume_left"] - v["volume_right"]
            stats["volume_comparison"] = {"rows": int(len(v)), "left_minus_right_mean": float(delta.mean()),
                                           "left_minus_right_median": float(delta.median()),
                                           "mean_absolute_difference": float(delta.abs().mean()),
                                           "maximum_absolute_difference": float(delta.abs().max())}
    return merged, {key: (None if pd.isna(value) else float(value) if isinstance(value, (np.floating, float)) else int(value) if isinstance(value, np.integer) else value) for key, value in stats.items()}

def save_comparison(df: pd.DataFrame, name: str):
    converted = df.copy()
    converted["timestamp_ist"] = converted["timestamp_ist"].map(lambda x: x.isoformat())
    converted.to_csv(COMP / name, index=False)

def line_chart(frame: pd.DataFrame, series: list[tuple[str, str]], filename: str, title: str):
    plt.figure(figsize=(15, 6))
    for col, label in series: plt.plot(frame["timestamp_ist"], frame[col], lw=.8, label=label)
    plt.title(title + "\nMCX CRUDEOILM | 60-minute candles | timestamps in Asia/Kolkata | price: INR per barrel")
    plt.xlabel("Timestamp (IST)"); plt.ylabel("Price"); plt.legend(); plt.grid(alpha=.25); plt.tight_layout()
    plt.savefig(CHARTS / filename, dpi=160); plt.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="Allow replacing existing comparison outputs")
    force = parser.parse_args().force
    COMP.mkdir(parents=True, exist_ok=True); CHARTS.mkdir(parents=True, exist_ok=True)
    raw, cont, sk = read("CRUDEOILM_19OCT_raw_60m.csv"), read("CRUDEOILM_CONT_flag1_60m.csv"), read("CRUDEOILM_SK_CONT_60m.csv")
    sk_dated = read("SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.csv")
    expected = [COMP / "comparison_summary.json", COMP / "fyers_raw_vs_continuous.csv", COMP / "fyers_vs_sharekhan_continuous.csv", COMP / "fyers_raw_vs_sharekhan_dated.csv"]
    expected += [CHARTS / name for name in ("raw_vs_continuous.png", "raw_continuous_difference.png", "expiry_roll_inspection.png", "continuous_comparison.png", "data_completeness.png", "fyers_raw_vs_sharekhan_dated.png")]
    existing = [str(p) for p in expected if p.exists()]
    if existing and not force:
        raise FileExistsError("Refusing to overwrite comparison outputs; rerun with --force")
    summary = {"generated_at_ist": datetime.now().astimezone().isoformat(), "datasets_present": {"fyers_raw": raw is not None, "fyers_continuous": cont is not None, "sharekhan_continuous": sk is not None, "sharekhan_dated_oct2026": sk_dated is not None}}
    if raw is not None and cont is not None and not raw.empty and not cont.empty:
        merged, stats = compare(raw, cont, "Fyers raw dated 19-Oct-2026", "Fyers continuous cont_flag=1")
        save_comparison(merged, "fyers_raw_vs_continuous.csv"); summary["fyers_raw_vs_continuous"] = stats
        line_chart(merged, [("close_left", "Fyers raw dated"), ("close_right", "Fyers continuous")], "raw_vs_continuous.png", "Raw dated contract versus FYERS continuous")
        line_chart(merged, [("close_difference", "Raw − continuous close")], "raw_continuous_difference.png", "Raw-to-continuous signed close-price difference")
        # This is an expiry-focused view, not a claim about the FYERS roll date.
        focus = merged[merged["timestamp_ist"] >= pd.Timestamp("2026-09-14", tz="Asia/Kolkata")]
        if not focus.empty:
            line_chart(focus, [("close_left", "Fyers raw dated"), ("close_right", "Fyers continuous")], "expiry_roll_inspection.png", "Inspection around verified 21-Sep-2026 CRUDEOILM expiry; FYERS roll date undocumented")
    if cont is not None and sk is not None and not cont.empty and not sk.empty:
        merged, stats = compare(cont, sk, "Fyers continuous cont_flag=1", "Sharekhan continuous")
        save_comparison(merged, "fyers_vs_sharekhan_continuous.csv"); summary["fyers_vs_sharekhan_continuous"] = stats
        line_chart(merged, [("close_left", "FYERS continuous"), ("close_right", "Sharekhan continuous")], "continuous_comparison.png", "FYERS versus Sharekhan continuous series")
    if raw is not None and sk_dated is not None and not raw.empty and not sk_dated.empty:
        # FYERS timestamps are on the hour (bar start); Sharekhan timestamps
        # are at :59:xx (bar-end trade time). Floor to hour is an explicit,
        # inferred interval pairing, not an exact timestamp match.
        left = raw.copy(); right = sk_dated.copy()
        left["timestamp_ist"] = left["timestamp_ist"].dt.floor("h")
        right["timestamp_ist"] = right["timestamp_ist"].dt.floor("h")
        merged, stats = compare(left, right, "Fyers raw 19-Oct-2026", "Sharekhan raw 19-Oct-2026")
        stats["alignment_method"] = "inferred hourly interval pairing: Fyers on-the-hour bar-start timestamps; Sharekhan :59:xx tradeTime floored to hour"
        stats["comparison_type"] = "same dated expiry across brokers; not continuous-vs-continuous"
        save_comparison(merged, "fyers_raw_vs_sharekhan_dated.csv")
        summary["fyers_raw_vs_sharekhan_dated"] = stats
        line_chart(merged, [("close_left", "FYERS raw 19-Oct-2026"), ("close_right", "Sharekhan raw 19-Oct-2026")], "fyers_raw_vs_sharekhan_dated.png", "Same dated CRUDEOILM contract across brokers; inferred hourly alignment")
    # Availability chart makes lack of Dataset C explicit instead of fabricating it.
    plt.figure(figsize=(15, 3.5)); labels = []
    for y, (label, frame) in enumerate((("FYERS raw", raw), ("FYERS continuous", cont), ("Sharekhan continuous", sk), ("Sharekhan raw 19-Oct-2026", sk_dated))):
        labels.append(label)
        if frame is not None and not frame.empty: plt.scatter(frame["timestamp_ist"], np.full(len(frame), y), s=2, label=label)
    plt.yticks(range(len(labels)), labels); plt.title("Data completeness | MCX CRUDEOILM | 60-minute | timestamps in Asia/Kolkata")
    plt.xlabel("Timestamp (IST)"); plt.grid(alpha=.25); plt.tight_layout(); plt.savefig(CHARTS / "data_completeness.png", dpi=160); plt.close()
    (COMP / "comparison_summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")

if __name__ == "__main__": main()
