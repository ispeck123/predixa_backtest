#!/usr/bin/env python3
"""Read-only Sharekhan MX master probe; never writes credentials or raw master data."""
from __future__ import annotations
import argparse, json, os, re
from pathlib import Path
from sqlitedict import SqliteDict

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "research" / "zone_series_comparison" / "metadata"

def token_from_sources():
    token = os.getenv("SHAREKHAN_ACCESS_TOKEN")
    if token: return token
    with SqliteDict(str(ROOT / "finprod.sqlite"), flag="r") as db:
        return db["access_json"]["data"]["token"]

def api_key():
    value = os.getenv("SHAREKHAN_API_KEY")
    if value: return value
    text = (ROOT / "apps/finprod_backend/endpoints/token.py").read_text()
    return re.search(r'api_key\s*=\s*"([^"]+)"', text).group(1)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--exchange", default="MX"); ap.add_argument("--needle", default="CRUDEOILM")
    args = ap.parse_args()
    from SharekhanApi.sharekhanConnect import SharekhanConnect
    client = SharekhanConnect(api_key(), access_token=token_from_sources())
    response = client.master(args.exchange)
    if isinstance(response, dict):
        records = response.get("data") if isinstance(response.get("data"), list) else []
        matches = [r for r in records if args.needle.upper() in str(r.get("tradingSymbol", "")).upper()
                   and str(r.get("optionType", "")).upper() == "FUT"]
        raw_size = len(json.dumps(response, separators=(",", ":")).encode())
        header = "dict response; fields=" + ",".join(sorted(records[0])) if records else None
    else:
        raw_size = len(response)
        header, matches = None, []
    result = {"exchange": args.exchange, "http_response_type": type(response).__name__,
              "response_bytes": raw_size, "header": header,
              "match_count": len(matches), "matches": matches[:100]}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "sharekhan_master_probe.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "matches"}, indent=2))
    for row in matches[:20]: print(json.dumps(row, separators=(",", ":")))
    return 0
if __name__ == "__main__": raise SystemExit(main())
