#!/usr/bin/env python3
"""Research-only FYERS OHLCV fetcher for 60m, 240m, and daily history."""
from __future__ import annotations
import argparse, csv, json, random, sys, time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "research" / "zone_series_comparison"
IST = ZoneInfo("Asia/Kolkata")

def client():
    sys.path.insert(0, str(ROOT))
    from data_fetchers.fyers.fyers_session import fyers_access_token_handler
    from fyers_apiv3 import fyersModel
    credential = fyers_access_token_handler().get_access_token()
    if not credential or ":" not in credential:
        raise RuntimeError("FYERS token handler unavailable")
    appid, token = credential.rsplit(":", 1)
    return fyersModel.FyersModel(client_id=appid, token=token, is_async=False, log_path="")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", required=True)
    p.add_argument("--continuous", choices=("0", "1"), required=True)
    p.add_argument("--resolution", choices=("60", "240", "D"), required=True)
    p.add_argument("--start", default="2025-10-09")
    p.add_argument("--end", default="2026-10-08")
    p.add_argument("--expiry")
    p.add_argument("--output", required=True)
    p.add_argument("--metadata", required=True)
    p.add_argument("--force", action="store_true")
    a = p.parse_args()
    start, end = date.fromisoformat(a.start), date.fromisoformat(a.end)
    out, meta = BASE / "data" / a.output, BASE / "metadata" / a.metadata
    if (out.exists() or meta.exists()) and not a.force:
        raise FileExistsError("Output exists; use --force to replace deliberately")
    out.parent.mkdir(parents=True, exist_ok=True); meta.parent.mkdir(parents=True, exist_ok=True)
    api = client(); raw=[]; failures=[]; batches=[]
    left=start
    while left <= end:
        right=min(left+timedelta(days=89), end)
        req={"symbol":a.symbol,"resolution":a.resolution,"date_format":"1","range_from":left.isoformat(),"range_to":right.isoformat(),"cont_flag":a.continuous}
        for attempt in range(4):
            try:
                res=api.history(data=req)
                if isinstance(res,dict) and "candles" in res:
                    candles=res["candles"] or []; raw.extend(candles)
                    batches.append({**req,"returned_candles":len(candles)})
                    break
                msg=(res or {}).get("message","non-candle response") if isinstance(res,dict) else "non-dict response"
                if any(x in msg.lower() for x in ("token","auth","permission")):
                    raise RuntimeError("FYERS authentication/permission response")
                raise RuntimeError("FYERS history request returned no candles: "+msg[:200])
            except Exception as e:
                if attempt==3: failures.append({"range_from":left.isoformat(),"range_to":right.isoformat(),"error":str(e)[:300]})
                else: time.sleep(min(8,2**attempt)+random.random())
        left=right+timedelta(days=1); time.sleep(.25)
    by_epoch={}
    dups=0
    for c in raw:
        if len(c)<6: continue
        t=int(c[0]); dups += int(t in by_epoch); by_epoch[t]=c
    rows=[]
    for t,c in sorted(by_epoch.items()):
        rows.append({"timestamp_ist":datetime.fromtimestamp(t,timezone.utc).astimezone(IST).isoformat(),"open":c[1],"high":c[2],"low":c[3],"close":c[4],"volume":c[5]})
    if not rows:
        safe_failures = failures[-5:]
        if safe_failures:
            details = "; ".join(f"{x['range_from']}..{x['range_to']}: {x['error']}" for x in safe_failures)
        else:
            details = "requests returned successful empty candle arrays"
        raise RuntimeError("No verified OHLCV candles returned; no empty market-data file written. " + details)
    with out.open("x" if not a.force else "w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=["timestamp_ist","open","high","low","close","volume"]); w.writeheader(); w.writerows(rows)
    info={"source_broker":"FYERS","api_symbol":a.symbol,"exchange":"MCX","pull_type":"continuous" if a.continuous=="1" else "dated_raw","continuous_flag":a.continuous,"contract_expiry":a.expiry,"resolution":a.resolution,"timeframe":"daily" if a.resolution=="D" else f"{a.resolution}minute","native_or_derived":"native","requested_start":start.isoformat(),"requested_end":end.isoformat(),"actual_first_timestamp_ist":rows[0]["timestamp_ist"],"actual_last_timestamp_ist":rows[-1]["timestamp_ist"],"total_rows":len(rows),"duplicate_epoch_count_removed":dups,"native_timestamp_format":"Unix epoch seconds","native_timezone":"UTC epoch","converted_timezone":"Asia/Kolkata","candle_timestamp_boundary":"FYERS History API timestamps candle start (official support documentation)","volume":"Broker-returned volume; cross-broker unit equivalence not established","request_batches":batches,"failures":failures,"collected_at_ist":datetime.now(IST).isoformat()}
    with meta.open("x" if not a.force else "w") as f: json.dump(info,f,indent=2); f.write("\n")
    print(json.dumps({"rows":len(rows),"first":info["actual_first_timestamp_ist"],"last":info["actual_last_timestamp_ist"],"failures":len(failures),"output":str(out)}))
    return 0 if not failures else 2
if __name__=="__main__": raise SystemExit(main())
