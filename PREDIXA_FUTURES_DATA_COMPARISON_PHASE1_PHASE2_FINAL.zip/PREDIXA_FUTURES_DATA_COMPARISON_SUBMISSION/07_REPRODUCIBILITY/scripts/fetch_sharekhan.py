#!/usr/bin/env python3
"""Sharekhan native-history probe; this SDK call retrieves its default window."""
from __future__ import annotations

import argparse
import os
import re
import sys
import csv
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[3]

def credentials(api_key_env: str, token_env: str):
    api_key, token = os.getenv(api_key_env), os.getenv(token_env)
    if not api_key:
        token_source = ROOT / "apps" / "finprod_backend" / "endpoints" / "token.py"
        match = re.search(r'api_key\s*=\s*"([^"]+)"', token_source.read_text())
        api_key = match.group(1) if match else None
    if not token:
        from sqlitedict import SqliteDict
        with SqliteDict(str(ROOT / "finprod.sqlite"), flag="r") as db:
            token = db["access_json"]["data"]["token"]
    return api_key, token

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--script-code", required=True, type=int)
    parser.add_argument("--interval", default="60minute")
    parser.add_argument("--api-key-env", default="SHAREKHAN_API_KEY")
    parser.add_argument("--token-env", default="SHAREKHAN_ACCESS_TOKEN")
    parser.add_argument("--output", help="Optional CSV filename under research data/ (dated history only)")
    parser.add_argument("--expiry", help="Verified expiry date YYYY-MM-DD for dated contract")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    try:
        api_key, token = credentials(args.api_key_env, args.token_env)
    except Exception:
        print("Sharekhan credentials unavailable; no request made.")
        return 2
    if not api_key or not token:
        print("Sharekhan credentials unavailable; no request made.")
        return 2
    sys.path.insert(0, str(ROOT))
    from SharekhanApi.sharekhanConnect import SharekhanConnect
    client = SharekhanConnect(api_key, access_token=token)
    response = client.historicaldata("MX", args.script_code, args.interval)
    rows = response.get("data", []) if isinstance(response, dict) else []
    print("response_type=", type(response).__name__)
    print("response_status=", response.get("status") if isinstance(response, dict) else "unparsed")
    print("response_message=", response.get("message") if isinstance(response, dict) else "unparsed")
    print("returned_candles=", len(rows))
    if not args.output:
        return 0 if rows else 2
    output = ROOT / "research" / "zone_series_comparison" / "data" / args.output
    metadata = ROOT / "research" / "zone_series_comparison" / "metadata" / (Path(args.output).stem + ".json")
    if (output.exists() or metadata.exists()) and not args.force:
        raise FileExistsError("Refusing to overwrite Sharekhan research output; pass --force explicitly")
    import csv
    converted = []
    for row in rows:
        # Sharekhan supplies day/month/year plus tradeTime; retain wall-clock value as IST.
        native = datetime.strptime(f"{row['tradeDate']} {row['tradeTime']}", "%d/%m/%Y %H:%M:%S")
        converted.append({"timestamp_ist": native.replace(tzinfo=ZoneInfo("Asia/Kolkata")).isoformat(),
                          "open": row.get("open"), "high": row.get("high"), "low": row.get("low"),
                          "close": row.get("close"), "volume": row.get("qty")})
    original_count = len(converted)
    by_time = {}
    for row in converted:
        by_time[row["timestamp_ist"]] = row
    converted = [by_time[k] for k in sorted(by_time)]
    output.parent.mkdir(parents=True, exist_ok=True); metadata.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["timestamp_ist", "open", "high", "low", "close", "volume"])
        writer.writeheader(); writer.writerows(converted)
    daily_mapping_unresolved = bool(converted and args.expiry and args.interval.lower() in ("daily", "day") and datetime.fromisoformat(converted[0]["timestamp_ist"]).date() < datetime.fromisoformat(args.expiry).date())
    info = {"source_broker": "Sharekhan", "api_endpoint": "https://api.sharekhan.com/skapi/services/historical/{exchange}/{scripcode}/{interval}",
            "exchange": "MX", "instrument_identifier": args.script_code, "pull_type": "dated_scripcode_default_history_mapping_unresolved" if daily_mapping_unresolved else "dated_contract_default_history",
            "continuous": "unknown for historical rows before the verified expiry contract existed" if daily_mapping_unresolved else False, "cont_flag": None, "contract_expiry": args.expiry, "interval": args.interval,
            "date_parameters": "SDK method provides no date-range parameters; broker default window returned",
            "native_timestamp_format": "tradeDate D/M/YYYY + tradeTime HH:MM:SS", "native_timezone": "not documented; interpreted as IST per MCX session convention",
            "candle_timestamp_boundary": "daily response date-label semantics undocumented; compare by trading date" if args.interval.lower() in ("daily", "day") else "unknown; time resembles interval-end trade time but not verified",
            "converted_timezone": "Asia/Kolkata", "requested_start": None, "requested_end": None,
            "actual_first_timestamp_ist": converted[0]["timestamp_ist"] if converted else None,
            "actual_last_timestamp_ist": converted[-1]["timestamp_ist"] if converted else None,
            "total_rows": len(converted), "raw_response_candle_count": original_count,
            "duplicate_timestamp_count_removed": original_count-len(converted), "response_status": response.get("status"),
            "response_message": response.get("message"), "volume": "Sharekhan qty retained as volume; unit semantics undocumented",
            "known_adjustments": "not documented; historical series mapping unresolved" if daily_mapping_unresolved else "none documented", "collected_at_ist": datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(),
            "limitations": ("The default daily response begins before the verified contract expiry; older rows cannot be certified as raw dated-contract history or as continuous data. No date-range parameters are exposed by the SDK." if daily_mapping_unresolved else "The broker response is its default window and cannot be date-ranged through this SDK method; the scrip code resolves to a dated contract in the authenticated master.")}
    metadata.write_text(json.dumps(info, indent=2) + "\n")
    print("rows_written=", len(converted), "first=", info["actual_first_timestamp_ist"], "last=", info["actual_last_timestamp_ist"])
    return 0 if rows else 2

if __name__ == "__main__":
    raise SystemExit(main())
