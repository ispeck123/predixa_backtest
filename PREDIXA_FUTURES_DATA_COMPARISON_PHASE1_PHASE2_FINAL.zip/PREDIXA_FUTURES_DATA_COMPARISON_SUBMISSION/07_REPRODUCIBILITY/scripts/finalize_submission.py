#!/usr/bin/env python3
"""Offline validation, comparison, reports, evidence bundle, and ZIP builder."""
from __future__ import annotations
import argparse, csv, hashlib, json, math, re, shutil, textwrap, zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/"research"/"zone_series_comparison"
DATA=BASE/"data"; META=BASE/"metadata"; COMP=BASE/"comparisons"; CHART=BASE/"charts"
OUT=BASE/"output"; SUB=OUT/"PREDIXA_FUTURES_DATA_COMPARISON_SUBMISSION"
IST=ZoneInfo("Asia/Kolkata")

FILES={
 "crude_60_cont":"CRUDEOILM_CONT_flag1_60m.csv",
 "crude_60_raw":"CRUDEOILM_19OCT_raw_60m.csv",
 "crude_60_sk":"SHAREKHAN_CRUDEOILM_19OCT2026_raw_60m.csv",
 "crude_240_cont":"CRUDEOILM_CONT_flag1_240m.csv",
 "crude_240_raw":"CRUDEOILM_19OCT_raw_240m.csv",
 "crude_D_cont":"CRUDEOILM_CONT_flag1_daily.csv",
 "crude_D_raw":"CRUDEOILM_19OCT_raw_daily.csv",
 "crude_D_sk":"CRUDEOILM_19OCT2026_SK_RAW_daily.csv",
 "gold_60_cont":"GOLD_CONT_flag1_60m.csv",
 "gold_60_raw":"GOLD_04DEC_raw_60m.csv",
 "gold_60_sk":"GOLD_04DEC2026_SK_RAW_60m.csv",
 "gold_240_cont":"GOLD_CONT_flag1_240m.csv",
 "gold_240_raw":"GOLD_04DEC_raw_240m.csv",
 "gold_D_cont":"GOLD_CONT_flag1_daily.csv",
 "gold_D_raw":"GOLD_04DEC_raw_daily.csv",
 "gold_D_sk":"GOLD_04DEC2026_SK_RAW_daily.csv",
 "gold_D_sk_feb":"GOLD_05FEB2027_SK_RAW_daily.csv",
 "crude_240_sk_derived":"CRUDEOILM_SK_derived_240m_from_60m.csv",
 "gold_240_sk_derived":"GOLD_SK_derived_240m_from_60m.csv",
}

def read(key):
    p=DATA/FILES[key]
    if not p.exists(): return None
    d=pd.read_csv(p)
    d["timestamp_ist"]=pd.to_datetime(d["timestamp_ist"],errors="coerce",utc=True).dt.tz_convert("Asia/Kolkata")
    for c in ("open","high","low","close","volume"): d[c]=pd.to_numeric(d[c],errors="coerce")
    return d.sort_values("timestamp_ist")

def stats_pair(a,b,label_a,label_b,ctype,align=None):
    x=a.copy(); y=b.copy()
    if align=="floor_hour":
        x["timestamp_ist"]=x.timestamp_ist.dt.floor("h"); y["timestamp_ist"]=y.timestamp_ist.dt.floor("h")
    elif align=="date":
        x["timestamp_ist"]=x.timestamp_ist.dt.strftime("%Y-%m-%d"); y["timestamp_ist"]=y.timestamp_ist.dt.strftime("%Y-%m-%d")
    m=x.merge(y,on="timestamp_ist",how="inner",suffixes=("_a","_b"))
    for c in ("open","high","low","close"): m[c+"_diff"]=m[c+"_a"]-m[c+"_b"]
    m["abs_close_diff"]=m.close_diff.abs()
    m["pct_close_diff_of_b"]=np.where(m.close_b!=0,100*m.close_diff/m.close_b,np.nan)
    d=m.close_diff.dropna(); ab=d.abs(); v=m[["volume_a","volume_b"]].dropna()
    s={"comparison_type":ctype,"left_series":label_a,"right_series":label_b,"signed_difference":"left minus right",
       "alignment_method":align or "exact timestamp","left_rows":int(len(a)),"right_rows":int(len(b)),"common_timestamps":int(len(m)),
       "left_unmatched":int(len(x)-len(m)),"right_unmatched":int(len(y)-len(m)),
       "left_match_pct":float(len(m)/len(x)*100) if len(x) else None,"right_match_pct":float(len(m)/len(y)*100) if len(y) else None,
       "mean_close_a":float(m.close_a.mean()) if len(m) else None,"mean_close_b":float(m.close_b.mean()) if len(m) else None,
       "mean_signed_close_diff":float(d.mean()) if len(d) else None,"median_signed_close_diff":float(d.median()) if len(d) else None,
       "mean_absolute_close_diff":float(ab.mean()) if len(ab) else None,"median_absolute_close_diff":float(ab.median()) if len(ab) else None,
       "p95_absolute_close_diff":float(ab.quantile(.95)) if len(ab) else None,"max_absolute_close_diff":float(ab.max()) if len(ab) else None,
       "mean_absolute_pct_close_diff_of_right_pct":float(m.pct_close_diff_of_b.abs().mean()) if len(m) else None,
       "rmse_close_diff":float(math.sqrt((d*d).mean())) if len(d) else None,
       "close_correlation":float(m.close_a.corr(m.close_b)) if len(m)>1 else None,
       "ohlc_mean_signed_diff":{c:float(m[c+"_diff"].mean()) for c in ("open","high","low","close")} if len(m) else {},
       "volume_rows":int(len(v)),"volume_a_sum":float(v.volume_a.sum()) if len(v) else None,"volume_b_sum":float(v.volume_b.sum()) if len(v) else None,
       "volume_mean_abs_diff":float((v.volume_a-v.volume_b).abs().mean()) if len(v) else None,
       "volume_correlation":float(v.volume_a.corr(v.volume_b)) if len(v)>1 else None}
    return m,s

def write_csv_atomic(df,path):
    df=df.copy(); df["timestamp_ist"]=df.timestamp_ist.map(lambda x:x.isoformat() if hasattr(x,"isoformat") else str(x))
    df.to_csv(path,index=False)

def validate(frame,name,timeframe):
    if frame is None: return {"dataset":name,"status":"UNAVAILABLE","rows":0}
    d=frame; nums=d[["open","high","low","close","volume"]]
    dup=int(d.timestamp_ist.duplicated().sum()); badts=int(d.timestamp_ist.isna().sum())
    nonasc=int((d.timestamp_ist.diff().dt.total_seconds().fillna(1)<=0).sum())-dup
    null=int(nums.isna().sum().sum()); negvol=int((nums.volume<0).sum()); nonpos=int((nums[["open","high","low","close"]]<=0).any(axis=1).sum())
    hi_bad=int((nums.high<nums[["open","close","low"]].max(axis=1)).sum()); lo_bad=int((nums.low>nums[["open","close","high"]].min(axis=1)).sum())
    zero=int((nums.volume==0).sum())
    same_day_gaps=None
    if timeframe in ("60","240"):
        local=d.timestamp_ist.dt.tz_convert("Asia/Kolkata")
        delta=d.timestamp_ist.diff().dt.total_seconds()/60
        same_day=(local.dt.date==local.shift(1).dt.date)
        same_day_gaps=int(((delta>int(timeframe)*1.5)&same_day).sum())
    counts={"empty":len(d)==0,"duplicate_timestamps":dup,"invalid_timestamps":badts,"nonascending_pairs":nonasc,"null_ohlcv_cells":null,"negative_volume_rows":negvol,"nonpositive_price_rows":nonpos,"high_ohlc_violations":hi_bad,"low_ohlc_violations":lo_bad,"zero_volume_rows":zero,"same_trading_date_gaps_over_1_5_intervals_unclassified":same_day_gaps}
    fail=any([len(d)==0,dup,badts,nonasc,null,negvol,nonpos])
    warning=bool(hi_bad or lo_bad or zero)
    return {"dataset":name,"status":"FAILED" if fail else "WARNING" if warning else "PASSED","rows":len(d),"first_timestamp_ist":d.timestamp_ist.min().isoformat() if len(d) else None,"last_timestamp_ist":d.timestamp_ist.max().isoformat() if len(d) else None,"native_interval":timeframe,"volume_available_pct":float(nums.volume.notna().mean()*100) if len(d) else 0,"checks":counts}

def chart_pair(df,title,path,unit="INR per unit"):
    if df is None or df.empty:return
    fig,ax=plt.subplots(2,1,figsize=(13,8),sharex=True,gridspec_kw={"height_ratios":[2,1]})
    ax[0].plot(df.timestamp_ist,df.close_a,lw=.9,label="Left series"); ax[0].plot(df.timestamp_ist,df.close_b,lw=.9,label="Right series")
    ax[0].set_ylabel(f"Price ({unit})"); ax[0].legend(); ax[0].grid(alpha=.25)
    ax[1].plot(df.timestamp_ist,df.close_diff,lw=.8,color="#9b351f"); ax[1].axhline(0,color="black",lw=.7); ax[1].set_ylabel("Left − right"); ax[1].grid(alpha=.25)
    fig.suptitle(title+"\nMCX | Asia/Kolkata timestamps; raw/continuous status per legend/report",fontsize=12)
    fig.tight_layout(); fig.savefig(path,dpi=180); plt.close(fig)

def make_derived_240(key,out_name,meta_name):
    src=read(key)
    if src is None:return None
    d=src.copy(); d["bar_start"]=d.timestamp_ist.dt.floor("h")
    local=d.bar_start.dt.tz_convert("Asia/Kolkata")
    d["trading_date"]=local.dt.date.astype(str)
    minute=local.dt.hour*60+local.dt.minute
    d["slot"]=((minute-540)//240).astype(int)
    d=d[(minute>=540)&(d.slot>=0)]
    groups=[]
    for (day,slot),g in d.groupby(["trading_date","slot"],sort=True):
        g=g.sort_values("bar_start").copy()
        # Split any unexpected missing-hour gap; never aggregate across it.
        g["segment"]=(g.bar_start.diff().dt.total_seconds().fillna(3600)>3600).cumsum()
        for _,seg in g.groupby("segment",sort=True):
            ts=seg.bar_start.iloc[0]
            groups.append({"timestamp_ist":ts,"open":seg.open.iloc[0],"high":seg.high.max(),"low":seg.low.min(),"close":seg.close.iloc[-1],"volume":seg.volume.sum(),"source_60m_rows":len(seg),"partial_bar":len(seg)<4,"session_bin":f"{day}_{slot}","gap_split_segment":bool(g.segment.nunique()>1)})
    out=DATA/out_name; pd.DataFrame(groups).assign(timestamp_ist=lambda q:q.timestamp_ist.map(lambda v:v.isoformat())).to_csv(out,index=False)
    source_meta=json.loads((META/(Path(FILES[key]).stem+".json")).read_text()) if (META/(Path(FILES[key]).stem+".json")).exists() else {}
    inf={"source_broker":"Sharekhan","instrument":source_meta.get("instrument","MCX instrument per scrip master"),"exchange":"MCX","api_symbol_or_scripcode":source_meta.get("instrument_identifier"),"series_type":"dated scripcode history; mapping per row not provided","timeframe":"240minute","native_or_derived":"derived from Sharekhan-native 60minute; not broker-native","source_interval":"60minute","aggregation":"Asia/Kolkata session anchor 09:00; fixed 4-hour bins [09,13), [13,17), [17,21), [21, session close); separate trading dates; split any >60-minute intra-bin source gap into segments; OHLC first/max/min/last; volume sum","source_rows":len(src),"output_rows":len(groups),"partial_groups_less_than_4_source_rows":sum(x['partial_bar'] for x in groups),"gap_split_segments":sum(x['gap_split_segment'] for x in groups),"timestamp_alignment":"source tradeTime floored to hour; inferred, not documented","collected_at_ist":datetime.now(IST).isoformat(),"volume_units":"Sharekhan qty; summation is within broker only; units not confirmed"}
    (META/meta_name).write_text(json.dumps(inf,indent=2)+"\n")
    return pd.DataFrame(groups)

def copy_file(src,dst):
    if src.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)

def main():
    p=argparse.ArgumentParser();p.add_argument("--force",action="store_true");a=p.parse_args()
    if SUB.exists() and any(SUB.iterdir()) and not a.force: raise FileExistsError(f"Refusing to replace existing submission {SUB}; use --force")
    COMP.mkdir(exist_ok=True);CHART.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True)
    # Secondary Sharekhan 240m derivations from native 60m, never broker-native.
    make_derived_240("crude_60_sk",FILES["crude_240_sk_derived"],"CRUDEOILM_SK_derived_240m_metadata.json")
    make_derived_240("gold_60_sk",FILES["gold_240_sk_derived"],"GOLD_SK_derived_240m_metadata.json")
    frames={k:read(k) for k in FILES}
    validations=[validate(frames[k],FILES[k],k.split("_")[1]) for k in FILES]
    pd.DataFrame([{"dataset":v["dataset"],"status":v["status"],"rows":v["rows"],"first_timestamp_ist":v.get("first_timestamp_ist"),"last_timestamp_ist":v.get("last_timestamp_ist"),"checks":json.dumps(v.get("checks",{}),sort_keys=True)} for v in validations]).to_csv(COMP/"data_quality_report.csv",index=False)
    (COMP/"validation_detail.json").write_text(json.dumps(validations,indent=2)+"\n")
    comparisons={}
    specs=[
     ("crude_60_raw","crude_60_cont","CRUDEOILM raw 19-Oct-2026","CRUDEOILM FYERS continuous cont_flag=1","Raw vs Continuous",None,"crudeoil_fyers_raw_vs_continuous_60m"),
     ("crude_240_raw","crude_240_cont","CRUDEOILM raw 19-Oct-2026","CRUDEOILM FYERS continuous cont_flag=1","Raw vs Continuous",None,"crudeoil_fyers_raw_vs_continuous_240m"),
     ("crude_D_raw","crude_D_cont","CRUDEOILM raw 19-Oct-2026","CRUDEOILM FYERS continuous cont_flag=1","Raw vs Continuous",None,"crudeoil_fyers_raw_vs_continuous_daily"),
     ("gold_60_raw","gold_60_cont","GOLD raw 04-Dec-2026","GOLD FYERS continuous cont_flag=1","Raw vs Continuous",None,"gold_fyers_raw_vs_continuous_60m"),
     ("gold_240_raw","gold_240_cont","GOLD raw 04-Dec-2026","GOLD FYERS continuous cont_flag=1","Raw vs Continuous",None,"gold_fyers_raw_vs_continuous_240m"),
     ("gold_D_raw","gold_D_cont","GOLD raw 04-Dec-2026","GOLD FYERS continuous cont_flag=1","Raw vs Continuous",None,"gold_fyers_raw_vs_continuous_daily"),
     ("crude_60_raw","crude_60_sk","CRUDEOILM FYERS raw 19-Oct-2026","CRUDEOILM Sharekhan scrip 569901","Raw vs Raw", "floor_hour","crudeoil_fyers_vs_sharekhan_raw_60m"),
     ("gold_60_raw","gold_60_sk","GOLD FYERS raw 04-Dec-2026","GOLD Sharekhan scrip 495213","Raw vs Raw", "floor_hour","gold_fyers_vs_sharekhan_raw_60m"),
     ("crude_D_cont","crude_D_sk","CRUDEOILM FYERS continuous cont_flag=1","Sharekhan scrip 569901 daily API history; historical mapping unknown","Mixed/ambiguous mapping","date","crudeoil_fyers_cont_vs_sharekhan_scrip_daily"),
     ("gold_D_cont","gold_D_sk","GOLD FYERS continuous cont_flag=1","Sharekhan scrip 495213 daily API history; historical mapping unknown","Mixed/ambiguous mapping","date","gold_fyers_cont_vs_sharekhan_scrip_daily"),
     ("crude_D_cont","crude_D_sk","CRUDEOILM FYERS continuous cont_flag=1","Sharekhan scrip 569901 daily API history; historical mapping unknown","Mixed/ambiguous mapping","date","crudeoil_fyers_cont_vs_sharekhan_scrip_daily"),
     ("gold_D_sk","gold_D_sk_feb","Sharekhan scrip 495213 daily","Sharekhan scrip 559933 daily","Scrip-code daily history; expiry mapping unresolved","date","gold_sharekhan_daily_codes_crosscheck"),
     ("crude_240_cont","crude_240_sk_derived","CRUDEOILM FYERS native 240m continuous","CRUDEOILM Sharekhan derived 240m from dated Oct scrip","Mixed Continuous vs Raw (right side derived)",None,"crudeoil_fyers_vs_sharekhan_derived_240m"),
     ("gold_240_cont","gold_240_sk_derived","GOLD FYERS native 240m continuous","GOLD Sharekhan derived 240m from dated Dec scrip","Mixed Continuous vs Raw (right side derived)",None,"gold_fyers_vs_sharekhan_derived_240m"),
    ]
    summary=[]
    for ka,kb,la,lb,ct,align,stem in specs:
        x,y=frames.get(ka),frames.get(kb)
        if x is None or y is None: continue
        m,s=stats_pair(x,y,la,lb,ct,align); comparisons[stem]=s
        if ct=="Raw vs Continuous":
            expiry="2026-10-19" if "crudeoil" in stem else "2026-12-04"
            m["time_to_expiry_calendar_days"]=(pd.Timestamp(expiry).date()-m.timestamp_ist.dt.date).apply(lambda v:v.days)
            bytte=m.groupby("time_to_expiry_calendar_days").agg(rows=("close_diff","size"),mean_signed_close_diff=("close_diff","mean"),mean_absolute_close_diff=("abs_close_diff","mean"),p95_absolute_close_diff=("abs_close_diff",lambda z:z.quantile(.95))).reset_index()
            bytte.to_csv(COMP/(stem+"_time_to_expiry.csv"),index=False)
            fig,ax=plt.subplots(figsize=(12,5));ax.scatter(m.time_to_expiry_calendar_days,m.abs_close_diff,s=4,alpha=.35);ax.set_xlabel("Calendar days to raw-contract expiry");ax.set_ylabel("Absolute close difference (INR)");ax.set_title(f"{la} vs {lb} | raw-continuous absolute difference by time to expiry\nExpiry={expiry}; timestamps IST; exact matches only");ax.grid(alpha=.25);fig.tight_layout();fig.savefig(CHART/(stem+"_time_to_expiry.png"),dpi=180);plt.close(fig)
        write_csv_atomic(m,COMP/(stem+".csv"))
        summary.append(s)
        chart_pair(m,f"{la} vs {lb} | {ct}",CHART/(stem+".png"))
    # Full-window completeness and verified expiry-date inspection.
    fig,ax=plt.subplots(figsize=(14,7)); present=[]
    for key,f in frames.items():
        if f is None or f.empty:continue
        present.append((key,f))
    for yi,(key,f) in enumerate(present):ax.scatter(f.timestamp_ist,np.full(len(f),yi),s=1.7,label=key)
    ax.set_yticks(range(len(present)),[x[0] for x in present],fontsize=7);ax.set_title("Actual returned data coverage | MCX CRUDEOILM and GOLD | all source intervals | IST");ax.set_xlabel("Timestamp (Asia/Kolkata)");ax.grid(axis="x",alpha=.2);fig.tight_layout();fig.savefig(CHART/"data_completeness_all.png",dpi=180);plt.close(fig)
    cont=frames.get("crude_60_cont")
    if cont is not None and not cont.empty:
        cal=pd.read_csv(DATA/"CRUDEOILM_expiry_roll_calendar.csv");fig,ax=plt.subplots(figsize=(14,6));ax.plot(cont.timestamp_ist,cont.close,lw=.75,color="#234c77")
        for _,row in cal.iterrows():
            dt=pd.Timestamp(row.expiry_date,tz="Asia/Kolkata")
            if cont.timestamp_ist.min()<=dt<=cont.timestamp_ist.max():ax.axvline(dt,color="#b94738",alpha=.3,lw=.7)
        ax.set_title("FYERS continuous CRUDEOILM 60m price with verified MCX expiry dates\nVertical lines mark expiry only; FYERS actual roll dates/method unknown; IST; INR/barrel")
        ax.set_xlabel("Timestamp (Asia/Kolkata)");ax.set_ylabel("Price (INR/barrel)");ax.grid(alpha=.25);fig.tight_layout();fig.savefig(CHART/"crudeoil_expiry_roll_inspection_full.png",dpi=180);plt.close(fig)
    # Mark comparison failure explicitly: no fabricated Sharekhan continuous.
    summary.append({"comparison_type":"Continuous vs Continuous","status":"NOT EXECUTED","reason":"No verified Sharekhan continuous CRUDEOILM/GOLD dataset through documented API path; see evidence/SHAREKHAN_CONTINUOUS_LIMITATION.md"})
    (COMP/"comparison_summary_final.json").write_text(json.dumps(comparisons,indent=2,allow_nan=False)+"\n")
    pd.DataFrame(summary).to_csv(COMP/"comparison_summary_final.csv",index=False)
    # Dataset manifest explicitly classifies API availability, series type and actual range.
    manifests=[]
    for k,f in frames.items():
        if f is None: continue
        meta=META/(Path(FILES[k]).stem+".json"); md=json.loads(meta.read_text()) if meta.exists() else {}
        tfkey=k.split("_")[1]; instkey="CRUDEOILM" if k.startswith("crude") else "GOLD"
        stype=md.get("pull_type",md.get("series_type"))
        if k in ("crude_D_sk","gold_D_sk","gold_D_sk_feb"):stype="Sharekhan daily scrip-code history; historical contract mapping unresolved"
        manifests.append({"dataset":FILES[k],"broker":md.get("source_broker"),"instrument":instkey,"timeframe":{"60":"60m","240":"240m","D":"daily"}.get(tfkey,tfkey),"series_type":stype,"symbol_or_scripcode":md.get("api_symbol",md.get("instrument_identifier",md.get("api_symbol_or_scripcode"))),"expiry":md.get("contract_expiry"),"native_or_derived":md.get("native_or_derived","native"),"rows":len(f),"first_timestamp_ist":f.timestamp_ist.min().isoformat(),"last_timestamp_ist":f.timestamp_ist.max().isoformat(),"status":"AVAILABLE"})
    manifests += [
      {"dataset":"Sharekhan continuous CRUDEOILM/GOLD (all timeframes)","broker":"Sharekhan","timeframe":"60m/240m/daily","series_type":"continuous","status":"UNAVAILABLE THROUGH VERIFIED API PATH","reason":"FAQ advertises continuous F&O, but installed SDK history route accepts only exchange/scripcode/interval; no verified continuous contract mapping/request convention; no speculative retry."},
      {"dataset":"Sharekhan native 240m","broker":"Sharekhan","timeframe":"240m","series_type":"dated/API scripcode","status":"NOT SUPPORTED IN DOCUMENTED INTERVAL LIST","reason":"Documented native intervals stop at 90 minutes; a 240m secondary derivation from 60m is reported separately if generated."},
    ]
    pd.DataFrame(manifests).to_csv(COMP/"dataset_manifest_final.csv",index=False)
    generate_reports(comparisons,summary,validations,manifests)
    build_package(manifests,validations,summary,a.force)

def generate_reports(comp,summary,validations,manifest):
    get=lambda s: comp.get(s,{})
    exchange="<exchange>"; scripcode="<scripcode>"; interval="<interval>"
    phase1=get("crudeoil_fyers_raw_vs_continuous_60m")
    cross=get("crudeoil_fyers_vs_sharekhan_raw_60m")
    gold=get("gold_fyers_raw_vs_continuous_60m")
    p1=f"""# Predixa — CRUDEOILM 60-Minute Futures Historical Series Comparison\n\n**Phase 1 — Completed with documented external data limitation.** All feasible requested data were retrieved, validated, aligned, and analyzed; Sharekhan continuous was not retrievable through the verified API path, so the originally required continuous-vs-continuous comparison remains unexecuted.\n\n## Executive summary\n\nFYERS returned 3,765 continuous and 1,302 dated raw CRUDEOILM 60-minute candles across 2025-10-09–2026-10-08 and 2026-05-22–2026-10-08 respectively. The matched raw/continuous sample is {phase1.get('common_timestamps')} bars; mean signed close difference (raw − continuous) ₹{phase1.get('mean_signed_close_diff',float('nan')):,.2f}, MAE ₹{phase1.get('mean_absolute_close_diff',float('nan')):,.2f}, p95 absolute difference ₹{phase1.get('p95_absolute_close_diff',float('nan')):,.2f}, maximum ₹{phase1.get('max_absolute_close_diff',float('nan')):,.2f}, correlation {phase1.get('close_correlation',float('nan')):.4f}. This indicates material absolute price-level divergence for historical zone coordinates. It does not reproduce Predixa zone output.\n\nThe exact October contract is MCX CRUDEOILM expiry 2026-10-19, FYERS `MCX:CRUDEOILM26OCTFUT` with `cont_flag=0`, Sharekhan scrip 569901. FYERS continuous used the same API symbol with `cont_flag=1`.\n\n## Research objective and methods\n\nTimestamp joins use exact FYERS start timestamps for raw/continuous. Cross-broker 60m rows are paired by the inferred rule: Sharekhan `tradeTime` values near `HH:59` floored to the hour to align with FYERS candle-start `HH:00`; original CSVs remain unchanged. Signed difference is left series minus right series; percentage difference denominator is the right-hand close. No missing bars were filled.\n\n## Dataset manifest and coverage\n\n| Dataset | Pull | Rows | Actual IST coverage |\n|---|---|---:|---|\n| FYERS CRUDEOILM continuous 60m (`cont_flag=1`) | `MCX:CRUDEOILM26OCTFUT` | 3,765 | 2025-10-09 09:00 – 2026-10-08 23:00 |\n| FYERS CRUDEOILM raw 60m (`cont_flag=0`) | same dated symbol; expiry 2026-10-19 | 1,302 | 2026-05-22 21:00 – 2026-10-08 23:00 |\n| Sharekhan CRUDEOILM 60m | `MX`, scrip 569901; dated Oct-2026 | 397 | 2026-09-01 09:59:05 – 2026-10-08 23:30:59 |\n| Sharekhan continuous | not identified | — | — |\n\n## FYERS raw vs continuous\n\n| Metric | Value |\n|---|---:|\n| Common timestamps | {phase1.get('common_timestamps')} |\n| Raw timestamps matched | {phase1.get('left_match_pct',float('nan')):.2f}% |\n| Mean signed close difference | ₹{phase1.get('mean_signed_close_diff',float('nan')):,.2f} |\n| Mean absolute / median absolute | ₹{phase1.get('mean_absolute_close_diff',float('nan')):,.2f} / ₹{phase1.get('median_absolute_close_diff',float('nan')):,.2f} |\n| p95 / maximum absolute | ₹{phase1.get('p95_absolute_close_diff',float('nan')):,.2f} / ₹{phase1.get('max_absolute_close_diff',float('nan')):,.2f} |\n| RMSE / correlation | ₹{phase1.get('rmse_close_diff',float('nan')):,.2f} / {phase1.get('close_correlation',float('nan')):.4f} |\n| Mean absolute percentage difference (continuous denominator) | {phase1.get('mean_absolute_pct_close_diff_of_right_pct',float('nan')):.3f}% |\n\nThe dated raw series begins later than continuous history; unmatched earlier continuous bars are not treated as raw zeroes or backfilled. Raw OHLCV is retained as received. Divergence may reflect futures basis/term structure as well as unknown continuous roll/adjustment behavior; rollover causation is not established.\n\n## FYERS raw vs Sharekhan raw\n\nSharekhan's matched dated-contract 60m values closely corroborate FYERS on the recent sample, subject to inferred timestamp pairing. Common rows: {cross.get('common_timestamps')}; mean close difference FYERS−Sharekhan ₹{cross.get('mean_signed_close_diff',float('nan')):,.2f}; MAE ₹{cross.get('mean_absolute_close_diff',float('nan')):,.2f}; p95 ₹{cross.get('p95_absolute_close_diff',float('nan')):,.2f}; maximum ₹{cross.get('max_absolute_close_diff',float('nan')):,.2f}; correlation {cross.get('close_correlation',float('nan')):.5f}. This is same dated expiry raw-vs-raw, not continuous agreement. Volume units are not independently established as comparable.\n\n## Sharekhan continuous limitation\n\nSharekhan FAQ publicly advertises continuous F&O data. The documented SDK method is `historicaldata(exchange, scripcode, interval)` mapped to `/skapi/services/historical/{exchange}/{scripcode}/{interval}`. The verified MCX master exposes dated CRUDEOILM futures codes; no continuous selector or clearly identified non-expiring CRUDEOILM identifier was available. The limitation is through the verified path, not a claim that Sharekhan universally lacks this feature. See `05_EVIDENCE/Sharekhan_API_Investigation/SHAREKHAN_CONTINUOUS_LIMITATION.md`.\n\n## Expiry, timestamps, and data quality\n\nVerified October expiry is 19-Oct-2026, as shown in both broker instrument masters; verified nearby September expiry 21-Sep-2026 is retained in the calendar. Actual continuous roll dates/method are unknown and are not equated with expiry. FYERS History API timestamps are candle starts (official support documentation) and were converted from UTC epoch to IST. Sharekhan provides tradeDate/tradeTime, with timezone/boundary semantics undocumented. FYERS continuous rows retain OHLC geometry anomalies; see validation CSV. No anomalous bars were silently dropped.\n\n## Zone-series risk and recommendation\n\nThe inspected offline zone path consumes absolute price ranges derived from OHLC highs/lows; volume is not an input to the core range/pattern logic. An average absolute close divergence of ₹{phase1.get('mean_absolute_close_diff',float('nan')):,.2f} and p95 of ₹{phase1.get('p95_absolute_close_diff',float('nan')):,.2f} can materially displace absolute candidate boundaries and affect pattern/range classification. No zone function was executed, so changed zone signals are not asserted.\n\n**Finding: Supports continuous-series input for further offline zone testing, not a production switch.** Before any decision, validate how historical continuous prices map to live dated-contract prices, and obtain Sharekhan’s supported continuous mapping/roll details.\n\n## Limitations\n\n- No verified Sharekhan continuous CRUDEOILM series; comparison not executed.\n- Raw expiry history starts 2026-05-22; no full-year raw series exists in returned data.\n- FYERS continuous roll/back-adjustment method is undocumented.\n- Sharekhan intraday timestamps are only inferred-aligned; volume equivalence is unknown.\n- Predixa zones were inspected conceptually but not recomputed offline.\n\n## Evidence and reproduction\n\nSee `02_PHASE1_CRUDEOILM_60M/`, `06_VALIDATION/`, `05_EVIDENCE/`, and `07_REPRODUCIBILITY/`.\n"""
    p2=f"""# Predixa — Multi-Instrument and Multi-Timeframe Futures Series Analysis\n\n## Executive summary\n\nPhase 2 extends the comparison to standard MCX GOLD (not GOLDM) across 60m, 240m, and daily bars, while also adding 240m and daily CRUDEOILM analysis. FYERS supplied native continuous and dated raw data for all required timeframes; Sharekhan supplied 60m and daily scrip-code histories. Sharekhan native 240m is not in the documented interval list (documented maximum 90 minutes); no 240m API request was invented. A separate 240m derivation may be made from Sharekhan 60m only if boundary/session aggregation is validated and is never called native.\n\n## Instrument selection\n\nSelected **GOLD** standard futures because both authenticated MCX masters contained exact `GOLD` futures with matching 04-Dec-2026 expiry (FYERS symbol `MCX:GOLD26DECFUT`; Sharekhan scrip 495213), avoiding GOLDM/GOLD mismatch.\n\n## Native FYERS findings\n\n| Instrument/timeframe | FYERS continuous | FYERS raw | Common candles | Mean abs close difference | p95 abs | Max abs | Correlation |\n|---|---:|---:|---:|---:|---:|---:|---:|\n"""
    for stem,ins,tf in [("crudeoil_fyers_raw_vs_continuous_240m","CRUDEOILM","240m"),("crudeoil_fyers_raw_vs_continuous_daily","CRUDEOILM","Daily"),("gold_fyers_raw_vs_continuous_60m","GOLD","60m"),("gold_fyers_raw_vs_continuous_240m","GOLD","240m"),("gold_fyers_raw_vs_continuous_daily","GOLD","Daily")]:
        z=get(stem)
        p2+=f"| {ins} {tf} | {z.get('right_rows','—')} | {z.get('left_rows','—')} | {z.get('common_timestamps','—')} | {money(z.get('mean_absolute_close_diff'))} | {money(z.get('p95_absolute_close_diff'))} | {money(z.get('max_absolute_close_diff'))} | {fmt(z.get('close_correlation'))} |\n"
    p2+=f"\nCRUDEOILM 60m Phase 1 full-window comparison: {phase1.get('common_timestamps','—')} matched rows; MAE {money(phase1.get('mean_absolute_close_diff'))}, p95 {money(phase1.get('p95_absolute_close_diff'))}. GOLD 60m raw-vs-continuous: {gold.get('common_timestamps','—')} matches; MAE {money(gold.get('mean_absolute_close_diff'))}, p95 {money(gold.get('p95_absolute_close_diff'))}.\n\n## Sharekhan cross-broker data and limitations\n\nNative Sharekhan 60m raw dated contract data overlap FYERS only in the broker’s default recent window. Inferred timestamp pairing is `floor_hour` because Sharekhan reports HH:59:xx and FYERS reports bar starts. Results are separately labeled raw-vs-raw. Sharekhan daily history requests for scrip codes 569901 and 495213 returned bars years before the current expiry contracts existed. Therefore those outputs are called **scrip-code daily histories with unresolved historical contract mapping**; they are not certified raw dated series or continuous series. This limitation materially restricts daily cross-broker conclusions.\n\nSharekhan’s documented native interval maximum is 90 minutes; 240m is unavailable natively in this verified SDK path. No 240m Sharekhan data is represented as native. If 240m is derived, session anchoring, partial bins, and timestamp pairing are disclosed in its metadata and it is secondary-only.\n\n## Zone-series impact\n\nRaw-vs-continuous comparisons measure absolute-price offset, not a change in generated zones. The application’s inspected zone path operates on OHLC highs/lows and absolute price levels; a series offset can therefore displace candidate levels. No production zone code was invoked. Switching from continuous historical zones to live dated-contract prices would also require an explicit mapping/roll policy.\n\n## Limitations and evidence\n\nSee individual CSV metadata, `06_VALIDATION/`, row-level comparison tables, and figures. Sharekhan continuous is unavailable through the verified path; FYERS roll adjustments are undocumented; Sharekhan daily contract mapping is unresolved; Sharekhan intraday boundary alignment is inferred; volumes are retained but not presumed comparable.\n"
    p1=p1.replace("## Expiry, timestamps, and data quality\n\n", "## Expiry, timestamps, and data quality\n\nVerified CRUDEOILM expiries in the requested analysis window: 20-Oct-2025, 19-Nov-2025, 18-Dec-2025, 16-Jan-2026, 19-Feb-2026, 19-Mar-2026, 20-Apr-2026, 18-May-2026, 18-Jun-2026, 20-Jul-2026, 19-Aug-2026, 21-Sep-2026, and 19-Oct-2026. These are exchange expiries; FYERS actual roll dates remain unknown.\n\n")
    p1=p1.replace("The dated raw series begins later than continuous history;", f"Median signed close difference is ₹{phase1.get('median_signed_close_diff',float('nan')):,.2f}; mean signed open/high/low differences and all volume statistics are in the row-level comparison outputs. Matched-bar volume differences are descriptive only: FYERS continuous volume may represent different expiry contracts through time and volume units/roll construction are undocumented.\n\nThe dated raw series begins later than continuous history;")
    crude_sk=get("crudeoil_fyers_vs_sharekhan_raw_60m"); gold_sk=get("gold_fyers_vs_sharekhan_raw_60m")
    crude_dsk=get("crudeoil_fyers_cont_vs_sharekhan_scrip_daily"); gold_dsk=get("gold_fyers_cont_vs_sharekhan_scrip_daily")
    crude_der=get("crudeoil_fyers_vs_sharekhan_derived_240m"); gold_der=get("gold_fyers_vs_sharekhan_derived_240m")
    p2 += f"\n## Sharekhan cross-broker results and derived timeframe\n\nRaw-vs-raw 60m (inferred hourly timestamp pairing): CRUDEOILM {crude_sk.get('common_timestamps')} common bars, MAE {money(crude_sk.get('mean_absolute_close_diff'))}, p95 {money(crude_sk.get('p95_absolute_close_diff'))}, correlation {fmt(crude_sk.get('close_correlation'))}; GOLD {gold_sk.get('common_timestamps')} bars, MAE {money(gold_sk.get('mean_absolute_close_diff'))}, p95 {money(gold_sk.get('p95_absolute_close_diff'))}, correlation {fmt(gold_sk.get('close_correlation'))}.\n\nSharekhan daily-by-scrip-code versus FYERS continuous (date-aligned, **descriptive only; mapping unresolved**): CRUDEOILM {crude_dsk.get('common_timestamps')} dates, mean signed difference {money(crude_dsk.get('mean_signed_close_diff'))}; GOLD {gold_dsk.get('common_timestamps')} dates, mean signed difference {money(gold_dsk.get('mean_signed_close_diff'))}. Because the Sharekhan histories start before the identified expiry contracts existed, these are not certified raw/continuous comparisons.\n\nSharekhan has no documented native 240m interval (documented max 90m). We generated secondary 240m bars from Sharekhan native 60m using Asia/Kolkata 09:00 session anchoring, separate 4-hour bins, source OHLC first/max/min/last, and summed within-broker `qty`; final session groups are marked partial. Comparing those recent derived dated-series rows with FYERS native continuous 240m is mixed continuous-vs-raw and not a like-for-like broker test: CRUDEOILM {crude_der.get('common_timestamps')} rows, MAE {money(crude_der.get('mean_absolute_close_diff'))}; GOLD {gold_der.get('common_timestamps')} rows, MAE {money(gold_der.get('mean_absolute_close_diff'))}.\n"
    p2=p2.replace("A separate 240m derivation may be made from Sharekhan 60m only if boundary/session aggregation is validated and is never called native.", "A secondary 240m derivation was produced from Sharekhan 60m with explicit session anchoring and partial-bin metadata; it is never called native.")
    p2=p2.replace("If 240m is derived, session anchoring, partial bins, and timestamp pairing are disclosed in its metadata and it is secondary-only.", "Derived 240m bins use the metadata-documented session anchor, do not bridge trading dates, and remain secondary-only.")
    p2=p2.replace("No verified Sharekhan continuous CRUDEOILM/GOLD dataset through documented API path; see evidence/SHAREKHAN_CONTINUOUS_LIMITATION.md", "No verified Sharekhan continuous CRUDEOILM/GOLD dataset through documented API path; see evidence/SHAREKHAN_CONTINUOUS_LIMITATION.md")
    phase2=p2
    conc=f"""# Predixa — Final Historical Futures Data Comparison & Zone-Series Assessment\n\n## Executive decision summary\n\nObserved FYERS CRUDEOILM raw-vs-continuous divergence over {phase1.get('common_timestamps','—')} identical 60m timestamps is mean absolute ₹{phase1.get('mean_absolute_close_diff',float('nan')):,.2f}, p95 ₹{phase1.get('p95_absolute_close_diff',float('nan')):,.2f}, max ₹{phase1.get('max_absolute_close_diff',float('nan')):,.2f}; raw-minus-continuous mean is ₹{phase1.get('mean_signed_close_diff',float('nan')):,.2f}. These offsets are large enough to be a credible material risk for absolute historical zone coordinates. The evidence supports continuous-series input for further offline zone testing, but not a production change.\n\nThe complete requested Sharekhan continuous comparison remains unexecuted. FYERS provides more complete continuous coverage; dated raw availability begins later. Sharekhan’s same-expiry intraday raw feeds corroborate prices on a short recent overlap, but Sharekhan daily histories expose pre-expiry dates and cannot safely be classified as raw. No actual Predixa zone output changes were tested.\n\n## Scope and availability matrix\n\n| Instrument/timeframe | FYERS continuous | FYERS raw | Sharekhan dated/API history | Sharekhan continuous |\n|---|---|---|---|---|\n| CRUDEOILM 60m | Native, 2025-10-09–2026-10-08 | Native, 2026-05-22–2026-10-08 | Native 60m dated, 2026-09-01–2026-10-08 | Unavailable through verified path |\n| CRUDEOILM 240m | Native | Native | Native not documented; derived only if validated | Unavailable through verified path |\n| CRUDEOILM daily | Native | Native from 2026-04-21 | Daily API history from 2015; historical mapping unresolved | Unavailable through verified path |\n| GOLD 60m | Native, full requested window | Native from 2026-05-14 | Native 60m dated, 2026-09-01–2026-10-08 | Unavailable through verified path |\n| GOLD 240m | Native | Native from 2026-05-14 | Native 240m undocumented; derived only if validated | Unavailable through verified path |\n| GOLD daily | Native | Native from 2025-12-16 | Daily API history from 2011; historical mapping unresolved | Unavailable through verified path |\n\n## Sharekhan limitation statement\n\n“Sharekhan publicly advertises continuous F&O historical data; however, the documented SDK method and authenticated MCX instrument master available during this investigation did not expose a verified continuous CRUDEOILM instrument identifier or request convention. Therefore, Sharekhan continuous futures data was not included in the quantitative comparison. This limitation applies to the verified access path and does not establish that Sharekhan categorically lacks continuous futures functionality.”\n\n## Comparative findings and zone assessment\n\n- CRUDEOILM 60m: mean absolute FYERS raw/continuous close displacement ₹{phase1.get('mean_absolute_close_diff',float('nan')):,.2f}; p95 ₹{phase1.get('p95_absolute_close_diff',float('nan')):,.2f}; {phase1.get('common_timestamps','—')} common timestamps.\n- CRUDEOILM raw cross-broker 60m: {cross.get('common_timestamps','—')} inferred-aligned rows, MAE {money(cross.get('mean_absolute_close_diff'))}; same expiry, raw-vs-raw.\n- GOLD raw-vs-continuous 60m: {gold.get('common_timestamps','—')} common timestamps, MAE {money(gold.get('mean_absolute_close_diff'))}; full metrics are in the comparison CSV/JSON.\n- Native FYERS comparisons are calculated for 240m and daily for both instruments. The raw contracts have shorter ranges and actual overlap is respected.\n- Sharekhan continuous-vs-continuous is not calculated. Sharekhan daily series from dated scrip codes predate the selected expiries, and are not treated as verified raw.\n\nThe inspected zone implementation derives absolute ranges from OHLC, especially high/low, and uses candle pattern/range structure; volume is not required for core zone-level placement. Therefore price displacement plausibly shifts zone levels and may change patterns. Actual zone outputs were not reproduced. Continuous history/live dated-futures mapping remains a risk requiring an explicit roll/basis method.\n\n## Recommendation\n\nUse the measured continuous-vs-raw differences as a trigger for controlled, offline zone-generation replay with fixed settings and well-defined live-price mapping. Do not change production behavior based on this report alone. Obtain broker roll/adjustment documentation and a verifiable Sharekhan continuous mapping before cross-broker continuous validation.\n\n## Reproducibility and limitations\n\nResearch data, metadata, scripts, comparisons, charts, quality logs, API references, and evidence are in the sibling folders of this report. No prices were synthesized for missing history. FYERS roll/adjustment method remains unknown; Sharekhan continuous is unresolved through the verified path; Sharekhan native 240m is not documented; Sharekhan daily contract mapping is ambiguous; Sharekhan 60m timestamp alignment is inferred; volume-unit comparability is not established.\n"""
    comparison_rows=[("crudeoil_fyers_raw_vs_continuous_60m","CRUDEOILM","60m"),("crudeoil_fyers_raw_vs_continuous_240m","CRUDEOILM","240m"),("crudeoil_fyers_raw_vs_continuous_daily","CRUDEOILM","Daily"),("gold_fyers_raw_vs_continuous_60m","GOLD","60m"),("gold_fyers_raw_vs_continuous_240m","GOLD","240m"),("gold_fyers_raw_vs_continuous_daily","GOLD","Daily")]
    metric_table="| Instrument | Timeframe | Matched bars | Signed mean raw−continuous | MAE | Median abs | p95 abs | Max abs | RMSE | Correlation |\n|---|---|---:|---:|---:|---:|---:|---:|---:|---:|\n"
    for key,instr,tf in comparison_rows:
        z=get(key);metric_table+=f"| {instr} | {tf} | {z.get('common_timestamps','—')} | {money(z.get('mean_signed_close_diff'))} | {money(z.get('mean_absolute_close_diff'))} | {money(z.get('median_absolute_close_diff'))} | {money(z.get('p95_absolute_close_diff'))} | {money(z.get('max_absolute_close_diff'))} | {money(z.get('rmse_close_diff'))} | {fmt(z.get('close_correlation'))} |\n"
    conc=conc.replace("## Comparative findings and zone assessment\n\n", "## Comparative findings and zone assessment\n\nFYERS native/raw dated series comparisons (signed difference is raw minus continuous; INR in instrument quote units):\n\n"+metric_table+"\n")
    conc=conc.replace("Native not documented; derived only if validated", "Native 240m undocumented; derived Sharekhan 240m from 60m is included as secondary")
    conc=conc.replace("Native 240m undocumented; derived only if validated", "Native 240m undocumented; derived Sharekhan 240m from 60m is included as secondary")
    conc=conc.replace("Sharekhan continuous-vs-continuous is not calculated.", "Sharekhan native 240m is not documented; 240m Sharekhan series are explicitly derived from 60m and compared only as mixed raw/continuous secondary evidence. Sharekhan continuous-vs-continuous is not calculated.")
    reports={"PHASE1_FINAL_REPORT.md":p1,"PHASE2_FINAL_REPORT.md":phase2,"CONSOLIDATED_FINAL_REPORT.md":conc}
    for n,body in reports.items():(OUT/n).write_text(body)
    # Keep research root report up to date as the concise Phase 1 canonical finding.
    (BASE/"REPORT.md").write_text(p1)
    executive="# Predixa futures data comparison — executive summary\n\n"+conc.split("## Scope and availability matrix")[0]
    (OUT/"EXECUTIVE_SUMMARY.md").write_text(executive)
    # Matplotlib PDFs: paginated readable text plus embedded result figures.
    for stem,md in reports.items():
        pdf=OUT/(Path(stem).stem+".pdf"); markdown_pdf(md,pdf)
    markdown_pdf(executive,OUT/"EXECUTIVE_SUMMARY.pdf")

def money(x): return "—" if x is None or pd.isna(x) else f"₹{x:,.2f}"
def fmt(x): return "—" if x is None or pd.isna(x) else f"{x:.4f}"

def markdown_pdf(md,path):
    lines=md.splitlines(); title=next((x.lstrip("# ") for x in lines if x.startswith("# ")),"Research report")
    with PdfPages(path) as pdf:
        per=38
        for offset in range(0,len(lines),per):
            fig=plt.figure(figsize=(8.27,11.69)); ax=fig.add_axes([.09,.06,.82,.88]); ax.axis("off")
            txt="\n".join(lines[offset:offset+per]); ax.text(0,1,txt,va="top",ha="left",fontsize=8.3,family="DejaVu Sans",wrap=True,linespacing=1.25)
            fig.suptitle(title,fontsize=12,y=.975); pdf.savefig(fig); plt.close(fig)
        candidates=sorted(CHART.glob("*_vs_*.png"))
        name=path.name.upper()
        if name.startswith("PHASE1"):
            candidates=[x for x in candidates if x.name.startswith(("crudeoil_fyers_raw_vs_continuous_60m", "crudeoil_fyers_vs_sharekhan_raw_60m"))]
            candidates += [x for x in [CHART/"crudeoil_expiry_roll_inspection_full.png",CHART/"data_completeness_all.png"] if x.exists()]
        elif name.startswith("PHASE2"):
            candidates=[x for x in candidates if x.name.startswith(("crudeoil_fyers_raw_vs_continuous_240m","crudeoil_fyers_raw_vs_continuous_daily","gold_"))]
            candidates += [x for x in [CHART/"data_completeness_all.png"] if x.exists()]
        elif name.startswith("EXECUTIVE"):
            candidates=[x for x in candidates if x.name.startswith("crudeoil_fyers_raw_vs_continuous_60m")]
        else:
            candidates += [x for x in [CHART/"crudeoil_expiry_roll_inspection_full.png",CHART/"data_completeness_all.png"] if x.exists()]
        candidates=list(dict.fromkeys(candidates))
        for image in candidates:
            fig=plt.figure(figsize=(11.7,8.27)); ax=fig.add_axes([.04,.06,.92,.88]); ax.axis("off"); ax.imshow(plt.imread(image)); ax.set_title(image.stem.replace("_"," "),fontsize=9); pdf.savefig(fig); plt.close(fig)

def build_package(manifest,validations,summary,force):
    if SUB.exists():
        if not force and any(SUB.iterdir()):raise FileExistsError("Submission directory already populated; use --force")
        if force: shutil.rmtree(SUB)
    dirs=["00_READ_ME_FIRST","01_FINAL_REPORTS","02_PHASE1_CRUDEOILM_60M/CSV","02_PHASE1_CRUDEOILM_60M/Comparisons","02_PHASE1_CRUDEOILM_60M/Charts","02_PHASE1_CRUDEOILM_60M/Metadata","02_PHASE1_CRUDEOILM_60M/Expiry_Calendar","03_PHASE2_CRUDEOILM/240m/CSV","03_PHASE2_CRUDEOILM/240m/Comparisons","03_PHASE2_CRUDEOILM/240m/Charts","03_PHASE2_CRUDEOILM/240m/Metadata","03_PHASE2_CRUDEOILM/Daily/CSV","03_PHASE2_CRUDEOILM/Daily/Comparisons","03_PHASE2_CRUDEOILM/Daily/Charts","03_PHASE2_CRUDEOILM/Daily/Metadata","04_PHASE2_BULLION/60m/CSV","04_PHASE2_BULLION/60m/Comparisons","04_PHASE2_BULLION/60m/Charts","04_PHASE2_BULLION/60m/Metadata","04_PHASE2_BULLION/240m/CSV","04_PHASE2_BULLION/240m/Comparisons","04_PHASE2_BULLION/240m/Charts","04_PHASE2_BULLION/240m/Metadata","04_PHASE2_BULLION/Daily/CSV","04_PHASE2_BULLION/Daily/Comparisons","04_PHASE2_BULLION/Daily/Charts","04_PHASE2_BULLION/Daily/Metadata","04_PHASE2_BULLION/Expiry_Calendar","05_EVIDENCE/Sharekhan_API_Investigation","05_EVIDENCE/Fyers_API_Evidence","05_EVIDENCE/Instrument_Master_Evidence","05_EVIDENCE/Expiry_Calendar_Sources","05_EVIDENCE/Data_Coverage_Evidence","06_VALIDATION","07_REPRODUCIBILITY/scripts","08_PACKAGE_INTEGRITY"]
    for d in dirs:(SUB/d).mkdir(parents=True,exist_ok=True)
    reportnames=["PHASE1_FINAL_REPORT.md","PHASE1_FINAL_REPORT.pdf","PHASE2_FINAL_REPORT.md","PHASE2_FINAL_REPORT.pdf","CONSOLIDATED_FINAL_REPORT.md","CONSOLIDATED_FINAL_REPORT.pdf"]
    for n in reportnames:copy_file(OUT/n,SUB/"01_FINAL_REPORTS"/n)
    copy_file(OUT/"EXECUTIVE_SUMMARY.pdf",SUB/"00_READ_ME_FIRST"/"EXECUTIVE_SUMMARY.pdf")
    copy_file(OUT/"EXECUTIVE_SUMMARY.md",SUB/"00_READ_ME_FIRST"/"EXECUTIVE_SUMMARY.md")
    # Copy every verified source CSV, with explicit organization by instrument/timeframe.
    for key,name in FILES.items():
        src=DATA/name
        if not src.exists():continue
        inst="CRUDEOILM" if key.startswith("crude") else "GOLD"; tf="60m" if "_60_" in key else "240m" if "_240_" in key else "Daily"
        if inst=="CRUDEOILM" and tf=="60m": dest=SUB/"02_PHASE1_CRUDEOILM_60M/CSV"/name
        elif inst=="CRUDEOILM": dest=SUB/"03_PHASE2_CRUDEOILM"/tf/"CSV"/name
        else:dest=SUB/"04_PHASE2_BULLION"/tf/"CSV"/name
        copy_file(src,dest)
        mp=META/(Path(name).stem+".json")
        if mp.exists():
            m_dest=dest.parent.parent/"Metadata"/mp.name;copy_file(mp,m_dest)
    copy_file(DATA/"CRUDEOILM_expiry_roll_calendar.csv",SUB/"02_PHASE1_CRUDEOILM_60M/Expiry_Calendar/CRUDEOILM_expiry_roll_calendar.csv")
    # Comparison results/chart classification by series.
    for f in COMP.glob("*final*"):copy_file(f,SUB/"06_VALIDATION"/f.name)
    for f in COMP.glob("*.csv"):
        stem=f.stem.lower()
        if "final" in stem or "quality" in stem or "validation" in stem:target=SUB/"06_VALIDATION"/f.name
        elif "crudeoil" in stem and "240m" in stem:target=SUB/"03_PHASE2_CRUDEOILM/240m/Comparisons"/f.name
        elif "crudeoil" in stem and ("daily" in stem or "time_to_expiry" in stem):target=SUB/"03_PHASE2_CRUDEOILM/Daily/Comparisons"/f.name
        elif "crudeoil" in stem:target=SUB/"02_PHASE1_CRUDEOILM_60M/Comparisons"/f.name
        elif "gold" in stem and "240m" in stem:target=SUB/"04_PHASE2_BULLION/240m/Comparisons"/f.name
        elif "gold" in stem and ("daily" in stem or "time_to_expiry" in stem):target=SUB/"04_PHASE2_BULLION/Daily/Comparisons"/f.name
        elif "gold" in stem:target=SUB/"04_PHASE2_BULLION/60m/Comparisons"/f.name
        else:target=SUB/"06_VALIDATION"/f.name
        copy_file(f,target)
    for f in CHART.glob("*.png"):
        stem=f.stem.lower()
        if "crudeoil" in stem and "240m" in stem:target=SUB/"03_PHASE2_CRUDEOILM/240m/Charts"/f.name
        elif "crudeoil" in stem and ("daily" in stem or "time_to_expiry" in stem):target=SUB/"03_PHASE2_CRUDEOILM/Daily/Charts"/f.name
        elif "crudeoil" in stem:target=SUB/"02_PHASE1_CRUDEOILM_60M/Charts"/f.name
        elif "gold" in stem and "240m" in stem:target=SUB/"04_PHASE2_BULLION/240m/Charts"/f.name
        elif "gold" in stem and ("daily" in stem or "time_to_expiry" in stem):target=SUB/"04_PHASE2_BULLION/Daily/Charts"/f.name
        elif "gold" in stem:target=SUB/"04_PHASE2_BULLION/60m/Charts"/f.name
        else:target=SUB/"06_VALIDATION"/f.name
        copy_file(f,target)
    for n in ["SHAREKHAN_CONTINUOUS_INVESTIGATION.md"]:copy_file(BASE/n,SUB/"05_EVIDENCE/Sharekhan_API_Investigation"/n)
    copy_file(BASE/"SHAREKHAN_CONTINUOUS_INVESTIGATION.md",SUB/"05_EVIDENCE/Sharekhan_API_Investigation/SHAREKHAN_CONTINUOUS_LIMITATION.md")
    (SUB/"05_EVIDENCE/Sharekhan_API_Investigation/API_DOCUMENTATION_REFERENCES.md").write_text("""# Verified API references\n\n- Official Sharekhan API FAQ: https://www.sharekhan.com/faq/API — advertises continuous F&O data and notes EOD scrip-wise data since inception/intraday availability wording.\n- Official Sharekhan technical documentation: https://www.sharekhan.com/trading-api/documentation — Historical Chart Data topic.\n- Installed Sharekhan Python SDK source (see `07_REPRODUCIBILITY/SOURCE_PROVENANCE.md`): `historicaldata(exchange, scripcode, interval)` to `/skapi/services/historical/{exchange}/{scripcode}/{interval}`; no verified continuous selector or date-range parameters.\n- Official FYERS History API support: https://support.fyers.in/portal/en/kb/fyers-api-integrations/fyers-api/api-v3/data-api — timestamp start semantics and supported history API.\n""")
    (SUB/"05_EVIDENCE/Sharekhan_API_Investigation/REDACTED_REQUEST_EXAMPLES.md").write_text("""# Redacted request examples (observed parameters only)\n\n## FYERS history\n\n```json\n{\"symbol\":\"MCX:CRUDEOILM26OCTFUT\",\"resolution\":\"60\",\"date_format\":\"1\",\"range_from\":\"2025-10-09\",\"range_to\":\"2025-12-30\",\"cont_flag\":\"1\"}\n```\n\nRaw mode used the same verified dated symbol with `cont_flag=0`. Other retrieved intervals used `resolution=240` or `resolution=D`. Auth headers and credentials are intentionally omitted.\n\n## Sharekhan history\n\nDocumented/read-only call: `historicaldata(\"MX\", 569901, \"60minute\")` for the verified CRUDEOILM 19-Oct-2026 dated contract; `historicaldata(\"MX\", 495213, \"daily\")` for the verified GOLD 04-Dec-2026 scrip. The SDK exposes no date range or continuous flag. No authorization header, token, customer/client identifier, or account data is included.\n""")
    for n in ["sharekhan_master_probe_GOLD.json","sharekhan_master_probe_CRUDEOILM.json"]:copy_file(META/n,SUB/"05_EVIDENCE/Instrument_Master_Evidence"/n)
    for n in ["fyers_continuous.json","fyers_raw.json","sharekhan_continuous.json"]:copy_file(META/n,SUB/"05_EVIDENCE/Fyers_API_Evidence"/n if n.startswith("fyers") else SUB/"05_EVIDENCE/Sharekhan_API_Investigation"/n)
    for f in META.glob("*.json"):
        if f not in [META/n for n in ["fyers_continuous.json","fyers_raw.json","sharekhan_continuous.json","sharekhan_master_probe_GOLD.json","sharekhan_master_probe_CRUDEOILM.json"]]:
            stem=f.stem.lower();inst="CRUDEOILM" if "crudeoilm" in stem else "GOLD" if stem.startswith("gold") else None
            tf="240m" if "240m" in stem or "derived_240m" in stem else "daily" if "daily" in stem or "_d_" in stem else "60m" if "60m" in stem else None
            if inst=="CRUDEOILM" and tf=="240m":target=SUB/"03_PHASE2_CRUDEOILM/240m/Metadata"/f.name
            elif inst=="CRUDEOILM" and tf=="daily":target=SUB/"03_PHASE2_CRUDEOILM/Daily/Metadata"/f.name
            elif inst=="CRUDEOILM" and tf=="60m":target=SUB/"02_PHASE1_CRUDEOILM_60M/Metadata"/f.name
            elif inst=="GOLD" and tf in ("60m","240m","daily"):target=SUB/"04_PHASE2_BULLION"/tf/"Metadata"/f.name
            else:target=SUB/"06_VALIDATION"/f.name
            copy_file(f,target)
    for s in ["fetch_fyers.py","fetch_fyers_multitf.py","fetch_sharekhan.py","probe_sharekhan_master.py","validate_ohlcv.py","compare_series.py","finalize_submission.py"]:copy_file(BASE/"scripts"/s,SUB/"07_REPRODUCIBILITY/scripts"/s)
    (SUB/"07_REPRODUCIBILITY/requirements.txt").write_text("pandas\nnumpy\nmatplotlib\nfyers-apiv3\nSharekhanApi\nsqlitedict\n")
    (SUB/"07_REPRODUCIBILITY/RUN_INSTRUCTIONS.md").write_text("""# Reproduction\n\nThe data were retrieved via documented read-only broker history/master calls on 2026-10-09 IST and then analyzed offline. Scripts use the existing FYERS token handler and existing Sharekhan configured token store/environment; no credentials are included.\n\n`python scripts/validate_ohlcv.py <csv>` validates a data file. `python scripts/finalize_submission.py` (run from repository root before packaging) rebuilds metrics/reports. Broker requests are not required to inspect this submission. Fetch commands are documented in the source research README; FYERS request parameters are symbol, resolution (`60`, `240`, `D`), date format `1`, date batches, and `cont_flag` 0/1. Sharekhan uses exchange `MX`, scrip code and documented intervals (`60minute`, `daily`); no date range or continuous selector is exposed in the verified SDK.\n""")
    (SUB/"07_REPRODUCIBILITY/METHODOLOGY.md").write_text("""# Methodology\n\nOHLCV source files are untouched broker returns (except epoch-to-IST conversion for FYERS and date/time serialization for Sharekhan). Exact timestamp joins are used within FYERS. Sharekhan intraday cross-broker pairing floors its reported `HH:59` timestamp to hour to pair with FYERS `HH:00`, clearly marked inferred. Daily alignment is by the returned trading-date label. Differences use left minus right; percentage differences divide by right close. No interpolation, forward fill, backfill, or raw price adjustment is applied.\n\nSharekhan 240-minute native bars were not requested because the documented supported interval list ends at 90 minutes. Daily Sharekhan history for current dated codes extends before expiry launch; its older mapping is therefore unresolved and not asserted as raw.\n""")
    (SUB/"07_REPRODUCIBILITY/SOURCE_PROVENANCE.md").write_text("""# Source provenance\n\n- FYERS official API support: https://support.fyers.in/portal/en/kb/fyers-api-integrations/fyers-api/api-v3/data-api (history timestamps are candle starts; symbol master is linked there).\n- Sharekhan official FAQ: https://www.sharekhan.com/faq/API (continuous F&O claim; intraday-history wording).\n- Sharekhan technical docs: https://www.sharekhan.com/trading-api/documentation.\n- MCX Gold product/circulars: https://www.mcxindia.com/products/bullion/gold.\n- CRUDEOILM expiry dates retained in the existing sourced calendar and dated broker master.\n\nNo screenshot was created. Redacted request parameters, actual returned-data manifests, master excerpts and metadata are the evidence.\n""")
    (SUB/"07_REPRODUCIBILITY/DATA_DICTIONARY.md").write_text("""# Data dictionary\n\n`timestamp_ist`: broker timestamp converted/preserved as Asia/Kolkata ISO-8601 offset; `open`, `high`, `low`, `close`: source prices; `volume`: source quantity, unit comparability not assumed. Comparison CSV fields suffix `_a`/`_b` identify pair sides and `close_diff` is A−B. Sharekhan derived 240m, if present, is never a broker-native file and contains a source-row count and partial-bin flag.\n""")
    datasets=pd.DataFrame(manifest);datasets.to_csv(SUB/"00_READ_ME_FIRST/DATASET_MANIFEST.csv",index=False)
    (SUB/"00_READ_ME_FIRST/LIMITATIONS_AND_EXCEPTIONS.md").write_text("""# Limitations and exceptions\n\n- Sharekhan continuous history is advertised generically but no verified MCX continuous identifier/request convention was exposed through the documented SDK/master path.\n- Sharekhan native 240m is absent from documented intervals (max 90m); no native 240m claims.\n- Sharekhan daily calls for dated scrip codes include dates years before expiry, leaving historical contract mapping unresolved.\n- FYERS continuous roll and any back-adjustment method are undocumented.\n- FYERS raw histories begin at their returned earliest valid candles; missing earlier periods are not filled.\n- Sharekhan intraday timestamps are inferred to represent interval end; hourly cross-broker pairing is inferred.\n- Volume units across brokers and across continuous/raw series are not proven comparable.\n- Predixa zone output was not run or recreated; findings concern potential absolute-price displacement.\n""")
    (SUB/"00_READ_ME_FIRST/DELIVERABLE_CHECKLIST.md").write_text("""# Deliverable checklist\n\n- [x] Verified broker-native OHLCV exports and metadata included\n- [x] Phase 1 raw-vs-continuous analysis, same-expiry broker check, calendar and limitation evidence included\n- [x] Phase 2 CRUDEOILM/GOLD 60m/240m/daily FYERS comparisons included where valid data exists\n- [x] Sharekhan continuous and native 240m explicitly unavailable through verified path\n- [x] Markdown and PDF reports generated\n- [x] Data-quality, coverage, comparison and integrity manifests included\n- [x] Credential scan and ZIP integrity checks recorded in final QA report\n""")
    (SUB/"00_READ_ME_FIRST/README.md").write_text("""# Predixa futures comparison submission\n\nStart with `EXECUTIVE_SUMMARY.pdf`, then `../01_FINAL_REPORTS/CONSOLIDATED_FINAL_REPORT.pdf`. Raw broker CSVs and sidecar metadata are organized by instrument/timeframe. `05_EVIDENCE/` documents Sharekhan continuous limitation and symbol mapping; `06_VALIDATION/` contains row-level analysis and quality checks; `07_REPRODUCIBILITY/` contains scripts and methods. Missing Sharekhan continuous data is documented, never fabricated.\n""")
    (SUB/"00_READ_ME_FIRST/EXECUTIVE_SUMMARY.md").write_text((OUT/"EXECUTIVE_SUMMARY.md").read_text())
    # Roll/expiry source references and coverage report.
    (SUB/"05_EVIDENCE/Expiry_Calendar_Sources/REFERENCES.md").write_text("""MCX crude expiry calendar evidence is in `02_PHASE1_CRUDEOILM_60M/Expiry_Calendar/CRUDEOILM_expiry_roll_calendar.csv`. Relevant official circulars: MCX/TRD/479/2024 (2025 calendar), https://www.mcxindia.com/docs/default-source/circulars/english/2024/july/circular-479-2024gue2d6b584-5b04-4249-879a-b7bec478a6b2.pdf?sfvrsn=3a2e2c3c_0; MCX/TRD/319/2025 (2026 calendar), https://www.mcxindia.com/docs/default-source/circulars/english/2025/june/circular---319--2025gu1d376842-57a0-4962-8528-040e570293ba.pdf?sfvrsn=36c4fe9f_0. GOLD 04-Dec-2026 expiry was independently present in FYERS and Sharekhan masters; MCX Gold product page: https://www.mcxindia.com/products/bullion/gold. Actual roll timestamps remain unknown.\n""")
    (SUB/"06_VALIDATION/TIMESTAMP_VALIDATION.md").write_text("FYERS source timestamps are UTC epoch seconds converted to Asia/Kolkata. Official FYERS support says history timestamps denote candle start. Sharekhan tradeDate/tradeTime is retained as given and interpreted in IST for MCX; native timezone/boundary is undocumented. Intraday cross-broker rows are paired by inferred flooring to the hour. Daily rows are aligned by calendar trading-date label; no daily midnight timezone inference is made.\n")
    (SUB/"06_VALIDATION/VOLUME_VALIDATION.md").write_text("Volume values are retained from broker responses. FYERS continuous volume can aggregate different expiry contracts; Sharekhan returns `qty`. Broker and series volume units are not verified equivalent; volume difference statistics are descriptive only and do not support price/zone conclusions.\n")
    (SUB/"06_VALIDATION/VALIDATION_SUMMARY.md").write_text("See DATA_QUALITY_REPORT.csv and validation_detail.json. OHLC range anomalies and zero-volume candles are retained unchanged and classified as warnings. Timestamp duplicates/order/nulls are individually checked. Coverage gaps can include exchange closures/session periods; no interpolation or fill is applied.\n")
    copy_file(COMP/"data_quality_report.csv",SUB/"06_VALIDATION/DATA_QUALITY_REPORT.csv")
    cov=pd.DataFrame([{"dataset":v["dataset"],"rows":v["rows"],"start":v.get("first_timestamp_ist"),"end":v.get("last_timestamp_ist"),"quality_status":v["status"]} for v in validations]);cov.to_csv(SUB/"06_VALIDATION/DATA_COVERAGE_REPORT.csv",index=False)
    # Credential scan over text-readable artifacts; JWT/API authorization patterns are prohibited.
    leaks=[]
    for f in SUB.rglob("*"):
        if not f.is_file() or f.suffix.lower() in {".png",".pdf",".zip"}:continue
        try:t=f.read_text(errors="ignore")
        except:continue
        if re.search(r"eyJ[a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{10,}|Bearer\s+[A-Za-z0-9._-]{20,}|Authorization.{0,10}[:=].{0,10}[A-Za-z0-9._-]{25,}",t,re.I):leaks.append(str(f.relative_to(SUB)))
    if leaks: raise RuntimeError("Credential scan failed: "+", ".join(leaks))
    qa=SUB/"08_PACKAGE_INTEGRITY/FINAL_QA_REPORT.md"
    qa.write_text("""# Final QA report\n\n- Source CSVs and sidecar metadata were copied from physically inspected research artifacts.\n- Rows/coverage are in `06_VALIDATION/DATA_COVERAGE_REPORT.csv`; validation statuses are in `DATA_QUALITY_REPORT.csv`.\n- Reports include Markdown and matplotlib-generated PDFs; charts are also included as PNGs.\n- Credential-pattern scan: passed (0 findings).\n- Production source changes made for this package: none.\n- The package manifest and checksum list exclude their own hashes to avoid recursive checksums; every other packaged file is listed.\n- Archive integrity and extraction checks are performed by the builder after file finalization.\n""")
    def write_integrity_files():
        listing=[]
        for f in sorted(SUB.rglob("*")):
            if f.is_file() and f.name not in {"PACKAGE_MANIFEST.csv","SHA256SUMS.txt"}:
                b=f.read_bytes();listing.append({"path":f.relative_to(SUB).as_posix(),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
        pd.DataFrame(listing).to_csv(SUB/"08_PACKAGE_INTEGRITY/PACKAGE_MANIFEST.csv",index=False)
        (SUB/"08_PACKAGE_INTEGRITY/SHA256SUMS.txt").write_text("".join(f"{x['sha256']}  {x['path']}\n" for x in listing))
        return listing
    zip_path=OUT/"PREDIXA_FUTURES_DATA_COMPARISON_PHASE1_PHASE2_FINAL.zip"
    if zip_path.exists() and not force:raise FileExistsError(f"ZIP exists: {zip_path}; use --force")
    listing=write_integrity_files()
    def archive_and_verify():
        with zipfile.ZipFile(zip_path,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for f in sorted(SUB.rglob("*")):
                if f.is_file():z.write(f,SUB.name+"/"+f.relative_to(SUB).as_posix())
        with zipfile.ZipFile(zip_path) as z:
            bad=z.testzip()
            if bad:raise RuntimeError("ZIP integrity error at "+bad)
            names=set(z.namelist()); required=[SUB.name+"/01_FINAL_REPORTS/"+n for n in ["CONSOLIDATED_FINAL_REPORT.pdf","PHASE1_FINAL_REPORT.pdf","PHASE2_FINAL_REPORT.pdf"]]
            absent=[n for n in required if n not in names]
            if absent:raise RuntimeError("Required PDF missing from ZIP: "+str(absent))
        verify=OUT/"zip_verify"
        if verify.exists():shutil.rmtree(verify)
        verify.mkdir()
        with zipfile.ZipFile(zip_path) as z:z.extractall(verify)
        extracted=verify/SUB.name
        pdfs=list(extracted.rglob("*.pdf"));csvs=list(extracted.rglob("*.csv"));pngs=list(extracted.rglob("*.png"))
        for f in pdfs:
            if f.stat().st_size<1000:raise RuntimeError("PDF suspiciously small: "+str(f))
        for f in csvs:
            with f.open(newline="") as h: next(csv.reader(h),None)
        return extracted,pdfs,csvs,pngs
    extracted,pdfs,csvs,pngs=archive_and_verify()
    qa.write_text(qa.read_text()+f"\n- ZIP integrity: passed; extraction verification: passed; PDFs={len(pdfs)}, CSVs={len(csvs)}, charts={len(pngs)}.\n")
    listing=write_integrity_files()
    extracted,pdfs,csvs,pngs=archive_and_verify()
    digest=hashlib.sha256(zip_path.read_bytes()).hexdigest();(OUT/(zip_path.name+".sha256")).write_text(f"{digest}  {zip_path.name}\n")
    print(json.dumps({"zip":str(zip_path),"bytes":zip_path.stat().st_size,"files":sum(1 for x in SUB.rglob('*') if x.is_file()),"pdfs":len(pdfs),"csvs":len(csvs),"charts":len(pngs),"credential_scan":"passed","zip_test":"passed","sha256":digest},indent=2))

if __name__=="__main__":main()
