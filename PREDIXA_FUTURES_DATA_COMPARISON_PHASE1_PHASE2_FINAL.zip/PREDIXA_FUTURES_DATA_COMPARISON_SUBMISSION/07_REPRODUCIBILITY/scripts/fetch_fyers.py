#!/usr/bin/env python3
"""Fetch broker-native FYERS OHLCV for the CRUDEOILM series comparison.

Uses the repository's token handler by default.  No credential is written to
stdout, CSV, JSON metadata, or this source file.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "research" / "zone_series_comparison"


def chunks(start: date, end: date, days: int = 90):
    current = start
    while current <= end:
        stop = min(current + timedelta(days=days - 1), end)
        yield current, stop
        current = stop + timedelta(days=1)


def atomic_json(path: Path, payload: dict, force: bool) -> None:
    if path.exists() and not force:
        raise FileExistsError(f"Refusing to overwrite existing output: {path}; use --force")
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def atomic_csv(path: Path, rows: list[dict], force: bool) -> None:
    if path.exists() and not force:
        raise FileExistsError(f"Refusing to overwrite existing output: {path}; use --force")
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["timestamp_ist", "open", "high", "low", "close", "volume"])
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def fyers_client():
    # Reuse the project handler instead of accepting or logging a token.
    sys.path.insert(0, str(ROOT))
    from data_fetchers.fyers.fyers_session import fyers_access_token_handler
    from fyers_apiv3 import fyersModel

    credential = fyers_access_token_handler().get_access_token()
    if not credential or ":" not in credential:
        raise RuntimeError("FYERS token handler did not return an appid:token credential")
    app_id, token = credential.rsplit(":", 1)
    return fyersModel.FyersModel(client_id=app_id, token=token, is_async=False, log_path="")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--continuous", choices=("0", "1"), required=True)
    parser.add_argument("--start", default="2025-10-09")
    parser.add_argument("--end", default="2026-10-08")
    parser.add_argument("--output", required=True)
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--contract-expiry", help="ISO date; only for a verified dated-symbol pull")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    output, metadata = OUT / "data" / args.output, OUT / "metadata" / args.metadata
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata.parent.mkdir(parents=True, exist_ok=True)
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    client = fyers_client()
    raw_rows, failures, request_log = [], [], []
    for left, right in chunks(start, end):
        request = {"symbol": args.symbol, "resolution": "60", "date_format": "1",
                   "range_from": left.isoformat(), "range_to": right.isoformat(),
                   "cont_flag": args.continuous}
        success = False
        for attempt in range(4):
            try:
                response = client.history(data=request)
                candles = response.get("candles") if isinstance(response, dict) else None
                if candles is not None:
                    raw_rows.extend(candles)
                    request_log.append({**{k: v for k, v in request.items() if k != "symbol"}, "symbol": args.symbol,
                                        "returned_candles": len(candles)})
                    success = True
                    break
                message = (response or {}).get("message", "unknown non-candle response")
                if "token" in str(message).lower() or "auth" in str(message).lower():
                    raise RuntimeError(f"Authentication/permission response: {message}")
                raise RuntimeError(f"FYERS response: {message}")
            except Exception as exc:
                if attempt == 3:
                    failures.append({"range_from": left.isoformat(), "range_to": right.isoformat(), "error": str(exc)})
                else:
                    time.sleep(min(16, 2 ** attempt) + random.random())
        if not success:
            continue
        time.sleep(0.25)
    duplicate_count = 0
    unique = {}
    for candle in raw_rows:
        if len(candle) < 6:
            continue
        epoch = int(candle[0])
        if epoch in unique:
            duplicate_count += 1
        unique[epoch] = candle
    rows = []
    for epoch, candle in sorted(unique.items()):
        ts = datetime.fromtimestamp(epoch, tz=timezone.utc).astimezone(IST).isoformat()
        rows.append({"timestamp_ist": ts, "open": candle[1], "high": candle[2], "low": candle[3], "close": candle[4], "volume": candle[5]})
    atomic_csv(output, rows, args.force)
    atomic_json(metadata, {
        "source_broker": "FYERS", "api_symbol": args.symbol, "pull_type": "continuous" if args.continuous == "1" else "dated_raw",
        "contract_expiry": args.contract_expiry,
        "cont_flag": args.continuous, "resolution": "60", "requested_start": start.isoformat(), "requested_end": end.isoformat(),
        "actual_first_timestamp_ist": rows[0]["timestamp_ist"] if rows else None,
        "actual_last_timestamp_ist": rows[-1]["timestamp_ist"] if rows else None,
        "total_rows": len(rows), "raw_response_candle_count": len(raw_rows), "duplicate_epoch_count_removed": duplicate_count,
        "native_timestamp_format": "Unix epoch seconds", "native_timestamp_timezone": "UTC epoch", "converted_timezone": "Asia/Kolkata",
        "candle_timestamp_boundary": "Undocumented by FYERS; treated as returned candle timestamp without shifting.",
        "volume": "Broker-returned candle volume", "request_batches": request_log, "failures": failures,
        "collected_at_ist": datetime.now(IST).isoformat(),
    }, args.force)
    print(f"rows={len(rows)} failures={len(failures)} output={output}")
    return 0 if rows and not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
