#!/usr/bin/env python3
"""Read-only integrity checks for exported broker-native OHLCV CSVs."""
from __future__ import annotations
import json
import sys
from pathlib import Path
import pandas as pd

def main():
    path = Path(sys.argv[1])
    df = pd.read_csv(path)
    required = ["timestamp_ist", "open", "high", "low", "close", "volume"]
    result = {"path": str(path), "rows": len(df), "missing_columns": [c for c in required if c not in df]}
    if not result["missing_columns"]:
        ts = pd.to_datetime(df.timestamp_ist, errors="coerce", utc=True)
        nums = df[["open", "high", "low", "close", "volume"]].apply(pd.to_numeric, errors="coerce")
        result.update({"invalid_timestamps": int(ts.isna().sum()), "duplicate_timestamps": int(ts.duplicated().sum()),
                       "nonascending_timestamp_pairs": int((ts.diff().dt.total_seconds().fillna(1) <= 0).sum()) - int(ts.duplicated().sum()),
                       "null_ohlcv_cells": int(nums.isna().sum().sum()),
                       "high_below_open_close_low": int(((nums.high < nums[["open", "close", "low"]].max(axis=1))).sum()),
                       "low_above_open_close_high": int(((nums.low > nums[["open", "close", "high"]].min(axis=1))).sum()),
                       "zero_volume_rows": int((nums.volume == 0).sum())})
    print(json.dumps(result, indent=2))

if __name__ == "__main__": main()
