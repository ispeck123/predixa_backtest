# Reproduction

The data were retrieved via documented read-only broker history/master calls on 2026-10-09 IST and then analyzed offline. Scripts use the existing FYERS token handler and existing Sharekhan configured token store/environment; no credentials are included.

`python scripts/validate_ohlcv.py <csv>` validates a data file. `python scripts/finalize_submission.py` (run from repository root before packaging) rebuilds metrics/reports. Broker requests are not required to inspect this submission. Fetch commands are documented in the source research README; FYERS request parameters are symbol, resolution (`60`, `240`, `D`), date format `1`, date batches, and `cont_flag` 0/1. Sharekhan uses exchange `MX`, scrip code and documented intervals (`60minute`, `daily`); no date range or continuous selector is exposed in the verified SDK.
