# Methodology

OHLCV source files are untouched broker returns (except epoch-to-IST conversion for FYERS and date/time serialization for Sharekhan). Exact timestamp joins are used within FYERS. Sharekhan intraday cross-broker pairing floors its reported `HH:59` timestamp to hour to pair with FYERS `HH:00`, clearly marked inferred. Daily alignment is by the returned trading-date label. Differences use left minus right; percentage differences divide by right close. No interpolation, forward fill, backfill, or raw price adjustment is applied.

Sharekhan 240-minute native bars were not requested because the documented supported interval list ends at 90 minutes. Daily Sharekhan history for current dated codes extends before expiry launch; its older mapping is therefore unresolved and not asserted as raw.
