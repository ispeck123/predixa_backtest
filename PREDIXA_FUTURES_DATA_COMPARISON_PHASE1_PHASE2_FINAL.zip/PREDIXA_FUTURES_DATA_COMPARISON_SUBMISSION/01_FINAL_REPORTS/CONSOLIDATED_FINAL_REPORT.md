# Predixa — Final Historical Futures Data Comparison & Zone-Series Assessment

## Executive decision summary

Observed FYERS CRUDEOILM raw-vs-continuous divergence over 1302 identical 60m timestamps is mean absolute ₹208.61, p95 ₹531.95, max ₹1,280.00; raw-minus-continuous mean is ₹-199.20. These offsets are large enough to be a credible material risk for absolute historical zone coordinates. The evidence supports continuous-series input for further offline zone testing, but not a production change.

The complete requested Sharekhan continuous comparison remains unexecuted. FYERS provides more complete continuous coverage; dated raw availability begins later. Sharekhan’s same-expiry intraday raw feeds corroborate prices on a short recent overlap, but Sharekhan daily histories expose pre-expiry dates and cannot safely be classified as raw. No actual Predixa zone output changes were tested.

## Scope and availability matrix

| Instrument/timeframe | FYERS continuous | FYERS raw | Sharekhan dated/API history | Sharekhan continuous |
|---|---|---|---|---|
| CRUDEOILM 60m | Native, 2025-10-09–2026-10-08 | Native, 2026-05-22–2026-10-08 | Native 60m dated, 2026-09-01–2026-10-08 | Unavailable through verified path |
| CRUDEOILM 240m | Native | Native | Native 240m undocumented; derived Sharekhan 240m from 60m is included as secondary | Unavailable through verified path |
| CRUDEOILM daily | Native | Native from 2026-04-21 | Daily API history from 2015; historical mapping unresolved | Unavailable through verified path |
| GOLD 60m | Native, full requested window | Native from 2026-05-14 | Native 60m dated, 2026-09-01–2026-10-08 | Unavailable through verified path |
| GOLD 240m | Native | Native from 2026-05-14 | Native 240m undocumented; derived Sharekhan 240m from 60m is included as secondary | Unavailable through verified path |
| GOLD daily | Native | Native from 2025-12-16 | Daily API history from 2011; historical mapping unresolved | Unavailable through verified path |

## Sharekhan limitation statement

“Sharekhan publicly advertises continuous F&O historical data; however, the documented SDK method and authenticated MCX instrument master available during this investigation did not expose a verified continuous CRUDEOILM instrument identifier or request convention. Therefore, Sharekhan continuous futures data was not included in the quantitative comparison. This limitation applies to the verified access path and does not establish that Sharekhan categorically lacks continuous futures functionality.”

## Comparative findings and zone assessment

FYERS native/raw dated series comparisons (signed difference is raw minus continuous; INR in instrument quote units):

| Instrument | Timeframe | Matched bars | Signed mean raw−continuous | MAE | Median abs | p95 abs | Max abs | RMSE | Correlation |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| CRUDEOILM | 60m | 1302 | ₹-199.20 | ₹208.61 | ₹166.50 | ₹531.95 | ₹1,280.00 | ₹283.22 | 0.9751 |
| CRUDEOILM | 240m | 351 | ₹-201.13 | ₹210.96 | ₹171.00 | ₹533.50 | ₹1,215.00 | ₹286.82 | 0.9743 |
| CRUDEOILM | Daily | 122 | ₹-472.15 | ₹481.20 | ₹251.00 | ₹1,629.70 | ₹2,113.00 | ₹713.26 | 0.8405 |
| GOLD | 60m | 1350 | ₹3,697.19 | ₹3,697.19 | ₹2,242.50 | ₹9,729.55 | ₹15,746.00 | ₹4,775.70 | 0.8821 |
| GOLD | 240m | 366 | ₹3,759.79 | ₹3,759.79 | ₹2,271.00 | ₹10,178.25 | ₹15,587.00 | ₹4,850.34 | 0.8815 |
| GOLD | Daily | 210 | ₹10,752.77 | ₹10,752.77 | ₹7,891.00 | ₹25,066.80 | ₹78,514.00 | ₹15,058.51 | 0.6126 |

- CRUDEOILM 60m: mean absolute FYERS raw/continuous close displacement ₹208.61; p95 ₹531.95; 1302 common timestamps.
- CRUDEOILM raw cross-broker 60m: 397 inferred-aligned rows, MAE ₹1.04; same expiry, raw-vs-raw.
- GOLD raw-vs-continuous 60m: 1350 common timestamps, MAE ₹3,697.19; full metrics are in the comparison CSV/JSON.
- Native FYERS comparisons are calculated for 240m and daily for both instruments. The raw contracts have shorter ranges and actual overlap is respected.
- Sharekhan native 240m is not documented; 240m Sharekhan series are explicitly derived from 60m and compared only as mixed raw/continuous secondary evidence. Sharekhan continuous-vs-continuous is not calculated. Sharekhan daily series from dated scrip codes predate the selected expiries, and are not treated as verified raw.

The inspected zone implementation derives absolute ranges from OHLC, especially high/low, and uses candle pattern/range structure; volume is not required for core zone-level placement. Therefore price displacement plausibly shifts zone levels and may change patterns. Actual zone outputs were not reproduced. Continuous history/live dated-futures mapping remains a risk requiring an explicit roll/basis method.

## Recommendation

Use the measured continuous-vs-raw differences as a trigger for controlled, offline zone-generation replay with fixed settings and well-defined live-price mapping. Do not change production behavior based on this report alone. Obtain broker roll/adjustment documentation and a verifiable Sharekhan continuous mapping before cross-broker continuous validation.

## Reproducibility and limitations

Research data, metadata, scripts, comparisons, charts, quality logs, API references, and evidence are in the sibling folders of this report. No prices were synthesized for missing history. FYERS roll/adjustment method remains unknown; Sharekhan continuous is unresolved through the verified path; Sharekhan native 240m is not documented; Sharekhan daily contract mapping is ambiguous; Sharekhan 60m timestamp alignment is inferred; volume-unit comparability is not established.
