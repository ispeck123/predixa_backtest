# Predixa — CRUDEOILM 60-Minute Futures Historical Series Comparison

**Phase 1 — Completed with documented external data limitation.** All feasible requested data were retrieved, validated, aligned, and analyzed; Sharekhan continuous was not retrievable through the verified API path, so the originally required continuous-vs-continuous comparison remains unexecuted.

## Executive summary

FYERS returned 3,765 continuous and 1,302 dated raw CRUDEOILM 60-minute candles across 2025-10-09–2026-10-08 and 2026-05-22–2026-10-08 respectively. The matched raw/continuous sample is 1302 bars; mean signed close difference (raw − continuous) ₹-199.20, MAE ₹208.61, p95 absolute difference ₹531.95, maximum ₹1,280.00, correlation 0.9751. This indicates material absolute price-level divergence for historical zone coordinates. It does not reproduce Predixa zone output.

The exact October contract is MCX CRUDEOILM expiry 2026-10-19, FYERS `MCX:CRUDEOILM26OCTFUT` with `cont_flag=0`, Sharekhan scrip 569901. FYERS continuous used the same API symbol with `cont_flag=1`.

## Research objective and methods

Timestamp joins use exact FYERS start timestamps for raw/continuous. Cross-broker 60m rows are paired by the inferred rule: Sharekhan `tradeTime` values near `HH:59` floored to the hour to align with FYERS candle-start `HH:00`; original CSVs remain unchanged. Signed difference is left series minus right series; percentage difference denominator is the right-hand close. No missing bars were filled.

## Dataset manifest and coverage

| Dataset | Pull | Rows | Actual IST coverage |
|---|---|---:|---|
| FYERS CRUDEOILM continuous 60m (`cont_flag=1`) | `MCX:CRUDEOILM26OCTFUT` | 3,765 | 2025-10-09 09:00 – 2026-10-08 23:00 |
| FYERS CRUDEOILM raw 60m (`cont_flag=0`) | same dated symbol; expiry 2026-10-19 | 1,302 | 2026-05-22 21:00 – 2026-10-08 23:00 |
| Sharekhan CRUDEOILM 60m | `MX`, scrip 569901; dated Oct-2026 | 397 | 2026-09-01 09:59:05 – 2026-10-08 23:30:59 |
| Sharekhan continuous | not identified | — | — |

## FYERS raw vs continuous

| Metric | Value |
|---|---:|
| Common timestamps | 1302 |
| Raw timestamps matched | 100.00% |
| Mean signed close difference | ₹-199.20 |
| Mean absolute / median absolute | ₹208.61 / ₹166.50 |
| p95 / maximum absolute | ₹531.95 / ₹1,280.00 |
| RMSE / correlation | ₹283.22 / 0.9751 |
| Mean absolute percentage difference (continuous denominator) | 2.503% |

Median signed close difference is ₹-166.50; mean signed open/high/low differences and all volume statistics are in the row-level comparison outputs. Matched-bar volume differences are descriptive only: FYERS continuous volume may represent different expiry contracts through time and volume units/roll construction are undocumented.

The dated raw series begins later than continuous history; unmatched earlier continuous bars are not treated as raw zeroes or backfilled. Raw OHLCV is retained as received. Divergence may reflect futures basis/term structure as well as unknown continuous roll/adjustment behavior; rollover causation is not established.

## FYERS raw vs Sharekhan raw

Sharekhan's matched dated-contract 60m values closely corroborate FYERS on the recent sample, subject to inferred timestamp pairing. Common rows: 397; mean close difference FYERS−Sharekhan ₹0.04; MAE ₹1.04; p95 ₹4.00; maximum ₹87.00; correlation 0.99986. This is same dated expiry raw-vs-raw, not continuous agreement. Volume units are not independently established as comparable.

## Sharekhan continuous limitation

Sharekhan FAQ publicly advertises continuous F&O data. The documented SDK method is `historicaldata(exchange, scripcode, interval)` mapped to `/skapi/services/historical/<exchange>/<scripcode>/<interval>`. The verified MCX master exposes dated CRUDEOILM futures codes; no continuous selector or clearly identified non-expiring CRUDEOILM identifier was available. The limitation is through the verified path, not a claim that Sharekhan universally lacks this feature. See `05_EVIDENCE/Sharekhan_API_Investigation/SHAREKHAN_CONTINUOUS_LIMITATION.md`.

## Expiry, timestamps, and data quality

Verified CRUDEOILM expiries in the requested analysis window: 20-Oct-2025, 19-Nov-2025, 18-Dec-2025, 16-Jan-2026, 19-Feb-2026, 19-Mar-2026, 20-Apr-2026, 18-May-2026, 18-Jun-2026, 20-Jul-2026, 19-Aug-2026, 21-Sep-2026, and 19-Oct-2026. These are exchange expiries; FYERS actual roll dates remain unknown.

Verified October expiry is 19-Oct-2026, as shown in both broker instrument masters; verified nearby September expiry 21-Sep-2026 is retained in the calendar. Actual continuous roll dates/method are unknown and are not equated with expiry. FYERS History API timestamps are candle starts (official support documentation) and were converted from UTC epoch to IST. Sharekhan provides tradeDate/tradeTime, with timezone/boundary semantics undocumented. FYERS continuous rows retain OHLC geometry anomalies; see validation CSV. No anomalous bars were silently dropped.

## Zone-series risk and recommendation

The inspected offline zone path consumes absolute price ranges derived from OHLC highs/lows; volume is not an input to the core range/pattern logic. An average absolute close divergence of ₹208.61 and p95 of ₹531.95 can materially displace absolute candidate boundaries and affect pattern/range classification. No zone function was executed, so changed zone signals are not asserted.

**Finding: Supports continuous-series input for further offline zone testing, not a production switch.** Before any decision, validate how historical continuous prices map to live dated-contract prices, and obtain Sharekhan’s supported continuous mapping/roll details.

## Limitations

- No verified Sharekhan continuous CRUDEOILM series; comparison not executed.
- Raw expiry history starts 2026-05-22; no full-year raw series exists in returned data.
- FYERS continuous roll/back-adjustment method is undocumented.
- Sharekhan intraday timestamps are only inferred-aligned; volume equivalence is unknown.
- Predixa zones were inspected conceptually but not recomputed offline.

## Evidence and reproduction

See `02_PHASE1_CRUDEOILM_60M/`, `06_VALIDATION/`, `05_EVIDENCE/`, and `07_REPRODUCIBILITY/`.
