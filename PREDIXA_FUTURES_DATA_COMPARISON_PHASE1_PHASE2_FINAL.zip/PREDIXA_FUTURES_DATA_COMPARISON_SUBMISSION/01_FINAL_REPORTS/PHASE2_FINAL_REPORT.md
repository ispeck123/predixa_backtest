# Predixa — Multi-Instrument and Multi-Timeframe Futures Series Analysis

## Executive summary

Phase 2 extends the comparison to standard MCX GOLD (not GOLDM) across 60m, 240m, and daily bars, while also adding 240m and daily CRUDEOILM analysis. FYERS supplied native continuous and dated raw data for all required timeframes; Sharekhan supplied 60m and daily scrip-code histories. Sharekhan native 240m is not in the documented interval list (documented maximum 90 minutes); no 240m API request was invented. A secondary 240m derivation was produced from Sharekhan 60m with explicit session anchoring and partial-bin metadata; it is never called native.

## Instrument selection

Selected **GOLD** standard futures because both authenticated MCX masters contained exact `GOLD` futures with matching 04-Dec-2026 expiry (FYERS symbol `MCX:GOLD26DECFUT`; Sharekhan scrip 495213), avoiding GOLDM/GOLD mismatch.

## Native FYERS findings

| Instrument/timeframe | FYERS continuous | FYERS raw | Common candles | Mean abs close difference | p95 abs | Max abs | Correlation |
|---|---:|---:|---:|---:|---:|---:|---:|
| CRUDEOILM 240m | 1006 | 351 | 351 | ₹210.96 | ₹533.50 | ₹1,215.00 | 0.9743 |
| CRUDEOILM Daily | 258 | 122 | 122 | ₹481.20 | ₹1,629.70 | ₹2,113.00 | 0.8405 |
| GOLD 60m | 3748 | 1350 | 1350 | ₹3,697.19 | ₹9,729.55 | ₹15,746.00 | 0.8821 |
| GOLD 240m | 1002 | 366 | 366 | ₹3,759.79 | ₹10,178.25 | ₹15,587.00 | 0.8815 |
| GOLD Daily | 258 | 210 | 210 | ₹10,752.77 | ₹25,066.80 | ₹78,514.00 | 0.6126 |

CRUDEOILM 60m Phase 1 full-window comparison: 1302 matched rows; MAE ₹208.61, p95 ₹531.95. GOLD 60m raw-vs-continuous: 1350 matches; MAE ₹3,697.19, p95 ₹9,729.55.

## Sharekhan cross-broker data and limitations

Native Sharekhan 60m raw dated contract data overlap FYERS only in the broker’s default recent window. Inferred timestamp pairing is `floor_hour` because Sharekhan reports HH:59:xx and FYERS reports bar starts. Results are separately labeled raw-vs-raw. Sharekhan daily history requests for scrip codes 569901 and 495213 returned bars years before the current expiry contracts existed. Therefore those outputs are called **scrip-code daily histories with unresolved historical contract mapping**; they are not certified raw dated series or continuous series. This limitation materially restricts daily cross-broker conclusions.

Sharekhan’s documented native interval maximum is 90 minutes; 240m is unavailable natively in this verified SDK path. No 240m Sharekhan data is represented as native. Derived 240m bins use the metadata-documented session anchor, do not bridge trading dates, and remain secondary-only.

## Zone-series impact

Raw-vs-continuous comparisons measure absolute-price offset, not a change in generated zones. The application’s inspected zone path operates on OHLC highs/lows and absolute price levels; a series offset can therefore displace candidate levels. No production zone code was invoked. Switching from continuous historical zones to live dated-contract prices would also require an explicit mapping/roll policy.

## Limitations and evidence

See individual CSV metadata, `06_VALIDATION/`, row-level comparison tables, and figures. Sharekhan continuous is unavailable through the verified path; FYERS roll adjustments are undocumented; Sharekhan daily contract mapping is unresolved; Sharekhan intraday boundary alignment is inferred; volumes are retained but not presumed comparable.

## Sharekhan cross-broker results and derived timeframe

Raw-vs-raw 60m (inferred hourly timestamp pairing): CRUDEOILM 397 common bars, MAE ₹1.04, p95 ₹4.00, correlation 0.9999; GOLD 397 bars, MAE ₹6.32, p95 ₹44.60, correlation 0.9999.

Sharekhan daily-by-scrip-code versus FYERS continuous (date-aligned, **descriptive only; mapping unresolved**): CRUDEOILM 97 dates, mean signed difference ₹237.93; GOLD 162 dates, mean signed difference ₹-6,307.14. Because the Sharekhan histories start before the identified expiry contracts existed, these are not certified raw/continuous comparisons.

Sharekhan has no documented native 240m interval (documented max 90m). We generated secondary 240m bars from Sharekhan native 60m using Asia/Kolkata 09:00 session anchoring, separate 4-hour bins, source OHLC first/max/min/last, and summed within-broker `qty`; final session groups are marked partial. Comparing those recent derived dated-series rows with FYERS native continuous 240m is mixed continuous-vs-raw and not a like-for-like broker test: CRUDEOILM 106 rows, MAE ₹184.19; GOLD 105 rows, MAE ₹1,599.56.
