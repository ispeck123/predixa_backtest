# Full-run validation findings

Both run databases pass SQLite integrity checks, but full expiry validation does not pass.

- TF2 / 60m validator command was run against the pinned NSEFO expiry map. It stopped with `KeyError: no NSEFO NEAR expiry observation for CDSL on 2026-02-01`. The selected derived 60m source file contains Sunday 2026-02-01 candles, and 44 trades entered on weekend dates.
- TF25 / 75m validator command was run after the run finalized. It stopped with `KeyError: no NSEFO NEAR expiry observation for ABCAPITAL on 2025-02-01`. The completed ledger contains 138 weekend-entry trades and 12 UNRESOLVED trades.
- Neither full run is accepted as final strategy performance. The results are preserved as provisional research evidence.
- The expiry-map status is `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER`; contract attribution is the declared FYERS continuous-container-as-NEAR assumption.
