# NSEFO TF2/60m and TF25/75m Backtest Status & Evaluation

**Final status checked:** 2026-11-17 06:25 EST  
**Classification:** Provisional expiry-aware research; not an officially verified contract-attributed performance certification.

## Executive summary

- **TF2 / 60m:** engine run is marked completed; 57,145 tasks completed and 2,884 failed. The database passes SQLite integrity, but the result is **not performance-validated**: 44 persisted trades entered on Sundays, while the derived NSEFO 60m source files contain Sunday bars. The expiry validator also aborts because the Sunday date has no NSEFO expiry-map observation. Do not treat its aggregate performance as final.
- **TF25 / 75m:** the full run is now **completed**: 229,464 tasks completed and 3,360 failed. SQLite integrity passes. However, it has 138 persisted weekend-entry trades and 12 unresolved trades; expiry validation fails on a Sunday entry date. Its output is completed but **not validated for final performance use**.
- Both full runs use an NSEFO expiry map whose verification state is `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER`; both label the series contract-slot assumption as FYERS continuous container treated as observed NEAR.

## Run inventory

| Run | Run ID | TF / bar stack | Status | Date range | Configured symbols | Workers | Tasks |
|---|---|---|---|---|---:|---:|---:|
| TF2 | `d3cb21dcaac04094a1714cdffee455b1` | TF2 / 60m | COMPLETED | 2024-10-01–2026-09-30 | 152 | 24 | 60,029 |
| TF25 | `186ba0f0b3e2418cb0cf10beb877a122` | TF25 / 75m | COMPLETED, validation failed | 2024-10-01–2026-09-30 | 152 | 24 | 232,824 |

### TF2 / 60m completed-run results

- Task statuses: {'COMPLETED': 57145, 'FAILED': 2884} (completed 57,145; failed 2,884; completion rate 95.20%).
- Signal records: 17,093; setups by disposition: {'ALLOWED': 4425, 'entry_window_closed': 12544, 'rr_below_2.1': 124}.
- Persisted trades: 4,369 across 19 symbols; outcomes: {'LOSS': 3011, 'WIN': 812, 'TIME_EXIT': 546}. Resolved-trade win rate: 21.24% (812 wins / 3,823 WIN or LOSS trades).
- Gross realized result: **-209.743 R**; mean -0.0480 R/trade; profit factor 0.932; cumulative event-ordered drawdown 700.85 R. These are gross R metrics, before monetary sizing and costs, and are not a valid final performance verdict given the timestamp defect below.
- Expiry `TIME_EXIT`: 546 trades (444.413 R total).
- Input/run evidence: ok SQLite integrity; expiry rules were not fully auditable because the validator stopped on an unobserved Sunday session.

### TF25 / 75m completed-run results

- Final task statuses: 229,464 completed and 3,360 failed (98.56% completed; all 232,824 tasks terminal).
- Signal records: 57,773; setup dispositions: 16,296 ALLOWED, 41,050 `entry_window_closed`, 427 `rr_below_2.1`.
- Persisted trades: 16,151; outcomes: 11,263 LOSS, 3,043 WIN, 1,833 TIME_EXIT, and 12 UNRESOLVED. Resolved WIN/LOSS win rate: 21.27%.
- Gross realized result including TIME_EXIT R and excluding unresolved trades: **-530.729 R**; mean -0.0329 R/trade; profit factor 0.954; cumulative event-ordered drawdown 2,177.89 R. These are gross R diagnostics, before monetary sizing and costs, and are not a final performance verdict due the timestamp defect.
- Expiry `TIME_EXIT`: 1,833 trades (1,286.533 R total). The 12 UNRESOLVED trades remain unresolved and are not counted as wins or losses.
- Weekend entry timestamps: 138 trades across 24 symbols, net +163.617 R. This materially affects the result and demonstrates the input timestamp issue in the 75m run.
- Run status finalized at `2026-11-17T11:25:38Z`; SQLite integrity is `ok`.

## Critical data and validation findings

1. **Weekend candles are present in the exact derived input view used by the run.** For CDSL, JIOFIN, PHOENIXLTD, and TORNTPHARM, the file `research/fyers_backtest_execution_20261110/data_quality/derived_valid_source_view/NSEFO/latest_data_csv/<SYMBOL>_27102026_sixty.csv` contains 60m rows timestamped Sunday 2026-02-01 from 09:15 through 15:15 IST. These are not NSEFO trading-session timestamps.
2. TF2 persisted **44 Sunday/weekend-entry trades** across CDSL@27102026, JIOFIN@27102026, PHOENIXLTD@27102026, TORNTPHARM@27102026; all 44 were LOSS, totaling -44.00 R. This is direct evidence the run executed on non-trading-day bars, so its reported aggregate performance is contaminated.
3. The full TF2 expiry validator was run against the configured map and failed with `KeyError: no NSEFO NEAR expiry observation for CDSL on 2026-02-01`. This is consistent with the weekend candle evidence; no expiry compliance pass is claimed.
4. TF2 finalized with 2,884 failed tasks and 7 distinct error groups. Error groups include insufficient E-TF warm-up (1–6 bars when 7 are required) and `single positional indexer is out-of-bounds` (294 attempts). The run status COMPLETED therefore means tasks reached terminal states, not that every task succeeded.
5. The TF25 full run finalized with 12 UNRESOLVED trades. They are not counted as resolved wins/losses; the unresolved cases require separate disposition.
6. Full TF25 expiry validation was attempted and failed with `KeyError: no NSEFO NEAR expiry observation for ABCAPITAL on 2025-02-01`, again a Sunday absent from the exchange expiry-map sessions.
7. The NSEFO expiry-map verification state is `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER`; contract identity is a provisional NEAR-slot assumption. These artifacts remain research evidence, not owner-verified official attribution.

## Validation and deliverable status

- TF2 SQLite `PRAGMA integrity_check`: `ok`.
- TF2 sample run `369c1e72fa3b4c40a481f38093f02969`: passed its focused validator (266 tasks, 6 losses, zero cutoff violations and zero task errors). That sample pass does not override the full-run Sunday-bar defect.
- TF2 full expiry validation: **failed / not evaluable** because the trade ledger includes a Sunday entry date without an expiry-map session.
- TF25 full run: completed with 3,360 failed tasks, but full expiry validation **failed** on a Sunday timestamp; no final performance claim is made.
- Do not combine TF2 and TF25 performance: they are separate timeframes and both contain invalid weekend executions.

## Artifact paths

- TF2 SQLite: `research/fyers_backtest_execution_20261117/NSEFO_full/nsefo_tf2_60m_expiry_aware_20261117.sqlite`
- TF2 full log: `logs/nsefo_tf2_60m_full_20261117.log`
- TF2 sample validation: `research/fyers_backtest_execution_20261117/sample_validation/NSEFO/nsefo_tf2_60m_sample_20261117.json`
- TF25 SQLite: `research/fyers_backtest_execution_20261117/NSEFO_full/nsefo_tf25_75m_expiry_aware_20261117.sqlite`
- TF25 original log: `logs/nsefo_tf25_75m_full_20261117.log`
- TF25 resume log: `logs/nsefo_tf25_75m_resume_20261117.log`
- NSEFO expiry map: `/home/ispeck/PROJECTS_DEV/STP_LATEST/fin_backend_final_latest/research/expiry_history/nsefo_official_extended_20261027_v2/NSEFO_historical_expiry_map.csv` (SHA-256 `e2a14377a6fde20bba7e747554a3dc172aa63e53fae588ce4396efd59a4409d7`)

## Conclusion

Both runs are complete, but **neither is accepted as a reliable final performance measurement**. TF2/60m contains 44 Sunday-entry trades; TF25/75m contains 138. The full validators fail on Sunday timestamps absent from the NSEFO expiry map. Both databases pass SQLite integrity, which confirms database consistency but does not validate the trading data. The evidence points to a non-trading-session filtering defect in the derived NSEFO view or its loader. Preserve the databases and logs; resolve the weekend-candle issue and rerun before using either result as final strategy performance.
