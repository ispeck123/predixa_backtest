# NSEFO TF2/60m and TF25/75m submission evidence

Prepared 2026-11-17. This package contains both full run databases as standalone SQLite backup copies, their run exports, logs, sample artifacts, the exact expiry-map snapshot, selected source CSVs showing weekend candles (including the exact TF25 input root), validation findings, and a detailed report.

## Run IDs
- TF2/60m: `d3cb21dcaac04094a1714cdffee455b1`
- TF25/75m: `186ba0f0b3e2418cb0cf10beb877a122`

## Important interpretation
Both runs finalized and both database copies pass `PRAGMA integrity_check`. Full expiry validation fails for each run on an NSEFO Sunday entry timestamp absent from the pinned expiry map. TF2 has 44 weekend-entry trades; TF25 has 138 weekend-entry trades and 12 unresolved trades. Treat the results as completed provisional research records, **not validated final performance**. The expiry map remains `OFFICIAL_SOURCE_CONFIRMED_PENDING_OWNER`; slot attribution is a documented continuous-container-as-NEAR assumption.

The `source_file_hashes.csv` file records SHA-256 hashes of copied source files. The full original databases and source CSVs in the repository were not modified. The bundled database files are backup copies. Monetary P&L and transaction-cost-adjusted performance are not asserted; trade results are reported in gross R.

See `01_REPORTS/NSEFO_TF2_60m_TF25_75m_Status_and_Evaluation_20261117.md` for detailed findings.


TF25 input root pinned in run config: `research/fyers_backtest_execution_20261110/data_quality/derived_valid_source_view_tf25_20261114/NSEFO/latest_data_csv`. Its weekend-evidence folder contains 24 exact selected 75-minute source CSVs for the affected symbols.
