# TF25 / 75-minute input evidence

The full run config pinned `research_data_root` to `research/fyers_backtest_execution_20261110/data_quality/derived_valid_source_view_tf25_20261114/NSEFO/latest_data_csv`. The run task records identify each selected container as `<symbol>@<filename expiry label>` and TF25. This evidence includes the corresponding `seventy_five` CSVs for all 24 symbols with weekend-entry trades, copied byte-for-byte from that input root. The adjacent CSV lists source paths, sizes, and SHA-256 hashes; the candle export contains weekend rows parsed from those files.

These are source evidence files, not corrected data. Saturday/Sunday timestamps are preserved as observed.
