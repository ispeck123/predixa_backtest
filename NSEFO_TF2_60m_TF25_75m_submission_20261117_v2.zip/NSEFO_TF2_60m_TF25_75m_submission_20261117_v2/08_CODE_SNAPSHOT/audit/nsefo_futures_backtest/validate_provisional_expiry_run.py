"""Read-only validator for NSEFO provisional-expiry research replays."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

import pandas as pd

from audit.derivatives_backtest_common.expiry_session_controls import ExpirySessionControlMap
from audit.nsefo_futures_backtest.run_provisional_expiry_aware import PROVISIONAL_STATUS


def validate(storage: Path, run_id: str, expiry_map_path: Path) -> dict:
    uri = f"file:{storage.resolve()}?mode=ro"
    with sqlite3.connect(uri, uri=True) as db:
        db.row_factory = sqlite3.Row
        run = dict(db.execute("SELECT * FROM backtest_runs WHERE run_id=?", (run_id,)).fetchone() or {})
        if not run:
            raise ValueError(f"unknown run: {run_id}")
        config = json.loads(run["config_json"])
        symbols = tuple(config["symbols"])
        expiries = ExpirySessionControlMap.load(expiry_map_path, "NSEFO", symbols, {PROVISIONAL_STATUS})
        task_counts = dict(db.execute("SELECT status,count(*) n FROM scan_tasks WHERE run_id=? GROUP BY status", (run_id,)).fetchall())
        errors = [dict(row) for row in db.execute(
            "SELECT exception_type,exception_message,count(*) n FROM errors WHERE run_id=? GROUP BY 1,2 ORDER BY n DESC",
            (run_id,),
        )]
        setups = [dict(row) for row in db.execute("""SELECT su.symbol,su.setup_timestamp,su.eligible,su.blocked_reason
          FROM setup_results su JOIN scan_results s ON s.scan_id=su.scan_id WHERE s.run_id=?""", (run_id,))]
        trades = [dict(row) for row in db.execute("""SELECT t.setup_id,t.entry_timestamp,t.exit_timestamp,t.outcome,t.gross_r,s.symbol
          FROM simulated_trades t JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=?""", (run_id,))]
        duplicate_setups = db.execute("""SELECT count(*) FROM (SELECT t.setup_id,count(*) n FROM simulated_trades t
          JOIN scan_results s ON s.scan_id=t.scan_id WHERE s.run_id=? GROUP BY t.setup_id HAVING n>1)""", (run_id,)).fetchone()[0]
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]

    cutoff_violations, time_exit_violations, missing_realized_r = [], [], []
    for setup in setups:
        symbol = str(setup["symbol"]).split("@", 1)[0]
        control = expiries.control(symbol, setup["setup_timestamp"], exclude_e1_gap=False, replay_end=config["end"])
        if setup["eligible"] and pd.Timestamp(setup["setup_timestamp"]).normalize() >= pd.Timestamp(control["entry_cutoff_date"]):
            cutoff_violations.append(setup)
    for trade in trades:
        symbol = str(trade["symbol"]).split("@", 1)[0]
        control = expiries.control(symbol, trade["entry_timestamp"], exclude_e1_gap=False, replay_end=config["end"])
        if pd.Timestamp(trade["entry_timestamp"]).normalize() >= pd.Timestamp(control["entry_cutoff_date"]):
            cutoff_violations.append({"trade_entry_after_cutoff": trade})
        if trade["outcome"] == "TIME_EXIT" and pd.Timestamp(trade["exit_timestamp"]).normalize() != pd.Timestamp(control["force_exit_date"]):
            time_exit_violations.append({"trade": trade, "expected_force_exit_date": control["force_exit_date"]})
        if trade["outcome"] in {"WIN", "LOSS", "TIME_EXIT"} and trade["gross_r"] is None:
            missing_realized_r.append(trade)

    outcome_counts: dict[str, int] = {}
    for trade in trades:
        outcome_counts[trade["outcome"]] = outcome_counts.get(trade["outcome"], 0) + 1
    blocked_counts: dict[str, int] = {}
    for setup in setups:
        name = setup["blocked_reason"] or "ALLOWED"
        blocked_counts[name] = blocked_counts.get(name, 0) + 1
    passed = (run["status"] == "COMPLETED" and integrity == "ok" and not errors and not duplicate_setups
              and not cutoff_violations and not time_exit_violations and not missing_realized_r)
    return {
        "run_id": run_id, "status": run["status"], "task_counts": task_counts, "integrity_check": integrity,
        "expiry_map": str(expiry_map_path.resolve()), "expiry_map_sha256": expiries.digest,
        "research_mode": config["research_mode"], "contract_slot_assumption": config["contract_slot_assumption"],
        "setups_by_disposition": blocked_counts, "trades_by_outcome": outcome_counts,
        "time_exit_count": outcome_counts.get("TIME_EXIT", 0), "duplicate_setup_trades": duplicate_setups,
        "cutoff_violations": len(cutoff_violations), "time_exit_date_violations": len(time_exit_violations),
        "resolved_trades_missing_realized_r": len(missing_realized_r), "error_groups": errors, "passed": passed,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_id")
    parser.add_argument("--storage", required=True, type=Path)
    parser.add_argument("--expiry-map", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    result = validate(args.storage, args.run_id, args.expiry_map)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite validation output: {args.output}")
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
