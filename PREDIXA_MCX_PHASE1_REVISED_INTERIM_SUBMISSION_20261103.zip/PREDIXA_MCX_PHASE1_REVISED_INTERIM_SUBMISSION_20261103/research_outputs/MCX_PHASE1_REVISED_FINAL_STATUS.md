# MCX Phase-1 revised status

- Task 1 back-adjustment: REMOVED FROM SCOPE for revised edge measurement.
- Task 2 FYERS recollection: REMOVED FROM SCOPE for revised edge measurement.
- Task 3 segmentation: PARTIAL — 55 isolated local segments emitted with explicit source/attestation/boundary statuses.
- Task 4 E1: COMPLETE in code; all revised segments carry E1 ids.
- Task 5 exclusions: PARTIAL — pre-replay segment exclusion ledger emitted; no trade-level replay possible yet.
- Task 6 realized-R export: BLOCKED — zero eligible segments.
- Task 7 overnight overlay: PARTIAL — conservative as-of implementation; daily close availability convention missing.
- Task 8 frozen-spec validation: BLOCKED — spec/config and eligible export unavailable.

MCX PAPER and REAL remain OFF.
