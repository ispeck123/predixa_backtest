# MCX OI roll-boundary verification

Discovered 2 dated OI responses and 1 strict OI crossover observations. A crossover is not an authoritative boundary unless the OI publication/availability time and the SK continuous switch schedule are both verified. The saved schedule therefore remains ineligible for revised authoritative segmentation.
