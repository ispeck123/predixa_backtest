# MCX session-calendar coverage

- Generated exchange-date rows: 1461.
- `OFFICIAL_VERIFIED` exchange dates: 0.
- The model records the 2026 work-order DST/Muhurat references, but no archival official calendar input was available for the replay period.
- E1 code remains active; revised authoritative replay excludes all segments until every used exchange date has traceable `OFFICIAL_VERIFIED` intervals.
