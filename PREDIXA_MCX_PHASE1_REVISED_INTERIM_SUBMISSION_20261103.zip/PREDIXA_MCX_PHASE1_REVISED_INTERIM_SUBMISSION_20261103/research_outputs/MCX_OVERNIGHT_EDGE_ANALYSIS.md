# MCX overnight-direction analysis

International files were found. The revised work order supplies a 17:00 America/New_York reference convention; `overnight_direction.py` can apply it as an explicitly owner-policy-labelled as-of time with DST-aware conversion. Provider daily-bar close/availability metadata remains absent, so this cannot independently establish a provider-verified overlay. No trades exist because no segment passed calendar eligibility. No UP/DOWN edge claim is made.
