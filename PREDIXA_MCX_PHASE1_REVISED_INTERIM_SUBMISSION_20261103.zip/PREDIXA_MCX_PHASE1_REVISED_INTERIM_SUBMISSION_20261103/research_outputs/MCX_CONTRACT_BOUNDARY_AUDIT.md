# MCX within-contract boundary audit

## Method

- Attestation: `OWNER_ATTESTED_SK_CONTINUOUS_EQUALS_DATED_WITHIN_ACTIVE_WINDOW_REVISED_WORK_ORDER_02NOV2026`.
- Local expiry-labelled continuous files are segmented independently; original provenance classifications remain unchanged.
- No additive/ratio adjustment is calculated.
- The revised workbook file was not present in the workspace; this report records the owner instruction supplied in the task instead.

## Result

| Family | Segments | Replay eligible |
|---|---:|---:|
| GOLD | 9 | 0 |
| SILVER | 6 | 0 |
| NATGAS | 12 | 0 |
| CRUDEOIL | 16 | 0 |
| ZINC | 12 | 0 |

All segments are currently excluded from authoritative replay because an official session/holiday/calendar file was not found. This is distinct from the owner-attested within-contract price-equivalence assumption.
