# MCX revised exclusion summary

No trade replay occurred: all candidate segments are excluded before setup discovery because the historical session calendar is unverified. `MCX_TRADE_EXCLUSIONS.csv` records the excluded source rows by segment; it is not a trade-performance ledger.
