"""Conservative international daily-close direction overlay for revised MCX replay."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
SERIES = {"GOLD": ROOT / "XAU_USD.csv", "GOLDM": ROOT / "XAU_USD.csv", "SILVER": ROOT / "XAG_USD.csv", "SILVERM": ROOT / "XAG_USD.csv", "CRUDEOIL": ROOT / "WTI_USD.csv", "CRUDEOILM": ROOT / "WTI_USD.csv", "NATGAS": ROOT / "NATURAL_GAS_USD.csv", "NATGASMINI": ROOT / "NATURAL_GAS_USD.csv"}


def load_daily_closes(path: Path, *, close_available_at: str | None = None,
                      owner_release_policy: bool = False) -> pd.DataFrame:
    """Load price/date files without inventing an intraday availability time.

    A date-only file is suitable for later descriptive coverage checks but not
    for an as-of directional decision. Callers must supply a verified closing
    availability convention before it can tag a trade UP/DOWN/FLAT.
    """
    raw = pd.read_csv(path)
    date_col = next((x for x in ("Datetime", "Date", "date", "timestamp") if x in raw), None)
    price_col = next((x for x in ("Price($)", "Price", "close", "Close") if x in raw), None)
    if not date_col or not price_col:
        raise ValueError("international source lacks date/price fields")
    dates = pd.to_datetime(raw[date_col], errors="coerce")
    prices = pd.to_numeric(raw[price_col], errors="coerce")
    if dates.isna().any() or prices.isna().any() or dates.duplicated().any() or not dates.is_monotonic_increasing:
        raise ValueError("international source has invalid dates/prices")
    result = pd.DataFrame({"source_date": dates.dt.date, "close": prices})
    if owner_release_policy:
        # The revised work order supplies 17:00 America/New_York as a
        # *reference convention*. It is deliberately labelled owner policy,
        # not provider-verified close availability, until source metadata is
        # archived. DST conversion is handled by zoneinfo rather than months.
        ny = ZoneInfo("America/New_York")
        result["available_at"] = [pd.Timestamp(datetime.strftime(d, "%Y-%m-%d") + " 17:00", tz=ny).tz_convert("Asia/Kolkata") for d in result.source_date]
        result["availability_basis"] = "OWNER_WORK_ORDER_17_00_AMERICA_NEW_YORK_UNVERIFIED_PROVIDER_CONVENTION"
    elif close_available_at:
        result["available_at"] = pd.to_datetime(result.source_date.astype(str) + " " + close_available_at, utc=True).dt.tz_convert("Asia/Kolkata")
        result["availability_basis"] = "CALLER_VERIFIED_CLOSE_AVAILABILITY"
    else:
        result["available_at"] = pd.NaT
        result["availability_basis"] = "UNKNOWN"
    return result


def overnight_direction(symbol: str, signal_timestamp, closes: pd.DataFrame) -> dict:
    """Use only the last two closes demonstrably available at the MCX setup."""
    ts = pd.Timestamp(signal_timestamp)
    if ts.tzinfo is None:
        raise ValueError("signal timestamp must be timezone-aware")
    ts = ts.tz_convert("Asia/Kolkata")
    if "available_at" not in closes or closes.available_at.isna().all():
        return {"overnight_dir": "UNKNOWN", "reason": "INTERNATIONAL_CLOSE_AVAILABILITY_UNVERIFIED", "source_dates": []}
    available = closes[closes.available_at <= ts]
    if len(available) < 2:
        return {"overnight_dir": "UNKNOWN", "reason": "INSUFFICIENT_PRIOR_INTERNATIONAL_CLOSES", "source_dates": []}
    before, prior = available.iloc[-1], available.iloc[-2]
    value = float(before.close) - float(prior.close)
    direction = "UP" if value > 0 else "DOWN" if value < 0 else "FLAT"
    return {"overnight_dir": direction, "reason": None, "source_dates": [str(prior.source_date), str(before.source_date)], "source_available_at": [prior.available_at.isoformat(), before.available_at.isoformat()]}
