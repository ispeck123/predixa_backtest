"""Fail-closed MCX historical session calendar for revised within-contract replay.

This module deliberately distinguishes a useful *schedule model* from an
authoritative historical calendar.  The latter requires dated MCX circulars or
an approved local source manifest for every replay date; unlisted dates remain
``UNVERIFIED`` and cannot admit a segment to authoritative replay.
"""
from __future__ import annotations

import argparse
import csv
import json
from datetime import date, datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
ROOT = Path(__file__).resolve().parents[2]

# These facts are explicitly supplied by the revised work order.  They are
# retained as owner-work-order evidence until the matching official circular
# PDFs are archived locally; they must not by themselves unlock research.
WORK_ORDER_EVENTS = {
    "2026-03-09": {"close": "23:30", "dst_regime": "SUMMER", "reference": "MCX/TRD/068/2026", "verification_status": "OWNER_WORK_ORDER_ATTESTED"},
    "2026-11-02": {"close": "23:55", "dst_regime": "WINTER", "reference": "MCX/TRD/550/2026", "verification_status": "OWNER_WORK_ORDER_ATTESTED"},
    "2026-11-08": {"special": "MUHURAT", "intervals": [["14:20", "15:30"]], "preliminary": [["14:05", "14:19"]], "reference": "MCX/TRD/590/2026", "verification_status": "OWNER_WORK_ORDER_ATTESTED"},
}


def _dt(day: date, value: str) -> datetime:
    hour, minute = map(int, value.split(":"))
    return datetime.combine(day, time(hour, minute), tzinfo=IST)


def _row(day: date, *, status: str, intervals: list[tuple[str, str]] | None = None,
         reference: str = "", source: str = "", dst: str = "", special: str = "") -> dict:
    intervals = intervals or []
    return {
        "exchange_date": day.isoformat(), "timezone": "Asia/Kolkata", "trading_status": "OPEN" if intervals else "UNVERIFIED",
        "morning_open": intervals[0][0] if intervals and intervals[0][0] == "09:00" else "",
        "morning_close": "17:00" if intervals and intervals[0][0] == "09:00" else "",
        "evening_open": "17:00" if intervals and intervals[0][0] == "09:00" else "",
        "evening_close": intervals[-1][1] if intervals else "",
        "actual_trading_intervals": json.dumps(intervals), "is_full_holiday": "false",
        "is_partial_holiday": "false", "is_muhurat": str(special == "MUHURAT").lower(),
        "is_special_session": str(bool(special)).lower(), "dst_regime": dst,
        "exchange_circular_reference": reference, "source_reference": source,
        "verification_status": status,
    }


def build_calendar(start: date, end: date, approved_records: dict[str, dict] | None = None) -> list[dict]:
    """Build records, failing closed unless a full approved record is supplied.

    ``approved_records`` is an audited date map.  Each record may provide
    ``intervals`` (IST HH:MM pairs), holiday flags, reference, and a
    verification status.  A record only supports replay when its status is
    ``OFFICIAL_VERIFIED``.
    """
    approved_records = approved_records or {}
    result: list[dict] = []
    day = start
    while day <= end:
        key = day.isoformat()
        supplied = approved_records.get(key)
        if supplied:
            status = supplied.get("verification_status", "UNVERIFIED")
            if supplied.get("is_full_holiday"):
                row = _row(day, status=status, reference=supplied.get("reference", ""), source=supplied.get("source", ""))
                row.update({"trading_status": "CLOSED", "is_full_holiday": "true"})
            else:
                row = _row(day, status=status, intervals=[tuple(x) for x in supplied.get("intervals", [])],
                           reference=supplied.get("reference", ""), source=supplied.get("source", ""),
                           dst=supplied.get("dst_regime", ""), special=supplied.get("special", ""))
                row["is_partial_holiday"] = str(bool(supplied.get("is_partial_holiday"))).lower()
            result.append(row)
        elif key == "2026-11-08":
            event = WORK_ORDER_EVENTS[key]
            result.append(_row(day, status=event["verification_status"], intervals=[tuple(x) for x in event["intervals"]],
                               reference=event["reference"], source="revised work order", special="MUHURAT"))
        else:
            # Weekdays are not presumed open: historical holidays, special
            # timings, and commodity-specific exceptions make that unsafe.
            result.append(_row(day, status="UNVERIFIED"))
        day += timedelta(days=1)
    return result


def session_contains(row: dict, stamp: datetime) -> bool:
    """Validate an aware candle timestamp against a supplied calendar row."""
    if row.get("verification_status") != "OFFICIAL_VERIFIED":
        return False
    stamp = stamp.astimezone(IST)
    if row.get("exchange_date") != stamp.date().isoformat():
        return False
    for opened, closed in json.loads(row.get("actual_trading_intervals", "[]")):
        if _dt(stamp.date(), opened) <= stamp <= _dt(stamp.date(), closed):
            return True
    return False


def write_calendar(records: list[dict], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "MCX_HISTORICAL_SESSION_CALENDAR.csv"
    fields = list(records[0]) if records else []
    with csv_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(records)
    manifest = output_dir / "MCX_SESSION_SOURCE_MANIFEST.json"
    manifest.write_text(json.dumps({"timezone": "Asia/Kolkata", "model": "fail_closed", "work_order_events": WORK_ORDER_EVENTS,
                                    "authoritative_coverage_requirement": "OFFICIAL_VERIFIED per exchange date"}, indent=2) + "\n")
    return csv_path, manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start", default="2023-01-01"); parser.add_argument("--end", default="2026-12-31")
    parser.add_argument("--approved-records", type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "research/mcx_within_contract_segments")
    args = parser.parse_args()
    records = json.loads(args.approved_records.read_text()) if args.approved_records else {}
    calendar = build_calendar(date.fromisoformat(args.start), date.fromisoformat(args.end), records)
    paths = write_calendar(calendar, args.output_dir)
    print(json.dumps({"calendar": str(paths[0]), "official_days": sum(x["verification_status"] == "OFFICIAL_VERIFIED" for x in calendar)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
