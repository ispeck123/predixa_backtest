"""Evidence-aware MCX dated-contract OI crossover boundary reconstruction."""
from __future__ import annotations

import argparse
import csv
from datetime import date
import hashlib
import json
from pathlib import Path
import re

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
PROVIDER_ROOT = ROOT / "research/mcx_fyers_expired"
EXPIRY_CALENDAR = ROOT / "research/zone_series_comparison/data/CRUDEOILM_expiry_roll_calendar.csv"
SYMBOL = re.compile(r"MCX:(?P<variant>[A-Z]+?)(?P<year>\d{2})(?P<month>[A-Z]{3})FUT")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def oi_series(path: Path) -> dict | None:
    payload = json.loads(path.read_text())
    columns = payload.get("columns", [])
    if "timestamp" not in columns or "open_interest" not in columns:
        return None
    match = SYMBOL.fullmatch(payload.get("symbol", ""))
    if not match:
        return None
    frame = pd.DataFrame(payload.get("candles", []), columns=columns)
    if frame.empty:
        return None
    frame["timestamp"] = pd.to_datetime(frame.timestamp, unit="s", utc=True).dt.tz_convert("Asia/Kolkata")
    frame["open_interest"] = pd.to_numeric(frame.open_interest, errors="coerce")
    frame = frame.dropna(subset=["open_interest"]).sort_values("timestamp")
    quarantine = "rejected" in path.parts
    return {"variant": match["variant"], "contract": payload["symbol"], "source_path": str(path.relative_to(ROOT)),
            "source_hash": digest(path), "quality": "QUARANTINED_RESPONSE" if quarantine else "PROVIDER_RESPONSE_VALIDATED",
            "availability_status": "UNKNOWN_PUBLICATION_TIME", "series": frame[["timestamp", "open_interest"]]}


def discover_oi(root: Path = PROVIDER_ROOT) -> list[dict]:
    return [item for path in root.rglob("provider_response.json") if (item := oi_series(path))]


def first_crossover(outgoing: dict, incoming: dict) -> dict | None:
    """Return first timestamp where next OI is strictly greater, never equal."""
    left = outgoing["series"].rename(columns={"open_interest": "outgoing_oi"})
    right = incoming["series"].rename(columns={"open_interest": "incoming_oi"})
    joined = left.merge(right, on="timestamp", how="inner")
    hits = joined[joined.incoming_oi > joined.outgoing_oi]
    if hits.empty:
        return None
    hit = hits.iloc[0]
    return {"underlying": outgoing["variant"], "outgoing_contract_id": outgoing["contract"], "incoming_contract_id": incoming["contract"],
            "observation_timestamp": hit.timestamp.isoformat(), "outgoing_oi": int(hit.outgoing_oi), "incoming_oi": int(hit.incoming_oi),
            "crossover_status": "OBSERVED_BUT_EXECUTABLE_TIME_UNKNOWN", "effective_roll_session": "",
            "oi_data_source": "FYERS expired F&O captured response", "outgoing_source_hash": outgoing["source_hash"],
            "incoming_source_hash": incoming["source_hash"], "availability_status": "UNKNOWN_PUBLICATION_TIME",
            "verification_status": "PROVISIONAL" if "QUARANTINED" in {outgoing["quality"], incoming["quality"]} else "OBSERVED_NOT_AUTHORITATIVE"}


def write_outputs(output_dir: Path, sources: list[dict]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for i, outgoing in enumerate(sources):
        for incoming in sources[i + 1:]:
            if incoming["variant"] == outgoing["variant"]:
                event = first_crossover(outgoing, incoming)
                if event: rows.append(event)
    fields = ["underlying", "outgoing_contract_id", "incoming_contract_id", "observation_timestamp", "outgoing_oi", "incoming_oi", "crossover_status", "effective_roll_session", "oi_data_source", "outgoing_source_hash", "incoming_source_hash", "availability_status", "verification_status"]
    with (output_dir / "MCX_HISTORICAL_OI_CROSSOVERS.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    # Expiry output preserves exact source quality. Only the supplied CRUDEOILM
    # circular calendar is independently present locally.
    expiry_rows = []
    if EXPIRY_CALENDAR.exists():
        for row in csv.DictReader(EXPIRY_CALENDAR.open()):
            expiry_rows.append({"variant": "CRUDEOILM", "expiry_date": row["expiry_date"], "source": row["source"], "verification_status": "CIRCULAR_REFERENCED_LOCAL"})
    with (output_dir / "MCX_HISTORICAL_CONTRACT_EXPIRIES.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["variant", "expiry_date", "source", "verification_status"]); writer.writeheader(); writer.writerows(expiry_rows)
    with (output_dir / "MCX_ROLL_BOUNDARY_SCHEDULE.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[*fields, "boundary_eligibility"]); writer.writeheader()
        for row in rows: writer.writerow({**row, "boundary_eligibility": "INELIGIBLE_UNKNOWN_OI_AVAILABILITY_OR_SK_SWITCH"})
    missing = {"required_variants": ["GOLDM", "SILVERM", "CRUDEOILM", "NATGASMINI", "ZINCMINI"],
               "available_oi_contracts": [{k: v for k, v in item.items() if k != "series"} for item in sources],
               "missing": ["Dated-contract OI pair coverage for GOLDM, SILVERM, NATGASMINI, ZINCMINI", "Verified OI publication availability timestamp", "Documented SK continuous contract switching schedule", "Published contract-specific expiry records for non-CRUDEOILM variants"]}
    (output_dir / "MCX_MISSING_OI_DATA.json").write_text(json.dumps(missing, indent=2) + "\n")
    (output_dir / "MCX_ROLL_BOUNDARY_VERIFICATION.md").write_text(
        "# MCX OI roll-boundary verification\n\n"
        f"Discovered {len(sources)} dated OI responses and {len(rows)} strict OI crossover observations. A crossover is not an authoritative boundary unless the OI publication/availability time and the SK continuous switch schedule are both verified. The saved schedule therefore remains ineligible for revised authoritative segmentation.\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--output-dir", type=Path, default=ROOT / "research/mcx_within_contract_segments")
    args = parser.parse_args(); sources = discover_oi(); write_outputs(args.output_dir, sources)
    print(json.dumps({"oi_sources": len(sources)})); return 0


if __name__ == "__main__":
    raise SystemExit(main())
