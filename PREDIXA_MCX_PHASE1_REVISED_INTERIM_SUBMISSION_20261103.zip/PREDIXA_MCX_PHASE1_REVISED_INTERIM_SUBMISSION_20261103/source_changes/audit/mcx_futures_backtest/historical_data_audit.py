"""Provenance-first MCX historical-source inventory.

This module never infers a dated contract from a filename.  It emits a source
manifest and admits only sources with an explicit raw dated-contract metadata
record into the provisional contract registry.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
FAMILIES = {
    "GOLDM": ("GOLD", "GOLDM"), "GOLDGUINEA": ("GOLD", "GOLDGUINEA"),
    "GOLDTEN": ("GOLD", "GOLDTEN"), "GOLD": ("GOLD", "GOLD"),
    "SILVERM": ("SILVER", "SILVERM"), "SILVER": ("SILVER", "SILVER"),
    "NATGASMINI": ("NATGAS", "NATGASMINI"), "NATGASM": ("NATGAS", "NATGASM"),
    "NATGAS": ("NATGAS", "NATGAS"), "CRUDEOILM": ("CRUDEOIL", "CRUDEOILM"),
    "CRUDEOIL": ("CRUDEOIL", "CRUDEOIL"), "ZINCMINI": ("ZINC", "ZINCMINI"),
    "ZINC": ("ZINC", "ZINC"),
}
FILENAME = re.compile(r"^(?P<symbol>[A-Z]+)_(?P<expiry>\d{8})_(?P<tf>[a-z_]+)\.csv$", re.I)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _parse_timestamp(value: str | None) -> str | None:
    if not value:
        return None
    for fmt in (None, "%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
        try:
            return datetime.fromisoformat(value).isoformat() if fmt is None else datetime.strptime(value, fmt).isoformat()
        except ValueError:
            pass
    return value


def csv_profile(path: Path) -> dict[str, Any]:
    """Stream CSV metadata; do not alter source data or synthesize timestamps."""
    with path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        timestamp_field = next((x for x in ("timestamp_ist", "timestamp", "tradeDate", "date") if x in headers), None)
        first = last = None
        previous = None
        count = duplicates = unordered = 0
        seen: set[str] = set()
        for row in reader:
            count += 1
            stamp = _parse_timestamp(row.get(timestamp_field)) if timestamp_field else None
            if first is None:
                first = stamp
            last = stamp
            if stamp:
                if stamp in seen:
                    duplicates += 1
                seen.add(stamp)
                if previous is not None and stamp < previous:
                    unordered += 1
                previous = stamp
    return {"headers": headers, "timestamp_field": timestamp_field, "records": count,
            "first_timestamp": first, "last_timestamp": last, "duplicate_timestamps": duplicates,
            "unordered_pairs": unordered}


def _identity(relative: str, known: dict[str, Any]) -> tuple[str | None, str | None, str | None]:
    entry = known.get(relative, {})
    if entry:
        return entry.get("family"), entry.get("variant"), None
    match = FILENAME.match(Path(relative).name)
    if not match:
        return None, None, None
    symbol = match.group("symbol").upper()
    family, variant = FAMILIES.get(symbol, (None, symbol))
    return family, variant, match.group("expiry")


def classify(relative: str, profile: dict[str, Any], known: dict[str, Any]) -> dict[str, Any]:
    entry = known.get(relative)
    if profile["records"] == 0 or not profile["timestamp_field"]:
        return {"status": "INVALID", "reason": "CSV has no usable timestamped rows", "metadata": None}
    if profile["duplicate_timestamps"] or profile["unordered_pairs"]:
        return {"status": "INVALID", "reason": "duplicate or unordered timestamps", "metadata": None}
    if not entry:
        return {"status": "UNVERIFIED", "reason": "no immutable provider/contract provenance sidecar", "metadata": None}
    meta_path = ROOT / entry["metadata"]
    if not meta_path.exists():
        return {"status": "UNVERIFIED", "reason": "configured provenance sidecar missing", "metadata": None}
    metadata = json.loads(meta_path.read_text())
    provider = metadata.get("source_broker", metadata.get("provider"))
    symbol = metadata.get("api_symbol", metadata.get("instrument_identifier", metadata.get("contract_symbol")))
    expiry_value = metadata.get("contract_expiry", metadata.get("expiry_date"))
    raw = metadata.get("pull_type") in {"dated_raw", "dated_contract_default_history"}
    exact = bool(symbol)
    expiry = bool(expiry_value)
    # The FYERS expired-F&O collector uses provider-native field names. Admit
    # its cache only when both persisted hashes and exact dated identity exist.
    fyers_expired_raw = (
        provider == "FYERS"
        and metadata.get("source_endpoint") == "/history/fno/expired/historical-data"
        and metadata.get("status") == "SUCCESS"
        and metadata.get("price_identity") == "EXACT_DATED_SYMBOL_RETURNED_BY_FYERS"
        and bool(metadata.get("raw_response_sha256"))
        and metadata.get("normalized_bars_sha256") == sha256(ROOT / relative)
        and exact
        and expiry
    )
    if (raw or fyers_expired_raw) and exact and expiry and metadata.get("continuous") is not True:
        return {"status": "VERIFIED_RAW", "reason": "explicit provider dated-contract metadata", "metadata": metadata}
    if metadata.get("pull_type") == "continuous" or metadata.get("continuous") is True:
        return {"status": "VERIFIED_CONTINUOUS", "reason": "explicit continuous metadata", "metadata": metadata}
    return {"status": "UNVERIFIED", "reason": "metadata does not verify dated raw attribution", "metadata": metadata}


def audit(config_path: Path, output_dir: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    config = json.loads(config_path.read_text())
    known = config.get("known_sources", {})
    files: set[Path] = set()
    for relative_root in config.get("scan_roots", []):
        source_root = ROOT / relative_root
        if source_root.exists():
            files.update(source_root.rglob("*.csv"))
    # Exact collector responses can live outside general CSV roots. Listing
    # them explicitly avoids treating derived diagnostics as raw sources.
    for relative in config.get("additional_sources", []):
        path = ROOT / relative
        if path.is_file():
            files.add(path)
    rows: list[dict[str, Any]] = []
    registry: list[dict[str, Any]] = []
    for path in sorted(files):
        relative = path.relative_to(ROOT).as_posix()
        profile = csv_profile(path)
        family, variant, filename_expiry = _identity(relative, known)
        verdict = classify(relative, profile, known)
        meta = verdict["metadata"] or {}
        row = {"source_path": relative, "family": family, "variant": variant,
               "filename_expiry_label": filename_expiry, "records": profile["records"],
               "first_timestamp": profile["first_timestamp"], "last_timestamp": profile["last_timestamp"],
               "timestamp_field": profile["timestamp_field"], "headers": profile["headers"],
               "duplicate_timestamps": profile["duplicate_timestamps"], "unordered_pairs": profile["unordered_pairs"],
               "current_sha256": sha256(path), "provider": meta.get("source_broker", meta.get("provider")),
               "provider_instrument_id": meta.get("api_symbol", meta.get("instrument_identifier", meta.get("contract_symbol"))),
               "request_mode": meta.get("pull_type", "fyers_expired_dated" if meta.get("source_endpoint") == "/history/fno/expired/historical-data" else None), "contract_expiry": meta.get("contract_expiry", meta.get("expiry_date")),
               "timezone": meta.get("converted_timezone"), "candle_boundary": meta.get("candle_timestamp_boundary"),
               "metadata_path": known.get(relative, {}).get("metadata"),
               "status": verdict["status"], "reason": verdict["reason"]}
        rows.append(row)
        if row["status"] == "VERIFIED_RAW":
            registry.append({"family": family, "variant": variant, "contract_symbol": row["provider_instrument_id"],
                             "provider": row["provider"], "provider_instrument_id": row["provider_instrument_id"],
                             "expiry_date": row["contract_expiry"], "first_raw_candle": row["first_timestamp"],
                             "last_raw_candle": row["last_timestamp"], "listing_date": "UNKNOWN",
                             "effective_interval": "OBSERVED_CANDLE_COVERAGE_ONLY", "source_path": relative,
                             "source_sha256": row["current_sha256"], "status": "VERIFIED_RAW_PARTIAL_COVERAGE"})
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "mcx_source_manifest.jsonl").open("w") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    with (output_dir / "mcx_contract_registry.csv").open("w", newline="") as handle:
        fields = ["family", "variant", "contract_symbol", "provider", "provider_instrument_id", "expiry_date", "first_raw_candle", "last_raw_candle", "listing_date", "effective_interval", "source_path", "source_sha256", "status"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(registry)
    summary = {"sources": rows, "summary": dict(Counter(row["status"] for row in rows)),
               "families_seen": {family: sum(row["family"] == family for row in rows) for family in ("GOLD", "SILVER", "NATGAS", "CRUDEOIL", "ZINC")},
               "verified_registry_records": len(registry),
               "generated_at": datetime.now().astimezone().isoformat()}
    (output_dir / "MCX_SOURCE_AUDIT.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return rows, registry


def write_reports(rows: list[dict[str, Any]], registry: list[dict[str, Any]], output_dir: Path) -> None:
    counts = Counter(row["status"] for row in rows)
    by_family = {family: [r for r in rows if r["family"] == family] for family in ("GOLD", "SILVER", "NATGAS", "CRUDEOIL", "ZINC")}
    lines = ["# MCX historical data inventory", "", "## Classification", "", f"- VERIFIED_RAW: {counts['VERIFIED_RAW']}", f"- VERIFIED_CONTINUOUS: {counts['VERIFIED_CONTINUOUS']}", f"- UNVERIFIED: {counts['UNVERIFIED']}", f"- INVALID: {counts['INVALID']}", "", "## Family readiness", "", "| Family | Sources | Verified raw sources | Roll-ready? |", "|---|---:|---:|---|"]
    for family, items in by_family.items():
        raw = sum(r["status"] == "VERIFIED_RAW" for r in items)
        lines.append(f"| {family} | {len(items)} | {raw} | NO — no verified adjacent raw overlap, policy, and calendar |")
    lines += ["", "## Verified dated-contract coverage", "", "| Family | Variant | Contract | Provider | Raw coverage (IST) | Attribution limitation |", "|---|---|---|---|---|---|"]
    for item in registry:
        lines.append(f"| {item['family']} | {item['variant']} | {item['contract_symbol']} | {item['provider']} | {item['first_raw_candle']} to {item['last_raw_candle']} | {item['effective_interval']}; listing date unknown |")
    lines += ["", "## CRUDEOILM provisional overlap", "", "FYERS cache contains exact dated `MCX:CRUDEOILM26AUGFUT` and `MCX:CRUDEOILM26OCTFUT` raw sources with observed 60-minute overlap from 03-Aug-2026 to 19-Aug-2026. `audit.mcx_futures_backtest.provisional_roll_diagnostic` validates the additive arithmetic using observed outgoing close and incoming open. Its output is deliberately `PROVISIONAL_ROLL_ARITHMETIC_ONLY`: neither the point-in-time selection interval, official session calendar, nor roll-policy approval is available. It cannot feed Task 3 or Task 4.", "", "## Interpretation", "", "Only sources with explicit provider instrument, raw mode, and expiry metadata enter `mcx_contract_registry.csv`. Their registry interval is observed raw-candle coverage, not an inferred listing date. Filename-only archives remain UNVERIFIED and cannot be used for executable fills or roll reconstruction.", "", "No authoritative `mcx_trade_export.csv` was created."]
    (output_dir / "MCX_HISTORICAL_DATA_INVENTORY.md").write_text("\n".join(lines) + "\n")
    with (output_dir / "mcx_roll_events.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["family", "outgoing_contract", "incoming_contract", "status", "reason"]); writer.writeheader()
        for family in ("GOLD", "SILVER", "NATGAS", "CRUDEOIL", "ZINC"):
            if family == "CRUDEOIL":
                writer.writerow({"family": family, "outgoing_contract": "MCX:CRUDEOILM26AUGFUT", "incoming_contract": "MCX:CRUDEOILM26OCTFUT", "status": "PROVISIONAL_ARITHMETIC_ONLY", "reason": "observed FYERS dated-source overlap; selection interval, official calendar, and additive-policy approval unavailable"})
            else:
                writer.writerow({"family": family, "outgoing_contract": "", "incoming_contract": "", "status": "UNVERIFIED", "reason": "verified adjacent raw-contract overlap and approved roll policy unavailable"})
    (output_dir / "MCX_EDGE_REPRO_RESULTS.md").write_text("# MCX edge reproduction results\n\nBLOCKED_MISSING_DATA. No authoritative clean realized-R export exists; the verifier was not run on unverified or partial inputs.\n")
    (output_dir / "MCX_PHASE1_FINAL_STATUS.md").write_text("# MCX Phase-1 status\n\n- Task 1 E1: COMPLETE and regression-tested.\n- Task 2: PARTIALLY_COMPLETED — provenance auditor and partial dated-source registry produced; no verified roll pairs.\n- Task 3: BLOCKED — no roll-correct authoritative source bundle.\n- Task 4: BLOCKED — no authoritative realized-R export or approved complete split/policy.\n\nMCX PAPER and REAL remain OFF.\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "audit/mcx_futures_backtest/historical_source_registry.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT)
    args = parser.parse_args()
    rows, registry = audit(args.config, args.output_dir)
    write_reports(rows, registry, args.output_dir)
    print(json.dumps({"sources": len(rows), "verified_raw": len(registry), "output_dir": str(args.output_dir)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
