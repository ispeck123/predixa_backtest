"""Revised 15-column within-contract realized-R export schema."""
from __future__ import annotations

import csv
from pathlib import Path

from .clean_realized_r_export import EXPORT_COLUMNS

WITHIN_CONTRACT_EXPORT_COLUMNS = [*EXPORT_COLUMNS, "overnight_dir"]
VALID_DIRECTION = {"UP", "DOWN", "FLAT", "UNKNOWN"}


def validate_rows(rows):
    seen = set()
    for row in rows:
        if row.get("side", "BUY") != "BUY":
            raise ValueError("revised MCX export is BUY-only")
        key = row.get("setup_id")
        if not key or key in seen:
            raise ValueError("missing or duplicate setup_id")
        seen.add(key)
        if row.get("overnight_dir") not in VALID_DIRECTION:
            raise ValueError("invalid overnight direction")
        entry, stop, exit_price = (float(row[x]) for x in ("entry_price", "stop_price", "exit_price"))
        risk = entry - stop
        if risk <= 0 or abs(float(row["gross_r"]) - (exit_price - entry) / risk) > 1e-8:
            raise ValueError("realized gross_r does not reconcile")


def write_provisional_export(rows, path: Path) -> None:
    """Only writes a clearly caller-labelled provisional export, never Task-3's clean path."""
    validate_rows(rows)
    with Path(path).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=WITHIN_CONTRACT_EXPORT_COLUMNS, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)
