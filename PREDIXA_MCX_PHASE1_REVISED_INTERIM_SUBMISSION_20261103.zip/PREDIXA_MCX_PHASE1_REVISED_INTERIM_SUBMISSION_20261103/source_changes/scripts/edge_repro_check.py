#!/usr/bin/env python3
"""
PREDIXA — edge-reproduction check (evidence guardrail).

The companion to the BE-drop verifier. The verifier checks the gate is *wired*
right (code regressions). THIS checks the gate is *pointed at a real edge*: for
each cell the gate treats as live, it recomputes REALIZED expectancy from the
raw trade export — net-of-cost, with win-rate and IS/OOS — and flags any live
cell that does not reproduce as a positive realized edge.

WHY THIS EXISTS: the MCX GOLD+CRUDE cells were populated from a finding doc whose
"+1.14R OOS" tracked PEAK favorable excursion, not what the exits realized; on
realized R the cells are OOS-negative (SW/SW/4: 6.6% win, -0.70R). Reading a
derived finding instead of the raw trades is the failure this tool prevents.
No cell backs real capital unless it reproduces here on realized R.

Realized R = gross_r from the export (verified = (exit-entry)/(entry-stop): a win
books its target R, a loss books -1). Net = gross_r - cost_in_R, cost_in_R =
round_trip_pct * entry / |entry-stop|.

Usage:
  python3 edge_repro_check.py <trade_export.csv> --segment NSE_CASH|NSEFO|MCX \
        --rt <round_trip_pct eg 0.0013> --split YYYY-MM-DD [--universe GOLDM,CRUDEOILM]
"""
from __future__ import annotations
import csv, sys, argparse, statistics as st, json
from pathlib import Path

# Support the documented standalone invocation from the repository root as
# well as module imports from release_preflight.  Without this bootstrap,
# ``python scripts/edge_repro_check.py`` resolves ``scripts`` relative to the
# script directory and exits before it can issue its intentional fail-closed
# validation verdict.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.tf_regime_gate_by_exchange import TF_REGIME_GATE

def live_cells(segment: str) -> dict:
    """Read the exact active gate schedule; never maintain a stale duplicate."""
    cfg = TF_REGIME_GATE.get(str(segment or "").upper())
    return dict(cfg.permit_cells) if cfg is not None else {}

def col(row, *cands):
    for c in cands:
        if c in row: return row[c]
    return None
def ff(x):
    try: return float(x)
    except: return None

def load(path, universe, provenance_path=None, manifest_path=None, split=None):
    rows=[]
    with open(path, encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        fields=set(reader.fieldnames or ())
        export_rows=list(reader)
        provenance_by_index={}
        if "setup_timestamp" not in fields and provenance_path:
            with open(provenance_path, encoding="utf-8") as ph:
                p_rows=list(csv.DictReader(ph))
            if len(p_rows)!=len(export_rows):
                raise ValueError("trade/provenance row count mismatch")
            for p in p_rows:
                try: index=int(p.get("export_row_index", ""))
                except (TypeError, ValueError): raise ValueError("provenance has invalid export_row_index")
                if index in provenance_by_index or index<0 or index>=len(export_rows):
                    raise ValueError("provenance has duplicate/out-of-range export_row_index")
                if not p.get("setup_id") or not p.get("signal_timestamp"):
                    raise ValueError("provenance lacks stable setup id or signal timestamp")
                provenance_by_index[index]=p
            if set(provenance_by_index)!=set(range(len(export_rows))):
                raise ValueError("provenance does not provide a complete one-to-one row join")
            if not manifest_path:
                raise ValueError("a provenance join requires the run manifest")
            try:
                manifest=json.loads(Path(manifest_path).read_text())
            except (OSError, ValueError):
                raise ValueError("cannot read provenance run manifest") from None
            if manifest.get("source_class")!="AUTHORITATIVE_CLEAN" or manifest.get("synthetic_or_test_only") is not False:
                raise ValueError("diagnostic/test-only evidence is not eligible for edge reproduction")
            if (manifest.get("data_validation") or {}).get("status")!="VALID":
                raise ValueError("run manifest lacks valid Task-2 data validation")
        required_groups={
            "outcome": {"outcome"}, "symbol": {"symbol", "stock", "stock_name"},
            "entry": {"entry_price", "entry"}, "stop": {"stop_price", "stop"},
            "realized R": {"gross_r"}, "timestamp": {"setup_timestamp"} if "setup_timestamp" in fields else set(),
            "E regime": {"E_regime", "e_regime"}, "A regime": {"A_regime", "a_regime"},
            "X regime": {"X_regime", "x_regime"},
            "strategy TF": {"strategy_tf", "time_frame", "tf"},
        }
        if provenance_path:
            required_groups["partition"]={"partition"}
        missing=[name for name, choices in required_groups.items()
                 if (not choices and name=="timestamp" and not provenance_path) or
                    (choices and not (fields & choices))]
        if missing:
            raise ValueError("unsupported trade-export schema; missing " + ", ".join(missing))
        for row_index,r in enumerate(export_rows):
            provenance=provenance_by_index.get(row_index)
            if provenance is not None:
                if str(provenance.get("partition","")) != str(r.get("partition","")):
                    raise ValueError(f"partition mismatch at export row {row_index}")
                r={**r,"setup_timestamp":provenance["signal_timestamp"]}
                try:
                    from datetime import datetime
                    parsed_ts=datetime.fromisoformat(str(r["setup_timestamp"]).replace("Z","+00:00"))
                    if parsed_ts.tzinfo is None:
                        raise ValueError("naive timestamp")
                except ValueError:
                    raise ValueError(f"invalid provenance signal timestamp at export row {row_index}")
                if split:
                    signal_day=str(r["setup_timestamp"])[:10]
                    expected="IS" if signal_day<split else "OOS"
                    if r.get("partition")!=expected:
                        raise ValueError(f"IS/OOS split mismatch at export row {row_index}")
            if (col(r,"side") or "BUY") != "BUY": continue
            oc=col(r,"outcome")
            if oc not in ("WIN","LOSS"): raise ValueError(f"invalid outcome at export row {row_index}")
            sym=(col(r,"symbol","stock","stock_name") or "").split("@")[0]
            if universe and sym not in universe: continue
            e=ff(col(r,"entry_price","entry")); s=ff(col(r,"stop_price","stop")); g=ff(col(r,"gross_r"))
            if None in (e,s,g) or (e-s)<=0: raise ValueError(f"invalid realized-R inputs at export row {row_index}")
            exit_price=ff(col(r,"exit_price"))
            if exit_price is not None and abs(g-(exit_price-e)/(e-s))>1e-8:
                raise ValueError(f"gross_r does not reconcile to exit price at export row {row_index}")
            if col(r,"partition") and col(r,"partition") not in {"IS","OOS"}:
                raise ValueError(f"invalid partition at export row {row_index}")
            cell=(sym, col(r,"E_regime","e_regime"), col(r,"A_regime","a_regime"),
                  str(col(r,"strategy_tf","time_frame","tf")), col(r,"X_regime","x_regime"))
            try: cell=(cell[0],cell[1],cell[2],int(float(cell[3])),cell[4])
            except: continue
            rows.append(dict(cell=cell, oc=oc, g=g, e=e, s=s,
                             d=(col(r,"setup_timestamp") or "")[:10],
                             peak=ff(col(r,"mfe_R"))))
    return rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("export"); ap.add_argument("--segment", required=True)
    ap.add_argument("--rt", type=float, required=True, help="round-trip cost fraction, e.g. 0.0013")
    ap.add_argument("--split", required=True, help="IS/OOS boundary date YYYY-MM-DD")
    ap.add_argument("--universe", default=None, help="comma symbols to scope (e.g. GOLDM,CRUDEOILM)")
    ap.add_argument("--provenance", default=None, help="Task-3 trade_provenance.csv for exact 14-column export")
    ap.add_argument("--manifest", default=None, help="authoritative clean run_manifest.json required with provenance")
    ap.add_argument("--candidate-cells", action="store_true",
                    help="evaluate cells present in the export even if they are not currently gate-permitted; analysis only")
    a=ap.parse_args()
    uni=set(a.universe.split(",")) if a.universe else None
    try:
        rows=load(a.export, uni, a.provenance, a.manifest, a.split)
    except (OSError, ValueError) as exc:
        print(f"VERDICT: EVIDENCE INVALID — FAIL CLOSED: {exc}")
        return 2
    live=live_cells(a.segment)
    if a.candidate_cells:
        live = {row["cell"]: "CANDIDATE_NOT_LIVE" for row in rows}
    if not live:
        print("VERDICT: NO LIVE-ELIGIBLE CELLS — FAIL CLOSED")
        print("No finding may be promoted without an explicitly scoped realized-R OOS reproduction.")
        return 1
    mean=lambda x: sum(x)/len(x) if x else float("nan")
    same_cell=lambda row,cell: (row["cell"] == cell if a.candidate_cells else row["cell"][1:4] == cell)
    def netvals(cell, part):
        out=[]; peak=[]
        for r in rows:
            if not same_cell(r,cell): continue
            if part=="IS" and not (r["d"]<a.split): continue
            if part=="OOS" and not (r["d"]>=a.split): continue
            out.append(r["g"] - a.rt*r["e"]/abs(r["e"]-r["s"]))
            if r["peak"] is not None: peak.append(r["peak"])
        return out, peak
    def wr(cell, part):
        c=[r for r in rows if same_cell(r,cell) and ((part=="OOS")==(r["d"]>=a.split))]
        return 100*sum(1 for r in c if r["oc"]=="WIN")/len(c) if c else float("nan")

    print("="*86)
    print(f"EDGE-REPRODUCTION CHECK — segment {a.segment} — export {a.export}")
    if a.candidate_cells:
        print("MODE: export candidate cells (analysis only; this does not grant gate permission)")
    print(f"realized R, net-of-cost (RT {a.rt*100:.3f}%), IS/OOS split {a.split}"
          + (f", universe {sorted(uni)}" if uni else ""))
    print("="*86)
    print(f"{'cell':13}{'tier':9}{'n_OOS':>6}{'win%':>7}{'IS netR':>9}{'OOS netR':>10}{'OOSpeak':>9}  verdict")
    fails=[]
    for cell,tier in live.items():
        isv,_=netvals(cell,"IS"); oosv,oospk=netvals(cell,"OOS")
        o=mean(oosv); i=mean(isv); w=wr(cell,"OOS"); pk=mean(oospk) if oospk else float("nan")
        v="REPRODUCES" if o>0 else "DOES NOT REPRODUCE"
        tag=""
        if o<=0 and not (pk!=pk) and pk>0.3: tag=" [positive only on PEAK excursion, not realized]"
        if o<=0: fails.append((cell,tier,o,w,pk))
        elif i>0 and o>0 and (i-o)>0.5: tag=" [IS≫OOS — watch overfit]"
        ck=(f"{cell[0]}:{cell[1]}/{cell[2]}/{cell[3]}/{cell[4]}" if a.candidate_cells
            else f"{cell[0]}/{cell[1]}/{cell[2]}")
        print(f"{ck:13}{tier:9}{len(oosv):>6}{w:>6.1f}%{i:>9.3f}{o:>10.3f}{pk:>9.3f}  {v}{tag}")
    print("="*86)
    if fails:
        print(f"VERDICT: SEGMENT EDGE DOES NOT REPRODUCE — {len(fails)} live cell(s) OOS-nonpositive on realized R:")
        for cell,tier,o,w,pk in fails:
            extra = f"; peak {pk:+.2f}R (give-back)" if (pk==pk and pk>0.3) else ""
            ck=(f"{cell[0]}:{cell[1]}/{cell[2]}/{cell[3]}/{cell[4]}" if a.candidate_cells
                else f"{cell[0]}/{cell[1]}/{cell[2]}")
            print(f"  {ck} ({tier}): OOS {o:+.3f}R, {w:.1f}% win{extra}")
        print("  -> these cells MUST NOT back real capital until they reproduce positive realized R.")
        rc=1
    else:
        print("VERDICT: all live cells reproduce a positive realized-R edge OOS.")
        rc=0
    print("-"*86)
    print("Validates the EDGE behind the gate cells on REALIZED R (what exits bank) — not peak")
    print("excursion, not a finding doc. Complements the code verifier (which checks wiring only).")
    print("No cell backs real capital unless it reproduces here. Clean data is the caller's duty")
    print("(contaminated series — roll/stitch/session-gap — invalidate the read in either direction).")
    return rc

if __name__=="__main__":
    sys.exit(main())
