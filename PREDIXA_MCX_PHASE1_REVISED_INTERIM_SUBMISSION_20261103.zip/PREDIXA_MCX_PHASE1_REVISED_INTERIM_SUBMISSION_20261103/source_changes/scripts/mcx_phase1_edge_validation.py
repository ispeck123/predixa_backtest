#!/usr/bin/env python3
"""Fail-closed Task-4 validation wrapper for a versioned MCX clean export.

The wrapper validates Task-2/3 evidence, exact export schema, hashes, split
approval and the Task-3 provenance join before invoking edge_repro_check.py.
Candidate-cell mode is analytical only and never modifies gate permissions.
"""
from __future__ import annotations

import argparse
import csv
from datetime import date, datetime
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from audit.mcx_futures_backtest.clean_realized_r_export import EXPORT_COLUMNS, readiness_issues

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RUNS = ROOT / "audit/mcx_futures_backtest/outputs"
VALID_UNIVERSE = {"GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"}
TASK2_FLAGS = (
    "dated_contract_ohlcv_verified", "historical_contract_attribution_verified",
    "roll_transitions_verified", "roll_prices_verified", "roll_policy_approved",
    "trading_calendar_verified", "e1_enforced", "executable_price_mapping_verified",
    "point_in_time_integrity_verified", "coverage_verified",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def locate_run(runs_root: Path) -> Path | None:
    """Choose newest versioned run containing all three required evidence files."""
    if not runs_root.is_dir():
        return None
    candidates = [p for p in runs_root.iterdir() if p.is_dir() and
                  all((p / name).is_file() for name in
                      ("clean_mcx_trade_export.csv", "trade_provenance.csv", "run_manifest.json"))]
    return max(candidates, key=lambda p: p.stat().st_mtime_ns) if candidates else None


def _read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path.name} must contain a JSON object")
    return value


def _block(verdict: str, reason: str, **extra) -> dict:
    return {"verdict": verdict, "reason": reason, "cells": [], **extra}


def _validate_task2_bundle(bundle: dict) -> dict:
    from audit.mcx_futures_backtest.run_clean_phase1 import validate_bundle
    return validate_bundle(bundle)


def validate_run(run_dir: Path, *, universe: set[str], rt: float,
                 split_override: str | None = None, approved_config: Path | None = None,
                 invoke_checker: bool = True) -> dict:
    """Validate a real run and calculate per-cell gross/net realized metrics."""
    run_dir = Path(run_dir)
    export = run_dir / "clean_mcx_trade_export.csv"
    provenance = run_dir / "trade_provenance.csv"
    manifest_path = run_dir / "run_manifest.json"
    validation_path = run_dir / "data_validation.json"
    export_validation_path = run_dir / "export_validation.json"
    statistical_path = run_dir / "statistical_validation.json"
    required = (export, provenance, manifest_path, validation_path, export_validation_path)
    missing = [p.name for p in required if not p.is_file()]
    if missing:
        return _block("BLOCKED_MISSING_DATA", "missing clean-run artifact(s): " + ", ".join(missing))
    try:
        manifest = _read_json(manifest_path)
        data_validation = _read_json(validation_path)
        export_validation = _read_json(export_validation_path)
        with export.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            fields = reader.fieldnames or []
            rows = list(reader)
        with provenance.open(newline="", encoding="utf-8") as f:
            prov_rows = list(csv.DictReader(f))
    except (OSError, ValueError, csv.Error) as exc:
        return _block("BLOCKED_INVALID_EXPORT", f"cannot parse run evidence: {type(exc).__name__}: {exc}")

    if fields != EXPORT_COLUMNS:
        return _block("BLOCKED_INVALID_EXPORT", "trade export schema/column order is not the required 14-column schema",
                      observed_columns=fields)
    if manifest.get("source_class") != "AUTHORITATIVE_CLEAN" or manifest.get("synthetic_or_test_only") is not False:
        return _block("BLOCKED_INVALID_EXPORT", "diagnostic or TEST_ONLY run cannot support authoritative edge validation")
    if manifest.get("output_sha256") != sha256(export):
        return _block("BLOCKED_INVALID_EXPORT", "trade export hash does not match run manifest")
    if manifest.get("data_validation") != data_validation:
        return _block("BLOCKED_INVALID_EXPORT", "manifest and data_validation.json evidence differ")
    if (export_validation.get("status") != "VALID" or export_validation.get("reconciled") is not True
            or export_validation.get("rows") != len(rows) or export_validation.get("schema_columns") != EXPORT_COLUMNS):
        return _block("BLOCKED_INVALID_EXPORT", "Task-3 export_validation.json is missing, inconsistent, or invalid")
    if data_validation.get("status") != "VALID" or data_validation.get("source_mode") != "RAW_DATED":
        return _block("BLOCKED_MISSING_DATA", "Task-2 validation is not VALID RAW_DATED evidence")
    issues = readiness_issues(data_validation)
    if issues:
        return _block("BLOCKED_MISSING_DATA", "; ".join(issues))
    if any(data_validation.get(flag) is not True for flag in TASK2_FLAGS):
        return _block("BLOCKED_MISSING_DATA", "one or more Task-2 integrity flags are not true")
    input_hashes = data_validation.get("input_hashes")
    if not isinstance(input_hashes, dict) or not input_hashes:
        return _block("BLOCKED_MISSING_DATA", "Task-2 input source hashes are missing")
    for source_name, expected_hash in input_hashes.items():
        source_path = Path(source_name)
        if not source_path.is_absolute():
            source_path = (ROOT / source_path).resolve()
        if not source_path.is_file():
            return _block("BLOCKED_MISSING_DATA", f"hashed Task-2 input is unavailable: {source_name}")
        if sha256(source_path) != expected_hash:
            return _block("BLOCKED_INVALID_EXPORT", f"Task-2 input hash mismatch: {source_name}")
    try:
        split = split_override or str(manifest["split_date"])
        split_day = date.fromisoformat(split)
    except (KeyError, ValueError, TypeError):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "approved ISO split date is missing or invalid")
    if str(manifest.get("split_date")) != split:
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "requested split differs from versioned run manifest")

    source_bundle_value = manifest.get("source_bundle")
    if not source_bundle_value:
        return _block("BLOCKED_MISSING_DATA", "run manifest lacks Task-2 source bundle path")
    source_bundle = Path(source_bundle_value)
    if not source_bundle.is_absolute():
        source_bundle = (ROOT / source_bundle).resolve()
    if not source_bundle.is_file():
        return _block("BLOCKED_MISSING_DATA", "Task-2 source bundle is unavailable")
    if manifest.get("source_bundle_sha256") != sha256(source_bundle):
        return _block("BLOCKED_INVALID_EXPORT", "Task-2 source bundle hash mismatch")
    try:
        bundle = _read_json(source_bundle)
    except (OSError, ValueError):
        return _block("BLOCKED_INVALID_EXPORT", "Task-2 source bundle is invalid JSON")
    approvals = bundle.get("approvals", {})
    if (approvals.get("split_date") != split or not approvals.get("split_date_approval_id")
            or approvals.get("edge_criteria_approval_id") is None):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION",
                      "split and edge-sample criteria require explicit approval IDs in the source bundle")
    # No sample-size or win-rate threshold is invented here. An independently
    # approved criteria record must state a minimum per partition.
    criteria = approvals.get("edge_criteria")
    if (not isinstance(criteria, dict) or criteria.get("approval_id") != approvals.get("edge_criteria_approval_id")
            or criteria.get("approval_status") != "APPROVED"
            or not isinstance(criteria.get("minimum_trades_per_partition"), int)
            or criteria["minimum_trades_per_partition"] < 1
            or not criteria.get("statistical_validation_spec_id")):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "approved sample and statistical validation criteria are absent or invalid")
    if approved_config is None:
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "independently approved edge/split config file is required")
    try:
        approved_path = Path(approved_config).resolve(strict=True)
        approved_path.relative_to(ROOT.resolve())
    except ValueError:
        pass
    except OSError:
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "external approved edge/split config is unavailable")
    else:
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "approved edge/split config must be outside the repository")
    try:
        approved = _read_json(approved_path)
    except (OSError, ValueError):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "external approved edge/split config is invalid")
    if (not approved.get("approval_record_id") or approved.get("split_date") != split
            or approved.get("split_date_approval_id") != approvals.get("split_date_approval_id")
            or approved.get("edge_criteria_approval_id") != approvals.get("edge_criteria_approval_id")
            or approved.get("edge_criteria") != criteria
            or approved.get("statistical_validation_spec_id") != criteria.get("statistical_validation_spec_id")):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "external approved edge/split config does not match run evidence")
    if not statistical_path.is_file():
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "approved statistical validation evidence is missing")
    try:
        statistical = _read_json(statistical_path)
    except (OSError, ValueError):
        return _block("BLOCKED_INVALID_EXPORT", "statistical validation evidence is invalid JSON")
    if (statistical.get("status") != "PASS"
            or statistical.get("specification_id") != criteria.get("statistical_validation_spec_id")
            or statistical.get("source_export_sha256") != sha256(export)):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "statistical validation is not passed for this export and approved specification")
    try:
        bundle_validation = _validate_task2_bundle(bundle)
    except Exception as exc:
        return _block("BLOCKED_MISSING_DATA", f"Task-2 bundle revalidation failed: {type(exc).__name__}: {exc}")
    if bundle_validation.get("status") != "VALID" or readiness_issues(bundle_validation):
        return _block("BLOCKED_MISSING_DATA", "Task-2 source bundle failed independent revalidation",
                      task2_errors=bundle_validation.get("errors", []))

    if len(rows) == 0:
        return _block("BLOCKED_INVALID_EXPORT", "clean export has no eligible resolved trades")
    if len(prov_rows) != len(rows):
        return _block("BLOCKED_INVALID_EXPORT", "trade/provenance row count mismatch")
    index_map = {}
    setup_ids = set()
    for item in prov_rows:
        try:
            idx = int(item.get("export_row_index", ""))
        except (TypeError, ValueError):
            return _block("BLOCKED_INVALID_EXPORT", "provenance row index is missing or invalid")
        if idx in index_map or idx < 0 or idx >= len(rows):
            return _block("BLOCKED_INVALID_EXPORT", "duplicate or out-of-range provenance row index")
        sid = item.get("setup_id", "")
        if not sid or sid in setup_ids:
            return _block("BLOCKED_INVALID_EXPORT", "missing or duplicate stable setup ID")
        setup_ids.add(sid)
        index_map[idx] = item
    if set(index_map) != set(range(len(rows))):
        return _block("BLOCKED_INVALID_EXPORT", "provenance does not join one-to-one by export_row_index")

    verified_contracts = {c.get("contract_symbol"): c for item in bundle.get("underlyings", [])
                          for c in item.get("contracts", []) if c.get("attribution_status") == "VERIFIED"}
    grouped = {}
    minimum = criteria["minimum_trades_per_partition"]
    for idx, row in enumerate(rows):
        p = index_map[idx]
        try:
            symbol = row["symbol"].upper()
            tf = int(row["strategy_tf"])
            entry, stop = float(row["entry_price"]), float(row["stop_price"])
            exit_price, gross, mfe = float(row["exit_price"]), float(row["gross_r"]), float(row["mfe_R"])
            timestamp = datetime.fromisoformat(p["signal_timestamp"].replace("Z", "+00:00"))
            entry_timestamp = datetime.fromisoformat(p["entry_timestamp"].replace("Z", "+00:00"))
            exit_timestamp = datetime.fromisoformat(p["exit_timestamp"].replace("Z", "+00:00"))
            bars_held = int(row["bars_held"])
            trade_day = timestamp.date()
        except (KeyError, TypeError, ValueError, OverflowError):
            return _block("BLOCKED_INVALID_EXPORT", f"invalid required numeric/timestamp field at export row {idx}")
        if (timestamp.tzinfo is None or entry_timestamp.tzinfo is None or exit_timestamp.tzinfo is None
                or entry_timestamp < timestamp or exit_timestamp < entry_timestamp or bars_held < 1):
            return _block("BLOCKED_INVALID_EXPORT", f"invalid/naive signal-entry-exit timestamp or bars_held at row {idx}")
        if symbol not in VALID_UNIVERSE:
            return _block("BLOCKED_INVALID_EXPORT", f"unsupported underlying at export row {idx}")
        if tf not in (1, 2, 3, 4) or row["outcome"] not in ("WIN", "LOSS"):
            return _block("BLOCKED_INVALID_EXPORT", f"invalid timeframe or outcome at export row {idx}")
        if not all(math.isfinite(v) for v in (entry, stop, exit_price, gross, mfe)) or entry <= stop:
            return _block("BLOCKED_INVALID_EXPORT", f"invalid realized-R inputs at export row {idx}")
        if abs(gross - (exit_price - entry) / (entry - stop)) > 1e-8:
            return _block("BLOCKED_INVALID_EXPORT", f"gross_r does not reconcile to executable exit at row {idx}")
        if (row["outcome"] == "WIN") != (gross > 0):
            return _block("BLOCKED_INVALID_EXPORT", f"outcome conflicts with realized gross_r at row {idx}")
        if p.get("partition") != row["partition"]:
            return _block("BLOCKED_INVALID_EXPORT", f"partition mismatch at export row {idx}")
        expected_partition = "IS" if trade_day < split_day else "OOS"
        if row["partition"] != expected_partition:
            return _block("BLOCKED_INVALID_EXPORT", f"split assignment mismatch at export row {idx}")
        contract = verified_contracts.get(p.get("historical_contract"))
        if p.get("underlying") != symbol or not contract or contract.get("underlying") != symbol:
            return _block("BLOCKED_MISSING_DATA", f"unverified dated-contract attribution at export row {idx}")
        try:
            active_from = datetime.fromisoformat(str(contract["active_from"]).replace("Z", "+00:00"))
            active_to = (datetime.fromisoformat(str(contract["active_to"]).replace("Z", "+00:00"))
                         if contract.get("active_to") else None)
        except (KeyError, TypeError, ValueError):
            return _block("BLOCKED_MISSING_DATA", f"contract active interval is unavailable at export row {idx}")
        if active_from.tzinfo is None or (active_to is not None and active_to.tzinfo is None):
            return _block("BLOCKED_MISSING_DATA", f"contract interval lacks timezone provenance at export row {idx}")
        if timestamp < active_from or (active_to is not None and timestamp >= active_to):
            return _block("BLOCKED_MISSING_DATA", f"signal timestamp falls outside dated-contract interval at row {idx}")
        if not p.get("data_source_id") or not p.get("roll_policy_version"):
            return _block("BLOCKED_MISSING_DATA", f"source or roll-policy provenance missing at export row {idx}")
        if symbol not in universe:
            continue
        cell = (symbol, tf, row["E_regime"], row["A_regime"], row["X_regime"])
        part = row["partition"]
        group = grouped.setdefault(cell, {"IS": [], "OOS": []})
        risk = entry - stop
        net_r = gross - rt * entry / risk
        group[part].append({"gross_r": gross, "net_r": net_r, "outcome": row["outcome"], "mfe_R": mfe})

    cells = []
    for cell, partitions in sorted(grouped.items()):
        metrics = {"underlying": cell[0], "strategy_tf": cell[1], "E_regime": cell[2],
                   "A_regime": cell[3], "X_regime": cell[4]}
        reasons = []
        for part in ("IS", "OOS"):
            data = partitions[part]
            n = len(data)
            metrics[f"{part.lower()}_count"] = n
            metrics[f"{part.lower()}_realized_gross_r"] = sum(x["gross_r"] for x in data) / n if n else None
            metrics[f"{part.lower()}_realized_net_r"] = sum(x["net_r"] for x in data) / n if n else None
            metrics[f"{part.lower()}_win_rate"] = sum(x["outcome"] == "WIN" for x in data) / n if n else None
            if n < minimum:
                reasons.append(f"{part} sample {n} below approved minimum {minimum}")
            avg = metrics[f"{part.lower()}_realized_net_r"]
            if avg is None or avg <= 0:
                reasons.append(f"{part} net realized expectancy is nonpositive or absent")
        metrics["reproduction_verdict"] = "PASS" if not reasons else "FAIL_EDGE"
        metrics["reason"] = "; ".join(reasons) if reasons else "positive IS/OOS net realized-R and approved sample floor passed"
        cells.append(metrics)

    stat_cells = statistical.get("cells")
    expected_keys = {(x["underlying"], x["strategy_tf"], x["E_regime"], x["A_regime"], x["X_regime"])
                     for x in cells}
    observed = {}
    if isinstance(stat_cells, list):
        for record in stat_cells:
            try:
                key = (str(record["underlying"]), int(record["strategy_tf"]), str(record["E_regime"]),
                       str(record["A_regime"]), str(record["X_regime"]))
            except (KeyError, TypeError, ValueError):
                return _block("BLOCKED_INVALID_EXPORT", "statistical-validation cell record has invalid fields")
            if key in observed:
                return _block("BLOCKED_INVALID_EXPORT", "duplicate statistical-validation cell record")
            observed[key] = record
    if set(observed) != expected_keys or any(v.get("verdict") != "PASS" for v in observed.values()):
        return _block("BLOCKED_UNAPPROVED_CONFIGURATION", "approved statistical validation does not pass every evaluated cell")
    for cell in cells:
        key = (cell["underlying"], cell["strategy_tf"], cell["E_regime"], cell["A_regime"], cell["X_regime"])
        cell["statistical_validation_verdict"] = observed[key]["verdict"]

    checker_command = [sys.executable, str(ROOT / "scripts/edge_repro_check.py"), str(export),
        "--segment", "MCX", "--rt", str(rt), "--split", split, "--universe", ",".join(sorted(universe)),
        "--provenance", str(provenance), "--manifest", str(manifest_path), "--candidate-cells"]
    checker_output, checker_exit = "", None
    if invoke_checker:
        proc = subprocess.run(checker_command, cwd=ROOT, capture_output=True, text=True, check=False)
        checker_output, checker_exit = proc.stdout + proc.stderr, proc.returncode
    fails = [x for x in cells if x["reproduction_verdict"] != "PASS"]
    verdict = "FAIL_EDGE" if fails or checker_exit not in (None, 0) else "PASS"
    return {"verdict": verdict, "reason": "per-cell realized net-R reproduction completed",
            "run_id": manifest.get("run_id"), "split_date": split, "segment": "MCX",
            "universe": sorted(universe), "round_trip_cost_fraction": rt,
            "approved_sample_minimum": minimum, "candidate_cells_are_not_live_permissions": True,
            "statistical_validation_spec_id": criteria["statistical_validation_spec_id"],
            "checker_exit_code": checker_exit, "checker_output": checker_output,
            "cells": cells, "task2_status": bundle_validation.get("status")}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--split", help="must match independently approved run split")
    parser.add_argument("--approved-config", type=Path,
                        help="independently approved JSON reference stored outside the repository checkout")
    parser.add_argument("--universe", required=True, help="comma-separated MCX underlying symbols")
    parser.add_argument("--rt", type=float, default=0.0010)
    parser.add_argument("--json-out", type=Path, default=ROOT / "PREDIXA_MCX_PHASE1_TASK4_VALIDATION_RESULTS.json")
    parser.add_argument("--report-out", type=Path, default=ROOT / "PREDIXA_MCX_PHASE1_TASK4_EDGE_REPRO_REPORT.md")
    args = parser.parse_args(argv)
    try:
        universe = {x.strip().upper() for x in args.universe.split(",") if x.strip()}
        if not universe or not universe.issubset(VALID_UNIVERSE) or args.rt < 0 or not math.isfinite(args.rt):
            raise ValueError("universe or cost input is invalid")
        run_dir = args.run_dir or locate_run(args.runs_root)
        if run_dir is None:
            result = _block("BLOCKED_MISSING_DATA", "no versioned clean_mcx_trade_export.csv run exists")
        else:
            result = validate_run(run_dir, universe=universe, rt=args.rt,
                                  split_override=args.split, approved_config=args.approved_config,
                                  invoke_checker=True)
    except (OSError, ValueError) as exc:
        result = _block("BLOCKED_INVALID_EXPORT", str(exc))
    args.json_out.parent.mkdir(parents=True, exist_ok=True)
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    lines = ["# PREDIXA MCX Phase-1 Task-4 Edge Reproduction", "",
             f"**Verdict: {result['verdict']}**", "", result.get("reason", ""), ""]
    if result.get("cells"):
        lines.extend(["| Underlying | TF | E/A/X | IS n | OOS n | IS gross R | OOS gross R | IS net R | OOS net R | IS win% | OOS win% | Verdict | Reason |",
                      "|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|"])
        for c in result["cells"]:
            fmt = lambda v: "—" if v is None else f"{v:.4f}"
            lines.append(f"| {c['underlying']} | {c['strategy_tf']} | {c['E_regime']}/{c['A_regime']}/{c['X_regime']} | {c['is_count']} | {c['oos_count']} | {fmt(c['is_realized_gross_r'])} | {fmt(c['oos_realized_gross_r'])} | {fmt(c['is_realized_net_r'])} | {fmt(c['oos_realized_net_r'])} | {fmt(c['is_win_rate'])} | {fmt(c['oos_win_rate'])} | {c['reproduction_verdict']} | {c['reason']} |")
    else:
        lines.append("No cell metrics were calculated because the run failed the evidence gate or no clean export exists.")
    lines += ["", "MFE is diagnostic only and was not used for expectancy. No result changes the MCX regime gate or authorizes trading.", ""]
    args.report_out.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({k: result.get(k) for k in ("verdict", "reason", "run_id", "task2_status")}, sort_keys=True))
    return 0 if result["verdict"] == "PASS" else (1 if result["verdict"] == "FAIL_EDGE" else 2)


if __name__ == "__main__":
    raise SystemExit(main())
