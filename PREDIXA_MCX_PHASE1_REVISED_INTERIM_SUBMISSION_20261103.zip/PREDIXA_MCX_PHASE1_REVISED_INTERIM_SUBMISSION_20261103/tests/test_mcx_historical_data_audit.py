import json
from pathlib import Path

from audit.mcx_futures_backtest import historical_data_audit as auditor


def test_filename_only_expiry_archive_is_unverified(tmp_path, monkeypatch):
    root = tmp_path / "repo"; root.mkdir()
    data = root / "data"; data.mkdir()
    source = data / "GOLDM_03072026_sixty.csv"
    source.write_text("open,high,low,close,qty,tradeDate\n1,2,1,2,3,01/01/2020 09:00:00\n")
    config = root / "config.json"
    config.write_text(json.dumps({"known_sources": {}, "scan_roots": ["data"]}))
    monkeypatch.setattr(auditor, "ROOT", root)
    rows, registry = auditor.audit(config, root / "out")
    assert rows[0]["status"] == "UNVERIFIED"
    assert rows[0]["family"] == "GOLD"
    assert registry == []


def test_explicit_raw_metadata_creates_partial_registry_record(tmp_path, monkeypatch):
    root = tmp_path / "repo"; root.mkdir()
    data = root / "data"; data.mkdir(); metadata = root / "metadata"; metadata.mkdir()
    source = data / "raw.csv"
    source.write_text("timestamp_ist,open,high,low,close,volume\n2026-10-01T09:00:00+05:30,1,2,1,2,3\n")
    meta = metadata / "raw.json"
    meta.write_text(json.dumps({"source_broker": "FYERS", "api_symbol": "MCX:CRUDEOILM26OCTFUT", "pull_type": "dated_raw", "continuous_flag": "0", "contract_expiry": "2026-10-19", "converted_timezone": "Asia/Kolkata"}))
    config = root / "config.json"
    config.write_text(json.dumps({"known_sources": {"data/raw.csv": {"metadata": "metadata/raw.json", "family": "CRUDEOIL", "variant": "CRUDEOILM"}}, "scan_roots": ["data"]}))
    monkeypatch.setattr(auditor, "ROOT", root)
    rows, registry = auditor.audit(config, root / "out")
    assert rows[0]["status"] == "VERIFIED_RAW"
    assert registry[0]["contract_symbol"] == "MCX:CRUDEOILM26OCTFUT"


def test_hash_verified_fyers_expired_response_creates_raw_registry_record(tmp_path, monkeypatch):
    root = tmp_path / "repo"; root.mkdir()
    source = root / "cache/MCX_CRUDEOILM26AUGFUT/bars.csv"
    source.parent.mkdir(parents=True)
    source.write_text("timestamp,open,high,low,close,volume\n2026-08-03T09:00:00+05:30,1,2,1,2,3\n")
    meta = root / "cache/meta.json"
    meta.write_text(json.dumps({
        "provider": "FYERS", "source_endpoint": "/history/fno/expired/historical-data",
        "status": "SUCCESS", "price_identity": "EXACT_DATED_SYMBOL_RETURNED_BY_FYERS",
        "raw_response_sha256": "response-digest", "normalized_bars_sha256": auditor.sha256(source),
        "contract_symbol": "MCX:CRUDEOILM26AUGFUT", "expiry_date": "2026-08-19",
    }))
    relative = "cache/MCX_CRUDEOILM26AUGFUT/bars.csv"
    config = root / "config.json"
    config.write_text(json.dumps({"scan_roots": [], "additional_sources": [relative], "known_sources": {
        relative: {"metadata": "cache/meta.json", "family": "CRUDEOIL", "variant": "CRUDEOILM"}
    }}))
    monkeypatch.setattr(auditor, "ROOT", root)
    rows, registry = auditor.audit(config, root / "out")
    assert rows[0]["status"] == "VERIFIED_RAW"
    assert rows[0]["provider_instrument_id"] == "MCX:CRUDEOILM26AUGFUT"
    assert registry[0]["expiry_date"] == "2026-08-19"
