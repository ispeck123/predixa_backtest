"""Offline regression coverage for Phase-1 Task-1 MCX E1 session seams.

Fixtures are synthetic OHLC timestamps only; they are correctness fixtures,
not market data or evidence of a trading edge.
"""
from datetime import UTC, datetime

import pytest

from scripts.graduated_live_config import mcx_execution_permitted
from scripts.mcx_session import IST, mcx_e1_session_ids
from scripts.models import CandleSeries, Config, TF, Zone, ZoneType
from scripts.position_sizing import CapitalAllocator, PortfolioPolicy, SEGMENTS
from scripts.tf_regime_gate_by_exchange import gate
from scripts.trade_engine import GapModule, ZoneDetector, ZoneQualifier


def ts(day, hour, minute=0):
    return int(datetime(2026, 1, day, hour, minute, tzinfo=IST).timestamp())


def series(timestamps, *, session_ids=None, lows=None, highs=None):
    n = len(timestamps)
    lows = lows or [99.0] * n
    highs = highs or [101.0] * n
    return CandleSeries(
        o=[100.0] * n, h=highs, l=lows, c=[100.0] * n,
        ts=timestamps, session_id=session_ids,
    )


class SegmentRecordingDetector(ZoneDetector):
    """Makes the detector's session segmentation observable without strategy tuning."""

    def _detect_unbounded(self, symbol, timeframe, candles):
        if len(candles.o) < 2:
            return []
        return [Zone(
            symbol=symbol, tf=timeframe, ztype=ZoneType.BZ,
            distal=min(candles.l), proximal=max(candles.h),
            created_idx=len(candles.o) - 1, base_start=0,
            base_end=len(candles.o) - 1, base_len=len(candles.o),
            departure_idx=len(candles.o) - 1,
        )]


def buy_zone(*, ztype=ZoneType.BZ):
    return Zone(
        symbol="MCX:TEST", tf=TF.X, ztype=ztype, distal=90.0, proximal=100.0,
        created_idx=0, base_start=0, base_end=0, base_len=1,
    )


def test_e1_01_normal_intraday_continuity_preserves_segment():
    timestamps = [ts(5, 9), ts(5, 10), ts(5, 11)]
    ids = mcx_e1_session_ids(timestamps)
    zones = SegmentRecordingDetector(Config()).detect("MCX:TEST", TF.X, series(timestamps, session_ids=ids))
    assert ids == [0, 0, 0]
    assert [(z.base_start, z.base_end) for z in zones] == [(0, 2)]


@pytest.mark.parametrize("close_bucket", [(23, 30), (23, 0), (21, 0)])
def test_e1_02_and_10_overnight_boundary_for_supported_final_buckets(close_bucket):
    timestamps = [ts(5, *close_bucket), ts(6, 9)]
    assert mcx_e1_session_ids(timestamps) == [0, 1]


def test_e1_03_no_artificial_bridge_or_cross_session_zone():
    timestamps = [ts(5, 23), ts(6, 9), ts(6, 10)]
    ids = mcx_e1_session_ids(timestamps)
    candles = series(timestamps, session_ids=ids, lows=[99, 130, 131], highs=[101, 140, 141])
    zones = SegmentRecordingDetector(Config()).detect("MCX:TEST", TF.X, candles)
    assert len(candles.o) == 3  # E1 labels data; it never manufactures a bar.
    assert [(z.base_start, z.base_end) for z in zones] == [(1, 2)]


def test_e1_03_resampler_drops_partial_preclose_chunk_instead_of_bridging(tmp_path, monkeypatch):
    """The legacy 15m->75m positional resampler must reset at the E1 seam."""
    from data_fetchers.fyers import indian_commodity_data_updater as updater

    csv_dir = tmp_path / "latest_data_csv"
    csv_dir.mkdir()
    rows = [
        # Four candles leave an incomplete 75m chunk at the 23:30 close.
        ("05/01/2026 22:30:00", 100), ("05/01/2026 22:45:00", 101),
        ("05/01/2026 23:00:00", 102), ("05/01/2026 23:15:00", 103),
        # Five valid next-session candles must make the only emitted bar.
        ("06/01/2026 09:00:00", 130), ("06/01/2026 09:15:00", 131),
        ("06/01/2026 09:30:00", 132), ("06/01/2026 09:45:00", 133),
        ("06/01/2026 10:00:00", 134),
    ]
    import pandas as pd
    pd.DataFrame([
        {"tradeDate": when, "open": price, "high": price + 1,
         "low": price - 1, "close": price, "qty": 1}
        for when, price in rows
    ]).to_csv(csv_dir / "TEST_fifteen.csv", index=False)
    monkeypatch.setattr(updater.sddcfg, "indian_commodity_data", str(tmp_path))
    emitted = []
    handler = updater.MCXFutureDataHandler.__new__(updater.MCXFutureDataHandler)
    handler.dump_csv = lambda headers, name, data: emitted.extend(data)
    handler.create_75munite_from_15munite("TEST_fifteen.csv")
    assert len(emitted) == 1
    assert emitted[0]["tradeDate"] == "06/01/2026 09:00:00"
    assert emitted[0]["open"] == 130 and emitted[0]["close"] == 134


def test_e1_04_and_05_base_and_legout_never_cross_session_indices():
    timestamps = [ts(5, 22), ts(5, 23), ts(6, 9), ts(6, 10)]
    ids = mcx_e1_session_ids(timestamps)
    zones = SegmentRecordingDetector(Config()).detect("MCX:TEST", TF.X, series(timestamps, session_ids=ids))
    assert zones
    assert all(ids[z.base_start] == ids[z.base_end] for z in zones)
    assert all(z.departure_idx is None or ids[z.base_end] == ids[z.departure_idx] for z in zones)


def test_e1_06_pure_gap_through_does_not_invalidate_regular_zone():
    timestamps = [ts(5, 23), ts(6, 9)]
    candles = series(timestamps, session_ids=mcx_e1_session_ids(timestamps), lows=[99, 70], highs=[101, 80])
    zone = buy_zone()
    ZoneQualifier(Config()).update_violation(candles, zone)
    assert not zone.invalidated


def test_e1_07_gap_open_does_not_retest_gap_zone():
    timestamps = [ts(5, 22), ts(5, 23), ts(6, 9)]
    # First post-base bar is basing so retest scanning starts at the 09:00 bar.
    candles = series(timestamps, session_ids=mcx_e1_session_ids(timestamps),
                     lows=[99, 99, 95], highs=[101, 101, 105])
    zone = buy_zone(ztype=ZoneType.GDZ)
    ZoneQualifier(Config()).update_retest(candles, zone)
    assert zone.retest_count == 0


def test_e1_07_gap_open_cannot_create_cross_session_gap_zone(monkeypatch):
    """A qualifying OHLC gap is ignored only when it straddles the E1 seam."""
    gap_module = GapModule()
    monkeypatch.setattr(gap_module, "_check_structure_removal", lambda *args, **kwargs: (True, "fixture"))
    monkeypatch.setattr(gap_module, "_check_breakaway", lambda *args, **kwargs: False)
    timestamps = [ts(5, 23), ts(6, 9)]
    seam = CandleSeries(
        o=[100, 150], h=[101, 160], l=[99, 150], c=[100, 160],
        ts=timestamps, session_id=mcx_e1_session_ids(timestamps),
    )
    same_session = CandleSeries(
        o=[100, 150], h=[101, 160], l=[99, 150], c=[100, 160],
        ts=[ts(6, 9), ts(6, 10)], session_id=[0, 0],
    )
    from scripts.models import VolatilityRegime
    assert gap_module.detect("MCX:TEST", TF.X, seam, VolatilityRegime.NORMAL) == []
    assert len(gap_module.detect("MCX:TEST", TF.X, same_session, VolatilityRegime.NORMAL)) == 1


def test_e1_08_valid_same_session_processing_remains_eligible():
    timestamps = [ts(6, 9), ts(6, 10), ts(6, 11)]
    ids = mcx_e1_session_ids(timestamps)
    zones = SegmentRecordingDetector(Config()).detect("MCX:TEST", TF.X, series(timestamps, session_ids=ids))
    assert len(zones) == 1
    assert zones[0].base_start == 0 and zones[0].base_end == 2


def test_e1_09_weekend_gap_is_not_a_bridge():
    timestamps = [ts(2, 23), ts(5, 9)]  # Friday to Monday, January 2026
    assert mcx_e1_session_ids(timestamps) == [0, 1]


def test_e1_11_utc_and_ist_timestamps_assign_same_session():
    ist_values = [datetime(2026, 1, 5, 23, tzinfo=IST), datetime(2026, 1, 6, 9, tzinfo=IST)]
    utc_values = [value.astimezone(UTC).timestamp() for value in ist_values]
    assert mcx_e1_session_ids(ist_values) == mcx_e1_session_ids(utc_values) == [0, 1]


def test_e1_12_no_session_labels_preserve_non_mcx_detector_path():
    timestamps = [ts(5, 23), ts(6, 9)]
    zones = SegmentRecordingDetector(Config()).detect("NSE:TEST", TF.X, series(timestamps))
    assert [(z.base_start, z.base_end) for z in zones] == [(0, 1)]


def test_e1_13_duplicate_and_unordered_timestamps_fail_closed_as_boundaries():
    duplicate = [ts(5, 23), ts(5, 23), ts(6, 9)]
    unordered = [ts(6, 9), ts(5, 23)]
    assert mcx_e1_session_ids(duplicate) == [0, 1, 2]
    assert mcx_e1_session_ids(unordered) == [0, 1]


def test_e1_14_existing_mcx_execution_blocks_remain_active():
    assert mcx_execution_permitted() is False
    portfolio = PortfolioPolicy(1_000_000, 5.0, 10, 2, 10.0)
    assert CapitalAllocator(portfolio, SEGMENTS).segment_status("MCX") == "BLOCKED"
    assert gate("MCX", 4, "UP", "UP", "CRUDEOILM")[1] == 0.0
