"""Synthetic fixtures test the Task-4 gate only; they are not market evidence."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest

from scripts import mcx_phase1_edge_validation as gate


GOOD_FLAGS = {key: True for key in gate.TASK2_FLAGS}
GOOD_VALIDATION = {
    "status": "VALID", "source_mode": "RAW_DATED", **GOOD_FLAGS,
    "underlyings": ["GOLDM", "GOLDGUINEA", "SILVERM", "CRUDEOILM", "NATGASMINI"],
    "strategy_timeframes": [1, 2, 3, 4], "coverage_start": "2025-11-03",
    "coverage_end": "2026-11-02", "roll_policy_version": "approved-policy-v1",
    "calendar_version": "official-calendar-v1", "input_hashes": {"fixture": "sha256:test"},
}


def make_run(tmp_path, *, is_gross=1.0, oos_gross=1.0, is_mfe=1.2, oos_mfe=1.2,
             min_sample=1, mutate=None, row_symbols=("GOLDM", "GOLDM")):
    run = tmp_path / "run-001"
    run.mkdir()
    input_file = tmp_path / "dated-bars.csv"
    input_file.write_text("test-only input bytes")
    validation = dict(GOOD_VALIDATION)
    validation["input_hashes"] = {str(input_file): hashlib.sha256(input_file.read_bytes()).hexdigest()}
    source = tmp_path / "source_bundle.json"
    bundle = {"approvals": {"split_date": "2026-02-01", "split_date_approval_id": "APP-SPLIT",
                             "edge_criteria_approval_id": "APP-EDGE",
                             "edge_criteria": {"approval_id": "APP-EDGE", "approval_status": "APPROVED",
                                               "minimum_trades_per_partition": min_sample,
                                               "statistical_validation_spec_id": "STAT-SPEC-1"}},
              "underlyings": [{"contracts": [{"contract_symbol": "MCX:GOLDM26OCTFUT",
                  "underlying": "GOLDM", "attribution_status": "VERIFIED",
                  "active_from": "2025-01-01T09:00:00+05:30", "active_to": None}]}]}
    source.write_text(json.dumps(bundle))
    approved_config = {"approval_record_id": "EXTERNAL-APPROVAL-001", "split_date": "2026-02-01",
        "split_date_approval_id": "APP-SPLIT", "edge_criteria_approval_id": "APP-EDGE",
        "edge_criteria": bundle["approvals"]["edge_criteria"],
        "statistical_validation_spec_id": "STAT-SPEC-1"}
    (tmp_path / "approved_edge_config.json").write_text(json.dumps(approved_config))
    manifest = {"source_class": "AUTHORITATIVE_CLEAN", "synthetic_or_test_only": False,
                "split_date": "2026-02-01", "run_id": "run-001",
                "source_bundle": str(source), "source_bundle_sha256": gate.sha256(source),
        "data_validation": validation}
    rows = [
        [row_symbols[0], 4, "SW", "UP", "UP", 100, 90, 120, 110 if is_gross == 1 else 90,
         "WIN" if is_gross > 0 else "LOSS", is_gross, is_mfe, "IS", 2],
        [row_symbols[1], 4, "SW", "UP", "UP", 100, 90, 120, 110 if oos_gross == 1 else 90,
         "WIN" if oos_gross > 0 else "LOSS", oos_gross, oos_mfe, "OOS", 2],
    ]
    if mutate:
        mutate(bundle, manifest, validation, rows)
        source.write_text(json.dumps(bundle))
        manifest["source_bundle_sha256"] = gate.sha256(source)
    fields = ["symbol", "strategy_tf", "E_regime", "A_regime", "X_regime", "entry_price", "stop_price",
              "target_price", "exit_price", "outcome", "gross_r", "mfe_R", "partition", "bars_held"]
    with (run / "clean_mcx_trade_export.csv").open("w", newline="") as f:
        writer = csv.writer(f); writer.writerow(fields); writer.writerows(rows)
    manifest["output_sha256"] = gate.sha256(run / "clean_mcx_trade_export.csv")
    (run / "statistical_validation.json").write_text(json.dumps({"status": "PASS",
        "specification_id": "STAT-SPEC-1", "source_export_sha256": manifest["output_sha256"],
        "cells": [{"underlying": "GOLDM", "strategy_tf": 4, "E_regime": "SW",
                   "A_regime": "UP", "X_regime": "UP", "verdict": "PASS"}]}))
    (run / "run_manifest.json").write_text(json.dumps(manifest))
    (run / "data_validation.json").write_text(json.dumps(validation))
    (run / "export_validation.json").write_text(json.dumps({"status": "VALID", "rows": len(rows),
        "schema_columns": ["symbol", "strategy_tf", "E_regime", "A_regime", "X_regime", "entry_price", "stop_price",
                           "target_price", "exit_price", "outcome", "gross_r", "mfe_R", "partition", "bars_held"],
        "reconciled": True}))
    with (run / "trade_provenance.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["export_row_index", "setup_id", "signal_timestamp", "partition",
            "entry_timestamp", "exit_timestamp", "underlying", "historical_contract", "data_source_id", "roll_policy_version"])
        writer.writeheader()
        writer.writerow({"export_row_index": 0, "setup_id": "setup-is", "signal_timestamp": "2026-01-10T10:00:00+05:30",
            "entry_timestamp": "2026-01-10T10:15:00+05:30", "exit_timestamp": "2026-01-10T10:30:00+05:30",
            "partition": "IS", "underlying": row_symbols[0], "historical_contract": "MCX:GOLDM26OCTFUT",
            "data_source_id": "sha256:fixture", "roll_policy_version": "approved-policy-v1"})
        writer.writerow({"export_row_index": 1, "setup_id": "setup-oos", "signal_timestamp": "2026-02-10T10:00:00+05:30",
            "entry_timestamp": "2026-02-10T10:15:00+05:30", "exit_timestamp": "2026-02-10T10:30:00+05:30",
            "partition": "OOS", "underlying": row_symbols[1], "historical_contract": "MCX:GOLDM26OCTFUT",
            "data_source_id": "sha256:fixture", "roll_policy_version": "approved-policy-v1"})
    return run


def rewrite_validation(run, validation):
    (run / "data_validation.json").write_text(json.dumps(validation))
    manifest_path = run / "run_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["data_validation"] = validation
    manifest_path.write_text(json.dumps(manifest))


def validate(run, **kwargs):
    kwargs.setdefault("approved_config", run.parent / "approved_edge_config.json")
    return gate.validate_run(run, **kwargs)


@pytest.fixture(autouse=True)
def task2_validation_stub(monkeypatch):
    monkeypatch.setattr(gate, "_validate_task2_bundle",
        lambda bundle: {"status": "VALID", "errors": [], **GOOD_VALIDATION})
    assert gate._validate_task2_bundle({})["status"] == "VALID"


def test_positive_is_oos_realized_metrics_pass(tmp_path):
    run = make_run(tmp_path)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "PASS", result
    cell = result["cells"][0]
    assert cell["is_count"] == cell["oos_count"] == 1
    assert cell["is_realized_gross_r"] > 0 and cell["oos_realized_net_r"] > 0


def test_negative_oos_realized_r_fails_even_with_positive_mfe(tmp_path):
    run = make_run(tmp_path, oos_gross=-1, oos_mfe=3)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "FAIL_EDGE"
    assert result["cells"][0]["oos_realized_gross_r"] == -1
    assert "nonpositive" in result["cells"][0]["reason"]


def test_approved_sample_minimum_is_enforced(tmp_path):
    run = make_run(tmp_path, min_sample=2)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["cells"][0]["reproduction_verdict"] == "FAIL_EDGE"
    assert "below approved minimum" in result["cells"][0]["reason"]


def test_unapproved_or_failed_statistical_validation_blocks_authoritative_verdict(tmp_path):
    run = make_run(tmp_path)
    stats_path = run / "statistical_validation.json"
    stats = json.loads(stats_path.read_text()); stats["cells"][0]["verdict"] = "FAIL"
    stats_path.write_text(json.dumps(stats))
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_UNAPPROVED_CONFIGURATION"
    stats_path.unlink()
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_UNAPPROVED_CONFIGURATION"


def test_missing_export_returns_nonzero_blocked(tmp_path, monkeypatch):
    json_out, md_out = tmp_path / "out.json", tmp_path / "out.md"
    rc = gate.main(["--runs-root", str(tmp_path / "none"), "--universe", "GOLDM",
                    "--json-out", str(json_out), "--report-out", str(md_out)])
    assert rc == 2 and json.loads(json_out.read_text())["verdict"] == "BLOCKED_MISSING_DATA"


def test_wrong_schema_and_missing_provenance_are_rejected(tmp_path):
    run = make_run(tmp_path)
    p = run / "trade_provenance.csv"
    p.write_text("export_row_index,setup_id\n0,a\n1,b\n")
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_INVALID_EXPORT"
    p.unlink()
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_MISSING_DATA"


def test_duplicate_mapping_and_incorrect_universe_rejected(tmp_path):
    run = make_run(tmp_path)
    provenance = run / "trade_provenance.csv"
    text = provenance.read_text().replace("1,setup-oos", "0,setup-oos")
    provenance.write_text(text)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_INVALID_EXPORT"
    run = tmp_path / "other"
    run.mkdir()
    run = make_run(run, row_symbols=("OTHER", "OTHER"))
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_INVALID_EXPORT"


def test_split_mismatch_and_missing_data_hashes_fail_closed(tmp_path):
    run = make_run(tmp_path)
    result = validate(run, universe={"GOLDM"}, rt=0.001,
                               split_override="2026-03-01", invoke_checker=False)
    assert result["verdict"] == "BLOCKED_UNAPPROVED_CONFIGURATION"
    result = validate(run, universe={"GOLDM"}, rt=0.001,
                               split_override="not-a-date", invoke_checker=False)
    assert result["verdict"] == "BLOCKED_UNAPPROVED_CONFIGURATION"
    validation = json.loads((run / "data_validation.json").read_text())
    validation["input_hashes"] = {}
    rewrite_validation(run, validation)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_MISSING_DATA"


@pytest.mark.parametrize("flag", ["roll_policy_approved", "trading_calendar_verified", "e1_enforced",
                                   "historical_contract_attribution_verified"])
def test_unapproved_roll_calendar_or_invalid_e1_contract_fails(tmp_path, flag):
    run = make_run(tmp_path)
    validation = json.loads((run / "data_validation.json").read_text())
    validation[flag] = False
    rewrite_validation(run, validation)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_MISSING_DATA"


def test_test_only_manifest_and_unapproved_edge_criteria_are_blocked(tmp_path):
    run = make_run(tmp_path)
    path = run / "run_manifest.json"
    manifest = json.loads(path.read_text()); manifest["synthetic_or_test_only"] = True
    path.write_text(json.dumps(manifest))
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_INVALID_EXPORT"
    run2 = tmp_path / "unapproved"; run2.mkdir(); run2 = make_run(run2)
    bundle_path = Path(json.loads((run2 / "run_manifest.json").read_text())["source_bundle"])
    bundle = json.loads(bundle_path.read_text()); del bundle["approvals"]["edge_criteria_approval_id"]
    bundle_path.write_text(json.dumps(bundle))
    mpath = run2 / "run_manifest.json"; m = json.loads(mpath.read_text()); m["source_bundle_sha256"] = gate.sha256(bundle_path); mpath.write_text(json.dumps(m))
    result = validate(run2, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_UNAPPROVED_CONFIGURATION"


def test_contract_mapping_and_input_hashes_are_verified(tmp_path):
    run = make_run(tmp_path)
    manifest = json.loads((run / "run_manifest.json").read_text())
    validation = json.loads((run / "data_validation.json").read_text())
    source_path = next(iter(validation["input_hashes"]))
    validation["input_hashes"][source_path] = "0" * 64
    rewrite_validation(run, validation)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_INVALID_EXPORT"
    run = tmp_path / "wrong-contract"; run.mkdir(); run = make_run(run)
    bundle_path = Path(json.loads((run / "run_manifest.json").read_text())["source_bundle"])
    bundle = json.loads(bundle_path.read_text())
    bundle["underlyings"][0]["contracts"][0]["attribution_status"] = "INFERRED"
    bundle_path.write_text(json.dumps(bundle))
    manifest_path = run / "run_manifest.json"; manifest = json.loads(manifest_path.read_text())
    manifest["source_bundle_sha256"] = gate.sha256(bundle_path); manifest_path.write_text(json.dumps(manifest))
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=False)
    assert result["verdict"] == "BLOCKED_MISSING_DATA"


def test_checker_is_invoked_in_candidate_only_mode_and_its_failure_is_not_hidden(tmp_path, monkeypatch):
    run = make_run(tmp_path)
    seen = {}
    def fake_run(command, **kwargs):
        seen["command"] = command
        return SimpleNamespace(stdout="candidate report", stderr="", returncode=1)
    monkeypatch.setattr(gate.subprocess, "run", fake_run)
    result = validate(run, universe={"GOLDM"}, rt=0.001, invoke_checker=True)
    assert result["verdict"] == "FAIL_EDGE"
    assert "--candidate-cells" in seen["command"]
    assert "--segment" in seen["command"] and "MCX" in seen["command"]


def test_existing_checker_cli_reports_candidate_without_changing_empty_mcx_gate(tmp_path):
    run = make_run(tmp_path)
    command = [sys.executable, str(gate.ROOT / "scripts/edge_repro_check.py"),
        str(run / "clean_mcx_trade_export.csv"), "--segment", "MCX", "--rt", "0.001",
        "--split", "2026-02-01", "--universe", "GOLDM",
        "--provenance", str(run / "trade_provenance.csv"),
        "--manifest", str(run / "run_manifest.json"), "--candidate-cells"]
    result = subprocess.run(command, cwd=gate.ROOT, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "candidate cells (analysis only" in result.stdout
    assert "CANDIDATE_NOT_LIVE" in result.stdout
