import pandas as pd

from audit.mcx_futures_backtest.oi_roll_boundaries import first_crossover


def test_strict_oi_crossover_requires_next_contract_to_exceed_not_equal():
    stamps = pd.to_datetime(["2026-01-01 10:00+05:30", "2026-01-01 11:00+05:30"])
    outgoing = {"variant": "GOLDM", "contract": "MCX:GOLDM26JANFUT", "source_hash": "a", "quality": "PROVIDER_RESPONSE_VALIDATED", "series": pd.DataFrame({"timestamp": stamps, "open_interest": [10, 9]})}
    incoming = {"variant": "GOLDM", "contract": "MCX:GOLDM26FEBFUT", "source_hash": "b", "quality": "PROVIDER_RESPONSE_VALIDATED", "series": pd.DataFrame({"timestamp": stamps, "open_interest": [10, 11]})}
    event = first_crossover(outgoing, incoming)
    assert event["observation_timestamp"].startswith("2026-01-01T11:00")
    assert event["effective_roll_session"] == ""
    assert event["crossover_status"] == "OBSERVED_BUT_EXECUTABLE_TIME_UNKNOWN"
