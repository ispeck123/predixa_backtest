from datetime import date, datetime
from zoneinfo import ZoneInfo

from audit.mcx_futures_backtest.mcx_historical_session_calendar import build_calendar, session_contains


def test_unlisted_weekday_is_not_assumed_open_or_verified():
    row = build_calendar(date(2026, 1, 5), date(2026, 1, 5))[0]
    assert row["verification_status"] == "UNVERIFIED"
    assert row["trading_status"] == "UNVERIFIED"


def test_verified_normal_day_is_continuous_across_1700_not_a_false_close():
    records = {"2026-01-05": {"verification_status": "OFFICIAL_VERIFIED", "reference": "archive", "intervals": [["09:00", "23:30"]]}}
    row = build_calendar(date(2026, 1, 5), date(2026, 1, 5), records)[0]
    assert session_contains(row, datetime(2026, 1, 5, 17, 30, tzinfo=ZoneInfo("Asia/Kolkata")))
    assert not session_contains(row, datetime(2026, 1, 6, 9, 0, tzinfo=ZoneInfo("Asia/Kolkata")))


def test_muhurat_does_not_create_synthetic_normal_session():
    row = build_calendar(date(2026, 11, 8), date(2026, 11, 8))[0]
    assert row["is_muhurat"] == "true"
    assert row["morning_open"] == ""
    assert row["actual_trading_intervals"] == '[["14:20", "15:30"]]'
