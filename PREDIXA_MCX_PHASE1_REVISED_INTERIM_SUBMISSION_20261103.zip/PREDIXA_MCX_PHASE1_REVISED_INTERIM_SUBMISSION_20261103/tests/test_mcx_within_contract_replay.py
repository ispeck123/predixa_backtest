from datetime import date
import hashlib
from pathlib import Path

import pandas as pd

from audit.mcx_futures_backtest import within_contract_replay as replay


def test_segmentation_does_not_overlap_and_first_window_is_not_assumed(tmp_path, monkeypatch):
    root = tmp_path / "repo"; root.mkdir()
    source_path = root / "data.csv"
    source_path.write_text(
        "tradeDate,open,high,low,close,qty\n"
        "01/01/2026 09:00:00,1,2,1,2,1\n"
        "05/01/2026 09:00:00,2,3,2,3,1\n"
        "06/01/2026 09:00:00,3,4,3,4,1\n"
        "10/01/2026 09:00:00,4,5,4,5,1\n"
    )
    monkeypatch.setattr(replay, "ROOT", root)
    source = {"source_path": "data.csv", "variant": "GOLDM", "family": "GOLD", "timeframe": "sixty",
              "source_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(), "boundary_evidence": "LOCAL_CONTRACT_EXPIRY_FILENAME_LABEL"}
    output = replay.segment_source(source, [date(2026, 1, 5), date(2026, 1, 10)], calendar_verified=True)
    assert len(output) == 2
    first, second = (item[0] for item in output)
    assert first["exclusion_reason"] == "UNVERIFIED_CONTRACT_WINDOW"
    assert second["replay_eligibility"] == "ELIGIBLE"
    assert first["segment_end"] < second["segment_start"]
    assert set(output[0][1].timestamp).isdisjoint(set(output[1][1].timestamp))


def test_session_ids_reset_at_e1_seam_within_segment(tmp_path, monkeypatch):
    root = tmp_path / "repo"; root.mkdir()
    source_path = root / "data.csv"
    source_path.write_text(
        "tradeDate,open,high,low,close,qty\n"
        "05/01/2026 23:00:00,1,2,1,2,1\n"
        "06/01/2026 09:00:00,2,3,2,3,1\n"
    )
    monkeypatch.setattr(replay, "ROOT", root)
    source = {"source_path": "data.csv", "variant": "GOLDM", "family": "GOLD", "timeframe": "sixty", "source_sha256": "h", "boundary_evidence": "LOCAL_CONTRACT_EXPIRY_FILENAME_LABEL"}
    manifest, frame = replay.segment_source(source, [date(2026, 1, 4), date(2026, 1, 6)], calendar_verified=True)[0]
    assert manifest["replay_eligibility"] == "ELIGIBLE"
    assert frame.e1_session_id.nunique() == 2
