import pandas as pd
import pytest

from audit.mcx_futures_backtest.overnight_direction import load_daily_closes, overnight_direction
from audit.mcx_futures_backtest.within_contract_export import validate_rows


def test_direction_uses_only_complete_closes_available_as_of_signal():
    closes = pd.DataFrame({"source_date": [pd.Timestamp("2026-01-01").date(), pd.Timestamp("2026-01-02").date()],
                           "close": [100.0, 101.0],
                           "available_at": pd.to_datetime(["2026-01-01 23:00:00+05:30", "2026-01-02 23:00:00+05:30"])})
    assert overnight_direction("GOLDM", "2026-01-03 09:00:00+05:30", closes)["overnight_dir"] == "UP"
    assert overnight_direction("GOLDM", "2026-01-02 10:00:00+05:30", closes)["overnight_dir"] == "UNKNOWN"


def test_date_only_international_file_is_unknown_and_export_uses_realized_exit():
    closes = pd.DataFrame({"source_date": [pd.Timestamp("2026-01-01").date(), pd.Timestamp("2026-01-02").date()], "close": [100.0, 99.0], "available_at": [pd.NaT, pd.NaT]})
    assert overnight_direction("GOLDM", "2026-01-03 09:00:00+05:30", closes)["overnight_dir"] == "UNKNOWN"
    validate_rows([{ "setup_id": "one", "side": "BUY", "entry_price": 100, "stop_price": 90, "exit_price": 110, "gross_r": 1, "overnight_dir": "UNKNOWN" }])
    with pytest.raises(ValueError):
        validate_rows([{ "setup_id": "one", "side": "BUY", "entry_price": 100, "stop_price": 90, "exit_price": 110, "gross_r": 2, "overnight_dir": "UNKNOWN" }])


def test_owner_reference_close_policy_uses_new_york_dst_not_month_guessing(tmp_path):
    path = tmp_path / "daily.csv"
    path.write_text("Date,Price\n2026-01-02,100\n2026-06-02,101\n")
    closes = load_daily_closes(path, owner_release_policy=True)
    assert closes.available_at.iloc[0].strftime("%H:%M") == "03:30"
    assert closes.available_at.iloc[1].strftime("%H:%M") == "02:30"
    assert closes.availability_basis.iloc[0].startswith("OWNER_WORK_ORDER")
