# MCX revised Phase-1 interim submission

This archive is INTERIM: no eligible replay segment, trade export, or formal edge verdict exists. See reports/PREDIXA_MCX_PHASE1_REVISED_FINAL_REPORT.md.
