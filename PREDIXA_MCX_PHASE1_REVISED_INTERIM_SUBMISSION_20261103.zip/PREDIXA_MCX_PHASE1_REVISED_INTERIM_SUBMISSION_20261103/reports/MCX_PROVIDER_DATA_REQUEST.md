# MCX provider data request

## Purpose

Supply the missing evidence required to complete MCX Phase-1 Tasks 2–4: verified roll reconstruction, clean realized-R export, and OOS edge reproduction. The requested data is for offline historical research only; it does not authorize MCX PAPER, REAL, broker orders, or strategy activation.

## Research window and format

- Window: **03-Nov-2025 through 02-Nov-2026**, inclusive (or the owner-approved replacement window).
- Resolution: 60-minute raw dated-contract OHLCV; ISO-8601 timestamps with timezone and explicit candle timestamp convention (start/end).
- Required fields: exact exchange symbol, provider symbol/scrip/instrument ID, underlying variant, exchange, contract expiry, contract listing/effective interval where available, open/high/low/close/volume, open interest when available, retrieval/request metadata, and immutable source-response hash.
- No continuous/stitched/adjusted series may substitute for raw dated-contract bars.

## Required contract families (never merge variants)

| Family | Exact variants required | Coverage requirement |
|---|---|---|
| GOLD | GOLD, GOLDM, GOLDGUINEA, and any separately mapped active variant | Each dated contract active in the research window, including adjacent monthly contracts and overlap near every roll. |
| SILVER | SILVER, SILVERM, and any separately mapped variant | Same. |
| NATGAS | NATGAS, NATGASM, NATGASMINI | Same. |
| CRUDEOIL | CRUDEOIL, CRUDEOILM | Same. Existing AUG/OCT-2026 evidence is partial and does not replace the full sequence. |
| ZINC | ZINC, ZINCMINI | Same. |

For every contract, include the first/last raw timestamp and enough simultaneous outgoing/incoming observations around the roll decision to calculate the documented adjustment from actual prices. Supply omitted or unavailable contracts explicitly as `NO_DATA` with the provider error/status.

## Additional required evidence

1. Point-in-time historical contract master snapshots or equivalent listing/effective intervals; a current master is not sufficient.
2. Official MCX trading-session/holiday/special-session calendar for the window, including seasonal close-time changes and expiry shifts.
3. The approved roll-selection rule and adjustment method/version. The existing candidate (additive, three verified sessions before expiry) is not owner-approved.
4. Approved fixed IS/OOS split date and selected universe for Task 4.
5. Provider response/error evidence for expired-contract API availability. One FYERS September 2026 response is quarantined because its 24-Aug-2026 09:00 IST bar has `high < open`; it must be corrected at source, not repaired locally.

## Current verified evidence

- FYERS `MCX:CRUDEOILM26AUGFUT`: 03-Aug-2026 to 19-Aug-2026, response-hash verified.
- FYERS `MCX:CRUDEOILM26OCTFUT`: dated raw sidecar, 22-May-2026 to 08-Oct-2026; original provider response body was not retained.
- These sources overlap and support a **provisional arithmetic diagnostic only**. They do not establish historical contract-selection intervals or an approved roll.

## Provider-support message

> Please provide/read-enable historical MCX expired-futures retrieval for the listed exact commodity variants for 03-Nov-2025 through 02-Nov-2026. For each dated contract, we require 60-minute raw OHLCV, exact provider instrument identifier, listing/effective interval, expiry date, request metadata and raw response hash. Please include adjacent-contract overlap around each expiry and an official MCX trading-session/holiday calendar. We cannot use continuous or stitched data for executable historical attribution. Please also investigate the invalid FYERS `MCX:CRUDEOILM26SEPFUT` 60-minute candle at 2026-08-24 09:00 IST (`open=8357`, `high=8224`, `low=8195`, `close=8206`).
