# PREDIXA MCX revised Phase-1 test results

## Scoped MCX regression — PASS

Command:

```bash
/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q \
  tests/test_mcx_historical_data_audit.py \
  tests/test_mcx_provisional_roll_diagnostic.py \
  tests/test_mcx_within_contract_replay.py \
  tests/test_mcx_historical_session_calendar.py \
  tests/test_mcx_oi_roll_boundaries.py \
  tests/test_mcx_overnight_direction.py \
  tests/test_mcx_contract_roll_adjustment.py \
  tests/test_mcx_clean_realized_r_export.py \
  tests/test_mcx_phase1_edge_validation.py \
  tests/test_mcx_e1_session_boundary.py \
  tests/test_mcx_remediation_guardrails.py
```

Result: **127 passed, 7 warnings, exit 0**.

The warnings are existing SQLAlchemy/Pydantic/FYERS dependency deprecations; no MCX test failed. `py_compile` passed for the revised modules and exporter.

## Repository-wide pytest collection — not an offline-valid suite

Command: `/home/ispeck/anaconda3/envs/finpro/bin/python -m pytest -q`

Result: **20 collection errors, 8 warnings, exit nonzero**. This command is not a valid repository-wide offline regression command because its default collection includes tests/modules that initiate external MySQL (`192.168.1.16`) and websocket connections, requires the absent optional `cv2` dependency, and imports duplicate test basenames from `PREDIXA_Futures_Option3_Submission/` and `tests/`.

No retry with relaxed guards was performed: doing so would either need network/database access or alter test collection outside the MCX workstream. The passing scoped suite is the valid evidence for this change.
