# PREDIXA MCX Phase-1 revised final report

## Conclusion

**INTERIM / NOT EVALUABLE FOR EDGE ACCEPTANCE.** The revised within-contract segmentation, fail-closed session model, OI crossover evidence handling and as-of overlay infrastructure are implemented. No segment has the official session and executable OI/SK-switch evidence required for replay; no strategy replay, realized-R export, or OOS decision was produced.

## Historical calendar

- Calendar output covers 2023-01-01 through 2026-12-31 in Asia/Kolkata.
- It records work-order references MCX/TRD/068/2026, 550/2026 and 590/2026, including the 8-Nov-2026 executable Muhurat interval (14:20–15:30 IST).
- Official circular source records for every replay date were not available locally; `OFFICIAL_VERIFIED` dates: 0. Therefore no weekday is assumed tradeable.

## Contract boundaries and OI

- Captured dated-contract OI sources: 2; strict observed OI crossovers: 1.
- The observed CRUDEOILM Aug→Sep crossover is provisional: OI publication availability time is unknown and the SK continuous switching schedule is undocumented. It cannot assign an executable historic boundary.
- No dated OI pair coverage was found for GOLDM, SILVERM, NATGASMINI or ZINCMINI.

## Eligibility and replay

| Variant | Segments | Eligible | Source rows | Exclusions |
|---|---:|---:|---:|---|
| GOLDM | 9 | 0 | 6089 | UNVERIFIED_CONTRACT_WINDOW:3, UNVERIFIED_SESSION:6 |
| SILVERM | 6 | 0 | 6089 | UNVERIFIED_CONTRACT_WINDOW:3, UNVERIFIED_SESSION:3 |
| NATGASMINI | 12 | 0 | 3581 | UNVERIFIED_CONTRACT_WINDOW:3, UNVERIFIED_SESSION:9 |
| CRUDEOILM | 16 | 0 | 6113 | UNVERIFIED_CONTRACT_WINDOW:4, UNVERIFIED_SESSION:12 |
| ZINCMINI | 12 | 0 | 19776 | UNVERIFIED_CONTRACT_WINDOW:3, UNVERIFIED_SESSION:9 |

No sd_engine replay was executed because eligibility is zero. This is **NOT_RUN**, not a claim that the strategy generated zero BUY signals. No authoritative or provisional `mcx_trade_export.csv` exists.

## International overnight overlay

- XAU, WTI and NATURAL_GAS_USD have local date/price series from 2023-05-01 to 2026-09-24; XAG only covers 2026-08-24 to 2026-09-24. ZINCMINI has no configured reference.
- The module implements the owner-supplied 17:00 America/New_York release convention with DST-aware conversion, but the provider close/availability convention is unverified. Any resulting tag remains owner-policy-labelled, not provider-verified.

## Formal acceptance

`PREDIXA_MCX_EDGE_ACCEPTANCE_SPEC` and its approved split/universe/cost configuration were not present in the workspace. Consequently SW/SW/4 and UP/SW/3 are `NOT_EVALUABLE`; `edge_repro_check.py` was not run against fixtures or empty data.

## Minimum external inputs to unblock

1. Dated official MCX calendar/circular manifest for every used 2025–2026 exchange date, including holidays, partial days and effective closes.
2. Dated-contract OI pair history plus OI publication availability timestamps, and SK's corresponding continuous-contract switch schedule (or an approved alternate boundary manifest), for each variant.
3. Frozen acceptance spec: split, universe, costs, sample/statistical gates and approval/hash.
4. Provider metadata establishing international daily-close identity and availability, or explicit acceptance of the labelled owner-policy overlay.

## Safety

MCX PAPER = OFF. MCX REAL = OFF. No strategy was enabled or altered by this research run.
