# PREDIXA MCX Phase-1 revised within-contract implementation

## Scope

The 02-Nov-2026 revised methodology was implemented as a separate research-admissibility layer. It uses local continuous SK-style data only inside independently bounded contract-local windows; it neither resumes FYERS expired-contract collection nor uses continuous-series back-adjustment.

The named revised workbook and `PREDIXA_MCX_EDGE_ACCEPTANCE_SPEC` were not found anywhere under `/home/ispeck`. This implementation records the owner instruction supplied in the task as the attestation reference and does not invent any missing frozen acceptance threshold, split, holiday, or close-time rule.

## Implementation

- `within_contract_replay.py` inventories local processed/latest continuous files, discovers local expiry labels, emits one source-isolated segment per interval/timeframe, attaches E1 session ids, and prevents first/unknown contract windows from becoming eligible.
- It records `ORIGINAL_SOURCE_CLASSIFICATION`, owner-attestation reference, boundary evidence/confidence, calendar status, and replay eligibility separately. It does not rewrite the provenance-first source audit.
- `overnight_direction.py` implements a strict as-of daily-close join. Daily date-only files are `UNKNOWN` until a verified close-availability timestamp is supplied.
- `within_contract_export.py` defines and validates the revised 15-column BUY-only schema, including `overnight_dir`, while reconciling `gross_r` from actual exit price.

## Data and segmentation result

The generated manifest contains 55 segments:

| Family | Variant | Segments | Replay eligible |
|---|---|---:|---:|
| GOLD | GOLDM | 9 | 0 |
| SILVER | SILVERM | 6 | 0 |
| NATGAS | NATGASMINI | 12 | 0 |
| CRUDEOIL | CRUDEOILM | 16 | 0 |
| ZINC | ZINCMINI | 12 | 0 |

Available strategy input files include GOLDM daily/240m/60m, CRUDEOILM weekly/daily/240m/60m, NATGASMINI daily/240m/120m, SILVERM daily/240m/60m, and ZINCMINI daily/240m/60m. Variants remain separate.

All emitted segments are currently excluded before setup discovery because the project has no verified historical MCX session/holiday/special-session calendar. The revised session module now records the supplied 2026 DST/Muhurat references but keeps them owner-work-order-attested rather than incorrectly treating them as complete official historical coverage. Leading windows before the first local expiry label are additionally excluded as `UNVERIFIED_CONTRACT_WINDOW`.

## International data

Local files were found:

- XAU: 01-May-2023 to 24-Sep-2026.
- XAG: 24-Aug-2026 to 24-Sep-2026.
- WTI: 01-May-2023 to 24-Sep-2026.
- NATURAL_GAS_USD: 01-May-2023 to 24-Sep-2026.

They contain dates but no verified close publication time/timezone convention. The implementation supports the owner-supplied 17:00 America/New_York convention with DST-aware conversion, but labels it as an owner policy until the provider's daily-bar convention is evidenced. The strict default intentionally emits `UNKNOWN`.

## OI boundary evidence

Two captured FYERS dated-contract OI series yield one strict CRUDEOILM August-to-September 2026 crossover observed at 2026-08-17 09:00 IST (19,270 versus 19,149 OI). It is deliberately **not** an executable boundary: OI publication availability time is unknown, the September response is quarantined for later OHLC failures, and the SK continuous-series switch schedule is undocumented. No pair OI coverage is present for GOLDM, SILVERM, NATGASMINI or ZINCMINI.

## Replay/export/validation outcome

No `sd_engine` strategy replay was executed on ineligible data. Therefore:

- no clean or provisional `mcx_trade_export.csv` was produced;
- no realized-R, net expectancy, IS/OOS, SW/SW/4, or UP/SW/3 result exists;
- `edge_repro_check.py` was not run on empty, fixture, or invalid evidence;
- the frozen-spec result is `NOT_EVALUABLE`.

## Required inputs to unblock empirical replay

1. A traceable MCX calendar covering the selected research period: trading sessions, holidays, special sessions, and date-specific close times.
2. The approved date-based contract boundary/roll schedule for each listed local variant, including a boundary before each desired leading segment.
3. The actual frozen acceptance spec and independent approved split/configuration file.
4. Verified international daily-close availability timestamps (or a documented source convention) for directional tags.

These are revised-methodology inputs, not requests to restart expired-contract retrieval.

## Safety

MCX PAPER and MCX REAL remain OFF. No broker/order/scanner, NSEFO, or NSE_CASH behavior changed.
