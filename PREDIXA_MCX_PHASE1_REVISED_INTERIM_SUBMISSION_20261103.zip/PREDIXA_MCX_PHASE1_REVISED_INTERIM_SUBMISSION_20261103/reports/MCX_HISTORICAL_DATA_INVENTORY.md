# MCX historical data inventory

## Classification

- VERIFIED_RAW: 5
- VERIFIED_CONTINUOUS: 2
- UNVERIFIED: 499
- INVALID: 2

## Family readiness

| Family | Sources | Verified raw sources | Roll-ready? |
|---|---:|---:|---|
| GOLD | 139 | 2 | NO — no verified adjacent raw overlap, policy, and calendar |
| SILVER | 120 | 0 | NO — no verified adjacent raw overlap, policy, and calendar |
| NATGAS | 72 | 0 | NO — no verified adjacent raw overlap, policy, and calendar |
| CRUDEOIL | 60 | 3 | NO — no verified adjacent raw overlap, policy, and calendar |
| ZINC | 56 | 0 | NO — no verified adjacent raw overlap, policy, and calendar |

## Verified dated-contract coverage

| Family | Variant | Contract | Provider | Raw coverage (IST) | Attribution limitation |
|---|---|---|---|---|---|
| CRUDEOIL | CRUDEOILM | MCX:CRUDEOILM26AUGFUT | FYERS | 2026-08-03T09:00:00+05:30 to 2026-08-19T23:00:00+05:30 | OBSERVED_CANDLE_COVERAGE_ONLY; listing date unknown |
| CRUDEOIL | CRUDEOILM | MCX:CRUDEOILM26OCTFUT | FYERS | 2026-05-22T21:00:00+05:30 to 2026-10-08T23:00:00+05:30 | OBSERVED_CANDLE_COVERAGE_ONLY; listing date unknown |
| GOLD | GOLD | 495213 | Sharekhan | 2026-09-01T09:59:10+05:30 to 2026-10-08T23:30:59+05:30 | OBSERVED_CANDLE_COVERAGE_ONLY; listing date unknown |
| GOLD | GOLD | MCX:GOLD26DECFUT | FYERS | 2026-05-14T10:00:00+05:30 to 2026-10-08T23:00:00+05:30 | OBSERVED_CANDLE_COVERAGE_ONLY; listing date unknown |
| CRUDEOIL | CRUDEOILM | 569901 | Sharekhan | 2026-09-01T09:59:05+05:30 to 2026-10-08T23:30:59+05:30 | OBSERVED_CANDLE_COVERAGE_ONLY; listing date unknown |

## CRUDEOILM provisional overlap

FYERS cache contains exact dated `MCX:CRUDEOILM26AUGFUT` and `MCX:CRUDEOILM26OCTFUT` raw sources with observed 60-minute overlap from 03-Aug-2026 to 19-Aug-2026. `audit.mcx_futures_backtest.provisional_roll_diagnostic` validates the additive arithmetic using observed outgoing close and incoming open. Its output is deliberately `PROVISIONAL_ROLL_ARITHMETIC_ONLY`: neither the point-in-time selection interval, official session calendar, nor roll-policy approval is available. It cannot feed Task 3 or Task 4.

## Interpretation

Only sources with explicit provider instrument, raw mode, and expiry metadata enter `mcx_contract_registry.csv`. Their registry interval is observed raw-candle coverage, not an inferred listing date. Filename-only archives remain UNVERIFIED and cannot be used for executable fills or roll reconstruction.

No authoritative `mcx_trade_export.csv` was created.
