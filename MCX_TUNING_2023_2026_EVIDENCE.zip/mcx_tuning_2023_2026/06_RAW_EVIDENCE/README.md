# Raw evidence references

Primary SQLite database (not copied into the ZIP): `audit/mcx_futures_backtest/storage/mcx_phase_a_full_2023_2026.sqlite`
Primary run ID: `5b7f93676ec2476c94962dcf5d059aa3`
Duplicate baseline run ID: `768e35d231634dafb8ef2e3351d19715`

The expected 36-run manifest was not found. No substitute manifest was created.
The cost schedule used by the analysis is copied at `audit/derivatives_tuning/cost_schedules/fyers_derivatives_2023_2026.json` in the repository and referenced by the reproducibility command.
