# MCX Tuning Executive Summary

## Decision

**NO_LOCK_INCOMPLETE_SWEEP**

The completed work is a baseline-only replay. No 36-run tuning manifest or candidate runs were found, so no parameter lock or C7/C8 sign-off is allowed.

## Evidence

- Primary run: `5b7f93676ec2476c94962dcf5d059aa3`
- Duplicate baseline: `768e35d231634dafb8ef2e3351d19715`
- Tasks: 87,364; completed: 86,887; failed: 477
- Scans/signals/eligible/entered/resolved: 86,887 / 24,439 / 5,975 / 4,277 / 4,234
- Quantity mode: `PAPER_QTY_10`
- Tests: tuning tests 6 passed; MCX policy test unavailable in the current environment
- Production files modified: **NONE**

The result is useful as a baseline evidence set, but insufficient for tuning selection or production lock.
