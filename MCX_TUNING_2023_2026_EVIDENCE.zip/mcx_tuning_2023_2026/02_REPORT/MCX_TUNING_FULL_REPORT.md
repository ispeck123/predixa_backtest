# MCX Tuning 2023–2026 Full Report

## 1. Executive Summary

The supplied primary run `5b7f93676ec2476c94962dcf5d059aa3` is a completed current-production MCX replay, but the evidence is **BASELINE_ONLY**. The expected 36-run sweep manifest is absent, and the database contains no candidate override runs. The correct decision is **NO_LOCK_INCOMPLETE_SWEEP**. No C7/C8 tuning sign-off or production parameter lock is permitted.

The run completed with 86,887 of 87,364 tasks and 477 failed tasks. It produced 86,887 scans, 24,439 signals, 5,975 eligible setup rows, 4,277 entered BUY trades, and 4,234 resolved trades.

## 2. Scope and Work-Order Compliance

- Primary run: `5b7f93676ec2476c94962dcf5d059aa3`
- Duplicate baseline record: `768e35d231634dafb8ef2e3351d19715`
- Database: `audit/mcx_futures_backtest/storage/mcx_phase_a_full_2023_2026.sqlite`
- Historical window: 2023-01-01 through 2026-10-22
- Symbols: CRUDEOILM, GOLDM, NATGASMINI, SILVER, SILVERM
- Strategy TFs: TF4 primary (`daily / two_forty / sixty`), TF3 conditional/report-only (`daily / two_forty / one_twenty`)
- MCX decision cut: BUY only in persisted trade rows; unexpected SELL rows: 0
- Tuning classification: BASELINE_ONLY; no complete or partial candidate sweep was found

## 3. Production-Code Non-Modification Statement

No production files under `scripts/` were modified for this report. No live Config defaults, production strategy logic, completed database, or raw market data was changed. Analysis used existing centralized SQLite results only.

## 4. MCX Universe, TF Mapping, and Data Coverage

The source inventory was read from `data/indian_commodity_data/latest_data_csv/`. Coverage is unequal by symbol:

```text
    symbol  strategy_tf  earliest_timestamp    latest_timestamp  complete_stack
 CRUDEOILM            3 2023-03-03T05:30:00 2026-10-22T15:00:00            True
 CRUDEOILM            4 2023-03-03T05:30:00 2026-10-22T15:00:00            True
     GOLDM            3 2020-01-01T05:30:00 2026-10-22T15:00:00            True
     GOLDM            4 2020-01-01T05:30:00 2026-10-22T15:00:00            True
NATGASMINI            3 2023-03-14T05:30:00 2026-10-22T15:00:00            True
NATGASMINI            4 2023-03-14T05:30:00 2026-10-22T15:00:00            True
    SILVER            3 2020-01-01T05:30:00 2026-10-22T15:00:00            True
    SILVER            4 2020-01-01T05:30:00 2026-10-22T15:00:00            True
   SILVERM            3 2020-01-01T05:30:00 2026-10-22T15:00:00            True
   SILVERM            4 2020-01-01T05:30:00 2026-10-22T15:00:00            True
```

All source files are classified as `STITCHED_OR_CONTINUOUS`; contract-live attribution is calendar-inferred, not exchange-verified historical contract identity.

## 5. Data / Stitched-Series Limitations

- The replay uses stitched/continuous files under expiry-labelled filenames.
- Contract labels are calendar-inferred and do not prove historical listed-contract identity.
- The production API does not expose a hard roll-boundary reset to the replay.
- The run has 477 failed tasks. Top error categories are retained in `run_data_quality.csv` and the SQLite `errors` table:

```text
exception_type                          exception_message   n
  RuntimeError single positional indexer is out-of-bounds 219
  RuntimeError        E-TF has 6 bars, minimum 7 required 213
  RuntimeError        E-TF has 1 bars, minimum 7 required 207
  RuntimeError        E-TF has 4 bars, minimum 7 required 207
  RuntimeError        E-TF has 5 bars, minimum 7 required 207
  RuntimeError        E-TF has 3 bars, minimum 7 required 201
  RuntimeError        E-TF has 2 bars, minimum 7 required 177
```

- The failed tasks prevent treating the run as a perfect complete-history replay.

## 6. Run Inventory and Completion Evidence

The primary run is `COMPLETED` at coordinator level, with 477 failed tasks recorded. The second run record is an identical baseline configuration, not a tuning candidate.

| item | count |
|---|---:|
| tasks | 87,364 |
| completed | 86,887 |
| failed | 477 |
| scans | 86,887 |
| signals | 24,439 |
| eligible setups | 5,975 |
| entered trades | 4,277 |
| resolved WIN/LOSS | 4,234 |
| unresolved | 43 |

Scan coverage is `2023-01-02T09:00:00` through `2026-10-22T15:00:00`. Trade entries range from `2023-02-17T09:00:00` through `2026-10-22T11:00:00`.

## 7. Decision Cut

The persisted trade set contains only BUY trades. TF4 is the primary cell; TF3 is conditional/report-only. The analysis command excluded SELL rows using `--side BUY`; the raw evidence still checks for unexpected SELL rows and found none.

## 8. Baseline/Control Results

The run configuration contains an empty `engine_overrides` object. Its effective control values are the production defaults: target 0.5, overlap 0.5, strict stop false, proximity tier false. It is not a candidate run.

Pooled 0-bps full-cost paper results:

```text
partition    n  win_rate  M1_give_back_rate  M2_wick_out_rate  gross_R_mean  net_R_mean_full_cost  full_cost_mean_inr
       IS 2153    0.2643             0.5417               0.0      0.227049              0.164561          121.154843
      OOS 2081    0.3349             0.4429               0.0      0.389625              0.341128          138.095965
   POOLED 4234    0.2990             0.4956               0.0      0.306955              0.251343          129.481360
```

## 9. Embed Sweep Results

No EMBED candidate runs exist in the database or manifest. No EMBED comparison or lock decision can be made.

## 10. Proximity Sweep Results

No PROXIMITY candidate runs exist in the database or manifest. No PROXIMITY comparison or lock decision can be made.

## 11. IS/OOS Results

The single-run analysis uses the persisted trade-entry midpoint `2024-09-03 23:00:00`. IS/OOS and pooled metrics are in `03_METRICS/tuning_metrics.csv`. These are baseline descriptive results only; they do not establish candidate confirmation.

## 12. M1 Give-Back and M2 Wick-Out

M1/M2 values are reported in the SQLite-derived metrics. No candidate-versus-control reduction can be computed because no candidate exists. M2 is zero in the available summary output and should not be interpreted as proof that the failure mode is absent outside the persisted fields.

## 13. Full-Cost Paper Net-R Methodology

The statutory audit schedule is `FYERS_DERIVATIVES_2023_2026_V1`. No reviewed lot-size file was supplied, so the quantity mode is **PAPER_QTY_10**. Full-cost Net-R and mean INR cost are paper-quantity estimates, not contract-accurate brokerage economics. The 0/2/5 bps sensitivity columns remain separate from the full-cost estimate.

## 14. Per-Cell Results

The complete IS/OOS/pooled cell table is in `03_METRICS/per_cell_is_oos_metrics.csv`. It includes TF3 and TF4 regime cells, trade count, win rate, M1, M2, gross R, paper full-cost Net-R, mean cost INR, and bps sensitivity.

## 15. Pass-Arithmetic Evaluation

The exact work-order arithmetic was **not applied** because the prerequisite 36-run set is absent. There is no evidence to test 3pp M1/M2 reductions, pooled Net-R non-regression, cell drawdown limits, OOS sign flips, or tie-break rules.

## 16. Recommended Lock Decision

**NO_LOCK_INCOMPLETE_SWEEP.** Retain the baseline as an audit result. Do not promote any parameter combination because no candidate comparison exists.

## 17. C7/C8 Status

- C7: **NOT SIGNED OFF** — no complete baseline-plus-candidate arithmetic evidence.
- C8: **NOT SIGNED OFF** — no completed tuning sweep and no production lock evidence.

## 18. Limitations

The primary limitations are the absent 36-run manifest/candidates, 477 failed replay tasks, stitched/calendar-inferred contract identity, paper quantity economics, no OI-4 complete cost-stack implementation, unequal symbol histories, unresolved trades, and the unavailable MCX policy-test gate in the current environment.

## 19. Reproducibility Instructions

Use the commands in `05_REPRODUCIBILITY/commands_executed.txt`. They analyze existing SQLite only. The database path and run IDs are recorded in `run_configurations.json` and `06_RAW_EVIDENCE/README.md`. No replay command is included.
