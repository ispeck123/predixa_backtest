# MCX Tuning 2023–2026 Evidence Package

This package is **BASELINE_ONLY**. It was generated from the existing centralized SQLite database without rerunning replay tasks. Read the executive summary first, then the full report and metrics. No 36-run sweep manifest was found, so no tuning lock is recommended.
