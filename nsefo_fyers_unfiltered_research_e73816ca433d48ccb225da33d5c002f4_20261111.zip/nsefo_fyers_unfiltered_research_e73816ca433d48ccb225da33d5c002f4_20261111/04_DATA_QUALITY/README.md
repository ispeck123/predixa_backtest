# Derived valid-source research view

This directory is a copy-only research view. Original FYERS CSVs were not changed. Any physical source frame with an invalid OHLC envelope was excluded in full; late-starting but structurally valid histories were retained.
