# NSEFO FYERS Research Submission

Run `e73816ca433d48ccb225da33d5c002f4` completed with `240,765` completed tasks and `5,826` bounded-retry exclusions. SQLite integrity is `ok`.

Resolved performance: **48,658** trades, **26.05%** win rate, **4,670.14R** gross realized R, and **1.1298** R profit factor.

## Scope and limitations

This is `UNFILTERED_RESEARCH_BASELINE` evidence. It uses the research-only gate bypass and does **not** claim historical expiry attribution, expiry-minus-five entry cutoff, expiry-minus-three TIME_EXIT, or verified MCX E1 compliance. `gross_r` is normalized realized R, not cash P&L. Contract multipliers, lot-size history, brokerage, exchange charges, slippage, and net cash P&L are not persisted by this runner and are not fabricated in this submission. The sequential drawdown is an informational ordering of resolved trade R by exit time, not a portfolio-equity calculation for overlapping positions.
